using ReportIA.Web.Components;
using ReportIA.Web.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.Configure<ReportApiOptions>(builder.Configuration.GetSection(ReportApiOptions.SectionName));

// Without a configured BaseUrl we fall back to the mock so the UI works out of the box.
var apiOptions = builder.Configuration.GetSection(ReportApiOptions.SectionName).Get<ReportApiOptions>() ?? new ReportApiOptions();
if (string.IsNullOrWhiteSpace(apiOptions.BaseUrl))
{
    builder.Services.AddScoped<IReportApiClient, MockReportApiClient>();
}
else
{
    builder.Services.AddHttpClient<IReportApiClient, HttpReportApiClient>(client =>
    {
        client.BaseAddress = new Uri(apiOptions.BaseUrl);
        client.Timeout = TimeSpan.FromSeconds(60);
    });
}

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();