// Chart.js is loaded globally (see App.razor).
const PALETTE = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'];

const charts = new WeakMap();

const withAlpha = (hex, alpha) => {
    const value = parseInt(hex.slice(1), 16);
    return `rgba(${(value >> 16) & 255}, ${(value >> 8) & 255}, ${value & 255}, ${alpha})`;
};

const colorAt = (index) => PALETTE[index % PALETTE.length];

const barStyle = (ds, i) => ({ ...ds, backgroundColor: withAlpha(colorAt(i), 0.85), borderRadius: 4 });

const lineStyle = (ds, i) => ({
    ...ds,
    borderColor: colorAt(i),
    backgroundColor: withAlpha(colorAt(i), 0.15),
    tension: 0.3,
    pointRadius: 3
});

// Per chart type: the Chart.js type, how each dataset is styled, and extra options.
const CHART_TYPES = {
    bar: {
        type: 'bar',
        style: barStyle,
        options: { scales: { y: { beginAtZero: true } } }
    },
    line: {
        type: 'line',
        style: (ds, i) => ({ ...lineStyle(ds, i), fill: true }),
        options: { scales: { y: { beginAtZero: true } } }
    },
    pie: {
        type: 'pie',
        // Pie colors each slice instead of each dataset.
        style: (ds) => ({ ...ds, backgroundColor: ds.data.map((_, i) => colorAt(i)), borderWidth: 1 })
    },
    stackedBar: {
        type: 'bar',
        style: barStyle,
        options: { scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true } } }
    },
    combo: {
        type: 'bar',
        // Each dataset declares its own type; default: first one is bars, the rest lines.
        style: (ds, i) => {
            const kind = ds.type ?? (i === 0 ? 'bar' : 'line');
            return kind === 'line'
                ? { ...lineStyle(ds, i), type: 'line', fill: false, borderWidth: 3 }
                : { ...barStyle(ds, i), type: 'bar' };
        },
        options: { scales: { y: { beginAtZero: true } } }
    }
};

const buildOptions = (title, extra = {}) => ({
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        title: { display: !!title, text: title, font: { size: 15 } },
        legend: { position: 'bottom' }
    },
    ...extra
});

export function renderChart(canvas, type, graphData) {
    destroyChart(canvas);

    const definition = CHART_TYPES[type];
    if (!definition) throw new Error(`Unsupported chart type: ${type}`);

    const chart = new Chart(canvas, {
        type: definition.type,
        data: {
            labels: graphData.labels,
            datasets: graphData.datasets.map(definition.style)
        },
        options: buildOptions(graphData.title, definition.options)
    });

    charts.set(canvas, chart);
}

export function destroyChart(canvas) {
    charts.get(canvas)?.destroy();
    charts.delete(canvas);
}
