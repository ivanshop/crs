export function scrollIntoView(element) {
    element?.scrollIntoView({ behavior: 'smooth', block: 'end' });
}
