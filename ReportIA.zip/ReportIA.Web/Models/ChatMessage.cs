namespace ReportIA.Web.Models;

public enum ChatRole
{
    User,
    Assistant,
    Error
}

/// <summary>A single bubble in the conversation. <see cref="Chart"/> is set only for assistant replies with a graph.</summary>
public sealed record ChatMessage(ChatRole Role, string? Text = null, ChartPayload? Chart = null);

/// <summary>A validated, ready-to-render chart.</summary>
public sealed record ChartPayload(ChartType Type, GraphData Data);
