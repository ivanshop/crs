namespace ReportIA.Web.Models;

/// <summary>
/// Chart types the UI knows how to render. The API sends them in camelCase
/// (bar, line, pie, stackedBar, combo); matching is case-insensitive.
/// </summary>
public enum ChartType
{
    Bar,
    Line,
    Pie,
    StackedBar,
    /// <summary>Bars plus lines in the same chart (e.g. actual vs target). See <see cref="GraphDataset.Type"/>.</summary>
    Combo
}
