namespace ReportIA.Web.Models;

/// <summary>Payload sent to the API: <c>{ "prompt": "..." }</c>.</summary>
public sealed record ChartQueryRequest(string Prompt);

/// <summary>
/// Expected API response, e.g.
/// <c>{ "message": "...", "graphType": "bar", "graphData": { "title": "...", "labels": [...], "datasets": [{ "label": "...", "data": [...] }] } }</c>
/// </summary>
public sealed class ChartQueryResponse
{
    /// <summary>Optional text shown above the chart.</summary>
    public string? Message { get; init; }

    /// <summary>Case-insensitive name of a <see cref="ChartType"/> (bar, line, pie, stackedBar, combo).</summary>
    public string? GraphType { get; init; }

    public GraphData? GraphData { get; init; }
}

public sealed class GraphData
{
    public string? Title { get; init; }
    public List<string> Labels { get; init; } = [];
    public List<GraphDataset> Datasets { get; init; } = [];
}

public sealed class GraphDataset
{
    public string Label { get; init; } = string.Empty;

    /// <summary>Only used by <c>combo</c> charts: "bar" or "line". Defaults to bar for the first dataset and line for the rest.</summary>
    public string? Type { get; init; }

    public List<double> Data { get; init; } = [];
}
