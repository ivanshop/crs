using ReportIA.Web.Models;

namespace ReportIA.Web.Services;

public static class ChartPayloadFactory
{
    /// <summary>Validates the API response. Returns null when it carries no chart; throws when the chart is malformed.</summary>
    public static ChartPayload? TryCreate(ChartQueryResponse response)
    {
        if (string.IsNullOrWhiteSpace(response.GraphType) && response.GraphData is null)
            return null;

        if (!Enum.TryParse<ChartType>(response.GraphType, ignoreCase: true, out var type) || !Enum.IsDefined(type))
            throw new InvalidOperationException(
                $"Unsupported graphType '{response.GraphType}'. Supported: {string.Join(", ", Enum.GetNames<ChartType>())}.");

        var data = response.GraphData
                   ?? throw new InvalidOperationException("The response has a graphType but no graphData.");

        if (data.Labels.Count == 0 || data.Datasets.Count == 0)
            throw new InvalidOperationException("graphData must include labels and at least one dataset.");

        if (data.Datasets.Any(d => d.Data.Count != data.Labels.Count))
            throw new InvalidOperationException("Every dataset must have one value per label.");

        return new ChartPayload(type, data);
    }
}
