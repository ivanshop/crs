using ReportIA.Web.Models;

namespace ReportIA.Web.Services;

public interface IReportApiClient
{
    Task<ChartQueryResponse> QueryAsync(string prompt, CancellationToken cancellationToken = default);
}
