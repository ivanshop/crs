namespace ReportIA.Web.Services;

public sealed class ReportApiOptions
{
    public const string SectionName = "ReportApi";

    /// <summary>API base URL. When empty, the built-in mock client is used.</summary>
    public string BaseUrl { get; set; } = string.Empty;

    /// <summary>Relative path of the query endpoint (POST).</summary>
    public string QueryPath { get; set; } = "api/query";
}
