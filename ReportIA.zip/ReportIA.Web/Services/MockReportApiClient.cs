using ReportIA.Web.Models;

namespace ReportIA.Web.Services;

/// <summary>
/// Development stand-in used while <c>ReportApi:BaseUrl</c> is empty.
/// Picks a chart type from keywords in the prompt (Spanish or English).
/// </summary>
public sealed class MockReportApiClient : IReportApiClient
{
    private static readonly string[] Months = ["Ene", "Feb", "Mar", "Abr", "May", "Jun"];

    public async Task<ChartQueryResponse> QueryAsync(string prompt, CancellationToken cancellationToken = default)
    {
        await Task.Delay(700, cancellationToken); // simulates network latency

        var text = prompt.ToLowerInvariant();

        if (ContainsAny(text, "meta", "objetivo", "target", "combo", "vs"))
            return Build("combo", "Ventas reales vs meta (miles USD)", Months,
                "Combinado de ventas reales (barras) contra la meta (línea).",
                ("Real", "bar", [120, 135, 128, 160, 172, 190]),
                ("Meta", "line", [130, 135, 140, 150, 165, 180]));

        if (ContainsAny(text, "gasto", "área", "area", "trimestre", "apilad", "stacked", "composición", "composicion"))
            return Build("stackedBar", "Gastos por área y trimestre (miles USD)", ["T1", "T2", "T3", "T4"],
                "Gastos por área, apilados por trimestre.",
                ("Operaciones", null, [220, 240, 235, 260]),
                ("Marketing", null, [90, 110, 95, 130]),
                ("TI", null, [70, 65, 80, 85]),
                ("RR. HH.", null, [50, 52, 55, 58]));

        if (ContainsAny(text, "participación", "participacion", "línea de negocio", "linea de negocio", "porcentaje", "distribución", "distribucion", "pie", "torta", "pastel", "share"))
            return Build("pie", "Participación por línea de negocio", ["Retail", "Mayorista", "Online", "Servicios", "Otros"],
                "Participación de cada línea de negocio sobre el total de ventas.",
                ("Ventas", null, [38, 24, 21, 12, 5]));

        if (ContainsAny(text, "tendencia", "ingreso", "evolución", "evolucion", "mensual", "line", "linea", "línea", "trend"))
            return Build("line", "Ingresos mensuales (miles USD)", Months,
                "Evolución de ingresos del primer semestre, comparada con el año anterior.",
                ("2025", null, [120, 135, 128, 160, 172, 190]),
                ("2026", null, [140, 150, 165, 180, 205, 230]));

        return Build("bar", "Ventas por sucursal (miles USD)", ["Lima", "Arequipa", "Cusco", "Trujillo", "Piura"],
            "Ventas acumuladas por sucursal.",
            ("Ventas", null, [320, 210, 180, 150, 90]));
    }

    private static bool ContainsAny(string text, params string[] keywords) => keywords.Any(text.Contains);

    private static ChartQueryResponse Build(
        string type, string title, IEnumerable<string> labels, string message,
        params (string Label, string? Type, double[] Data)[] datasets) => new()
    {
        Message = $"{message} (datos simulados)",
        GraphType = type,
        GraphData = new GraphData
        {
            Title = title,
            Labels = [.. labels],
            Datasets = [.. datasets.Select(d => new GraphDataset { Label = d.Label, Type = d.Type, Data = [.. d.Data] })]
        }
    };
}
