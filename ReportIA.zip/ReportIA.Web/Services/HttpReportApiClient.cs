using Microsoft.Extensions.Options;
using ReportIA.Web.Models;

namespace ReportIA.Web.Services;

/// <summary>Sends the prompt to the configured API and deserializes its response.</summary>
public sealed class HttpReportApiClient(HttpClient httpClient, IOptions<ReportApiOptions> options) : IReportApiClient
{
    public async Task<ChartQueryResponse> QueryAsync(string prompt, CancellationToken cancellationToken = default)
    {
        using var response = await httpClient.PostAsJsonAsync(
            options.Value.QueryPath, new ChartQueryRequest(prompt), cancellationToken);

        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<ChartQueryResponse>(cancellationToken)
               ?? throw new InvalidOperationException("The API returned an empty response.");
    }
}
