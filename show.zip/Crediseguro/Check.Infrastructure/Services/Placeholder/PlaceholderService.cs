﻿using Check.Core.Interfaces;
using Check.Core.Models.PlaceHolder;
using System.Net.Http.Json;

namespace Check.Infrastructure.Services.Placeholder;

public class PlaceholderService : IPlaceHolderService
{
    private readonly HttpClient _httpClient;

    public PlaceholderService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }
    public async Task<Post> GetPostById(string postId)
    {
        var response = await _httpClient.GetFromJsonAsync<Post>($"/posts/{postId}");
        return response!;
    }
}
