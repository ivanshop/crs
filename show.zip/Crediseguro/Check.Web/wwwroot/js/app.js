﻿document.addEventListener("DOMContentLoaded", function () {
    const phrases = [
        { title: "Él es Check", subtitle: "Tu nuevo partner en seguros" },
        { title: "Seguro y rápido", subtitle: "Cotiza en segundos" },
        { title: "Siempre contigo", subtitle: "Tu aliado digital de confianza" }
    ];

    const container = document.getElementById("phrases");
    let i = 0;

    function switchPhrases() {
        gsap.to(container, {
            opacity: 0,
            duration: 0.5,
            onComplete: () => {
                container.innerHTML = `
                  <h1 class="mb-1"><b>${phrases[i].title}</b></h1>
                  <h2 class="mb-0">${phrases[i].subtitle}</h2>
                `;
                gsap.to(container, { opacity: 1, duration: 0.5 });
                i = (i + 1) % phrases.length;
            }
        });
    }

    setInterval(switchPhrases, 5000);
});