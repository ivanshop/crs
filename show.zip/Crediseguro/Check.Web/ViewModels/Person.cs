﻿using System.ComponentModel.DataAnnotations;

namespace Check.Web.Models;

public class Person : IValidatableObject
{
    [Required]
    [StringLength(16, ErrorMessage = "El límite máximo de caracteres son 16")]
    public string DocumentNumber { get; set; }

    [StringLength(16, ErrorMessage = "El límite máximo de caracteres son 16")]
    public string DocumentComplement { get; set; }

    [StringLength(2, MinimumLength = 2, ErrorMessage = "El complemento tiene 2 caracteres.")]
    public string DocumentExtension { get; set; }

    [Required]
    [StringLength(30, ErrorMessage = "El límite máximo de caracteres son 30")]
    public string Names { get; set; }

    [StringLength(30, ErrorMessage = "El límite máximo de caracteres son 30")]
    public string PaternalLastName { get; set; }

    [StringLength(30, ErrorMessage = "El límite máximo de caracteres son 30")]
    public string MaternalLastName { get; set; }

    [Required]
    public DateTime BirthDay { get; set; }

    [Required(ErrorMessage = "Debe seleccionar un país.")]
    public string ResidenceCity { get; set; }

    [Range(1, 100000, ErrorMessage = "Accommodation invalid (1-100000).")]
    public int MaximumAccommodation { get; set; }

    [Required]
    [Range(typeof(bool), "true", "true", ErrorMessage = "This form disallows unapproved ships.")]
    public bool IsValidatedDesign { get; set; }


    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (string.IsNullOrWhiteSpace(PaternalLastName) && string.IsNullOrWhiteSpace(MaternalLastName))
        {
            yield return new ValidationResult("Debe ingresar al menos el Apellido Paterno o el Apellido Materno.", new[] { nameof(PaternalLastName), nameof(MaternalLastName) });
        }
    }
}
