﻿using Check.Web.Models;

namespace Check.Web.Components.Pages.Yape;

public partial class Counter
{
    private int currentCount = 0;
    private Person ensured = new Person();
    private List<string> cities = new List<string>();
    private bool _menuSet = false;

    protected override void OnInitialized()
    {
        cities = new List<string>
        {
            "La Paz",
            "Cochabamba",
            "Santa Cruz",
            "Sucre",
            "Beni"
        };
        base.OnInitialized();
    }

    private void IncrementCount()
    {
        currentCount++;
    }

    private void HandleValidSubmit()
    {
        // Process/Save the data
    }
}
