﻿using Check.Core.Interfaces;
using Check.Core.Models.PlaceHolder;
using Microsoft.AspNetCore.Components;

namespace Check.Web.Components.Pages.Yape;

public partial class Welcome
{
    [Inject]
    private IPlaceHolderService placeHolderService { get; set; }

    [Inject]
    protected NavigationManager navigator { get; set; }

    private Post post = new Post();

    protected override async Task OnInitializedAsync()
    {
        post = await placeHolderService.GetPostById("2");
    }

    private void TakeEnsurance()
    {
        navigator.NavigateTo("/yape/ensurance");
    }
}
