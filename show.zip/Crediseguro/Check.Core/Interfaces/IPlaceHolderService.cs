﻿using Check.Core.Models.PlaceHolder;

namespace Check.Core.Interfaces;

public interface IPlaceHolderService
{
    Task<Post> GetPostById(string postId);
}
