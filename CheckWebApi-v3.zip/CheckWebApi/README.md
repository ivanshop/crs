# Check Web API

API de la plataforma de venta digital de seguros de Crediseguro S.A. (.NET 10, PostgreSQL 18).

## Estructura

| Proyecto | Contenido |
|---|---|
| `Check.Domain` | Entidades, value objects y domain services. Sin dependencias. |
| `Check.Application` | Un caso de uso por acción (`ExecuteAsync`) y los puertos (interfaces). Sin CQRS ni mediador. |
| `Check.Infrastructure` | EF Core + Npgsql (DB-first, sin migraciones), cifrado, JWT, clientes externos y Service Bus (SDK oficial, sin MassTransit). |
| `Check.Api` | Controllers, autenticación, límites de uso, ProblemDetails, logs con ZLogger y servicios en segundo plano. |

El código está en inglés; los mensajes de error, éxito y log, en español.

## Puesta en marcha

1. Ejecutar `check-web-api.sql` en la base `check` (PostgreSQL 18).
2. Revisar `src/Check.Api/appsettings.Development.json` (cadena de conexión y llaves de desarrollo).
3. `dotnet run --project src/Check.Api` y probar con `src/Check.Api/Check.Api.http`.

Con `ExternalServices:UseFakes = true` no se llama a ningún servicio real:

- SEGIP: un CI que termina en `000` no coincide.
- AMLC: un CI que empieza con `999` figura en listas.
- Archivo Negativo: un CI que empieza con `888` figura en el archivo.
- OTP: el código se escribe en el log. Banco: devuelve un QR de texto. LlamitAI: no reconoce campos.

## Flujo de contratación

| Paso | Endpoint | Estado resultante |
|---|---|---|
| Leer carnet (opcional) | `POST /api/v1/identity-readings` | — |
| Iniciar | `POST /api/v1/contracts` | `Started` (devuelve el token del contrato) |
| Validar SEGIP, AMLC, AN | `POST /contracts/{id}/screening` | `Validated` o `Rejected` |
| Beneficiarios y PEP | `PUT /contracts/{id}/declarations` | `Declared` |
| Aceptaciones | `PUT /contracts/{id}/consents` | `Declared` |
| OTP | `POST /contracts/{id}/otp` y `/otp/verification` | `Verified` |
| QR | `POST /contracts/{id}/qr` | `PendingPayment` |
| Aviso del Banco | `POST /api/v1/payments/notifications` | `Active` (número de póliza y cobertura) |

Al activarse el contrato se registran tres eventos en `sales.contract_events`: `PaymentConfirmed` (bitácora),
`WelcomeEmail` y `ClientFolder` (se publican en Service Bus). El consumidor confirma con
`POST /api/v1/internal/events/{eventId}/confirmation`.

## Convenios corporativos (backoffice)

Un ejecutivo negocia con una empresa (`core.companies`) una prima y unos días de cobertura para un plan a cambio
de un cupo de personas (`offer.agreements`). El convenio nace en `Draft`; lo aprueba un usuario **distinto** de quien
lo negoció (regla de cuatro ojos en el dominio y en la restricción `agreements_four_eyes_ck`) y pasa a `Active`.
Los empleados contratan enviando `agreementCode` en `POST /api/v1/contracts`: el contrato congela la prima y los días
del convenio. El cupo cuenta contratos pagados (`Active` o `Expired`).

| Acción | Endpoint |
|---|---|
| Registrar empresa | `POST /api/v1/internal/companies` |
| Negociar convenio | `POST /api/v1/internal/agreements` |
| Aprobar / cerrar | `POST /internal/agreements/{code}/approval` y `/closure` |
| Consultar (backoffice) | `GET /internal/agreements/{code}` |
| Consultar (web) | `GET /api/v1/agreements/{code}` |

En desarrollo, `check-backoffice` negocia y `check-gerencia` aprueba (ambos con rol `internal`).

## Pruebas

- `tests/Check.UnitTests`: 63 pruebas xUnit del dominio, una clase por sprint (`dotnet test`).
- `tests/load/check-load.k6.js`: prueba de carga y estrés con k6 (`k6 run -e BASE=http://localhost:5080 -e CLIENT_SECRET=... tests/load/check-load.k6.js`).
- El catálogo se guarda en caché `Flow:CatalogCacheSeconds` segundos (60 por defecto).

## Seguridad

- **Tokens JWT**: de cliente (`web`, `internal`) y de contrato (solo sirve para ese contrato).
- **Aviso del Banco**: sin JWT; se valida la firma HMAC-SHA256 del cuerpo (`BankCallback:Secret`, cabecera `X-Signature`) y, si se configura, la IP de origen.
- **Datos personales**: cifrados con AES-256-GCM en columnas `bytea`; el documento se busca por HMAC.
- **Límites de uso** por IP en token, inicio de contrato, validaciones, OTP y lectura del carnet.
- Detrás de un proxy, configurar `ForwardedHeaders:KnownProxies` para que la IP del cliente sea la real.

## Logs (ZLogger)

Todo se configura en `appsettings.json`:

- `Logging:LogLevel`: nivel por categoría (estándar de .NET).
- `Logs:Console` y `Logs:File`: activar o desactivar cada destino y elegir `Json` o `Text`.
- `Logs:File`: carpeta, prefijo, rotación (`Day`, `Hour`…) y tamaño máximo por archivo.
- `Logs:Fields`: nombres de los campos. Por defecto son los de Elastic Common Schema
  (`@timestamp`, `log.level`, `log.logger`, `message`, `error`, `service.name`), así Filebeat o Elastic Agent
  indexan cada línea sin transformarla.

Cada línea es un objeto JSON. Los parámetros de los mensajes (`ContractId`, `PlanCode`…) y los del scope
(`traceId`, `clientIp`) salen como campos propios y se pueden filtrar. No se registran cuerpos de solicitudes.

## Supuestos por confirmar

Los contratos de estos servicios no están definidos; están aislados en un solo archivo cada uno:

- **OTP, Banco (QR) y LlamitAI**: rutas y nombres de campos en `Infrastructure/ExternalServices/FlowClients.cs`.
- **Aviso del Banco**: cuerpo `{ qrPaymentId, transactionId, amount, currency, paidAt? }` en `PaymentNotificationRequest`.
- **Fotos del carnet**: se guardan en una carpeta local (`Storage:IdentityImagesPath`); para Azure Blob basta otra implementación de `IIdentityImageStore`.
