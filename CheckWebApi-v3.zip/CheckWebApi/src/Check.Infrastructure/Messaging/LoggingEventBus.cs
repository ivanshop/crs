using Check.Application.Abstractions;
using Microsoft.Extensions.Logging;

namespace Check.Infrastructure.Messaging;

/// <summary>Sin Service Bus configurado (desarrollo): el mensaje solo se escribe en el log.</summary>
internal sealed class LoggingEventBus(ILogger<LoggingEventBus> logger) : IEventBus
{
    public Task PublishAsync(string queue, Guid messageId, string subject, string payloadJson, CancellationToken ct)
    {
        logger.LogWarning("[SIN SERVICE BUS] Mensaje {MessageId} ({Asunto}) para la cola {Cola}: {Payload}", messageId, subject, queue, payloadJson);
        return Task.CompletedTask;
    }
}
