using System.Collections.Concurrent;
using Azure.Messaging.ServiceBus;
using Check.Application.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Check.Infrastructure.Messaging;

/// <summary>
/// Publica en colas de Azure Service Bus con el SDK oficial (sin MassTransit).
/// MessageId = id del evento: con detección de duplicados en la cola, un reenvío no se procesa dos veces.
/// </summary>
internal sealed class ServiceBusEventBus(ServiceBusClient client) : IEventBus, IAsyncDisposable
{
    private readonly ConcurrentDictionary<string, ServiceBusSender> _senders = new();

    public Task PublishAsync(string queue, Guid messageId, string subject, string payloadJson, CancellationToken ct)
    {
        var sender = _senders.GetOrAdd(queue, client.CreateSender);
        var message = new ServiceBusMessage(BinaryData.FromString(payloadJson))
        {
            MessageId = messageId.ToString(),
            Subject = subject,
            ContentType = "application/json"
        };
        return sender.SendMessageAsync(message, ct);
    }

    public async ValueTask DisposeAsync()
    {
        foreach (var sender in _senders.Values) await sender.DisposeAsync();
    }
}

internal static class ServiceBusRegistration
{
    public static void AddServiceBusEventBus(this IServiceCollection services, string connectionString)
    {
        services.AddSingleton(new ServiceBusClient(connectionString));
        services.AddSingleton<IEventBus, ServiceBusEventBus>();
    }
}
