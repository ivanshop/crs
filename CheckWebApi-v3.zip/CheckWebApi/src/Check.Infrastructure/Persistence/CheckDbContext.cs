using Check.Application.Abstractions;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Offer;
using Check.Domain.Payments;
using Check.Domain.People;
using Check.Infrastructure.Persistence.Models;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence;

/// <summary>
/// Mapea la BD existente (script SQL); no se usan migraciones.
/// Las columnas de auditoría son propiedades sombra: el Domain no las conoce.
/// </summary>
public sealed class CheckDbContext(
    DbContextOptions<CheckDbContext> options,
    FieldEncryptor encryptor,
    ICurrentUser currentUser,
    TimeProvider time) : DbContext(options), IUnitOfWork
{
    internal const string CreatedBy = "CreatedBy";
    internal const string CreatedAt = "CreatedAt";
    internal const string UpdatedBy = "UpdatedBy";
    internal const string UpdatedAt = "UpdatedAt";
    internal const string IsActive = "IsActive";

    // core
    public DbSet<Country> Countries => Set<Country>();
    public DbSet<CatalogEntry> Catalogs => Set<CatalogEntry>();
    public DbSet<Relationship> Relationships => Set<Relationship>();
    public DbSet<Person> People => Set<Person>();
    public DbSet<Agency> Agencies => Set<Agency>();
    public DbSet<Agent> Agents => Set<Agent>();
    public DbSet<ScreeningException> ScreeningExceptions => Set<ScreeningException>();
    // offer
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Plan> Plans => Set<Plan>();
    public DbSet<Faq> Faqs => Set<Faq>();
    public DbSet<ContractFieldDefinition> ContractFieldDefinitions => Set<ContractFieldDefinition>();
    public DbSet<PlanParameter> PlanParameters => Set<PlanParameter>();
    public DbSet<Company> Companies => Set<Company>();
    public DbSet<Agreement> Agreements => Set<Agreement>();
    public DbSet<ParameterDefinition> ParameterDefinitions => Set<ParameterDefinition>();
    // sales
    public DbSet<Contract> Contracts => Set<Contract>();
    public DbSet<OtpChallenge> OtpChallenges => Set<OtpChallenge>();
    public DbSet<QrPayment> QrPayments => Set<QrPayment>();
    public DbSet<PaymentNotification> PaymentNotifications => Set<PaymentNotification>();
    public DbSet<ContractEvent> ContractEvents => Set<ContractEvent>();
    // compliance y feedback
    public DbSet<Screening> Screenings => Set<Screening>();
    public DbSet<PepDeclaration> PepDeclarations => Set<PepDeclaration>();
    public DbSet<IdentityReading> IdentityReadings => Set<IdentityReading>();
    public DbSet<SurveyResponse> SurveyResponses => Set<SurveyResponse>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // El encriptador es singleton: el modelo (cacheado) puede capturarlo en los converters.
        Configurations.CoreConfiguration.Apply(modelBuilder, encryptor);
        Configurations.OfferConfiguration.Apply(modelBuilder);
        Configurations.SalesConfiguration.Apply(modelBuilder, encryptor);
        Configurations.ComplianceConfiguration.Apply(modelBuilder, encryptor);
        modelBuilder.UseSnakeCaseColumns();
    }

    Task IUnitOfWork.SaveChangesAsync(CancellationToken ct) => SaveChangesAsync(ct);

    public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken ct = default)
    {
        StampAudit();
        return base.SaveChangesAsync(acceptAllChangesOnSuccess, ct);
    }

    private void StampAudit()
    {
        var now = time.GetUtcNow();
        foreach (var entry in ChangeTracker.Entries())
        {
            var metadata = entry.Metadata;
            if (entry.State == EntityState.Added)
            {
                if (metadata.FindProperty(CreatedBy) is not null) entry.Property(CreatedBy).CurrentValue = currentUser.Name;
                if (metadata.FindProperty(CreatedAt) is { } createdAt && createdAt.IsShadowProperty())
                    entry.Property(CreatedAt).CurrentValue = now;
                if (metadata.FindProperty(IsActive) is { } isActive && isActive.IsShadowProperty())
                    entry.Property(IsActive).CurrentValue = true;
            }
            else if (entry.State == EntityState.Modified)
            {
                if (metadata.FindProperty(UpdatedBy) is not null) entry.Property(UpdatedBy).CurrentValue = currentUser.Name;
                if (metadata.FindProperty(UpdatedAt) is not null) entry.Property(UpdatedAt).CurrentValue = now;
            }
        }
    }
}
