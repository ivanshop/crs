using Check.Domain.Compliance;
using Check.Domain.People;
using Check.Infrastructure.Persistence.Models;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Configurations;

/// <summary>Esquema core: países, catálogos, parentescos, personas, agencias, agentes y lista blanca.</summary>
internal static class CoreConfiguration
{
    public static void Apply(ModelBuilder b, FieldEncryptor encryptor)
    {
        b.Entity<Country>(e => { e.ToTable("countries", "core"); e.HasAudit(); });
        b.Entity<CatalogEntry>(e => { e.ToTable("catalogs", "core"); e.HasAudit(); });
        b.Entity<Relationship>(e => { e.ToTable("relationships", "core"); e.HasAudit(); });

        b.Entity<Person>(e =>
        {
            e.ToTable("people", "core");
            e.Property(p => p.Id).ValueGeneratedNever();
            e.Property(p => p.DocumentType).HasConversion<string>();
            e.Property(p => p.Gender).HasConversion<string>();
            e.Property(p => p.DocumentNumber).IsEncrypted(encryptor);
            e.Property(p => p.DocumentComplement!).IsEncrypted(encryptor);
            e.Property(p => p.Names).IsEncrypted(encryptor);
            e.Property(p => p.PaternalLastname!).IsEncrypted(encryptor);
            e.Property(p => p.MaternalLastname!).IsEncrypted(encryptor);
            e.Property(p => p.Birthdate).IsEncrypted(encryptor);
            e.Property(p => p.Address!).IsEncrypted(encryptor);
            e.Property(p => p.Cellphone!).IsEncrypted(encryptor);
            e.Property(p => p.Email!).IsEncrypted(encryptor);
            e.Ignore(p => p.FullName);
            e.HasAudit();
        });

        b.Entity<Agency>(e =>
        {
            e.ToTable("agencies", "core");
            e.Property(a => a.Id).ValueGeneratedNever();
            e.HasAudit();
        });

        b.Entity<Agent>(e =>
        {
            e.ToTable("agents", "core");
            e.Property(a => a.Id).ValueGeneratedNever();
            e.HasOne(a => a.Person).WithMany().HasForeignKey(a => a.PersonId);
            e.HasOne(a => a.Agency).WithMany().HasForeignKey(a => a.AgencyId);
            e.HasAudit();
        });

        b.Entity<ScreeningException>(e =>
        {
            e.ToTable("screening_exceptions", "core");
            e.HasOne<Person>().WithMany().HasForeignKey(x => x.PersonId);
            e.Property(x => x.Provider).HasConversion<string>();
            e.HasAudit();
        });
    }
}
