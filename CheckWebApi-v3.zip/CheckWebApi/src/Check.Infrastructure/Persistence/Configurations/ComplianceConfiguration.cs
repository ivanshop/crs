using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.People;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Configurations;

internal static class ComplianceConfiguration
{
    public static void Apply(ModelBuilder b, FieldEncryptor encryptor)
    {
        b.Entity<Screening>(e =>
        {
            e.ToTable("screenings", "compliance");
            // Sin navegación en el Domain, pero EF necesita conocer la clave foránea para ordenar los INSERT.
            e.HasOne<Person>().WithMany().HasForeignKey(x => x.PersonId);
            e.HasOne<Contract>().WithMany().HasForeignKey(x => x.ContractId);
            e.HasOne<ScreeningException>().WithMany().HasForeignKey(x => x.ExceptionId);
            e.Property(x => x.Provider).HasConversion<string>();
            e.Property(x => x.Detail).HasColumnType("jsonb");
            e.Property(x => x.RawResponse).HasColumnType("jsonb");
            e.HasMany(x => x.Items).WithOne().HasForeignKey(i => i.ScreeningId);
            e.Ignore(x => x.IsApproved);
            e.HasAudit(full: false);
        });

        b.Entity<ScreeningItem>(e => { e.ToTable("screening_items", "compliance"); e.HasAudit(full: false); });

        b.Entity<PepDeclaration>(e =>
        {
            e.ToTable("pep_declarations", "compliance");
            e.HasOne<Person>().WithMany().HasForeignKey(x => x.PersonId);
            e.HasMany(x => x.Relatives).WithOne().HasForeignKey(r => r.PepDeclarationId);
            e.HasMany(x => x.Partners).WithOne().HasForeignKey(p => p.PepDeclarationId);
            e.HasAudit();
        });

        b.Entity<PepRelative>(e =>
        {
            e.ToTable("pep_relatives", "compliance");
            e.Property(x => x.Names).IsEncrypted(encryptor);
            e.Property(x => x.PaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.MaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.DocumentNumber!).IsEncrypted(encryptor);
            e.HasAudit();
        });

        b.Entity<PepPartner>(e =>
        {
            e.ToTable("pep_partners", "compliance");
            e.Property(x => x.Names).IsEncrypted(encryptor);
            e.Property(x => x.PaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.MaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.DocumentNumber!).IsEncrypted(encryptor);
            e.HasAudit();
        });

        b.Entity<IdentityReading>(e =>
        {
            e.ToTable("identity_readings", "compliance");
            e.HasOne<Person>().WithMany().HasForeignKey(x => x.PersonId);
            e.HasOne<Contract>().WithMany().HasForeignKey(x => x.ContractId);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.Status).HasConversion<string>();
            e.Property(x => x.ExtractedText!).IsEncrypted(encryptor);
            e.Property(x => x.ExtractedFields!).IsEncrypted(encryptor);
            e.Property(x => x.RawResponse!).IsEncrypted(encryptor);
            e.Property(x => x.Differences).HasColumnType("jsonb");
            e.Property(x => x.ClientIp!).IsInet();
            e.HasAudit();
        });
    }
}
