using Check.Domain.Offer;
using Check.Infrastructure.Persistence.Models;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Configurations;

internal static class OfferConfiguration
{
    public static void Apply(ModelBuilder b)
    {
        b.Entity<Product>(e =>
        {
            e.ToTable("products", "offer");
            e.HasMany(p => p.Plans).WithOne(p => p.Product).HasForeignKey(p => p.ProductId);
            e.HasAudit();
        });

        b.Entity<Plan>(e =>
        {
            e.ToTable("plans", "offer");
            e.HasMany(p => p.Coverages).WithOne().HasForeignKey(c => c.PlanId);
            e.HasMany(p => p.Assistances).WithOne().HasForeignKey(a => a.PlanId);
            e.HasMany(p => p.Exclusions).WithOne().HasForeignKey(x => x.PlanId);
            e.HasAudit();
        });

        b.Entity<Coverage>(e => { e.ToTable("coverages", "offer"); e.HasAudit(); });
        b.Entity<Assistance>(e => { e.ToTable("assistances", "offer"); e.HasAudit(); });
        b.Entity<Exclusion>(e => { e.ToTable("exclusions", "offer"); e.HasAudit(); });
        b.Entity<Faq>(e => { e.ToTable("faqs", "offer"); e.HasAudit(); });

        b.Entity<ContractFieldDefinition>(e =>
        {
            e.ToTable("contract_field_definitions", "offer");
            e.Property(x => x.DataType).HasConversion<string>();
            e.HasAudit();
        });

        b.Entity<Company>(e =>
        {
            e.ToTable("companies", "core");
            e.Property(x => x.Id).ValueGeneratedNever();
            e.HasAudit();
        });

        b.Entity<Agreement>(e =>
        {
            e.ToTable("agreements", "offer");
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.Status).HasConversion<string>();
            e.HasOne(x => x.Company).WithMany().HasForeignKey(x => x.CompanyId);
            e.HasOne(x => x.Plan).WithMany().HasForeignKey(x => x.PlanId);
            e.Ignore(x => x.Terms);
            e.HasAudit();
        });

        b.Entity<ParameterDefinition>(e => { e.ToTable("parameter_definitions", "offer"); e.HasAudit(); });

        b.Entity<PlanParameter>(e =>
        {
            e.ToTable("plan_parameters", "offer");
            e.HasOne(x => x.Definition).WithMany().HasForeignKey(x => x.DefinitionId);
            e.HasAudit();
        });
    }
}
