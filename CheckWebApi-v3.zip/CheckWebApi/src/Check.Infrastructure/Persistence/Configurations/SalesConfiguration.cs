using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Offer;
using Check.Domain.Payments;
using Check.Domain.People;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Configurations;

/// <summary>Esquemas sales y feedback: el contrato y todo lo que cuelga de él.</summary>
internal static class SalesConfiguration
{
    public static void Apply(ModelBuilder b, FieldEncryptor encryptor)
    {
        b.Entity<Contract>(e =>
        {
            e.ToTable("contracts", "sales");
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.Status).HasConversion<string>();
            e.Property(x => x.Channel).HasConversion<string>();
            e.Property(x => x.ClientIp!).IsInet();
            e.HasOne<Agreement>().WithMany().HasForeignKey(x => x.AgreementId);
            e.HasMany(x => x.Parties).WithOne().HasForeignKey(p => p.ContractId);
            e.HasMany(x => x.Details).WithOne().HasForeignKey(d => d.ContractId);
            e.HasMany(x => x.Beneficiaries).WithOne().HasForeignKey(x => x.ContractId);
            e.HasMany(x => x.Consents).WithOne().HasForeignKey(c => c.ContractId);
            e.Ignore(x => x.Contractor);
            e.Ignore(x => x.Insured);
            e.Ignore(x => x.Agent);
            e.Ignore(x => x.Customers);
            e.Ignore(x => x.HasRequiredConsents);
            e.HasAudit();
        });

        b.Entity<ContractParty>(e =>
        {
            e.ToTable("contract_parties", "sales");
            e.Property(x => x.Role).HasConversion<string>();
            e.Property(x => x.Gender).HasConversion<string>();
            e.HasOne(x => x.Person).WithMany().HasForeignKey(x => x.PersonId);
            e.HasOne<Agent>().WithMany().HasForeignKey(x => x.AgentId);
            e.HasOne<PepDeclaration>().WithMany().HasForeignKey(x => x.PepDeclarationId);
            e.Property(x => x.DocumentNumber).IsEncrypted(encryptor);
            e.Property(x => x.DocumentComplement!).IsEncrypted(encryptor);
            e.Property(x => x.Names).IsEncrypted(encryptor);
            e.Property(x => x.PaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.MaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.Birthdate).IsEncrypted(encryptor);
            e.Property(x => x.Address!).IsEncrypted(encryptor);
            e.Property(x => x.Cellphone!).IsEncrypted(encryptor);
            e.Property(x => x.Email!).IsEncrypted(encryptor);
            e.Ignore(x => x.FullName);
            e.HasAudit();
        });

        b.Entity<ContractDetail>(e => { e.ToTable("contract_details", "sales"); e.HasAudit(); });

        b.Entity<Beneficiary>(e =>
        {
            e.ToTable("beneficiaries", "sales");
            e.Property(x => x.DocumentNumber!).IsEncrypted(encryptor);
            e.Property(x => x.Names).IsEncrypted(encryptor);
            e.Property(x => x.PaternalLastname!).IsEncrypted(encryptor);
            e.Property(x => x.MaternalLastname!).IsEncrypted(encryptor);
            e.HasAudit();
        });

        b.Entity<Consent>(e =>
        {
            e.ToTable("consents", "sales");
            e.Property(x => x.DocumentType).HasConversion<string>();
            e.Property(x => x.IpAddress).IsInet();
            e.HasOne(x => x.ContractParty).WithMany().HasForeignKey(x => x.ContractPartyId);
            e.HasOne<OtpChallenge>().WithMany().HasForeignKey(x => x.OtpChallengeId);
            e.HasAudit();
        });

        b.Entity<OtpChallenge>(e =>
        {
            e.ToTable("otp_challenges", "sales");
            e.Property(x => x.Channel).HasConversion<string>();
            // Sin navegación en el Domain, pero EF necesita conocer la clave foránea para ordenar los INSERT.
            e.HasOne<Contract>().WithMany().HasForeignKey(x => x.ContractId);
            e.Property(x => x.Destination).IsEncrypted(encryptor);
            e.HasAudit();
        });

        b.Entity<QrPayment>(e =>
        {
            e.ToTable("qr_payments", "sales");
            e.HasOne<Contract>().WithMany().HasForeignKey(x => x.ContractId);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.Status).HasConversion<string>();
            e.HasAudit();
        });

        b.Entity<PaymentNotification>(e =>
        {
            e.ToTable("payment_notifications", "sales");
            e.HasOne<QrPayment>().WithMany().HasForeignKey(x => x.QrPaymentId);
            e.Property(x => x.Result).HasConversion<string>();
            e.Property(x => x.RawPayload).HasColumnType("jsonb");
            e.HasAudit(full: false);
        });

        b.Entity<ContractEvent>(e =>
        {
            e.ToTable("contract_events", "sales");
            e.HasOne<Contract>().WithMany().HasForeignKey(x => x.ContractId);
            e.Property(x => x.Id).ValueGeneratedNever();
            e.Property(x => x.Type).HasConversion<string>();
            e.Property(x => x.Status).HasConversion<string>();
            e.Property(x => x.Payload).HasColumnType("jsonb");
            e.HasAudit(hasIsActive: false);
        });

        b.Entity<SurveyResponse>(e =>
        {
            e.ToTable("survey_responses", "feedback");
            e.HasOne<Contract>().WithMany().HasForeignKey(x => x.ContractId);
            e.Property(x => x.Type).HasConversion<string>();
            e.HasAudit(full: false);
        });
    }
}
