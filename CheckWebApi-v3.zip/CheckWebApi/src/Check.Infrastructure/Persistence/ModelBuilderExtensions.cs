using System.Net;
using System.Text;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Check.Infrastructure.Persistence;

internal static class ModelBuilderExtensions
{
    /// <summary>Columnas en snake_case (PlanId → plan_id) salvo las configuradas a mano.</summary>
    public static void UseSnakeCaseColumns(this ModelBuilder modelBuilder)
    {
        foreach (var entity in modelBuilder.Model.GetEntityTypes())
        foreach (var property in entity.GetProperties())
        {
            if (property.GetColumnName() == property.Name)
                property.SetColumnName(ToSnakeCase(property.Name));
        }
    }

    public static string ToSnakeCase(string name)
    {
        var sb = new StringBuilder(name.Length + 8);
        for (var i = 0; i < name.Length; i++)
        {
            var c = name[i];
            if (char.IsUpper(c) && i > 0) sb.Append('_');
            sb.Append(char.ToLowerInvariant(c));
        }
        return sb.ToString();
    }

    /// <summary>created_by, created_at y, si <paramref name="full"/>, updated_by, updated_at, is_active.</summary>
    public static EntityTypeBuilder<T> HasAudit<T>(this EntityTypeBuilder<T> builder, bool full = true, bool hasIsActive = true) where T : class
    {
        builder.Property<string>(CheckDbContext.CreatedBy);
        if (builder.Metadata.FindProperty(CheckDbContext.CreatedAt) is null)
            builder.Property<DateTimeOffset>(CheckDbContext.CreatedAt);
        if (!full) return builder;

        builder.Property<string?>(CheckDbContext.UpdatedBy);
        builder.Property<DateTimeOffset?>(CheckDbContext.UpdatedAt);
        if (hasIsActive && builder.Metadata.FindProperty(CheckDbContext.IsActive) is null)
        {
            builder.Property<bool>(CheckDbContext.IsActive);
            builder.HasQueryFilter(e => EF.Property<bool>(e, CheckDbContext.IsActive));
        }
        return builder;
    }

    /// <summary>Texto cifrado en bytea. EF no pasa nulls al converter: un null queda null.</summary>
    public static PropertyBuilder<string> IsEncrypted(this PropertyBuilder<string> builder, FieldEncryptor encryptor) =>
        builder.HasConversion(new ValueConverter<string, byte[]>(v => encryptor.Encrypt(v), v => encryptor.Decrypt(v)))
               .HasColumnType("bytea");

    public static PropertyBuilder<DateOnly> IsEncrypted(this PropertyBuilder<DateOnly> builder, FieldEncryptor encryptor) =>
        builder.HasConversion(new ValueConverter<DateOnly, byte[]>(
                    v => encryptor.Encrypt(v.ToString("yyyy-MM-dd")),
                    v => DateOnly.ParseExact(encryptor.Decrypt(v), "yyyy-MM-dd")))
               .HasColumnType("bytea");

    /// <summary>Fecha opcional cifrada (el agente no registra fecha de nacimiento).</summary>
    public static PropertyBuilder<DateOnly?> IsEncrypted(this PropertyBuilder<DateOnly?> builder, FieldEncryptor encryptor) =>
        builder.HasConversion(new ValueConverter<DateOnly, byte[]>(
                    v => encryptor.Encrypt(v.ToString("yyyy-MM-dd")),
                    v => DateOnly.ParseExact(encryptor.Decrypt(v), "yyyy-MM-dd")))
               .HasColumnType("bytea");

    public static PropertyBuilder<string> IsInet(this PropertyBuilder<string> builder) =>
        builder.HasConversion(new ValueConverter<string, IPAddress>(v => IPAddress.Parse(v), v => v.ToString()))
               .HasColumnType("inet");
}
