using Check.Application.Abstractions;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Offer;
using Check.Domain.Payments;
using Check.Domain.People;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

internal sealed class PlanRepository(CheckDbContext db) : IPlanRepository
{
    public Task<Plan?> GetActiveByCodeAsync(string code, CancellationToken ct) =>
        db.Plans.Include(p => p.Product).FirstOrDefaultAsync(p => p.Code == code && p.IsActive && p.Product.IsActive, ct);

    public Task<Plan?> GetByIdAsync(long id, CancellationToken ct) =>
        db.Plans.Include(p => p.Product).FirstOrDefaultAsync(p => p.Id == id, ct);

    public async Task<IReadOnlyList<ContractFieldDefinition>> GetFieldsAsync(long productId, CancellationToken ct) =>
        await db.ContractFieldDefinitions.Where(f => f.ProductId == productId && f.IsActive).OrderBy(f => f.SortOrder).ToListAsync(ct);
}

internal sealed class PersonRepository(CheckDbContext db) : IPersonRepository
{
    public Task<Person?> GetByDocumentHashAsync(byte[] documentHash, CancellationToken ct) =>
        db.People.FirstOrDefaultAsync(p => p.DocumentHash == documentHash, ct);

    public void Add(Person person) => db.People.Add(person);

    public Task<Agency?> GetAgencyByCodeAsync(string code, CancellationToken ct) =>
        db.Agencies.FirstOrDefaultAsync(a => a.Code == code, ct);

    public Task<Agent?> GetAgentByCodeAsync(string code, CancellationToken ct) =>
        db.Agents.Include(a => a.Person).Include(a => a.Agency).FirstOrDefaultAsync(a => a.Code == code, ct);

    public void Add(Agency agency) => db.Agencies.Add(agency);
    public void Add(Agent agent) => db.Agents.Add(agent);
}

internal sealed class ContractRepository(CheckDbContext db) : IContractRepository
{
    public Task<Contract?> GetAsync(Guid id, CancellationToken ct) =>
        db.Contracts
            .Include(c => c.Parties).ThenInclude(p => p.Person)
            .Include(c => c.Details)
            .Include(c => c.Beneficiaries)
            .Include(c => c.Consents)
            .AsSplitQuery()
            .FirstOrDefaultAsync(c => c.Id == id, ct);

    public void Add(Contract contract) => db.Contracts.Add(contract);

    public Task<bool> HasActiveOfProductAsync(Guid insuredPersonId, long productId, DateTimeOffset now, CancellationToken ct) =>
        db.Contracts.AnyAsync(c =>
            c.Status == ContractStatus.Active && c.CoverageTo > now &&
            c.Parties.Any(p => p.Role == PartyRole.Insured && p.PersonId == insuredPersonId) &&
            db.Plans.Any(pl => pl.Id == c.PlanId && pl.ProductId == productId), ct);

    public Task<bool> SurveyExistsAsync(Guid contractId, SurveyType type, CancellationToken ct) =>
        db.SurveyResponses.AnyAsync(s => s.ContractId == contractId && s.Type == type, ct);

    public void Add(SurveyResponse survey) => db.SurveyResponses.Add(survey);
}

internal sealed class ComplianceRepository(CheckDbContext db) : IComplianceRepository
{
    public Task<bool> ScreeningsExistAsync(Guid contractId, CancellationToken ct) =>
        db.Screenings.AnyAsync(s => s.ContractId == contractId, ct);

    public async Task<IReadOnlyList<ScreeningException>> GetExceptionsAsync(Guid personId, DateOnly date, CancellationToken ct) =>
        await db.ScreeningExceptions.Where(e => e.PersonId == personId && e.ValidFrom <= date && e.ValidUntil >= date).ToListAsync(ct);

    public void Add(Screening screening) => db.Screenings.Add(screening);
    public void Add(ScreeningException exception) => db.ScreeningExceptions.Add(exception);

    public Task<PepDeclaration?> GetCurrentPepAsync(Guid personId, CancellationToken ct) =>
        db.PepDeclarations.Include(d => d.Relatives).Include(d => d.Partners).AsSplitQuery()
            .FirstOrDefaultAsync(d => d.PersonId == personId && d.SupersededAt == null, ct);

    public void Add(PepDeclaration declaration) => db.PepDeclarations.Add(declaration);

    public Task<IdentityReading?> GetReadingAsync(Guid id, CancellationToken ct) =>
        db.IdentityReadings.FirstOrDefaultAsync(r => r.Id == id, ct);

    public void Add(IdentityReading reading) => db.IdentityReadings.Add(reading);
}

internal sealed class PaymentRepository(CheckDbContext db) : IPaymentRepository
{
    public Task<OtpChallenge?> GetLatestOtpAsync(Guid contractId, CancellationToken ct) =>
        db.OtpChallenges.Where(o => o.ContractId == contractId).OrderByDescending(o => o.CreatedAt).FirstOrDefaultAsync(ct);

    public Task<int> CountOtpsAsync(Guid contractId, CancellationToken ct) =>
        db.OtpChallenges.CountAsync(o => o.ContractId == contractId, ct);

    public void Add(OtpChallenge challenge) => db.OtpChallenges.Add(challenge);

    public Task<QrPayment?> GetQrAsync(Guid id, CancellationToken ct) =>
        db.QrPayments.FirstOrDefaultAsync(q => q.Id == id, ct);

    public Task<QrPayment?> GetPendingQrAsync(Guid contractId, CancellationToken ct) =>
        db.QrPayments.FirstOrDefaultAsync(q => q.ContractId == contractId && q.Status == QrPaymentStatus.Pending, ct);

    public Task<bool> NotificationAppliedAsync(string bankTransactionId, CancellationToken ct) =>
        db.PaymentNotifications.AnyAsync(n => n.BankTransactionId == bankTransactionId && n.Result == NotificationResult.Applied, ct);

    public void Add(QrPayment payment) => db.QrPayments.Add(payment);
    public void Add(PaymentNotification notification) => db.PaymentNotifications.Add(notification);
}

internal sealed class EventRepository(CheckDbContext db) : IEventRepository
{
    public Task<ContractEvent?> GetAsync(Guid id, CancellationToken ct) =>
        db.ContractEvents.FirstOrDefaultAsync(e => e.Id == id, ct);

    public Task<ContractEvent?> GetLatestAsync(Guid contractId, ContractEventType type, CancellationToken ct) =>
        db.ContractEvents.Where(e => e.ContractId == contractId && e.Type == type).OrderByDescending(e => e.CreatedAt).FirstOrDefaultAsync(ct);

    public async Task<IReadOnlyList<ContractEvent>> GetByContractAsync(Guid contractId, CancellationToken ct) =>
        await db.ContractEvents.AsNoTracking().Where(e => e.ContractId == contractId).OrderBy(e => e.CreatedAt).ToListAsync(ct);

    public async Task<IReadOnlyList<ContractEvent>> GetDueAsync(DateTimeOffset now, int batchSize, CancellationToken ct) =>
        await db.ContractEvents
            .Where(e => e.Status == ContractEventStatus.Pending && e.NextAttemptAt <= now)
            .OrderBy(e => e.CreatedAt).Take(batchSize).ToListAsync(ct);

    public void Add(ContractEvent contractEvent) => db.ContractEvents.Add(contractEvent);
}

internal sealed class AgreementRepository(CheckDbContext db) : IAgreementRepository
{
    public Task<Company?> GetCompanyByTaxIdAsync(string taxId, CancellationToken ct) =>
        db.Companies.FirstOrDefaultAsync(c => c.TaxId == taxId, ct);

    public void Add(Company company) => db.Companies.Add(company);

    public Task<Agreement?> GetByCodeAsync(string code, CancellationToken ct) =>
        db.Agreements.Include(a => a.Company).Include(a => a.Plan).ThenInclude(p => p.Product)
            .FirstOrDefaultAsync(a => a.Code == code, ct);

    public Task<int> CountUsedAsync(Guid agreementId, CancellationToken ct) =>
        db.Contracts.CountAsync(c => c.AgreementId == agreementId &&
                                     (c.Status == ContractStatus.Active || c.Status == ContractStatus.Expired), ct);

    public void Add(Agreement agreement) => db.Agreements.Add(agreement);
}

/// <summary>Actualizaciones en bloque con ExecuteUpdate: no cargan entidades ni pasan por el Domain.</summary>
internal sealed class MaintenanceRepository(CheckDbContext db) : IMaintenanceRepository
{
    private const string System = "housekeeping";

    private static readonly ContractStatus[] InProgress =
        [ContractStatus.Started, ContractStatus.Validated, ContractStatus.Declared, ContractStatus.Verified, ContractStatus.PendingPayment];

    public Task<int> ExpireQrPaymentsAsync(DateTimeOffset now, CancellationToken ct) =>
        db.QrPayments
            .Where(q => q.Status == QrPaymentStatus.Pending && q.ExpiresAt < now)
            .ExecuteUpdateAsync(s => s
                .SetProperty(q => q.Status, QrPaymentStatus.Expired)
                .SetProperty(q => EF.Property<string?>(q, CheckDbContext.UpdatedBy), System)
                .SetProperty(q => EF.Property<DateTimeOffset?>(q, CheckDbContext.UpdatedAt), now), ct);

    public Task<int> AbandonContractsAsync(DateTimeOffset inactiveSince, CancellationToken ct) =>
        db.Contracts
            .Where(c => InProgress.Contains(c.Status) &&
                        (EF.Property<DateTimeOffset?>(c, CheckDbContext.UpdatedAt) ?? c.CreatedAt) < inactiveSince)
            .ExecuteUpdateAsync(s => s
                .SetProperty(c => c.Status, ContractStatus.Abandoned)
                .SetProperty(c => EF.Property<string?>(c, CheckDbContext.UpdatedBy), System)
                .SetProperty(c => EF.Property<DateTimeOffset?>(c, CheckDbContext.UpdatedAt), DateTimeOffset.UtcNow), ct);

    public Task<int> ExpireContractsAsync(DateTimeOffset now, CancellationToken ct) =>
        db.Contracts
            .Where(c => c.Status == ContractStatus.Active && c.CoverageTo < now)
            .ExecuteUpdateAsync(s => s
                .SetProperty(c => c.Status, ContractStatus.Expired)
                .SetProperty(c => EF.Property<string?>(c, CheckDbContext.UpdatedBy), System)
                .SetProperty(c => EF.Property<DateTimeOffset?>(c, CheckDbContext.UpdatedAt), now), ct);
}
