using Check.Application.Abstractions;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

internal sealed class CatalogQueries(CheckDbContext db) : ICatalogQueries
{
    private const string CountryTopic = "country";

    public async Task<IReadOnlyList<ProductRow>> GetActiveProductsAsync(string? productCode, CancellationToken ct)
    {
        var query = db.Products.AsNoTracking().Where(p => p.IsActive);
        if (productCode is not null) query = query.Where(p => p.Code == productCode);

        var products = await query
            .Include(p => p.Plans.Where(pl => pl.IsActive)).ThenInclude(pl => pl.Coverages.Where(c => c.IsActive))
            .Include(p => p.Plans.Where(pl => pl.IsActive)).ThenInclude(pl => pl.Assistances.Where(a => a.IsActive))
            .Include(p => p.Plans.Where(pl => pl.IsActive)).ThenInclude(pl => pl.Exclusions.Where(x => x.IsActive))
            .OrderBy(p => p.Id)
            .AsSplitQuery()
            .ToListAsync(ct);

        var productIds = products.Select(p => p.Id).ToList();
        var fields = await db.ContractFieldDefinitions.AsNoTracking()
            .Where(f => productIds.Contains(f.ProductId) && f.IsActive)
            .OrderBy(f => f.SortOrder)
            .ToListAsync(ct);

        return products.Select(p => new ProductRow(
            p.Id, p.Code, p.Name, p.Description,
            p.Plans.OrderBy(pl => pl.Id).Select(pl => new PlanRow(
                pl.Id, pl.Code, pl.Name, pl.Description,
                pl.Coverages.OrderBy(c => c.SortOrder).Select(c => new CoverageRow(c.Name, c.Type, c.InsuredAmount, c.Currency, c.Description)).ToList(),
                pl.Assistances.OrderBy(a => a.SortOrder).Select(a => new AssistanceRow(a.Name, a.Service, a.Description)).ToList(),
                pl.Exclusions.OrderBy(x => x.SortOrder).Select(x => x.Description).ToList())).ToList(),
            fields.Where(f => f.ProductId == p.Id)
                .Select(f => new FieldRow(f.Code, f.Label, f.DataType.ToString(), f.CatalogTopic, f.IsRequired, f.MaxLength)).ToList()))
            .ToList();
    }

    public async Task<IReadOnlyList<FaqRow>> GetFaqsAsync(string? productCode, CancellationToken ct)
    {
        var query =
            from f in db.Faqs.AsNoTracking()
            join p in db.Products on f.ProductId equals p.Id
            where f.IsActive && p.IsActive && (productCode == null || p.Code == productCode)
            orderby p.Id, f.SortOrder
            select new FaqRow(p.Code, f.Question, f.Answer);
        return await query.ToListAsync(ct);
    }

    public async Task<IReadOnlyList<CatalogItemRow>> GetCatalogAsync(string topic, CancellationToken ct)
    {
        if (string.Equals(topic, CountryTopic, StringComparison.OrdinalIgnoreCase))
            return await db.Countries.AsNoTracking()
                .Where(c => c.IsActive)
                .OrderBy(c => c.SortOrder).ThenBy(c => c.Name)
                .Select(c => new CatalogItemRow(c.IsoCode, c.Name))
                .ToListAsync(ct);

        return await db.Catalogs.AsNoTracking()
            .Where(c => c.Topic == topic && c.IsActive)
            .OrderBy(c => c.SortOrder).ThenBy(c => c.Value)
            .Select(c => new CatalogItemRow(c.Code, c.Value))
            .ToListAsync(ct);
    }

    public Task<bool> CatalogOptionExistsAsync(string topic, string code, CancellationToken ct) =>
        string.Equals(topic, CountryTopic, StringComparison.OrdinalIgnoreCase)
            ? db.Countries.AnyAsync(c => c.IsoCode == code.ToUpper() && c.IsActive, ct)
            : db.Catalogs.AnyAsync(c => c.Topic == topic && c.Code == code && c.IsActive, ct);

    public async Task<short?> GetCountryIdAsync(string isoCode, CancellationToken ct) =>
        await db.Countries.AsNoTracking().Where(c => c.IsoCode == isoCode && c.IsActive).Select(c => (short?)c.Id).FirstOrDefaultAsync(ct);

    public async Task<IReadOnlyList<RelationshipRow>> GetRelationshipsAsync(CancellationToken ct) =>
        await db.Relationships.AsNoTracking()
            .Where(r => r.IsActive)
            .OrderBy(r => r.Id)
            .Select(r => new RelationshipRow(r.Id, r.Code, r.Name, r.IsUnique, r.PepDegree))
            .ToListAsync(ct);
}
