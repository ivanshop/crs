namespace Check.Infrastructure.Persistence.Models;

// Tablas que solo se leen y no tienen comportamiento de negocio.

public sealed class CatalogEntry
{
    public long Id { get; set; }
    public string Topic { get; set; } = null!;
    public string Code { get; set; } = null!;
    public string Value { get; set; } = null!;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
}

public sealed class ParameterDefinition
{
    public long Id { get; set; }
    public string Code { get; set; } = null!;
    public string Name { get; set; } = null!;
    public string DataType { get; set; } = null!;
    public bool IsRequired { get; set; }
    public bool IsActive { get; set; }
}

public sealed class PlanParameter
{
    public long Id { get; set; }
    public long DefinitionId { get; set; }
    public long PlanId { get; set; }
    public string Value { get; set; } = null!;
    public DateOnly ValidFrom { get; set; }
    public DateOnly? ValidTo { get; set; }
    public bool IsActive { get; set; }

    public ParameterDefinition Definition { get; set; } = null!;
}

public sealed class Country
{
    public short Id { get; set; }
    public string IsoCode { get; set; } = null!;
    public string Iso3Code { get; set; } = null!;
    public string Name { get; set; } = null!;
    public string Nationality { get; set; } = null!;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
}

public sealed class Relationship
{
    public long Id { get; set; }
    public string Code { get; set; } = null!;
    public string Name { get; set; } = null!;
    public bool IsUnique { get; set; }
    public short? PepDegree { get; set; }
    public bool IsActive { get; set; }
}
