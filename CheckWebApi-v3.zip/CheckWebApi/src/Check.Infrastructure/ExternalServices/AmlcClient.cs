using System.Net.Http.Headers;
using System.Security;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Check.Application.Abstractions;

namespace Check.Infrastructure.ExternalServices;

/// <summary>
/// Cliente del servicio WCF de AMLC (basicHttpBinding) vía SOAP 1.1 con HttpClient,
/// sin proxy generado. AJUSTAR: operación, namespace y nombres de elementos según el WSDL.
/// La respuesta se guarda como JSON en compliance.screenings.raw_response.
/// </summary>
internal sealed class AmlcClient(HttpClient http, ServiceEndpoint endpoint) : IAmlcClient
{
    public async Task<WatchlistResult> SearchAsync(WatchlistRequest request, CancellationToken ct)
    {
        var ns = endpoint.SoapNamespace ?? "http://tempuri.org/";
        var envelope = $"""
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
              <s:Body>
                <Search xmlns="{ns}">
                  <documentNumber>{Esc(request.DocumentNumber)}</documentNumber>
                  <documentExtension>{Esc(request.DocumentExtension)}</documentExtension>
                  <documentComplement>{Esc(request.DocumentComplement)}</documentComplement>
                </Search>
              </s:Body>
            </s:Envelope>
            """;

        string xml;
        try
        {
            using var content = new StringContent(envelope, Encoding.UTF8, "text/xml");
            using var message = new HttpRequestMessage(HttpMethod.Post, endpoint.Path) { Content = content };
            message.Headers.Add("SOAPAction", $"\"{endpoint.SoapAction ?? ns + "Search"}\"");
            using var response = await http.SendAsync(message, ct);
            xml = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
                throw new ExternalServiceException("AMLC", $"AMLC respondió {(int)response.StatusCode}.");
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ct.IsCancellationRequested)
        {
            throw new ExternalServiceException("AMLC", "AMLC no está disponible.", ex);
        }

        try
        {
            // Cada coincidencia: un elemento <Item> con hijos FoundIn, Code, Position, Entity, Year, Observation
            var items = XDocument.Parse(xml).Descendants().Where(e => e.Name.LocalName == "Item")
                .Select(e => new WatchlistItem(
                    Value(e, "FoundIn") ?? "AMLC", Value(e, "Code"), Value(e, "Position"),
                    Value(e, "Entity"), Value(e, "Year"), Value(e, "Observation")))
                .ToList();
            return new WatchlistResult(items, JsonSerializer.Serialize(new { soap = xml }));
        }
        catch (System.Xml.XmlException ex)
        {
            throw new ExternalServiceException("AMLC", "AMLC devolvió una respuesta que no se pudo leer.", ex);
        }
    }

    private static string? Value(XElement e, string name) =>
        e.Elements().FirstOrDefault(x => x.Name.LocalName == name)?.Value;

    private static string Esc(string? value) => SecurityElement.Escape(value ?? string.Empty);
}
