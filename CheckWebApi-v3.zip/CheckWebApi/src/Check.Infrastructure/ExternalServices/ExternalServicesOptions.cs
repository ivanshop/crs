namespace Check.Infrastructure.ExternalServices;

public sealed class ExternalServicesOptions
{
    public const string Section = "ExternalServices";

    /// <summary>true = usa simuladores en lugar de SEGIP, AMLC, AN, OTP, Banco y LlamitAI reales (solo desarrollo).</summary>
    public bool UseFakes { get; init; }

    public ServiceEndpoint Segip { get; init; } = new();
    public ServiceEndpoint Amlc { get; init; } = new();
    public ServiceEndpoint NegativeFile { get; init; } = new();
    public ServiceEndpoint Otp { get; init; } = new();
    public ServiceEndpoint BankQr { get; init; } = new();
    public ServiceEndpoint LlamitAI { get; init; } = new();
}

public sealed class ServiceEndpoint
{
    public string BaseUrl { get; init; } = "http://localhost";
    /// <summary>Ruta del recurso (REST) o de la operación (WCF).</summary>
    public string Path { get; init; } = "/";
    public string? ApiKey { get; init; }
    public int TimeoutSeconds { get; init; } = 15;
    /// <summary>Solo AMLC (SOAP): SOAPAction y namespace del contrato WCF.</summary>
    public string? SoapAction { get; init; }
    public string? SoapNamespace { get; init; }
}

/// <summary>Azure Service Bus. Sin cadena de conexión, los eventos solo se escriben en el log (desarrollo).</summary>
public sealed class ServiceBusOptions
{
    public const string Section = "ServiceBus";
    public string? ConnectionString { get; init; }
}

/// <summary>Carpeta privada donde se guardan las fotos del carnet.</summary>
public sealed class StorageOptions
{
    public const string Section = "Storage";
    public string IdentityImagesPath { get; init; } = "data/identity";
}
