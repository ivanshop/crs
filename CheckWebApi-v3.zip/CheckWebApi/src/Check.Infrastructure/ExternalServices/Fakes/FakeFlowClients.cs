using System.Text;
using Check.Application.Abstractions;
using Check.Domain.Payments;
using Microsoft.Extensions.Logging;

namespace Check.Infrastructure.ExternalServices.Fakes;

// Simuladores para desarrollo (ExternalServices:UseFakes = true).

/// <summary>No envía nada: escribe el código en el log para poder probar el flujo. NUNCA usar en producción.</summary>
internal sealed class FakeOtpSender(ILogger<FakeOtpSender> logger) : IOtpSender
{
    public Task SendAsync(OtpChannel channel, string destination, string code, CancellationToken ct)
    {
        logger.LogWarning("[SIMULADOR] Código OTP {Codigo} por {Canal}. Solo para desarrollo.", code, channel);
        return Task.CompletedTask;
    }
}

/// <summary>Devuelve un "QR" de texto en base64 y una transacción simulada.</summary>
internal sealed class FakeBankQrClient : IBankQrClient
{
    public Task<QrResult> GenerateAsync(QrRequest request, CancellationToken ct) =>
        Task.FromResult(new QrResult(null,
            Convert.ToBase64String(Encoding.UTF8.GetBytes($"QR-SIMULADO|{request.QrPaymentId}|{request.Amount}|{request.Currency}"))));
}

/// <summary>No reconoce campos: el formulario se llena a mano.</summary>
internal sealed class FakeIdentityOcrClient : IIdentityOcrClient
{
    public Task<OcrResult> ReadAsync(byte[] frontImage, byte[] backImage, CancellationToken ct) =>
        Task.FromResult(new OcrResult("LECTURA SIMULADA", new Dictionary<string, string>(), """{"fake":true}"""));
}
