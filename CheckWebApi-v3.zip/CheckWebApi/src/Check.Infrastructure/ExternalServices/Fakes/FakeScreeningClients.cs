using System.Text.Json;
using Check.Application.Abstractions;

namespace Check.Infrastructure.ExternalServices.Fakes;

// Simuladores para desarrollo (ExternalServices:UseFakes = true).
//   SEGIP:            CI que termina en 000 → datos no coinciden.
//   AMLC:             CI que empieza con 999 → figura en listas internacionales.
//   Archivo Negativo: CI que empieza con 888 → figura en el archivo.

internal sealed class FakeSegipClient : ISegipClient
{
    public Task<SegipResult> VerifyAsync(SegipRequest request, CancellationToken ct)
    {
        var match = !request.DocumentNumber.EndsWith("000");
        var raw = JsonSerializer.Serialize(new { fake = true, exists = true, allMatch = match });
        return Task.FromResult(new SegipResult(true, true, true, true, true, match, match, raw));
    }
}

internal sealed class FakeAmlcClient : IAmlcClient
{
    public Task<WatchlistResult> SearchAsync(WatchlistRequest request, CancellationToken ct) =>
        Task.FromResult(FakeWatchlist.Search(request, "999", "OFAC", "Lista de sanciones (simulada)"));
}

internal sealed class FakeNegativeFileClient : INegativeFileClient
{
    public Task<WatchlistResult> SearchAsync(WatchlistRequest request, CancellationToken ct) =>
        Task.FromResult(FakeWatchlist.Search(request, "888", "ASFI", "Deuda en mora (simulada)"));
}

internal static class FakeWatchlist
{
    public static WatchlistResult Search(WatchlistRequest request, string prefix, string foundIn, string observation)
    {
        IReadOnlyList<WatchlistItem> items = request.DocumentNumber.StartsWith(prefix)
            ? [new WatchlistItem(foundIn, "SIM-001", null, "Entidad simulada", "2015", observation)]
            : [];
        return new WatchlistResult(items, JsonSerializer.Serialize(new { fake = true, items }));
    }
}
