using System.Net.Http.Headers;
using System.Text.Json;
using Check.Application.Abstractions;
using Check.Domain.Payments;

namespace Check.Infrastructure.ExternalServices;

// NOTA: los contratos de estos tres servicios (rutas y nombres de campos) son los supuestos
// documentados en el README. Ajustar aquí cuando se confirmen con cada proveedor.

/// <summary>Servicio de OTP: entrega el código por SMS, WhatsApp o correo.</summary>
internal sealed class OtpSender(HttpClient http, ServiceEndpoint endpoint) : IOtpSender
{
    public async Task SendAsync(OtpChannel channel, string destination, string code, CancellationToken ct) =>
        await HttpJson.PostAsync(http, endpoint.Path, new
        {
            channel = channel.ToString(),
            destination,
            message = $"Tu código de verificación de Check es {code}. No lo compartas con nadie."
        }, "OTP", ct);
}

/// <summary>Banco: genera el QR de cobro.</summary>
internal sealed class BankQrClient(HttpClient http, ServiceEndpoint endpoint) : IBankQrClient
{
    private sealed record BankQrResponse(string? TransactionId, string? QrImage);

    public async Task<QrResult> GenerateAsync(QrRequest request, CancellationToken ct)
    {
        var raw = await HttpJson.PostAsync(http, endpoint.Path, new
        {
            reference = request.QrPaymentId,
            amount = request.Amount,
            currency = request.Currency,
            expiresAt = request.ExpiresAt,
            singleUse = request.SingleUse,
            description = request.Description
        }, "Banco", ct);

        try
        {
            var response = JsonSerializer.Deserialize<BankQrResponse>(raw, HttpJson.Options);
            if (string.IsNullOrEmpty(response?.QrImage))
                throw new ExternalServiceException("Banco", "El Banco no devolvió la imagen del QR.");
            return new QrResult(response.TransactionId, response.QrImage);
        }
        catch (JsonException ex)
        {
            throw new ExternalServiceException("Banco", "El Banco devolvió una respuesta que no se pudo leer.", ex);
        }
    }
}

/// <summary>LlamitAI: OCR del anverso y reverso del carnet. Devuelve el texto procesado y los campos reconocidos.</summary>
internal sealed class LlamitAiClient(HttpClient http, ServiceEndpoint endpoint) : IIdentityOcrClient
{
    private sealed record OcrResponse(string? Text, Dictionary<string, string>? Fields);

    public async Task<OcrResult> ReadAsync(byte[] frontImage, byte[] backImage, CancellationToken ct)
    {
        try
        {
            using var form = new MultipartFormDataContent();
            form.Add(Image(frontImage), "front", "front.jpg");
            form.Add(Image(backImage), "back", "back.jpg");

            using var response = await http.PostAsync(endpoint.Path, form, ct);
            var raw = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
                throw new ExternalServiceException("LlamitAI", $"LlamitAI respondió {(int)response.StatusCode}.");

            var parsed = JsonSerializer.Deserialize<OcrResponse>(raw, HttpJson.Options);
            return new OcrResult(parsed?.Text ?? string.Empty, parsed?.Fields ?? [], raw);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ct.IsCancellationRequested)
        {
            throw new ExternalServiceException("LlamitAI", "LlamitAI no está disponible.", ex);
        }
        catch (JsonException ex)
        {
            throw new ExternalServiceException("LlamitAI", "LlamitAI devolvió una respuesta que no se pudo leer.", ex);
        }
    }

    private static ByteArrayContent Image(byte[] content)
    {
        var part = new ByteArrayContent(content);
        part.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
        return part;
    }
}
