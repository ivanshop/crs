using System.Net.Http.Json;
using System.Text.Json;
using Check.Application.Abstractions;

namespace Check.Infrastructure.ExternalServices;

/// <summary>
/// Cliente REST de SEGIP (servicio ya integrado en Check).
/// AJUSTAR: nombres de campos del request/response al contrato real.
/// </summary>
internal sealed class SegipClient(HttpClient http, ServiceEndpoint endpoint) : ISegipClient
{
    public async Task<SegipResult> VerifyAsync(SegipRequest request, CancellationToken ct)
    {
        var body = new
        {
            isBolivian = request.IsBolivian,
            paternalLastname = request.PaternalLastname,
            maternalLastname = request.MaternalLastname,
            names = request.Names,
            documentNumber = request.DocumentNumber,
            documentComplement = request.DocumentComplement,
            birthdate = request.Birthdate.ToString("yyyy-MM-dd")
        };

        var raw = await HttpJson.PostAsync(http, endpoint.Path, body, "SEGIP", ct);
        var r = JsonSerializer.Deserialize<SegipResponse>(raw, HttpJson.Options)
                ?? throw new ExternalServiceException("SEGIP", "SEGIP devolvió una respuesta vacía.");

        return new SegipResult(r.Exists, r.DocumentNumber, r.DocumentComplement, r.PaternalLastname,
            r.MaternalLastname, r.Names, r.Birthdate, raw);
    }

    private sealed record SegipResponse(
        bool Exists, bool DocumentNumber, bool DocumentComplement, bool PaternalLastname,
        bool MaternalLastname, bool Names, bool Birthdate);
}

/// <summary>
/// Cliente REST de Archivo Negativo.
/// AJUSTAR: nombres de campos al contrato real.
/// </summary>
internal sealed class NegativeFileClient(HttpClient http, ServiceEndpoint endpoint) : INegativeFileClient
{
    public async Task<WatchlistResult> SearchAsync(WatchlistRequest request, CancellationToken ct)
    {
        var body = new
        {
            documentNumber = request.DocumentNumber,
            documentExtension = request.DocumentExtension,
            documentComplement = request.DocumentComplement
        };

        var raw = await HttpJson.PostAsync(http, endpoint.Path, body, "Archivo Negativo", ct);
        var items = JsonSerializer.Deserialize<List<WatchlistItem>>(raw, HttpJson.Options) ?? [];
        return new WatchlistResult(items, raw);
    }
}

internal static class HttpJson
{
    public static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web);

    /// <summary>POST JSON y devuelve el cuerpo crudo; toda falla técnica es ExternalServiceException.</summary>
    public static async Task<string> PostAsync(HttpClient http, string path, object body, string service, CancellationToken ct)
    {
        try
        {
            using var response = await http.PostAsJsonAsync(path, body, Options, ct);
            var raw = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
                throw new ExternalServiceException(service, $"{service} respondió {(int)response.StatusCode}.");
            return raw;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ct.IsCancellationRequested)
        {
            throw new ExternalServiceException(service, $"{service} no está disponible.", ex);
        }
        catch (JsonException ex)
        {
            throw new ExternalServiceException(service, $"{service} devolvió una respuesta que no se pudo leer.", ex);
        }
    }
}
