using Check.Application.Abstractions;
using Check.Infrastructure.ExternalServices;
using Check.Infrastructure.ExternalServices.Fakes;
using Check.Infrastructure.Messaging;
using Check.Infrastructure.Persistence;
using Check.Infrastructure.Persistence.Repositories;
using Check.Infrastructure.Rules;
using Check.Infrastructure.Security;
using Check.Infrastructure.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Check");
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new InvalidOperationException("Falta la cadena de conexión 'ConnectionStrings:Check'.");

        services.AddOptions<EncryptionOptions>().Bind(configuration.GetSection(EncryptionOptions.Section)).ValidateOnStart();
        services.AddOptions<JwtOptions>().Bind(configuration.GetSection(JwtOptions.Section)).ValidateOnStart();
        services.AddOptions<ExternalServicesOptions>().Bind(configuration.GetSection(ExternalServicesOptions.Section));
        services.AddOptions<StorageOptions>().Bind(configuration.GetSection(StorageOptions.Section));
        services.AddSingleton(configuration.GetSection("Flow").Get<FlowSettings>() ?? new FlowSettings());

        services.AddSingleton<FieldEncryptor>();
        services.AddSingleton<IDocumentHasher, DocumentHasher>();
        services.AddSingleton<JwtTokenFactory>();
        services.AddSingleton<IContractTokenService>(sp => sp.GetRequiredService<JwtTokenFactory>());
        services.AddSingleton<IIdentityImageStore, LocalIdentityImageStore>();

        services.AddDbContext<CheckDbContext>(o => o.UseNpgsql(connectionString));
        services.AddScoped<IUnitOfWork>(sp => sp.GetRequiredService<CheckDbContext>());

        services.AddScoped<IPlanRepository, PlanRepository>();
        services.AddScoped<IPersonRepository, PersonRepository>();
        services.AddScoped<IContractRepository, ContractRepository>();
        services.AddScoped<IComplianceRepository, ComplianceRepository>();
        services.AddScoped<IPaymentRepository, PaymentRepository>();
        services.AddScoped<IEventRepository, EventRepository>();
        services.AddScoped<IAgreementRepository, AgreementRepository>();
        services.AddScoped<IMaintenanceRepository, MaintenanceRepository>();
        services.AddScoped<ICatalogQueries, CatalogQueries>();
        services.AddScoped<IPlanRulesProvider, PlanRulesProvider>();

        AddExternalClients(services, configuration);
        AddEventBus(services, configuration);
        return services;
    }

    private static void AddEventBus(IServiceCollection services, IConfiguration configuration)
    {
        var serviceBus = configuration.GetSection(ServiceBusOptions.Section).Get<ServiceBusOptions>();
        if (string.IsNullOrWhiteSpace(serviceBus?.ConnectionString))
            services.AddSingleton<IEventBus, LoggingEventBus>();
        else
            services.AddServiceBusEventBus(serviceBus.ConnectionString);
    }

    private static void AddExternalClients(IServiceCollection services, IConfiguration configuration)
    {
        var options = configuration.GetSection(ExternalServicesOptions.Section).Get<ExternalServicesOptions>() ?? new();
        if (options.UseFakes)
        {
            services.AddSingleton<ISegipClient, FakeSegipClient>();
            services.AddSingleton<IAmlcClient, FakeAmlcClient>();
            services.AddSingleton<INegativeFileClient, FakeNegativeFileClient>();
            services.AddSingleton<IOtpSender, FakeOtpSender>();
            services.AddSingleton<IBankQrClient, FakeBankQrClient>();
            services.AddSingleton<IIdentityOcrClient, FakeIdentityOcrClient>();
            return;
        }

        AddClient<ISegipClient>(services, "Segip", o => o.Segip, (h, e) => new SegipClient(h, e));
        AddClient<IAmlcClient>(services, "Amlc", o => o.Amlc, (h, e) => new AmlcClient(h, e));
        AddClient<INegativeFileClient>(services, "NegativeFile", o => o.NegativeFile, (h, e) => new NegativeFileClient(h, e));
        AddClient<IOtpSender>(services, "Otp", o => o.Otp, (h, e) => new OtpSender(h, e));
        AddClient<IBankQrClient>(services, "BankQr", o => o.BankQr, (h, e) => new BankQrClient(h, e));
        AddClient<IIdentityOcrClient>(services, "LlamitAI", o => o.LlamitAI, (h, e) => new LlamitAiClient(h, e));
    }

    private static void AddClient<T>(IServiceCollection services, string name,
        Func<ExternalServicesOptions, ServiceEndpoint> select, Func<HttpClient, ServiceEndpoint, T> create) where T : class
    {
        services.AddHttpClient(name, (sp, http) =>
        {
            var endpoint = select(sp.GetRequiredService<IOptions<ExternalServicesOptions>>().Value);
            http.BaseAddress = new Uri(endpoint.BaseUrl);
            http.Timeout = TimeSpan.FromSeconds(endpoint.TimeoutSeconds);
            if (endpoint.ApiKey is not null) http.DefaultRequestHeaders.Add("X-Api-Key", endpoint.ApiKey);
        });
        services.AddTransient(sp => create(
            sp.GetRequiredService<IHttpClientFactory>().CreateClient(name),
            select(sp.GetRequiredService<IOptions<ExternalServicesOptions>>().Value)));
    }
}
