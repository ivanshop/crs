using System.Security.Claims;
using System.Text;
using Check.Application.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;

namespace Check.Infrastructure.Security;

public sealed class JwtOptions
{
    public const string Section = "Jwt";

    public string Issuer { get; init; } = "check-api";
    /// <summary>Llave simétrica (mínimo 32 caracteres). En producción, Key Vault.</summary>
    public string SigningKey { get; init; } = null!;
    public int ClientTokenMinutes { get; init; } = 60;
    public int ContractTokenMinutes { get; init; } = 60;
    /// <summary>Clientes autorizados para pedir un token (client credentials).</summary>
    public List<JwtClient> Clients { get; init; } = [];
}

public sealed class JwtClient
{
    public string ClientId { get; init; } = null!;
    public string ClientSecret { get; init; } = null!;
    /// <summary>web, internal, bank-callback</summary>
    public List<string> Roles { get; init; } = [];
}

public static class CheckClaims
{
    public const string ContractId = "contract_id";
    public const string ClientAudience = "check-client";
    public const string ContractAudience = "check-contract";
}

public sealed class JwtTokenFactory(IOptions<JwtOptions> options, TimeProvider time) : IContractTokenService
{
    private readonly JwtOptions _options = options.Value;

    public SymmetricSecurityKey SigningKey => new(Encoding.UTF8.GetBytes(_options.SigningKey));

    public AccessToken Issue(Guid contractId) =>
        Create(CheckClaims.ContractAudience, _options.ContractTokenMinutes,
            [new Claim(JwtRegisteredClaimNames.Sub, $"contract:{contractId}"), new Claim(CheckClaims.ContractId, contractId.ToString())]);

    public AccessToken? IssueForClient(string clientId, string clientSecret)
    {
        var client = _options.Clients.FirstOrDefault(c => c.ClientId == clientId &&
            CryptographicEquals(c.ClientSecret, clientSecret));
        if (client is null) return null;

        var claims = new List<Claim> { new(JwtRegisteredClaimNames.Sub, client.ClientId) };
        claims.AddRange(client.Roles.Select(r => new Claim("role", r)));
        return Create(CheckClaims.ClientAudience, _options.ClientTokenMinutes, claims);
    }

    private AccessToken Create(string audience, int minutes, IEnumerable<Claim> claims)
    {
        var now = time.GetUtcNow();
        var expires = now.AddMinutes(minutes);
        var token = new JsonWebTokenHandler().CreateToken(new SecurityTokenDescriptor
        {
            Issuer = _options.Issuer,
            Audience = audience,
            Subject = new ClaimsIdentity(claims),
            NotBefore = now.UtcDateTime,
            IssuedAt = now.UtcDateTime,
            Expires = expires.UtcDateTime,
            SigningCredentials = new SigningCredentials(SigningKey, SecurityAlgorithms.HmacSha256)
        });
        return new AccessToken(token, expires);
    }

    private static bool CryptographicEquals(string a, string b) =>
        System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(a), Encoding.UTF8.GetBytes(b));
}
