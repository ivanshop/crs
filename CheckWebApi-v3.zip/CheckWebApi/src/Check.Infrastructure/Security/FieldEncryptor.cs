using System.Security.Cryptography;
using System.Text;
using Check.Application.Abstractions;
using Check.Domain.People;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.Security;

public sealed class EncryptionOptions
{
    public const string Section = "Encryption";

    /// <summary>Llave AES-256 en Base64 (32 bytes). En producción viene de Azure Key Vault.</summary>
    public string DataKey { get; init; } = null!;

    /// <summary>Llave HMAC-SHA256 en Base64 para los hashes de búsqueda.</summary>
    public string HashKey { get; init; } = null!;
}

/// <summary>
/// Cifra datos personales con AES-256-GCM.
/// Formato en la columna bytea: nonce (12) | tag (16) | texto cifrado.
/// </summary>
public sealed class FieldEncryptor
{
    private const int NonceSize = 12;
    private const int TagSize = 16;
    private readonly byte[] _key;

    public FieldEncryptor(IOptions<EncryptionOptions> options)
    {
        _key = Convert.FromBase64String(options.Value.DataKey);
        if (_key.Length != 32)
            throw new InvalidOperationException("La llave de cifrado (Encryption:DataKey) debe tener 32 bytes en Base64.");
    }

    public byte[] Encrypt(string plain)
    {
        var data = Encoding.UTF8.GetBytes(plain);
        var output = new byte[NonceSize + TagSize + data.Length];
        var nonce = output.AsSpan(0, NonceSize);
        RandomNumberGenerator.Fill(nonce);

        using var aes = new AesGcm(_key, TagSize);
        aes.Encrypt(nonce, data, output.AsSpan(NonceSize + TagSize), output.AsSpan(NonceSize, TagSize));
        return output;
    }

    public string Decrypt(byte[] cipher)
    {
        var plain = new byte[cipher.Length - NonceSize - TagSize];
        using var aes = new AesGcm(_key, TagSize);
        aes.Decrypt(cipher.AsSpan(0, NonceSize), cipher.AsSpan(NonceSize + TagSize), cipher.AsSpan(NonceSize, TagSize), plain);
        return Encoding.UTF8.GetString(plain);
    }
}

/// <summary>HMAC-SHA256 con llave secreta: un SHA-256 simple de un CI se revierte probando todos.</summary>
public sealed class DocumentHasher : IDocumentHasher
{
    private readonly byte[] _key;

    public DocumentHasher(IOptions<EncryptionOptions> options) =>
        _key = Convert.FromBase64String(options.Value.HashKey);

    public byte[] Hash(IdentityDocument document) =>
        Hash(document.CanonicalKey);

    public byte[] Hash(string value) =>
        HMACSHA256.HashData(_key, Encoding.UTF8.GetBytes(value));
}
