using System.Globalization;
using Check.Application.Abstractions;
using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Rules;

/// <summary>
/// Lee offer.plan_parameters a una fecha y arma PlanRules.
/// Cada plan tiene su propio conjunto de reglas; entre dos valores vigentes gana el valid_from más reciente.
/// </summary>
internal sealed class PlanRulesProvider(CheckDbContext db) : IPlanRulesProvider
{
    public async Task<Result<PlanRules>> GetAsync(long planId, DateOnly date, CancellationToken ct)
    {
        var plan = await db.Plans.AsNoTracking().Where(p => p.Id == planId)
            .Select(p => new { p.Id, p.Code, p.ProductId }).FirstOrDefaultAsync(ct);
        if (plan is null)
            return Error.NotFound("PLAN_NOT_FOUND", "El plan no existe o no está disponible.");

        var rows = await db.PlanParameters.AsNoTracking()
            .Where(p => p.IsActive && p.Definition.IsActive &&
                        p.PlanId == plan.Id &&
                        p.ValidFrom <= date && (p.ValidTo == null || p.ValidTo >= date))
            .Select(p => new { p.Definition.Code, p.Definition.Name, p.Definition.IsRequired, p.ValidFrom, p.Value })
            .ToListAsync(ct);

        var values = rows
            .GroupBy(r => r.Code)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(r => r.ValidFrom).First().Value);

        var missing = await db.ParameterDefinitions.AsNoTracking()
            .Where(d => d.IsActive && d.IsRequired)
            .Select(d => new { d.Code, d.Name })
            .ToListAsync(ct);
        var firstMissing = missing.FirstOrDefault(d => !values.ContainsKey(d.Code));
        if (firstMissing is not null)
            return Incomplete(plan.Code, $"le falta la regla '{firstMissing.Name}'");

        try
        {
            var premium = Money.Create(Decimal(values, ParameterCodes.PremiumAmount), values[ParameterCodes.PremiumCurrency]);
            if (premium.IsFailure) return Incomplete(plan.Code, premium.Error!.Message);

            return new PlanRules(
                plan.Code,
                Int(values, ParameterCodes.DurationDays),
                premium.Value,
                Int(values, ParameterCodes.MinAge),
                Int(values, ParameterCodes.MaxAge),
                Int(values, ParameterCodes.MaxBeneficiaries),
                Bool(values, ParameterCodes.IsRenewable),
                Bool(values, ParameterCodes.BrokerSaleEnabled),
                Int(values, ParameterCodes.QrLifetimeMinutes),
                OptionalDecimal(values, ParameterCodes.NetPremiumRate),
                OptionalDecimal(values, ParameterCodes.CededPremiumRate));
        }
        catch (Exception ex) when (ex is FormatException or KeyNotFoundException)
        {
            return Incomplete(plan.Code, ex.Message);
        }
    }

    private static Error Incomplete(string planCode, string detail) =>
        Error.BusinessRule("PLAN_RULES_INCOMPLETE", $"Las reglas del plan {planCode} no están completas: {detail}.");

    private static int Int(Dictionary<string, string> v, string code) =>
        int.TryParse(Get(v, code), NumberStyles.Integer, CultureInfo.InvariantCulture, out var r) ? r : throw Bad(code);

    private static decimal Decimal(Dictionary<string, string> v, string code) =>
        decimal.TryParse(Get(v, code), NumberStyles.Number, CultureInfo.InvariantCulture, out var r) ? r : throw Bad(code);

    private static bool Bool(Dictionary<string, string> v, string code) =>
        bool.TryParse(Get(v, code), out var r) ? r : throw Bad(code);

    private static decimal? OptionalDecimal(Dictionary<string, string> v, string code) =>
        v.ContainsKey(code) ? Decimal(v, code) : null;

    private static string Get(Dictionary<string, string> v, string code) =>
        v.TryGetValue(code, out var value) ? value : throw new KeyNotFoundException($"le falta la regla '{code}'");

    private static FormatException Bad(string code) => new($"el valor de '{code}' no tiene el tipo esperado");
}
