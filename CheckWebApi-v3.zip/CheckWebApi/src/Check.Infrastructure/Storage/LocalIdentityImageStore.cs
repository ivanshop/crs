using Check.Application.Abstractions;
using Check.Infrastructure.ExternalServices;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.Storage;

/// <summary>
/// Guarda las fotos del carnet en una carpeta privada del servidor (año/mes/lectura).
/// Para Azure Blob Storage basta otra implementación de IIdentityImageStore.
/// </summary>
internal sealed class LocalIdentityImageStore(IOptions<StorageOptions> options, TimeProvider time) : IIdentityImageStore
{
    public async Task<string> SaveAsync(Guid readingId, string side, byte[] content, string extension, CancellationToken ct)
    {
        var now = time.GetUtcNow();
        var relative = Path.Combine(now.ToString("yyyy"), now.ToString("MM"), $"{readingId:N}_{side}{extension.ToLowerInvariant()}");
        var full = Path.Combine(Path.GetFullPath(options.Value.IdentityImagesPath), relative);

        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllBytesAsync(full, content, ct);
        return relative.Replace('\\', '/');
    }
}
