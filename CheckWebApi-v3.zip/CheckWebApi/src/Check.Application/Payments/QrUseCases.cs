using System.ComponentModel.DataAnnotations;
using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Payments;
using Microsoft.Extensions.Logging;

namespace Check.Application.Payments;

public sealed record QrResponse(Guid ContractId, Guid QrPaymentId, decimal Amount, string Currency, string QrImage, DateTimeOffset ExpiresAt);

/// <summary>
/// Genera el QR de pago: un solo uso y la vida que fija el plan (30 minutos por defecto).
/// Si ya hay uno vigente lo devuelve; si venció, genera otro sin pedir un nuevo OTP.
/// </summary>
public sealed class GenerateQrUseCase(
    IContractRepository contracts, IPaymentRepository payments, IEventRepository events, IPlanRulesProvider rulesProvider,
    IPlanRepository plans, IBankQrClient bank, IUnitOfWork unitOfWork, TimeProvider time, ILogger<GenerateQrUseCase> logger)
{
    public async Task<Result<QrResponse>> ExecuteAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;
        if (contract.Status is not (ContractStatus.Verified or ContractStatus.PendingPayment))
            return ContractErrors.InvalidStatus(contract.Status, "generar el QR de");

        var now = time.GetUtcNow();
        var pending = await payments.GetPendingQrAsync(contractId, ct);
        if (pending is not null && !pending.IsExpiredAt(now))
            return new QrResponse(contractId, pending.Id, pending.Amount, pending.Currency, pending.QrImage!, pending.ExpiresAt);
        pending?.Expire();

        var rules = await rulesProvider.GetAsync(contract.PlanId, time.TodayInBolivia(), ct);
        if (rules.IsFailure) return rules.Error!;
        var plan = await plans.GetByIdAsync(contract.PlanId, ct);

        var amount = Money.Create(contract.PremiumAmount, contract.Currency).Value;
        var qrId = Guid.CreateVersion7();
        var expiresAt = now.AddMinutes(rules.Value.QrLifetimeMinutes);

        QrResult generated;
        try
        {
            generated = await bank.GenerateAsync(new QrRequest(qrId, amount.Amount, amount.Currency, expiresAt, true, $"Check - {plan?.Name}"), ct);
        }
        catch (ExternalServiceException ex)
        {
            logger.LogWarning(ex, "El Banco no generó el QR del contrato {ContractId}.", contractId);
            return Error.ExternalService("BANK_UNAVAILABLE", "No pudimos generar el QR. Intenta nuevamente en unos minutos.");
        }

        var moved = contract.MarkPendingPayment();
        if (moved.IsFailure) return moved.Error!;

        payments.Add(QrPayment.Create(qrId, contractId, amount, generated.BankTransactionId, generated.QrImageBase64, expiresAt));
        events.Add(ContractEvent.Record(contractId, ContractEventType.QrGenerated, EventPayload.Of(new { qrPaymentId = qrId, expiresAt }), now));
        await unitOfWork.SaveChangesAsync(ct);

        logger.LogInformation("QR {QrPaymentId} generado para el contrato {ContractId}; vence a las {Vence}.", qrId, contractId, expiresAt);
        return new QrResponse(contractId, qrId, amount.Amount, amount.Currency, generated.QrImageBase64, expiresAt);
    }
}

/// <summary>Aviso de pago que envía el Banco.</summary>
public sealed class PaymentNotificationRequest
{
    /// <summary>Identificador del QR que Check envió al generarlo.</summary>
    [Required(ErrorMessage = "La referencia del QR es obligatoria.")]
    public Guid? QrPaymentId { get; init; }

    [Required(ErrorMessage = "El identificador de la transacción es obligatorio.")]
    public string TransactionId { get; init; } = null!;

    public decimal Amount { get; init; }

    [Required(ErrorMessage = "La moneda es obligatoria.")]
    public string Currency { get; init; } = null!;

    public DateTimeOffset? PaidAt { get; init; }
}

public sealed record PaymentNotificationResponse(string Result, string Message);

/// <summary>
/// Procesa el aviso del Banco. Es idempotente: cada aviso se guarda tal como llegó y solo el primero válido
/// activa el contrato. Un QR vencido no se procesa (queda como evidencia para conciliar).
/// </summary>
public sealed class ProcessPaymentNotificationUseCase(
    IPaymentRepository payments, ContractActivator activator, IUnitOfWork unitOfWork, TimeProvider time,
    ILogger<ProcessPaymentNotificationUseCase> logger)
{
    public async Task<Result<PaymentNotificationResponse>> ExecuteAsync(PaymentNotificationRequest request, string rawPayload, CancellationToken ct)
    {
        var now = time.GetUtcNow();
        var qr = await payments.GetQrAsync(request.QrPaymentId!.Value, ct);

        NotificationResult result;
        if (qr is null)
            result = NotificationResult.Unknown;
        else if (await payments.NotificationAppliedAsync(request.TransactionId, ct))
            result = NotificationResult.Duplicate;
        else
            result = qr.Apply(request.Amount, request.Currency, request.TransactionId, request.PaidAt ?? now);

        payments.Add(PaymentNotification.Record(qr?.Id, request.TransactionId, rawPayload, result, now));

        if (result == NotificationResult.Applied)
        {
            var activated = await activator.ActivateAsync(qr!, ct);
            if (activated.IsFailure) return activated.Error!;
        }

        await unitOfWork.SaveChangesAsync(ct);

        if (result is NotificationResult.Applied or NotificationResult.Duplicate)
            logger.LogInformation("Aviso de pago {TransactionId} del QR {QrPaymentId}: {Resultado}.", request.TransactionId, request.QrPaymentId, result);
        else
            logger.LogWarning("Aviso de pago {TransactionId} del QR {QrPaymentId} NO aplicado: {Resultado}. Requiere conciliación.", request.TransactionId, request.QrPaymentId, result);

        return new PaymentNotificationResponse(result.ToString(), result switch
        {
            NotificationResult.Applied => "Pago aplicado.",
            NotificationResult.Duplicate => "El pago ya había sido aplicado.",
            NotificationResult.Expired => "El QR venció o ya no está vigente; el pago no fue aplicado.",
            NotificationResult.AmountMismatch => "El monto o la moneda no coinciden con el QR; el pago no fue aplicado.",
            _ => "El QR no existe."
        });
    }
}

/// <summary>
/// Vuelve póliza vigente un contrato pagado: número, vigencia desde el pago y los eventos de
/// correo de bienvenida y Carpeta de Cliente. Lo usan el aviso del Banco y la conciliación manual.
/// </summary>
public sealed class ContractActivator(
    IContractRepository contracts, IPlanRepository plans, IEventRepository events,
    TimeProvider time, ILogger<ContractActivator> logger)
{
    public async Task<Result> ActivateAsync(QrPayment qr, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(qr.ContractId, ct);
        if (contract is null) return ContractErrors.NotFound;

        var plan = await plans.GetByIdAsync(contract.PlanId, ct);
        if (plan is null) return Error.NotFound("PLAN_NOT_FOUND", "El plan del contrato no existe.");
        var paidAt = qr.PaidAt ?? time.GetUtcNow();

        var number = ContractNumber.Generate(plan.Product.Code, TimeZoneInfo.ConvertTime(paidAt, BoliviaClock.Zone).Year);
        var activated = contract.Activate(number, paidAt);
        if (activated.IsFailure) return activated;

        var now = time.GetUtcNow();
        var payload = EventPayload.Of(new { contractId = contract.Id, number = contract.Number, productCode = plan.Product.Code, planCode = plan.Code });
        events.Add(ContractEvent.Record(contract.Id, ContractEventType.PaymentConfirmed,
            EventPayload.Of(new { qrPaymentId = qr.Id, qr.BankTransactionId, manual = qr.ConfirmedManuallyBy is not null }), now));
        events.Add(ContractEvent.Enqueue(contract.Id, ContractEventType.WelcomeEmail, ContractEvent.WelcomeEmailQueue, payload, now));
        events.Add(ContractEvent.Enqueue(contract.Id, ContractEventType.ClientFolder, ContractEvent.ClientFolderQueue, payload, now));

        logger.LogInformation("Contrato {ContractId} activado: póliza {Numero}, cobertura de {Desde} a {Hasta}.",
            contract.Id, contract.Number, contract.CoverageFrom, contract.CoverageTo);
        return Result.Success();
    }
}
