using System.ComponentModel.DataAnnotations;
using System.Security.Cryptography;
using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Application.Contracts;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Payments;
using Microsoft.Extensions.Logging;

namespace Check.Application.Payments;

public sealed class SendOtpRequest
{
    /// <summary>Sms, WhatsApp o Email.</summary>
    [Required(ErrorMessage = "El canal de envío es obligatorio.")]
    public string Channel { get; init; } = null!;
}

public sealed class VerifyOtpRequest
{
    [Required(ErrorMessage = "El código es obligatorio.")]
    [RegularExpression(@"^\d{6}$", ErrorMessage = "El código debe tener 6 dígitos.")]
    public string Code { get; init; } = null!;
}

public sealed record SendOtpResponse(Guid ContractId, string Channel, string MaskedDestination, DateTimeOffset ExpiresAt);

/// <summary>Envía un código de 6 dígitos al celular o correo del contratante (los del contrato, no se pueden cambiar aquí).</summary>
public sealed class SendOtpUseCase(
    IContractRepository contracts, IPaymentRepository payments, IOtpSender sender, IDocumentHasher hasher,
    FlowSettings settings, IUnitOfWork unitOfWork, TimeProvider time, ILogger<SendOtpUseCase> logger)
{
    public async Task<Result<SendOtpResponse>> ExecuteAsync(Guid contractId, SendOtpRequest request, CancellationToken ct)
    {
        if (!Enum.TryParse<OtpChannel>(request.Channel, true, out var channel))
            return Error.Validation("OTP_INVALID_CHANNEL", "El canal debe ser Sms, WhatsApp o Email.");

        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;
        if (contract.Status != ContractStatus.Declared)
            return ContractErrors.InvalidStatus(contract.Status, "enviar un código a");
        if (!contract.HasRequiredConsents) return ContractErrors.ConsentsRequired;

        var now = time.GetUtcNow();
        if (await payments.CountOtpsAsync(contractId, ct) >= settings.OtpMaxSends)
            return Error.BusinessRule("OTP_SENDS_EXCEEDED", "Superaste la cantidad de códigos permitidos para esta compra.");

        var last = await payments.GetLatestOtpAsync(contractId, ct);
        if (last is not null && (now - last.CreatedAt).TotalSeconds < settings.OtpResendSeconds)
            return Error.BusinessRule("OTP_TOO_SOON", $"Espera {settings.OtpResendSeconds} segundos antes de pedir otro código.");

        var destination = channel == OtpChannel.Email ? contract.Contractor.Email : contract.Contractor.Cellphone;
        if (string.IsNullOrEmpty(destination)) return ContractErrors.ContractorContactRequired;

        var code = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
        var challenge = OtpChallenge.Create(contractId, channel, destination, hasher.Hash(OtpCode.Material(contractId, code)),
            now, settings.OtpLifetimeMinutes, settings.OtpMaxAttempts);

        try
        {
            await sender.SendAsync(channel, destination, code, ct);
        }
        catch (ExternalServiceException ex)
        {
            logger.LogWarning(ex, "No se pudo enviar el OTP del contrato {ContractId} por {Canal}.", contractId, channel);
            return Error.ExternalService("OTP_SERVICE_UNAVAILABLE", "No pudimos enviar el código. Intenta con otro canal o en unos minutos.");
        }

        payments.Add(challenge);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("OTP enviado para el contrato {ContractId} por {Canal}.", contractId, channel);

        return new SendOtpResponse(contractId, channel.ToString(), OtpCode.Mask(destination), challenge.ExpiresAt);
    }
}

/// <summary>Valida el código. Al acertar, las aceptaciones quedan firmadas y el contrato pasa a Verified.</summary>
public sealed class VerifyOtpUseCase(
    IContractRepository contracts, IPaymentRepository payments, IEventRepository events, IDocumentHasher hasher,
    IUnitOfWork unitOfWork, TimeProvider time, ILogger<VerifyOtpUseCase> logger)
{
    public async Task<Result<ContractStepResponse>> ExecuteAsync(Guid contractId, VerifyOtpRequest request, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;
        if (contract.Status != ContractStatus.Declared)
            return ContractErrors.InvalidStatus(contract.Status, "verificar");

        var challenge = await payments.GetLatestOtpAsync(contractId, ct);
        if (challenge is null)
            return Error.NotFound("OTP_NOT_FOUND", "Primero solicita un código de verificación.");

        var now = time.GetUtcNow();
        var verification = challenge.Verify(hasher.Hash(OtpCode.Material(contractId, request.Code)), now);
        if (verification.IsFailure)
        {
            await unitOfWork.SaveChangesAsync(ct); // guarda el intento fallido
            logger.LogWarning("Contrato {ContractId}: intento de OTP fallido ({Intentos} de {Maximo}).", contractId, challenge.Attempts, challenge.MaxAttempts);
            return verification.Error!;
        }

        var verified = contract.MarkVerified(challenge.Id);
        if (verified.IsFailure) return verified.Error!;

        events.Add(ContractEvent.Record(contractId, ContractEventType.OtpVerified, EventPayload.Of(new { channel = challenge.Channel.ToString() }), now));
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Contrato {ContractId} verificado con OTP por {Canal}.", contractId, challenge.Channel);

        return new ContractStepResponse(contractId, contract.Status.ToString(), "Código verificado. Ya puedes generar tu QR de pago.");
    }
}

internal static class OtpCode
{
    /// <summary>El hash incluye el contrato: el mismo código no sirve para otro.</summary>
    public static string Material(Guid contractId, string code) => $"otp|{contractId:N}|{code}";

    public static string Mask(string destination)
    {
        var at = destination.IndexOf('@');
        if (at > 1) return $"{destination[0]}***{destination[(at - 1)..]}";
        return destination.Length > 3 ? $"{new string('*', destination.Length - 3)}{destination[^3..]}" : "***";
    }
}
