using System.Text.Json;
using Check.Application.Abstractions;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Microsoft.Extensions.Logging;

namespace Check.Application.Compliance;

public sealed record IdentityImage(byte[] Content, string Extension);
public sealed record IdentityReadingResponse(Guid IdentityReadingId, string Status, IReadOnlyDictionary<string, string> Fields, string? Message);

/// <summary>
/// Lee el anverso y el reverso del carnet con LlamitAI para precargar el formulario.
/// La lectura se guarda como evidencia y se vincula a la persona al iniciar el contrato.
/// Si LlamitAI falla, el cliente puede llenar el formulario a mano.
/// </summary>
public sealed class ReadIdentityUseCase(
    IIdentityOcrClient ocr, IIdentityImageStore store, IComplianceRepository compliance, FlowSettings settings,
    IUnitOfWork unitOfWork, TimeProvider time, ILogger<ReadIdentityUseCase> logger)
{
    private static readonly string[] AllowedExtensions = [".jpg", ".jpeg", ".png", ".webp"];

    public async Task<Result<IdentityReadingResponse>> ExecuteAsync(IdentityImage front, IdentityImage back, string? clientIp, CancellationToken ct)
    {
        foreach (var (image, side) in new[] { (front, "anverso"), (back, "reverso") })
        {
            if (image.Content.Length == 0)
                return Error.Validation("IDENTITY_IMAGE_REQUIRED", $"Falta la foto del {side} del carnet.");
            if (image.Content.Length > settings.MaxIdentityImageKb * 1024)
                return Error.Validation("IDENTITY_IMAGE_TOO_LARGE", $"La foto del {side} supera el tamaño permitido ({settings.MaxIdentityImageKb} KB).");
            if (!AllowedExtensions.Contains(image.Extension.ToLowerInvariant()))
                return Error.Validation("IDENTITY_IMAGE_INVALID", $"La foto del {side} debe ser JPG, PNG o WEBP.");
        }

        var id = Guid.CreateVersion7();
        var frontPath = await store.SaveAsync(id, "front", front.Content, front.Extension, ct);
        var backPath = await store.SaveAsync(id, "back", back.Content, back.Extension, ct);

        var reading = IdentityReading.Request(id, frontPath, backPath, clientIp, time.GetUtcNow());
        compliance.Add(reading);

        IReadOnlyDictionary<string, string> fields = new Dictionary<string, string>();
        try
        {
            var result = await ocr.ReadAsync(front.Content, back.Content, ct);
            fields = result.Fields;
            reading.Complete(result.Text, JsonSerializer.Serialize(result.Fields), result.RawResponse, time.GetUtcNow());
            logger.LogInformation("Lectura de carnet {IdentityReadingId} completada: {Campos} campos reconocidos.", id, fields.Count);
        }
        catch (ExternalServiceException ex)
        {
            reading.Fail(ex.Message, time.GetUtcNow());
            logger.LogWarning(ex, "Lectura de carnet {IdentityReadingId} fallida: LlamitAI no respondió.", id);
        }

        await unitOfWork.SaveChangesAsync(ct);

        return new IdentityReadingResponse(id, reading.Status.ToString(), fields,
            reading.Status == IdentityReadingStatus.Completed ? null : "No pudimos leer tu carnet. Completa tus datos manualmente.");
    }
}
