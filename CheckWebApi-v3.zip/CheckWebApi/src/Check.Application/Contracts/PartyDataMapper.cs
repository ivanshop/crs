using Check.Application.Abstractions;
using Check.Domain.Common;
using Check.Domain.People;

namespace Check.Application.Contracts;

/// <summary>Convierte el request en value objects del Domain; devuelve el primer error en español.</summary>
internal static class PartyDataMapper
{
    public static async Task<Result<PartyData>> MapAsync(PersonalDataRequest r, string who, ICatalogQueries catalogs, CancellationToken ct)
    {
        if (!Enum.TryParse<DocumentType>(r.DocumentType, true, out var documentType))
            return Error.Validation("DOCUMENT_INVALID_TYPE", $"El tipo de documento {who} debe ser CI o CE.");
        if (!Enum.TryParse<Gender>(r.Gender, true, out var gender))
            return Error.Validation("GENDER_INVALID", $"El género {who} debe ser Male o Female.");

        var document = IdentityDocument.Create(documentType, r.DocumentNumber, r.DocumentComplement, r.DocumentExtension);
        if (document.IsFailure) return WithWho(document.Error!, who);

        var name = PersonName.Create(r.Names, r.PaternalLastname, r.MaternalLastname);
        if (name.IsFailure) return WithWho(name.Error!, who);

        PhoneNumber? cellphone = null;
        if (!string.IsNullOrWhiteSpace(r.Cellphone))
        {
            var phone = PhoneNumber.Create(r.Cellphone);
            if (phone.IsFailure) return WithWho(phone.Error!, who);
            cellphone = phone.Value;
        }

        Email? email = null;
        if (!string.IsNullOrWhiteSpace(r.Email))
        {
            var mail = Email.Create(r.Email);
            if (mail.IsFailure) return WithWho(mail.Error!, who);
            email = mail.Value;
        }

        var nationalityId = await catalogs.GetCountryIdAsync(r.Nationality.ToUpperInvariant(), ct);
        if (nationalityId is null)
            return Error.Validation("NATIONALITY_INVALID", $"La nacionalidad {who} no es un país válido.");

        return new PartyData(
            document.Value, name.Value, r.Birthdate!.Value, gender, nationalityId.Value,
            Clean(r.Address), Clean(r.City), cellphone, email,
            Clean(r.MaritalStatus), Clean(r.Occupation), Clean(r.EconomicActivity), Clean(r.MonthlyIncomeRange));
    }

    public static Result<PersonName> MapName(NamedPersonRequest r, string who)
    {
        var name = PersonName.Create(r.Names, r.PaternalLastname, r.MaternalLastname);
        return name.IsFailure ? WithWho(name.Error!, who) : name;
    }

    public static string? Clean(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static Error WithWho(Error error, string who) =>
        error with { Message = $"{error.Message.TrimEnd('.')} ({who})." };
}
