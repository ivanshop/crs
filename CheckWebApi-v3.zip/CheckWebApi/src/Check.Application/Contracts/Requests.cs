using System.ComponentModel.DataAnnotations;

namespace Check.Application.Contracts;

public sealed class StartContractRequest
{
    [Required(ErrorMessage = "El código del plan es obligatorio.")]
    public string PlanCode { get; init; } = null!;

    [Required(ErrorMessage = "Los datos del contratante son obligatorios.")]
    public PersonalDataRequest Contractor { get; init; } = null!;

    /// <summary>Null cuando el contratante es también el asegurado.</summary>
    public PersonalDataRequest? Insured { get; init; }

    /// <summary>Código del agente cuando la venta viene de una agencia de brokers.</summary>
    public string? AgentCode { get; init; }

    /// <summary>Código del convenio corporativo cuando el empleado de una empresa contrata con condiciones negociadas.</summary>
    public string? AgreementCode { get; init; }

    /// <summary>Campos propios del producto: código → valor (ORIGIN, DEVICE_IMEI...).</summary>
    public Dictionary<string, string>? Details { get; init; }
}

public sealed class PersonalDataRequest
{
    [Required(ErrorMessage = "El tipo de documento es obligatorio.")]
    public string DocumentType { get; init; } = null!;

    [Required(ErrorMessage = "El número de documento es obligatorio.")]
    public string DocumentNumber { get; init; } = null!;

    public string? DocumentComplement { get; init; }
    public string? DocumentExtension { get; init; }

    [Required(ErrorMessage = "Los nombres son obligatorios.")]
    public string Names { get; init; } = null!;

    public string? PaternalLastname { get; init; }
    public string? MaternalLastname { get; init; }

    [Required(ErrorMessage = "La fecha de nacimiento es obligatoria.")]
    public DateOnly? Birthdate { get; init; }

    [Required(ErrorMessage = "El género es obligatorio.")]
    public string Gender { get; init; } = null!;

    [Required(ErrorMessage = "La nacionalidad es obligatoria.")]
    [StringLength(2, MinimumLength = 2, ErrorMessage = "La nacionalidad debe ser un código de país de 2 letras (BO).")]
    public string Nationality { get; init; } = "BO";

    [StringLength(250, ErrorMessage = "La dirección no puede superar 250 caracteres.")]
    public string? Address { get; init; }
    public string? City { get; init; }
    public string? Cellphone { get; init; }
    public string? Email { get; init; }
    public string? MaritalStatus { get; init; }
    public string? Occupation { get; init; }
    public string? EconomicActivity { get; init; }
    public string? MonthlyIncomeRange { get; init; }

    /// <summary>Lectura del carnet con LlamitAI que precargó estos datos (opcional).</summary>
    public Guid? IdentityReadingId { get; init; }
}

public sealed record StartContractResponse(
    Guid ContractId, string Status, decimal Premium, string Currency,
    string AccessToken, DateTimeOffset AccessTokenExpiresAt);

public sealed record ContractStepResponse(Guid ContractId, string Status, string? Message);

public sealed class DeclarationsRequest
{
    /// <summary>Vacío o nulo = herederos legales.</summary>
    public List<BeneficiaryRequest>? Beneficiaries { get; init; }

    [Required(ErrorMessage = "La declaración PEP del contratante es obligatoria.")]
    public PepRequest ContractorPep { get; init; } = null!;

    /// <summary>Obligatoria si el asegurado es una persona distinta y mayor de edad.</summary>
    public PepRequest? InsuredPep { get; init; }
}

public sealed class NamedPersonRequest
{
    [Required(ErrorMessage = "Los nombres son obligatorios.")]
    public string Names { get; init; } = null!;
    public string? PaternalLastname { get; init; }
    public string? MaternalLastname { get; init; }
    public string? DocumentNumber { get; init; }
    /// <summary>Código del parentesco (SPOUSE, CHILD...). No aplica a socios.</summary>
    public string? Relationship { get; init; }
    /// <summary>Solo para socios PEP.</summary>
    public string? CompanyName { get; init; }
}

public sealed class BeneficiaryRequest
{
    [Required(ErrorMessage = "Los datos del beneficiario son obligatorios.")]
    public NamedPersonRequest Person { get; init; } = null!;

    [Range(0.01, 100, ErrorMessage = "El porcentaje debe ser mayor a 0 y como máximo 100.")]
    public decimal Percentage { get; init; }
}

public sealed class PepRequest
{
    public bool IsPep { get; init; }
    public string? Position { get; init; }
    public string? Institution { get; init; }
    public DateOnly? PeriodStart { get; init; }
    public DateOnly? PeriodEnd { get; init; }
    public List<NamedPersonRequest>? Relatives { get; init; }
    public List<NamedPersonRequest>? Partners { get; init; }
}

public sealed class ConsentsRequest
{
    [Required(ErrorMessage = "Debes enviar al menos una aceptación.")]
    [MinLength(1, ErrorMessage = "Debes enviar al menos una aceptación.")]
    public List<ConsentRequest> Consents { get; init; } = null!;
}

public sealed class ConsentRequest
{
    /// <summary>GeneralConditions, ParticularConditions, DataPrivacy, PepStatement o BeneficiaryStatement.</summary>
    [Required(ErrorMessage = "El tipo de documento es obligatorio.")]
    public string DocumentType { get; init; } = null!;

    [Required(ErrorMessage = "El código del documento es obligatorio.")]
    public string DocumentCode { get; init; } = null!;

    [Required(ErrorMessage = "La versión del documento es obligatoria.")]
    public string DocumentVersion { get; init; } = null!;

    /// <summary>SHA-256 (hexadecimal) del texto exacto que se mostró al cliente.</summary>
    [Required(ErrorMessage = "La huella del documento es obligatoria.")]
    [RegularExpression("^[0-9a-fA-F]{64}$", ErrorMessage = "La huella del documento debe ser un SHA-256 en hexadecimal.")]
    public string ContentSha256 { get; init; } = null!;
}

public sealed class SurveyRequest
{
    /// <summary>ConditionsComprehension (1 a 5) o PurchaseEase (1 a 10).</summary>
    [Required(ErrorMessage = "El tipo de encuesta es obligatorio.")]
    public string Type { get; init; } = null!;
    public int Score { get; init; }
    [StringLength(1000, ErrorMessage = "El comentario no puede superar 1000 caracteres.")]
    public string? Comment { get; init; }
}

public sealed record ContractResponse(
    Guid ContractId, string Status, string? Number, string PlanCode, decimal Premium, string Currency,
    DateTimeOffset? CoverageFrom, DateTimeOffset? CoverageTo, bool LegalHeirs, DateTimeOffset CreatedAt, string? Message);
