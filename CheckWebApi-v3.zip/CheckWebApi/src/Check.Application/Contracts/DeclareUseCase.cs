using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Contracts;

/// <summary>
/// Registra los beneficiarios (o herederos legales) y la declaración PEP del contratante y del asegurado.
/// La declaración PEP es de la persona: si no cambió, se reutiliza la vigente; si cambió, la nueva la reemplaza.
/// </summary>
public sealed class DeclareUseCase(
    IContractRepository contracts,
    IComplianceRepository compliance,
    IPlanRulesProvider rulesProvider,
    ICatalogQueries catalogs,
    IUnitOfWork unitOfWork,
    TimeProvider time,
    ILogger<DeclareUseCase> logger)
{
    public async Task<Result<ContractStepResponse>> ExecuteAsync(Guid contractId, DeclarationsRequest request, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;

        var now = time.GetUtcNow();
        var today = time.TodayInBolivia();
        var relationships = await catalogs.GetRelationshipsAsync(ct);

        var rules = await rulesProvider.GetAsync(contract.PlanId, today, ct);
        if (rules.IsFailure) return rules.Error!;

        // ---- Beneficiarios ----
        var beneficiaries = new List<Beneficiary>();
        var drafts = new List<BeneficiaryDraft>();
        foreach (var b in request.Beneficiaries ?? [])
        {
            var relationship = relationships.FirstOrDefault(r => string.Equals(r.Code, b.Person.Relationship, StringComparison.OrdinalIgnoreCase));
            if (relationship is null)
                return Error.Validation("RELATIONSHIP_INVALID", "El parentesco de un beneficiario no es válido.");
            var name = PartyDataMapper.MapName(b.Person, "beneficiario");
            if (name.IsFailure) return name.Error!;

            drafts.Add(new BeneficiaryDraft(relationship.Id, relationship.IsUnique, b.Percentage));
            beneficiaries.Add(Beneficiary.Create(relationship.Id, name.Value, PartyDataMapper.Clean(b.Person.DocumentNumber), b.Percentage));
        }

        var insuredIsMinor = Age.At(contract.Insured.Birthdate!.Value, today) < Age.AdultAge;
        var check = BeneficiaryPolicy.Check(drafts, rules.Value, insuredIsMinor);
        if (check.IsFailure) return check.Error!;

        // ---- PEP ----
        var sameCustomer = contract.Contractor.PersonId == contract.Insured.PersonId;
        var contractorPep = await ResolvePepAsync(contract.Contractor, request.ContractorPep, relationships, now, ct);
        if (contractorPep.IsFailure) return contractorPep.Error!;

        PepDeclaration? insuredPep = null;
        if (sameCustomer)
        {
            insuredPep = contractorPep.Value;
        }
        else if (!insuredIsMinor)
        {
            if (request.InsuredPep is null)
                return Error.Validation("INSURED_PEP_REQUIRED", "Falta la declaración PEP del asegurado.");
            var resolved = await ResolvePepAsync(contract.Insured, request.InsuredPep, relationships, now, ct);
            if (resolved.IsFailure) return resolved.Error!;
            insuredPep = resolved.Value;
        }

        var declared = contract.Declare(beneficiaries);
        if (declared.IsFailure) return declared.Error!;

        // Primer guardado: las declaraciones nuevas reciben su id; luego se enlazan a las partes.
        await unitOfWork.SaveChangesAsync(ct);
        contract.Contractor.LinkPepDeclaration(contractorPep.Value.Id);
        if (insuredPep is not null) contract.Insured.LinkPepDeclaration(insuredPep.Id);
        await unitOfWork.SaveChangesAsync(ct);

        logger.LogInformation("Contrato {ContractId}: {Beneficiarios} beneficiarios declarados (herederos legales: {HerederosLegales}); contratante PEP: {EsPep}.",
            contractId, beneficiaries.Count, beneficiaries.Count == 0, contractorPep.Value.IsPep);

        return new ContractStepResponse(contract.Id, contract.Status.ToString(),
            beneficiaries.Count == 0 ? "Sin beneficiarios declarados: aplican los herederos legales." : "Declaraciones registradas.");
    }

    private async Task<Result<PepDeclaration>> ResolvePepAsync(ContractParty party, PepRequest request,
        IReadOnlyList<RelationshipRow> relationships, DateTimeOffset now, CancellationToken ct)
    {
        var relatives = new List<PepRelative>();
        foreach (var r in request.IsPep ? request.Relatives ?? [] : [])
        {
            var relationship = relationships.FirstOrDefault(x => string.Equals(x.Code, r.Relationship, StringComparison.OrdinalIgnoreCase));
            if (relationship is null)
                return Error.Validation("RELATIONSHIP_INVALID", "El parentesco de un familiar PEP no es válido.");
            var name = PartyDataMapper.MapName(r, "familiar PEP");
            if (name.IsFailure) return name.Error!;
            relatives.Add(PepRelative.Create(relationship.Id, name.Value, PartyDataMapper.Clean(r.DocumentNumber)));
        }

        var partners = new List<PepPartner>();
        foreach (var p in request.IsPep ? request.Partners ?? [] : [])
        {
            var name = PartyDataMapper.MapName(p, "socio PEP");
            if (name.IsFailure) return name.Error!;
            partners.Add(PepPartner.Create(name.Value, PartyDataMapper.Clean(p.DocumentNumber), PartyDataMapper.Clean(p.CompanyName)));
        }

        var declaration = PepDeclaration.Create(party.PersonId, request.IsPep, request.Position, request.Institution,
            request.PeriodStart, request.PeriodEnd, relatives, partners, now);
        if (declaration.IsFailure) return declaration.Error!;

        var current = await compliance.GetCurrentPepAsync(party.PersonId, ct);
        if (current is not null && current.IsEquivalentTo(declaration.Value))
            return current;

        current?.Supersede(now);
        compliance.Add(declaration.Value);
        return declaration.Value;
    }
}
