using Check.Application.Abstractions;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Contracts;

/// <summary>Registra el consentimiento expreso del contratante. Queda firmado al validar el OTP.</summary>
public sealed class AcceptConsentsUseCase(
    IContractRepository contracts, IUnitOfWork unitOfWork, TimeProvider time, ILogger<AcceptConsentsUseCase> logger)
{
    public async Task<Result<ContractStepResponse>> ExecuteAsync(Guid contractId, ConsentsRequest request, string ipAddress, string? userAgent, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;

        var now = time.GetUtcNow();
        foreach (var c in request.Consents)
        {
            if (!Enum.TryParse<ConsentDocumentType>(c.DocumentType, true, out var type))
                return Error.Validation("CONSENT_INVALID_TYPE", $"El tipo de documento '{c.DocumentType}' no es válido.");

            var accepted = contract.Accept(type, c.DocumentCode.Trim(), c.DocumentVersion.Trim(),
                Convert.FromHexString(c.ContentSha256), ipAddress, userAgent, now);
            if (accepted.IsFailure) return accepted.Error!;
        }

        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Contrato {ContractId}: {Aceptaciones} aceptaciones registradas desde {Ip}.", contractId, request.Consents.Count, ipAddress);

        return new ContractStepResponse(contract.Id, contract.Status.ToString(),
            contract.HasRequiredConsents ? "Aceptaciones registradas." : "Aún falta aceptar el condicionado general o la política de datos.");
    }
}

public sealed class GetContractUseCase(IContractRepository contracts, IPlanRepository plans)
{
    public async Task<Result<ContractResponse>> ExecuteAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;

        var plan = await plans.GetByIdAsync(contract.PlanId, ct);
        var message = contract.Status == ContractStatus.Rejected ? ScreenContractUseCase.RejectedMessage : null;
        var legalHeirs = contract.Status >= ContractStatus.Declared && contract.Status != ContractStatus.Rejected && contract.Beneficiaries.Count == 0;

        return new ContractResponse(contract.Id, contract.Status.ToString(), contract.Number, plan?.Code ?? string.Empty,
            contract.PremiumAmount, contract.Currency, contract.CoverageFrom, contract.CoverageTo, legalHeirs, contract.CreatedAt, message);
    }
}

/// <summary>Encuestas: comprensión del condicionado (1 a 5) y facilidad de compra (1 a 10). Una de cada tipo por contrato.</summary>
public sealed class SubmitSurveyUseCase(IContractRepository contracts, IUnitOfWork unitOfWork, ILogger<SubmitSurveyUseCase> logger)
{
    public async Task<Result<ContractStepResponse>> ExecuteAsync(Guid contractId, SurveyRequest request, CancellationToken ct)
    {
        if (!Enum.TryParse<SurveyType>(request.Type, true, out var type))
            return Error.Validation("SURVEY_INVALID_TYPE", "El tipo de encuesta debe ser ConditionsComprehension o PurchaseEase.");

        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;
        if (await contracts.SurveyExistsAsync(contractId, type, ct))
            return Error.Conflict("SURVEY_ALREADY_ANSWERED", "Esta encuesta ya fue respondida.");

        var survey = SurveyResponse.Create(contractId, type, request.Score, request.Comment);
        if (survey.IsFailure) return survey.Error!;

        contracts.Add(survey.Value);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Contrato {ContractId}: encuesta {Encuesta} respondida con {Puntaje}.", contractId, type, request.Score);

        return new ContractStepResponse(contract.Id, contract.Status.ToString(), "¡Gracias por tu opinión!");
    }
}
