using System.Text.Json;
using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Microsoft.Extensions.Logging;

namespace Check.Application.Contracts;

/// <summary>
/// Pasa al contratante y al asegurado por SEGIP, AMLC y Archivo Negativo. Cada contrato exige
/// sus propias validaciones. Un error técnico de un servicio no rechaza: el contrato queda en Started para reintentar.
/// </summary>
public sealed class ScreenContractUseCase(
    IContractRepository contracts,
    IComplianceRepository compliance,
    IEventRepository events,
    ISegipClient segip,
    IAmlcClient amlc,
    INegativeFileClient negativeFile,
    IUnitOfWork unitOfWork,
    TimeProvider time,
    ILogger<ScreenContractUseCase> logger)
{
    /// <summary>Mensaje al cliente: no revela qué lista lo rechazó (no alertar al cliente, UIF).</summary>
    public const string RejectedMessage = "No es posible continuar con la compra. Para más información comunícate con Check.";

    public async Task<Result<ContractStepResponse>> ExecuteAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await contracts.GetAsync(contractId, ct);
        if (contract is null) return ContractErrors.NotFound;

        if (contract.Status is ContractStatus.Validated or ContractStatus.Rejected || await compliance.ScreeningsExistAsync(contractId, ct))
            return ScreeningPolicy.AlreadyScreened;
        if (contract.Status != ContractStatus.Started)
            return ContractErrors.InvalidStatus(contract.Status, "validar");

        var today = time.TodayInBolivia();
        var results = new List<(PartyRole Role, Screening Screening)>();

        try
        {
            // Una sola consulta por persona aunque sea contratante y asegurado a la vez
            foreach (var group in contract.Customers.GroupBy(p => p.PersonId))
            {
                var party = group.First();
                var exceptions = await compliance.GetExceptionsAsync(party.PersonId, today, ct);

                foreach (var screening in await ScreenPersonAsync(contract.Id, party, ct))
                {
                    var exception = exceptions.FirstOrDefault(e => e.Provider == screening.Provider && e.IsValidOn(today));
                    if (exception is not null) screening.ApplyException(exception);

                    compliance.Add(screening);
                    results.AddRange(group.Select(member => (member.Role, screening)));
                }
            }
        }
        catch (ExternalServiceException ex)
        {
            logger.LogWarning(ex, "Validación del contrato {ContractId} interrumpida: el servicio {Servicio} no respondió.", contractId, ex.Service);
            return Error.ExternalService("SCREENING_SERVICE_UNAVAILABLE",
                "No pudimos completar la validación de tus datos. Intenta nuevamente en unos minutos.");
        }

        var decision = ScreeningPolicy.Decide(results);
        var transition = decision.IsApproved ? contract.MarkValidated() : contract.Reject(decision.Reason!);
        if (transition.IsFailure) return transition.Error!;

        var now = time.GetUtcNow();
        var whitelisted = results.Count(r => r.Screening.ExceptionId is not null);
        events.Add(ContractEvent.Record(contract.Id,
            decision.IsApproved ? ContractEventType.ScreeningCompleted : ContractEventType.ContractRejected,
            EventPayload.Of(new { approved = decision.IsApproved, reason = decision.Reason, whitelisted }), now));

        await unitOfWork.SaveChangesAsync(ct);

        if (decision.IsApproved)
            logger.LogInformation("Contrato {ContractId} validado: SEGIP, AMLC y Archivo Negativo aptos ({Exceptuadas} con lista blanca).", contractId, whitelisted);
        else
            logger.LogWarning("Contrato {ContractId} rechazado: {Motivo}", contractId, decision.Reason);

        return new ContractStepResponse(contract.Id, contract.Status.ToString(),
            decision.IsApproved ? "Tus datos fueron validados correctamente." : RejectedMessage);
    }

    private async Task<IReadOnlyList<Screening>> ScreenPersonAsync(Guid contractId, ContractParty party, CancellationToken ct)
    {
        var watchlistRequest = new WatchlistRequest(party.DocumentNumber, party.DocumentExtension, party.DocumentComplement);
        var segipRequest = new SegipRequest(
            party.Person.DocumentType == Domain.People.DocumentType.CI, party.PaternalLastname, party.MaternalLastname, party.Names,
            party.DocumentNumber, party.DocumentComplement, party.Birthdate!.Value);

        var requestedAt = time.GetUtcNow();
        var segipTask = segip.VerifyAsync(segipRequest, ct);
        var amlcTask = amlc.SearchAsync(watchlistRequest, ct);
        var negativeTask = negativeFile.SearchAsync(watchlistRequest, ct);
        await Task.WhenAll(segipTask, amlcTask, negativeTask);
        var respondedAt = time.GetUtcNow();

        var s = await segipTask;
        var segipDetail = JsonSerializer.Serialize(new
        {
            s.Exists, s.DocumentNumberMatches, s.DocumentComplementMatches,
            s.PaternalLastnameMatches, s.MaternalLastnameMatches, s.NamesMatches, s.BirthdateMatches
        });

        Screening Watchlist(ScreeningProvider provider, WatchlistResult r) => Screening.Record(
            party.PersonId, contractId, provider, !r.IsListed, null, r.RawResponse,
            r.Items.Select(i => ScreeningItem.Create(i.FoundIn, i.Code, i.Position, i.Entity, i.Year, i.Observation)), requestedAt, respondedAt);

        return
        [
            Screening.Record(party.PersonId, contractId, ScreeningProvider.Segip, s.IsFullMatch, segipDetail, s.RawResponse, [], requestedAt, respondedAt),
            Watchlist(ScreeningProvider.Amlc, await amlcTask),
            Watchlist(ScreeningProvider.NegativeFile, await negativeTask)
        ];
    }
}
