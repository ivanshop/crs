using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Offer;
using Check.Domain.People;
using Microsoft.Extensions.Logging;

namespace Check.Application.Contracts;

public sealed class StartContractUseCase(
    IPlanRepository plans,
    IPlanRulesProvider rulesProvider,
    IPersonRepository people,
    IContractRepository contracts,
    IAgreementRepository agreements,
    IComplianceRepository compliance,
    IEventRepository events,
    ICatalogQueries catalogs,
    IDocumentHasher hasher,
    IContractTokenService tokens,
    IUnitOfWork unitOfWork,
    TimeProvider time,
    ILogger<StartContractUseCase> logger)
{
    public static readonly Error PlanNotFound = Error.NotFound("PLAN_NOT_FOUND", "El plan no existe o no está disponible.");
    public static readonly Error AgreementNotFound = Error.NotFound("AGREEMENT_NOT_FOUND", "El código de convenio no existe.");

    public async Task<Result<StartContractResponse>> ExecuteAsync(StartContractRequest request, string? clientIp, CancellationToken ct)
    {
        var now = time.GetUtcNow();
        var today = time.TodayInBolivia();

        var plan = await plans.GetActiveByCodeAsync(request.PlanCode, ct);
        if (plan is null) return PlanNotFound;

        var rules = await rulesProvider.GetAsync(plan.Id, today, ct);
        if (rules.IsFailure) return PlanNotFound;

        var contractorData = await PartyDataMapper.MapAsync(request.Contractor, "del contratante", catalogs, ct);
        if (contractorData.IsFailure) return contractorData.Error!;

        var insuredData = request.Insured is null
            ? contractorData
            : await PartyDataMapper.MapAsync(request.Insured, "del asegurado", catalogs, ct);
        if (insuredData.IsFailure) return insuredData.Error!;

        Agent? agent = null;
        if (!string.IsNullOrWhiteSpace(request.AgentCode))
        {
            agent = await people.GetAgentByCodeAsync(request.AgentCode.Trim().ToUpperInvariant(), ct);
            if (agent is null || !agent.IsValidOn(today)) return ContractErrors.AgentNotValid;
        }

        var terms = ContractTerms.FromPlan(rules.Value);
        if (!string.IsNullOrWhiteSpace(request.AgreementCode))
        {
            var agreement = await agreements.GetByCodeAsync(request.AgreementCode.Trim().ToUpperInvariant(), ct);
            if (agreement is null) return AgreementNotFound;
            var usable = agreement.CanBeUsed(plan.Id, today, await agreements.CountUsedAsync(agreement.Id, ct));
            if (usable.IsFailure) return usable.Error!;
            terms = agreement.Terms;
        }

        var contractorIsInsured = contractorData.Value.Document.CanonicalKey == insuredData.Value.Document.CanonicalKey;
        var contractor = await FindOrCreateAsync(contractorData.Value, ct);
        var insured = contractorIsInsured ? contractor : await FindOrCreateAsync(insuredData.Value, ct);

        var hasActive = await contracts.HasActiveOfProductAsync(insured.Id, plan.ProductId, now, ct);
        var eligibility = EligibilityPolicy.Check(rules.Value, contractorData.Value, insuredData.Value,
            contractorIsInsured, hasActive, agent is not null, today);
        if (eligibility.IsFailure) return eligibility.Error!;

        var details = await ValidateDetailsAsync(plan.ProductId, request.Details, ct);
        if (details.IsFailure) return details.Error!;

        var contract = Contract.Start(plan.Id, terms, contractor, contractorData.Value,
            insured, insuredData.Value, agent, details.Value, clientIp, now);
        contracts.Add(contract);
        events.Add(ContractEvent.Record(contract.Id, ContractEventType.ContractStarted,
            EventPayload.Of(new { planCode = plan.Code, channel = contract.Channel.ToString(), agentCode = agent?.Code, agreementCode = request.AgreementCode }), now));

        await LinkReadingAsync(request.Contractor, contractor, contract.Id, ct);
        if (request.Insured is not null && !contractorIsInsured)
            await LinkReadingAsync(request.Insured, insured, contract.Id, ct);

        await unitOfWork.SaveChangesAsync(ct);

        logger.LogInformation("Contrato {ContractId} iniciado para el plan {PlanCode} por el canal {Canal}.", contract.Id, plan.Code, contract.Channel);

        var token = tokens.Issue(contract.Id);
        return new StartContractResponse(contract.Id, contract.Status.ToString(), contract.PremiumAmount, contract.Currency, token.Value, token.ExpiresAt);
    }

    /// <summary>Reutiliza la persona por su documento y actualiza sus datos actuales, o la crea.</summary>
    private async Task<Person> FindOrCreateAsync(PartyData data, CancellationToken ct)
    {
        var hash = hasher.Hash(data.Document);
        var person = await people.GetByDocumentHashAsync(hash, ct);
        if (person is null)
        {
            person = Person.Create(data, hash);
            people.Add(person);
        }
        else
        {
            person.Update(data);
        }
        return person;
    }

    /// <summary>Vincula la lectura de LlamitAI y anota qué campos difieren de lo declarado (sin valores).</summary>
    private async Task LinkReadingAsync(PersonalDataRequest declared, Person person, Guid contractId, CancellationToken ct)
    {
        if (declared.IdentityReadingId is not { } readingId) return;
        var reading = await compliance.GetReadingAsync(readingId, ct);
        if (reading is null || reading.Status != IdentityReadingStatus.Completed || reading.ContractId is not null) return;

        reading.LinkTo(person.Id, contractId, IdentityComparer.Differences(reading.ExtractedFields, declared));
    }

    private async Task<Result<IReadOnlyDictionary<long, string>>> ValidateDetailsAsync(
        long productId, Dictionary<string, string>? values, CancellationToken ct)
    {
        values ??= [];
        var definitions = await plans.GetFieldsAsync(productId, ct);

        var unknown = values.Keys.FirstOrDefault(k => definitions.All(d => !string.Equals(d.Code, k, StringComparison.OrdinalIgnoreCase)));
        if (unknown is not null)
            return Error.Validation("FIELD_UNKNOWN", $"El campo '{unknown}' no corresponde a este producto.");

        var result = new Dictionary<long, string>();
        foreach (var definition in definitions)
        {
            var value = values.FirstOrDefault(v => string.Equals(v.Key, definition.Code, StringComparison.OrdinalIgnoreCase)).Value?.Trim();

            var validation = definition.Validate(value);
            if (validation.IsFailure) return validation.Error!;
            if (string.IsNullOrEmpty(value)) continue;

            if (definition.DataType == FieldDataType.Option &&
                !await catalogs.CatalogOptionExistsAsync(definition.CatalogTopic!, value, ct))
                return Error.Validation("FIELD_INVALID_OPTION", $"El valor '{value}' no es una opción válida para '{definition.Label}'.");

            result[definition.Id] = value;
        }
        return result;
    }
}
