using Check.Application.Common;
using Check.Application.Abstractions;
using Check.Domain.Common;

namespace Check.Application.Catalog;

public sealed class GetProductsUseCase(ICatalogQueries queries, ProductAssembler assembler, CatalogCache cache, TimeProvider time)
{
    public async Task<Result<IReadOnlyList<ProductResponse>>> ExecuteAsync(CancellationToken ct)
    {
        var today = time.TodayInBolivia();
        var response = await cache.GetOrAddAsync<IReadOnlyList<ProductResponse>>($"products|{today:yyyy-MM-dd}", async () =>
        {
            var products = await queries.GetActiveProductsAsync(null, ct);
            var built = new List<ProductResponse>();
            foreach (var product in products)
            {
                var item = await assembler.BuildAsync(product, today, ct);
                if (item.Plans.Count > 0) built.Add(item);
            }
            return built;
        });
        return Result.Success(response);
    }
}
