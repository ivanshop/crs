using Check.Application.Abstractions;
using Check.Domain.Common;

namespace Check.Application.Catalog;

public sealed class GetCatalogUseCase(ICatalogQueries queries)
{
    public async Task<Result<IReadOnlyList<CatalogItemResponse>>> ExecuteAsync(string topic, CancellationToken ct)
    {
        var items = await queries.GetCatalogAsync(topic, ct);
        if (items.Count == 0)
            return Error.NotFound("CATALOG_NOT_FOUND", $"El catálogo '{topic}' no existe.");
        return items.Select(i => new CatalogItemResponse(i.Code, i.Value)).ToList();
    }
}

public sealed class GetRelationshipsUseCase(ICatalogQueries queries)
{
    public async Task<Result<IReadOnlyList<RelationshipResponse>>> ExecuteAsync(CancellationToken ct) =>
        (await queries.GetRelationshipsAsync(ct)).Select(r => new RelationshipResponse(r.Code, r.Name, r.IsUnique)).ToList();
}
