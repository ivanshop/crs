using Check.Application.Abstractions;
using Check.Domain.Common;

namespace Check.Application.Catalog;

public sealed class GetFaqsUseCase(ICatalogQueries queries)
{
    public async Task<Result<IReadOnlyList<FaqResponse>>> ExecuteAsync(string? productCode, CancellationToken ct)
    {
        var faqs = await queries.GetFaqsAsync(productCode, ct);
        return faqs.Select(f => new FaqResponse(f.ProductCode, f.Question, f.Answer)).ToList();
    }
}
