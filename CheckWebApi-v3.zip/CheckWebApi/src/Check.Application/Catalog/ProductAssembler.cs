using Check.Application.Abstractions;
using Microsoft.Extensions.Logging;

namespace Check.Application.Catalog;

/// <summary>Une el catálogo con las reglas vigentes de cada plan. Omite planes no vendibles.</summary>
public sealed class ProductAssembler(IPlanRulesProvider rulesProvider, ILogger<ProductAssembler> logger)
{
    public async Task<ProductResponse> BuildAsync(ProductRow product, DateOnly today, CancellationToken ct)
    {
        var plans = new List<PlanResponse>();
        foreach (var plan in product.Plans)
        {
            var rules = await rulesProvider.GetAsync(plan.Id, today, ct);
            if (rules.IsFailure)
            {
                logger.LogWarning("El plan {PlanCode} se omite del catálogo: {Motivo}", plan.Code, rules.Error!.Message);
                continue;
            }

            var r = rules.Value;
            plans.Add(new PlanResponse(
                plan.Code, plan.Name, plan.Description,
                r.Premium.Amount, r.Premium.Currency, r.DurationDays, r.MinAge, r.MaxAge, r.MaxBeneficiaries,
                plan.Coverages.Select(c => new CoverageResponse(c.Name, c.Type, c.InsuredAmount, c.Currency, c.Description)).ToList(),
                plan.Assistances.Select(a => new AssistanceResponse(a.Name, a.Service, a.Description)).ToList(),
                plan.Exclusions));
        }

        return new ProductResponse(
            product.Code, product.Name, product.Description, plans,
            product.ContractFields.Select(f => new ContractFieldResponse(f.Code, f.Label, f.DataType, f.CatalogTopic, f.IsRequired, f.MaxLength)).ToList());
    }
}
