namespace Check.Application.Catalog;

public sealed record ProductResponse(
    string Code,
    string Name,
    string? Description,
    IReadOnlyList<PlanResponse> Plans,
    IReadOnlyList<ContractFieldResponse> ContractFields);

public sealed record PlanResponse(
    string Code,
    string Name,
    string? Description,
    decimal Premium,
    string Currency,
    int DurationDays,
    int MinAge,
    int MaxAge,
    int MaxBeneficiaries,
    IReadOnlyList<CoverageResponse> Coverages,
    IReadOnlyList<AssistanceResponse> Assistances,
    IReadOnlyList<string> Exclusions);

public sealed record CoverageResponse(string Name, string Type, decimal? InsuredAmount, string? Currency, string Description);
public sealed record AssistanceResponse(string Name, string Service, string Description);
public sealed record ContractFieldResponse(string Code, string Label, string DataType, string? CatalogTopic, bool IsRequired, int? MaxLength);
public sealed record FaqResponse(string ProductCode, string Question, string Answer);
public sealed record CatalogItemResponse(string Code, string Value);
public sealed record RelationshipResponse(string Code, string Name, bool IsUnique);
