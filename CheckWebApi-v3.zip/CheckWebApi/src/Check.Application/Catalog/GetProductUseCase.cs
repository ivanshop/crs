using Check.Application.Common;
using Check.Application.Abstractions;
using Check.Domain.Common;

namespace Check.Application.Catalog;

public sealed class GetProductUseCase(ICatalogQueries queries, ProductAssembler assembler, TimeProvider time)
{
    public static readonly Error NotFound = Error.NotFound("PRODUCT_NOT_FOUND", "El producto no existe o no está disponible.");

    public async Task<Result<ProductResponse>> ExecuteAsync(string code, CancellationToken ct)
    {
        var today = time.TodayInBolivia();
        var product = (await queries.GetActiveProductsAsync(code, ct)).FirstOrDefault();
        if (product is null) return NotFound;

        var built = await assembler.BuildAsync(product, today, ct);
        return built.Plans.Count > 0 ? built : NotFound;
    }
}
