using System.Collections.Concurrent;
using Check.Application.Abstractions;

namespace Check.Application.Catalog;

/// <summary>
/// Caché en memoria del catálogo armado (productos con sus reglas vigentes).
/// El catálogo cambia pocas veces al día y era la operación más costosa en la prueba de estrés:
/// cada consulta recalculaba las reglas de todos los planes.
/// </summary>
public sealed class CatalogCache(FlowSettings settings, TimeProvider time)
{
    private readonly ConcurrentDictionary<string, (DateTimeOffset Expires, object Value)> _entries = new();

    public async Task<T> GetOrAddAsync<T>(string key, Func<Task<T>> factory)
    {
        var now = time.GetUtcNow();
        if (_entries.TryGetValue(key, out var hit) && hit.Expires > now) return (T)hit.Value;

        var value = await factory();
        if (settings.CatalogCacheSeconds > 0)
            _entries[key] = (now.AddSeconds(settings.CatalogCacheSeconds), value!);
        return value;
    }
}
