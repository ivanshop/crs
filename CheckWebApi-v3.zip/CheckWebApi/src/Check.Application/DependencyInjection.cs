using Check.Application.Catalog;
using Check.Application.Compliance;
using Check.Application.Contracts;
using Check.Application.Internal;
using Check.Application.Payments;
using Microsoft.Extensions.DependencyInjection;

namespace Check.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddSingleton(TimeProvider.System);

        // Catálogo
        services.AddScoped<ProductAssembler>();
        services.AddSingleton<CatalogCache>();
        services.AddScoped<GetProductsUseCase>();
        services.AddScoped<GetProductUseCase>();
        services.AddScoped<GetFaqsUseCase>();
        services.AddScoped<GetCatalogUseCase>();
        services.AddScoped<GetRelationshipsUseCase>();

        // Flujo de contratación
        services.AddScoped<ReadIdentityUseCase>();
        services.AddScoped<StartContractUseCase>();
        services.AddScoped<ScreenContractUseCase>();
        services.AddScoped<DeclareUseCase>();
        services.AddScoped<AcceptConsentsUseCase>();
        services.AddScoped<SendOtpUseCase>();
        services.AddScoped<VerifyOtpUseCase>();
        services.AddScoped<GenerateQrUseCase>();
        services.AddScoped<ContractActivator>();
        services.AddScoped<ProcessPaymentNotificationUseCase>();
        services.AddScoped<GetContractUseCase>();
        services.AddScoped<SubmitSurveyUseCase>();

        // Operación interna y tareas en segundo plano
        services.AddScoped<ConfirmPaymentManuallyUseCase>();
        services.AddScoped<ContractEventsUseCase>();
        services.AddScoped<PublishPendingEventsUseCase>();
        services.AddScoped<HousekeepingUseCase>();
        services.AddScoped<CreateScreeningExceptionUseCase>();
        services.AddScoped<AgenciesUseCase>();
        services.AddScoped<AgreementsUseCase>();

        return services;
    }
}
