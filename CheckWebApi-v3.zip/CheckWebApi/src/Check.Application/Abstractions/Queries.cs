namespace Check.Application.Abstractions;

/// <summary>Lecturas del catálogo y de las tablas de referencia (proyecciones directas, sin entidades).</summary>
public interface ICatalogQueries
{
    Task<IReadOnlyList<ProductRow>> GetActiveProductsAsync(string? productCode, CancellationToken ct);
    Task<IReadOnlyList<FaqRow>> GetFaqsAsync(string? productCode, CancellationToken ct);
    /// <summary>Lista simple por tema. El tema "country" lee core.countries.</summary>
    Task<IReadOnlyList<CatalogItemRow>> GetCatalogAsync(string topic, CancellationToken ct);
    Task<bool> CatalogOptionExistsAsync(string topic, string code, CancellationToken ct);
    Task<short?> GetCountryIdAsync(string isoCode, CancellationToken ct);
    Task<IReadOnlyList<RelationshipRow>> GetRelationshipsAsync(CancellationToken ct);
}

public sealed record ProductRow(
    long Id, string Code, string Name, string? Description,
    IReadOnlyList<PlanRow> Plans,
    IReadOnlyList<FieldRow> ContractFields);

public sealed record PlanRow(
    long Id, string Code, string Name, string? Description,
    IReadOnlyList<CoverageRow> Coverages,
    IReadOnlyList<AssistanceRow> Assistances,
    IReadOnlyList<string> Exclusions);

public sealed record CoverageRow(string Name, string Type, decimal? InsuredAmount, string? Currency, string Description);
public sealed record AssistanceRow(string Name, string Service, string Description);
public sealed record FieldRow(string Code, string Label, string DataType, string? CatalogTopic, bool IsRequired, int? MaxLength);
public sealed record FaqRow(string ProductCode, string Question, string Answer);
public sealed record CatalogItemRow(string Code, string Value);
public sealed record RelationshipRow(long Id, string Code, string Name, bool IsUnique, short? PepDegree);
