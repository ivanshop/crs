using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.Offer;
using Check.Domain.Payments;
using Check.Domain.People;

namespace Check.Application.Abstractions;

public interface IUnitOfWork
{
    Task SaveChangesAsync(CancellationToken ct);
}

public interface IPlanRepository
{
    /// <summary>Plan activo de un producto activo, con su producto.</summary>
    Task<Plan?> GetActiveByCodeAsync(string code, CancellationToken ct);
    Task<Plan?> GetByIdAsync(long id, CancellationToken ct);
    Task<IReadOnlyList<ContractFieldDefinition>> GetFieldsAsync(long productId, CancellationToken ct);
}

public interface IPersonRepository
{
    Task<Person?> GetByDocumentHashAsync(byte[] documentHash, CancellationToken ct);
    void Add(Person person);

    Task<Agency?> GetAgencyByCodeAsync(string code, CancellationToken ct);
    /// <summary>Agente con su persona y su agencia.</summary>
    Task<Agent?> GetAgentByCodeAsync(string code, CancellationToken ct);
    void Add(Agency agency);
    void Add(Agent agent);
}

public interface IContractRepository
{
    /// <summary>Contrato con partes, detalles, beneficiarios y aceptaciones.</summary>
    Task<Contract?> GetAsync(Guid id, CancellationToken ct);
    void Add(Contract contract);
    /// <summary>¿El asegurado tiene una póliza vigente de cualquier plan de este producto?</summary>
    Task<bool> HasActiveOfProductAsync(Guid insuredPersonId, long productId, DateTimeOffset now, CancellationToken ct);
    Task<bool> SurveyExistsAsync(Guid contractId, SurveyType type, CancellationToken ct);
    void Add(SurveyResponse survey);
}

public interface IComplianceRepository
{
    Task<bool> ScreeningsExistAsync(Guid contractId, CancellationToken ct);
    Task<IReadOnlyList<ScreeningException>> GetExceptionsAsync(Guid personId, DateOnly date, CancellationToken ct);
    void Add(Screening screening);
    void Add(ScreeningException exception);

    /// <summary>Declaración PEP vigente de la persona, con familiares y socios.</summary>
    Task<PepDeclaration?> GetCurrentPepAsync(Guid personId, CancellationToken ct);
    void Add(PepDeclaration declaration);

    Task<IdentityReading?> GetReadingAsync(Guid id, CancellationToken ct);
    void Add(IdentityReading reading);
}

public interface IPaymentRepository
{
    Task<OtpChallenge?> GetLatestOtpAsync(Guid contractId, CancellationToken ct);
    Task<int> CountOtpsAsync(Guid contractId, CancellationToken ct);
    void Add(OtpChallenge challenge);

    Task<QrPayment?> GetQrAsync(Guid id, CancellationToken ct);
    Task<QrPayment?> GetPendingQrAsync(Guid contractId, CancellationToken ct);
    Task<bool> NotificationAppliedAsync(string bankTransactionId, CancellationToken ct);
    void Add(QrPayment payment);
    void Add(PaymentNotification notification);
}

public interface IEventRepository
{
    Task<ContractEvent?> GetAsync(Guid id, CancellationToken ct);
    Task<ContractEvent?> GetLatestAsync(Guid contractId, ContractEventType type, CancellationToken ct);
    Task<IReadOnlyList<ContractEvent>> GetByContractAsync(Guid contractId, CancellationToken ct);
    /// <summary>Eventos Pending cuyo próximo intento ya venció, los más antiguos primero.</summary>
    Task<IReadOnlyList<ContractEvent>> GetDueAsync(DateTimeOffset now, int batchSize, CancellationToken ct);
    void Add(ContractEvent contractEvent);
}

/// <summary>Tareas periódicas en bloque (sin cargar entidades).</summary>
public interface IAgreementRepository
{
    Task<Company?> GetCompanyByTaxIdAsync(string taxId, CancellationToken ct);
    void Add(Company company);
    /// <summary>Convenio con su empresa y su plan (y el producto del plan).</summary>
    Task<Agreement?> GetByCodeAsync(string code, CancellationToken ct);
    /// <summary>Personas que ya usaron el convenio: contratos pagados (Active o Expired).</summary>
    Task<int> CountUsedAsync(Guid agreementId, CancellationToken ct);
    void Add(Agreement agreement);
}

public interface IMaintenanceRepository
{
    Task<int> ExpireQrPaymentsAsync(DateTimeOffset now, CancellationToken ct);
    Task<int> AbandonContractsAsync(DateTimeOffset inactiveSince, CancellationToken ct);
    Task<int> ExpireContractsAsync(DateTimeOffset now, CancellationToken ct);
}
