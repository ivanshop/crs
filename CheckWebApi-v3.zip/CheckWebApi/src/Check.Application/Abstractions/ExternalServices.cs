namespace Check.Application.Abstractions;

/// <summary>Falla técnica de un servicio externo (timeout, caída). No es un rechazo.</summary>
public sealed class ExternalServiceException(string service, string message, Exception? inner = null)
    : Exception(message, inner)
{
    public string Service { get; } = service;
}

// ---------- SEGIP ----------

public sealed record SegipRequest(
    bool IsBolivian,
    string? PaternalLastname,
    string? MaternalLastname,
    string Names,
    string DocumentNumber,
    string? DocumentComplement,
    DateOnly Birthdate);

public sealed record SegipResult(
    bool Exists,
    bool DocumentNumberMatches,
    bool DocumentComplementMatches,
    bool PaternalLastnameMatches,
    bool MaternalLastnameMatches,
    bool NamesMatches,
    bool BirthdateMatches,
    string RawResponse)
{
    public bool IsFullMatch => Exists && DocumentNumberMatches && DocumentComplementMatches &&
                               PaternalLastnameMatches && MaternalLastnameMatches && NamesMatches && BirthdateMatches;
}

public interface ISegipClient
{
    Task<SegipResult> VerifyAsync(SegipRequest request, CancellationToken ct);
}

// ---------- AMLC y Archivo Negativo ----------

public sealed record WatchlistRequest(string DocumentNumber, string? DocumentExtension, string? DocumentComplement);

public sealed record WatchlistItem(string FoundIn, string? Code, string? Position, string? Entity, string? Year, string? Observation);

public sealed record WatchlistResult(IReadOnlyList<WatchlistItem> Items, string RawResponse)
{
    public bool IsListed => Items.Count > 0;
}

/// <summary>AMLC: listas internacionales (servicio WCF).</summary>
public interface IAmlcClient
{
    Task<WatchlistResult> SearchAsync(WatchlistRequest request, CancellationToken ct);
}

/// <summary>Archivo Negativo (servicio REST).</summary>
public interface INegativeFileClient
{
    Task<WatchlistResult> SearchAsync(WatchlistRequest request, CancellationToken ct);
}
