using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Domain.Payments;
using Check.Domain.People;

namespace Check.Application.Abstractions;

/// <summary>HMAC con llave secreta: buscar personas sin descifrar y guardar códigos OTP sin exponerlos.</summary>
public interface IDocumentHasher
{
    byte[] Hash(IdentityDocument document);
    byte[] Hash(string value);
}

/// <summary>Reglas tipadas de un plan a una fecha.</summary>
public interface IPlanRulesProvider
{
    Task<Result<PlanRules>> GetAsync(long planId, DateOnly date, CancellationToken ct);
}

/// <summary>Token corto que da acceso a un solo contrato.</summary>
public interface IContractTokenService
{
    AccessToken Issue(Guid contractId);
}

public sealed record AccessToken(string Value, DateTimeOffset ExpiresAt);

/// <summary>Quién ejecuta la acción (para auditoría).</summary>
public interface ICurrentUser
{
    string Name { get; }
}

/// <summary>Envío del código OTP por SMS, WhatsApp o correo.</summary>
public interface IOtpSender
{
    Task SendAsync(OtpChannel channel, string destination, string code, CancellationToken ct);
}

public sealed record QrRequest(Guid QrPaymentId, decimal Amount, string Currency, DateTimeOffset ExpiresAt, bool SingleUse, string Description);
public sealed record QrResult(string? BankTransactionId, string QrImageBase64);

/// <summary>Generación del QR en el Banco.</summary>
public interface IBankQrClient
{
    Task<QrResult> GenerateAsync(QrRequest request, CancellationToken ct);
}

public sealed record OcrResult(string Text, IReadOnlyDictionary<string, string> Fields, string RawResponse);

/// <summary>LlamitAI: OCR del anverso y reverso del carnet.</summary>
public interface IIdentityOcrClient
{
    Task<OcrResult> ReadAsync(byte[] frontImage, byte[] backImage, CancellationToken ct);
}

/// <summary>Almacén privado de las fotos del carnet. Devuelve la ruta guardada.</summary>
public interface IIdentityImageStore
{
    Task<string> SaveAsync(Guid readingId, string side, byte[] content, string extension, CancellationToken ct);
}

/// <summary>Publicación de un evento en una cola de Azure Service Bus.</summary>
public interface IEventBus
{
    Task PublishAsync(string queue, Guid messageId, string subject, string payloadJson, CancellationToken ct);
}

/// <summary>Parámetros del flujo que no dependen del plan (sección "Flow" de appsettings).</summary>
public sealed class FlowSettings
{
    public int OtpLifetimeMinutes { get; init; } = 5;
    public int OtpMaxAttempts { get; init; } = 3;
    /// <summary>Máximo de códigos que se pueden pedir por contrato.</summary>
    public int OtpMaxSends { get; init; } = 5;
    public int OtpResendSeconds { get; init; } = 60;
    /// <summary>Horas sin avance para marcar un contrato como abandonado.</summary>
    public int AbandonAfterHours { get; init; } = 24;
    public int EventMaxAttempts { get; init; } = 8;
    public int EventBatchSize { get; init; } = 20;
    public int MaxIdentityImageKb { get; init; } = 5120;
    /// <summary>Segundos que se reutiliza el catálogo armado; 0 lo desactiva.</summary>
    public int CatalogCacheSeconds { get; init; } = 60;
}
