namespace Check.Application.Common;

/// <summary>Fechas de negocio en hora de Bolivia (edades, vigencias), sin depender del servidor.</summary>
public static class BoliviaClock
{
    public static readonly TimeZoneInfo Zone = TimeZoneInfo.FindSystemTimeZoneById("America/La_Paz");

    public static DateOnly TodayInBolivia(this TimeProvider time) =>
        DateOnly.FromDateTime(TimeZoneInfo.ConvertTime(time.GetUtcNow(), Zone).DateTime);
}
