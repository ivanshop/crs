using System.Globalization;
using System.Text;
using System.Text.Json;
using Check.Application.Contracts;

namespace Check.Application.Common;

internal static class EventPayload
{
    public static string Of(object value) => JsonSerializer.Serialize(value, JsonSerializerOptions.Web);
}

/// <summary>Compara lo que leyó LlamitAI con lo que declaró el cliente. Devuelve solo nombres de campos.</summary>
internal static class IdentityComparer
{
    public static IReadOnlyList<string> Differences(string? extractedFieldsJson, PersonalDataRequest declared)
    {
        if (string.IsNullOrEmpty(extractedFieldsJson)) return [];
        var read = JsonSerializer.Deserialize<Dictionary<string, string>>(extractedFieldsJson) ?? [];

        var expected = new Dictionary<string, string?>
        {
            ["documentNumber"] = declared.DocumentNumber,
            ["names"] = declared.Names,
            ["paternalLastname"] = declared.PaternalLastname,
            ["maternalLastname"] = declared.MaternalLastname,
            ["birthdate"] = declared.Birthdate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
        };

        return expected
            .Where(e => read.TryGetValue(e.Key, out var value) && Normalize(value) != Normalize(e.Value))
            .Select(e => e.Key)
            .ToList();
    }

    private static string Normalize(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        var sb = new StringBuilder();
        foreach (var c in value.Trim().ToUpperInvariant().Normalize(NormalizationForm.FormD))
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return string.Join(' ', sb.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries));
    }
}
