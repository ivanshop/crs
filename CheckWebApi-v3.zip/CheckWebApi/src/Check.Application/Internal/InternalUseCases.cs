using System.ComponentModel.DataAnnotations;
using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Application.Contracts;
using Check.Application.Payments;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Events;
using Check.Domain.People;
using Microsoft.Extensions.Logging;

namespace Check.Application.Internal;

// Casos de uso para operadores internos (soporte, Cumplimiento, administración comercial).

public sealed class ManualPaymentRequest
{
    [Required(ErrorMessage = "El identificador de la transacción del Banco es obligatorio.")]
    public string TransactionId { get; init; } = null!;

    [Required(ErrorMessage = "Debes justificar la conciliación manual.")]
    [StringLength(500, MinimumLength = 10, ErrorMessage = "La justificación debe tener entre 10 y 500 caracteres.")]
    public string Reason { get; init; } = null!;
}

/// <summary>Conciliación manual: el Banco no avisó, pero el pago consta en sus registros.</summary>
public sealed class ConfirmPaymentManuallyUseCase(
    IPaymentRepository payments, ContractActivator activator, ICurrentUser user, IUnitOfWork unitOfWork,
    TimeProvider time, ILogger<ConfirmPaymentManuallyUseCase> logger)
{
    public async Task<Result<PaymentNotificationResponse>> ExecuteAsync(Guid qrPaymentId, ManualPaymentRequest request, CancellationToken ct)
    {
        var qr = await payments.GetQrAsync(qrPaymentId, ct);
        if (qr is null) return Error.NotFound("QR_NOT_FOUND", "El QR no existe.");

        var confirmed = qr.ConfirmManually(request.TransactionId.Trim(), user.Name, request.Reason, time.GetUtcNow());
        if (confirmed.IsFailure) return confirmed.Error!;

        var activated = await activator.ActivateAsync(qr, ct);
        if (activated.IsFailure) return activated.Error!;

        await unitOfWork.SaveChangesAsync(ct);
        logger.LogWarning("Pago del QR {QrPaymentId} conciliado manualmente por {Operador}: {Motivo}", qrPaymentId, user.Name, request.Reason);
        return new PaymentNotificationResponse("Applied", "Pago conciliado y contrato activado.");
    }
}

public sealed record EventResponse(Guid EventId, Guid ContractId, string Type, string? Queue, string Status, int Attempts,
    DateTimeOffset CreatedAt, DateTimeOffset? PublishedAt, DateTimeOffset? CompletedAt, string? LastError);

public sealed class EventConfirmationRequest
{
    public bool Succeeded { get; init; }
    [StringLength(2000, ErrorMessage = "El error no puede superar 2000 caracteres.")]
    public string? Error { get; init; }
}

/// <summary>Bitácora del contrato, reenvíos y confirmación de los consumidores (correo, DocumentEngine).</summary>
public sealed class ContractEventsUseCase(IEventRepository events, IUnitOfWork unitOfWork, TimeProvider time, ILogger<ContractEventsUseCase> logger)
{
    public async Task<Result<IReadOnlyList<EventResponse>>> ListAsync(Guid contractId, CancellationToken ct) =>
        (await events.GetByContractAsync(contractId, ct)).Select(Map).ToList();

    /// <summary>Vuelve a encolar el último correo de bienvenida o la última Carpeta de Cliente.</summary>
    public async Task<Result<EventResponse>> ResendAsync(Guid contractId, string type, CancellationToken ct)
    {
        if (!Enum.TryParse<ContractEventType>(type, true, out var eventType) ||
            eventType is not (ContractEventType.WelcomeEmail or ContractEventType.ClientFolder))
            return Error.Validation("EVENT_INVALID_TYPE", "Solo se puede reenviar WelcomeEmail o ClientFolder.");

        var contractEvent = await events.GetLatestAsync(contractId, eventType, ct);
        if (contractEvent is null)
            return Error.NotFound("EVENT_NOT_FOUND", "El contrato aún no tiene ese evento: todavía no fue pagado.");

        var requeued = contractEvent.Requeue(time.GetUtcNow());
        if (requeued.IsFailure) return requeued.Error!;

        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Evento {EventId} ({Tipo}) del contrato {ContractId} reencolado.", contractEvent.Id, eventType, contractId);
        return Map(contractEvent);
    }

    public async Task<Result<EventResponse>> ConfirmAsync(Guid eventId, EventConfirmationRequest request, CancellationToken ct)
    {
        var contractEvent = await events.GetAsync(eventId, ct);
        if (contractEvent is null) return Error.NotFound("EVENT_NOT_FOUND", "El evento no existe.");

        var confirmed = contractEvent.Confirm(request.Succeeded, request.Error, time.GetUtcNow());
        if (confirmed.IsFailure) return confirmed.Error!;

        await unitOfWork.SaveChangesAsync(ct);
        if (request.Succeeded)
            logger.LogInformation("Evento {EventId} ({Tipo}) del contrato {ContractId} completado por su consumidor.", eventId, contractEvent.Type, contractEvent.ContractId);
        else
            logger.LogError("Evento {EventId} ({Tipo}) del contrato {ContractId} falló en su consumidor: {Error}", eventId, contractEvent.Type, contractEvent.ContractId, request.Error);
        return Map(contractEvent);
    }

    private static EventResponse Map(ContractEvent e) => new(e.Id, e.ContractId, e.Type.ToString(), e.Queue, e.Status.ToString(),
        e.Attempts, e.CreatedAt, e.PublishedAt, e.CompletedAt, e.LastError);
}

/// <summary>Publica en Service Bus los eventos pendientes. Lo llama el servicio en segundo plano.</summary>
public sealed class PublishPendingEventsUseCase(
    IEventRepository events, IEventBus bus, FlowSettings settings, IUnitOfWork unitOfWork, TimeProvider time,
    ILogger<PublishPendingEventsUseCase> logger)
{
    public async Task<int> ExecuteAsync(CancellationToken ct)
    {
        var due = await events.GetDueAsync(time.GetUtcNow(), settings.EventBatchSize, ct);
        foreach (var contractEvent in due)
        {
            try
            {
                await bus.PublishAsync(contractEvent.Queue!, contractEvent.Id, contractEvent.Type.ToString(), contractEvent.Payload, ct);
                contractEvent.MarkPublished(time.GetUtcNow());
                logger.LogInformation("Evento {EventId} ({Tipo}) del contrato {ContractId} publicado en {Cola}.",
                    contractEvent.Id, contractEvent.Type, contractEvent.ContractId, contractEvent.Queue);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                contractEvent.MarkPublishFailed(ex.Message, time.GetUtcNow(), settings.EventMaxAttempts);
                logger.LogError(ex, "No se pudo publicar el evento {EventId} ({Tipo}) en {Cola}; intento {Intento}.",
                    contractEvent.Id, contractEvent.Type, contractEvent.Queue, contractEvent.Attempts);
            }
            await unitOfWork.SaveChangesAsync(ct); // uno por uno: un fallo no revierte los ya publicados
        }
        return due.Count;
    }
}

/// <summary>Vence QR, abandona contratos sin avance y cierra coberturas terminadas.</summary>
public sealed class HousekeepingUseCase(IMaintenanceRepository maintenance, FlowSettings settings, TimeProvider time, ILogger<HousekeepingUseCase> logger)
{
    public async Task ExecuteAsync(CancellationToken ct)
    {
        var now = time.GetUtcNow();
        var qrs = await maintenance.ExpireQrPaymentsAsync(now, ct);
        var abandoned = await maintenance.AbandonContractsAsync(now.AddHours(-settings.AbandonAfterHours), ct);
        var expired = await maintenance.ExpireContractsAsync(now, ct);
        if (qrs + abandoned + expired > 0)
            logger.LogInformation("Mantenimiento: {QrVencidos} QR vencidos, {Abandonados} contratos abandonados, {Vencidos} coberturas terminadas.", qrs, abandoned, expired);
    }
}

public sealed class ScreeningExceptionRequest
{
    [Required(ErrorMessage = "Los datos del documento son obligatorios.")]
    public string DocumentType { get; init; } = "CI";
    [Required(ErrorMessage = "El número de documento es obligatorio.")]
    public string DocumentNumber { get; init; } = null!;
    public string? DocumentComplement { get; init; }
    public string? DocumentExtension { get; init; }

    /// <summary>Amlc o NegativeFile.</summary>
    [Required(ErrorMessage = "El proveedor es obligatorio.")]
    public string Provider { get; init; } = null!;
    [Required(ErrorMessage = "El motivo es obligatorio.")]
    public string Reason { get; init; } = null!;
    public DateOnly? ValidFrom { get; init; }
    [Required(ErrorMessage = "La fecha de fin de vigencia es obligatoria.")]
    public DateOnly? ValidUntil { get; init; }
}

public sealed record CreatedResponse(string Id, string Message);

/// <summary>Lista blanca: Cumplimiento exceptúa a una persona ya registrada de AMLC o Archivo Negativo.</summary>
public sealed class CreateScreeningExceptionUseCase(
    IPersonRepository people, IComplianceRepository compliance, IDocumentHasher hasher, ICurrentUser user,
    IUnitOfWork unitOfWork, TimeProvider time, ILogger<CreateScreeningExceptionUseCase> logger)
{
    public async Task<Result<CreatedResponse>> ExecuteAsync(ScreeningExceptionRequest request, CancellationToken ct)
    {
        if (!Enum.TryParse<DocumentType>(request.DocumentType, true, out var documentType))
            return Error.Validation("DOCUMENT_INVALID_TYPE", "El tipo de documento debe ser CI o CE.");
        if (!Enum.TryParse<ScreeningProvider>(request.Provider, true, out var provider))
            return Error.Validation("EXCEPTION_INVALID_PROVIDER", "El proveedor debe ser Amlc o NegativeFile.");

        var document = IdentityDocument.Create(documentType, request.DocumentNumber, request.DocumentComplement, request.DocumentExtension);
        if (document.IsFailure) return document.Error!;

        var person = await people.GetByDocumentHashAsync(hasher.Hash(document.Value), ct);
        if (person is null)
            return Error.NotFound("PERSON_NOT_FOUND", "La persona aún no está registrada: debe haber iniciado al menos una compra.");

        var exception = ScreeningException.Create(person.Id, provider, request.Reason, user.Name,
            request.ValidFrom ?? time.TodayInBolivia(), request.ValidUntil!.Value);
        if (exception.IsFailure) return exception.Error!;

        compliance.Add(exception.Value);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogWarning("Lista blanca: {Operador} exceptuó a la persona {PersonId} de {Proveedor} hasta {Hasta}.", user.Name, person.Id, provider, request.ValidUntil);
        return new CreatedResponse(exception.Value.Id.ToString(), "Excepción registrada.");
    }
}

public sealed class AgencyRequest
{
    [Required(ErrorMessage = "El código de la agencia es obligatorio.")]
    [StringLength(20, ErrorMessage = "El código no puede superar 20 caracteres.")]
    public string Code { get; init; } = null!;
    [Required(ErrorMessage = "El nombre de la agencia es obligatorio.")]
    public string Name { get; init; } = null!;
    public string? LicenseNumber { get; init; }
    public string? Email { get; init; }
    public string? Phone { get; init; }
}

public sealed class AgentRequest
{
    [Required(ErrorMessage = "El código del agente es obligatorio.")]
    [StringLength(20, ErrorMessage = "El código no puede superar 20 caracteres.")]
    public string Code { get; init; } = null!;
    public string? LicenseNumber { get; init; }
    [Required(ErrorMessage = "Los datos personales del agente son obligatorios.")]
    public PersonalDataRequest Person { get; init; } = null!;
    public DateOnly? ValidFrom { get; init; }
    public DateOnly? ValidTo { get; init; }
}

/// <summary>Alta de agencias de brokers y de sus agentes.</summary>
public sealed class AgenciesUseCase(
    IPersonRepository people, ICatalogQueries catalogs, IDocumentHasher hasher, IUnitOfWork unitOfWork,
    TimeProvider time, ILogger<AgenciesUseCase> logger)
{
    public async Task<Result<CreatedResponse>> CreateAgencyAsync(AgencyRequest request, CancellationToken ct)
    {
        var code = request.Code.Trim().ToUpperInvariant();
        if (await people.GetAgencyByCodeAsync(code, ct) is not null)
            return Error.Conflict("AGENCY_CODE_TAKEN", "Ya existe una agencia con ese código.");

        var agency = Agency.Create(code, request.Name, request.LicenseNumber, request.Email, request.Phone);
        people.Add(agency);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Agencia {AgencyCode} registrada.", agency.Code);
        return new CreatedResponse(agency.Code, "Agencia registrada.");
    }

    public async Task<Result<CreatedResponse>> CreateAgentAsync(string agencyCode, AgentRequest request, CancellationToken ct)
    {
        var agency = await people.GetAgencyByCodeAsync(agencyCode.Trim().ToUpperInvariant(), ct);
        if (agency is null) return Error.NotFound("AGENCY_NOT_FOUND", "La agencia no existe.");

        var code = request.Code.Trim().ToUpperInvariant();
        if (await people.GetAgentByCodeAsync(code, ct) is not null)
            return Error.Conflict("AGENT_CODE_TAKEN", "Ya existe un agente con ese código.");

        var data = await PartyDataMapper.MapAsync(request.Person, "del agente", catalogs, ct);
        if (data.IsFailure) return data.Error!;

        var hash = hasher.Hash(data.Value.Document);
        var person = await people.GetByDocumentHashAsync(hash, ct);
        if (person is null)
        {
            person = Person.Create(data.Value, hash);
            people.Add(person);
        }

        var agent = Agent.Create(agency, person, code, request.LicenseNumber, request.ValidFrom ?? time.TodayInBolivia(), request.ValidTo);
        people.Add(agent);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Agente {AgentCode} registrado en la agencia {AgencyCode}.", agent.Code, agency.Code);
        return new CreatedResponse(agent.Code, "Agente registrado.");
    }
}
