using System.ComponentModel.DataAnnotations;
using Check.Application.Abstractions;
using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Offer;
using Microsoft.Extensions.Logging;

namespace Check.Application.Internal;

// Backoffice: una empresa negocia prima y tiempo de cobertura a cambio de un cupo de personas.

public sealed class CompanyRequest
{
    [Required(ErrorMessage = "El NIT es obligatorio.")]
    public string TaxId { get; init; } = null!;
    [Required(ErrorMessage = "La razón social es obligatoria.")]
    public string Name { get; init; } = null!;
    public string? ContactName { get; init; }
    public string? ContactEmail { get; init; }
    public string? ContactPhone { get; init; }
}

public sealed class AgreementRequest
{
    [Required(ErrorMessage = "El código del convenio es obligatorio.")]
    public string Code { get; init; } = null!;
    [Required(ErrorMessage = "El NIT de la empresa es obligatorio.")]
    public string CompanyTaxId { get; init; } = null!;
    [Required(ErrorMessage = "El código del plan es obligatorio.")]
    public string PlanCode { get; init; } = null!;
    [Range(0.01, 1_000_000, ErrorMessage = "La prima negociada debe ser mayor a cero.")]
    public decimal Premium { get; init; }
    public string Currency { get; init; } = "BOB";
    [Range(1, 366, ErrorMessage = "Los días de cobertura deben estar entre 1 y 366.")]
    public int CoverageDays { get; init; }
    [Range(1, 1_000_000, ErrorMessage = "El cupo debe ser de al menos una persona.")]
    public int Quota { get; init; }
    [Required(ErrorMessage = "La fecha de inicio es obligatoria.")]
    public DateOnly? ValidFrom { get; init; }
    [Required(ErrorMessage = "La fecha de fin es obligatoria.")]
    public DateOnly? ValidTo { get; init; }
    [StringLength(1000, ErrorMessage = "Las notas no pueden superar 1000 caracteres.")]
    public string? Notes { get; init; }
}

public sealed record AgreementResponse(
    string Code, string CompanyName, string PlanCode, string PlanName, decimal Premium, string Currency,
    int CoverageDays, int Quota, int Used, int Available, DateOnly ValidFrom, DateOnly ValidTo,
    string Status, string NegotiatedBy, string? ApprovedBy);

/// <summary>Lo que ve el empleado en la web al ingresar el código del convenio.</summary>
public sealed record AgreementOfferResponse(
    string Code, string CompanyName, string PlanCode, string PlanName, decimal Premium, string Currency,
    int CoverageDays, int Available, DateOnly ValidTo);

public sealed class AgreementsUseCase(
    IAgreementRepository agreements, IPlanRepository plans, ICurrentUser user, IUnitOfWork unitOfWork,
    TimeProvider time, ILogger<AgreementsUseCase> logger)
{
    private static readonly Error NotFound = Error.NotFound("AGREEMENT_NOT_FOUND", "El código de convenio no existe.");

    public async Task<Result<CreatedResponse>> CreateCompanyAsync(CompanyRequest request, CancellationToken ct)
    {
        if (await agreements.GetCompanyByTaxIdAsync(request.TaxId.Trim(), ct) is not null)
            return Error.Conflict("COMPANY_TAX_ID_TAKEN", "Ya existe una empresa con ese NIT.");

        var company = Company.Create(request.TaxId, request.Name, request.ContactName, request.ContactEmail, request.ContactPhone);
        if (company.IsFailure) return company.Error!;

        agreements.Add(company.Value);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Empresa {Nit} registrada por {Usuario}.", company.Value.TaxId, user.Name);
        return new CreatedResponse(company.Value.TaxId, "Empresa registrada.");
    }

    /// <summary>El ejecutivo registra las condiciones negociadas; el convenio nace en borrador.</summary>
    public async Task<Result<AgreementResponse>> NegotiateAsync(AgreementRequest request, CancellationToken ct)
    {
        var company = await agreements.GetCompanyByTaxIdAsync(request.CompanyTaxId.Trim(), ct);
        if (company is null) return Error.NotFound("COMPANY_NOT_FOUND", "La empresa no está registrada.");

        var plan = await plans.GetActiveByCodeAsync(request.PlanCode, ct);
        if (plan is null) return Error.NotFound("PLAN_NOT_FOUND", "El plan no existe o no está disponible.");

        if (await agreements.GetByCodeAsync(request.Code.Trim().ToUpperInvariant(), ct) is not null)
            return Error.Conflict("AGREEMENT_CODE_TAKEN", "Ya existe un convenio con ese código.");

        var premium = Money.Create(request.Premium, request.Currency);
        if (premium.IsFailure) return premium.Error!;

        var agreement = Agreement.Negotiate(request.Code, company, plan, premium.Value, request.CoverageDays, request.Quota,
            request.ValidFrom!.Value, request.ValidTo!.Value, user.Name, request.Notes);
        if (agreement.IsFailure) return agreement.Error!;

        agreements.Add(agreement.Value);
        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Convenio {Convenio} negociado por {Usuario} con {Nit}: {Cupo} personas a {Prima} {Moneda}.",
            agreement.Value.Code, user.Name, company.TaxId, request.Quota, request.Premium, request.Currency);
        return Map(agreement.Value, 0);
    }

    public async Task<Result<AgreementResponse>> ApproveAsync(string code, CancellationToken ct)
    {
        var agreement = await agreements.GetByCodeAsync(code.Trim().ToUpperInvariant(), ct);
        if (agreement is null) return NotFound;

        var approved = agreement.Approve(user.Name, time.GetUtcNow());
        if (approved.IsFailure) return approved.Error!;

        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Convenio {Convenio} aprobado por {Usuario}.", agreement.Code, user.Name);
        return Map(agreement, 0);
    }

    public async Task<Result<AgreementResponse>> CloseAsync(string code, CancellationToken ct)
    {
        var agreement = await agreements.GetByCodeAsync(code.Trim().ToUpperInvariant(), ct);
        if (agreement is null) return NotFound;

        var closed = agreement.Close();
        if (closed.IsFailure) return closed.Error!;

        await unitOfWork.SaveChangesAsync(ct);
        logger.LogInformation("Convenio {Convenio} cerrado por {Usuario}.", agreement.Code, user.Name);
        return Map(agreement, await agreements.CountUsedAsync(agreement.Id, ct));
    }

    public async Task<Result<AgreementResponse>> GetAsync(string code, CancellationToken ct)
    {
        var agreement = await agreements.GetByCodeAsync(code.Trim().ToUpperInvariant(), ct);
        if (agreement is null) return NotFound;
        return Map(agreement, await agreements.CountUsedAsync(agreement.Id, ct));
    }

    /// <summary>Vista pública para la web: solo si el convenio puede usarse hoy.</summary>
    public async Task<Result<AgreementOfferResponse>> GetOfferAsync(string code, CancellationToken ct)
    {
        var agreement = await agreements.GetByCodeAsync(code.Trim().ToUpperInvariant(), ct);
        if (agreement is null) return NotFound;

        var used = await agreements.CountUsedAsync(agreement.Id, ct);
        var usable = agreement.CanBeUsed(agreement.PlanId, time.TodayInBolivia(), used);
        if (usable.IsFailure) return usable.Error!;

        return new AgreementOfferResponse(agreement.Code, agreement.Company.Name, agreement.Plan.Code, agreement.Plan.Name,
            agreement.PremiumAmount, agreement.Currency, agreement.CoverageDays, agreement.Quota - used, agreement.ValidTo);
    }

    private static AgreementResponse Map(Agreement a, int used) => new(
        a.Code, a.Company.Name, a.Plan.Code, a.Plan.Name, a.PremiumAmount, a.Currency, a.CoverageDays, a.Quota, used,
        Math.Max(0, a.Quota - used), a.ValidFrom, a.ValidTo, a.Status.ToString(), a.NegotiatedBy, a.ApprovedBy);
}
