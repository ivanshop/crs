using Check.Domain.Common;

namespace Check.Domain.Payments;

public enum OtpChannel { Sms, WhatsApp, Email }

/// <summary>Código de un solo uso enviado al contratante. Solo se guarda su hash.</summary>
public sealed class OtpChallenge
{
    private OtpChallenge() { } // EF Core

    public long Id { get; private set; }
    public Guid ContractId { get; private set; }
    public OtpChannel Channel { get; private set; }
    public string Destination { get; private set; } = null!;
    public byte[] CodeHash { get; private set; } = null!;
    public DateTimeOffset ExpiresAt { get; private set; }
    public short Attempts { get; private set; }
    public short MaxAttempts { get; private set; }
    public DateTimeOffset? VerifiedAt { get; private set; }
    public DateTimeOffset CreatedAt { get; private set; }

    public static OtpChallenge Create(Guid contractId, OtpChannel channel, string destination, byte[] codeHash,
        DateTimeOffset now, int lifetimeMinutes, int maxAttempts) => new()
    {
        ContractId = contractId, Channel = channel, Destination = destination, CodeHash = codeHash,
        ExpiresAt = now.AddMinutes(lifetimeMinutes), MaxAttempts = (short)maxAttempts, CreatedAt = now
    };

    /// <summary>Compara el código recibido (ya hasheado) y cuenta el intento.</summary>
    public Result Verify(byte[] codeHash, DateTimeOffset now)
    {
        if (VerifiedAt is not null)
            return Error.Conflict("OTP_ALREADY_USED", "Este código ya fue utilizado.");
        if (now > ExpiresAt)
            return Error.BusinessRule("OTP_EXPIRED", "El código venció. Solicita uno nuevo.");
        if (Attempts >= MaxAttempts)
            return Error.BusinessRule("OTP_ATTEMPTS_EXCEEDED", "Superaste los intentos permitidos. Solicita un código nuevo.");

        Attempts++;
        if (!System.Security.Cryptography.CryptographicOperations.FixedTimeEquals(CodeHash, codeHash))
            return Error.Validation("OTP_INVALID", $"El código no es correcto. Te quedan {MaxAttempts - Attempts} intentos.");

        VerifiedAt = now;
        return Result.Success();
    }
}

public enum QrPaymentStatus { Pending, Paid, Expired, Replaced }

/// <summary>Código QR generado por el Banco para cobrar un contrato: un solo uso y con vencimiento.</summary>
public sealed class QrPayment
{
    private QrPayment() { } // EF Core

    public Guid Id { get; private set; }
    public Guid ContractId { get; private set; }
    public decimal Amount { get; private set; }
    public string Currency { get; private set; } = null!;
    public string? BankTransactionId { get; private set; }
    public string? QrImage { get; private set; }
    public bool IsSingleUse { get; private set; }
    public DateTimeOffset ExpiresAt { get; private set; }
    public QrPaymentStatus Status { get; private set; }
    public DateTimeOffset? PaidAt { get; private set; }
    public string? ConfirmedManuallyBy { get; private set; }
    public string? ManualReason { get; private set; }

    public static QrPayment Create(Guid id, Guid contractId, Money amount, string? bankTransactionId, string qrImage, DateTimeOffset expiresAt) => new()
    {
        Id = id, ContractId = contractId, Amount = amount.Amount, Currency = amount.Currency,
        BankTransactionId = bankTransactionId, QrImage = qrImage, IsSingleUse = true, ExpiresAt = expiresAt, Status = QrPaymentStatus.Pending
    };

    public bool IsExpiredAt(DateTimeOffset now) => now > ExpiresAt;

    /// <summary>Aplica el aviso del Banco. Un QR vencido o ya usado no se procesa.</summary>
    public NotificationResult Apply(decimal amount, string currency, string bankTransactionId, DateTimeOffset paidAt)
    {
        if (Status == QrPaymentStatus.Paid) return NotificationResult.Duplicate;
        if (Status != QrPaymentStatus.Pending || IsExpiredAt(paidAt)) return NotificationResult.Expired;
        if (amount != Amount || !string.Equals(currency, Currency, StringComparison.OrdinalIgnoreCase)) return NotificationResult.AmountMismatch;

        Status = QrPaymentStatus.Paid;
        PaidAt = paidAt;
        BankTransactionId = bankTransactionId;
        return NotificationResult.Applied;
    }

    /// <summary>Conciliación manual: un operador confirma un pago que el Banco no notificó.</summary>
    public Result ConfirmManually(string bankTransactionId, string operatorName, string reason, DateTimeOffset now)
    {
        if (Status == QrPaymentStatus.Paid)
            return Error.Conflict("QR_ALREADY_PAID", "Este QR ya figura como pagado.");
        if (string.IsNullOrWhiteSpace(reason))
            return Error.Validation("MANUAL_REASON_REQUIRED", "Debes justificar la conciliación manual.");
        Status = QrPaymentStatus.Paid;
        PaidAt = now;
        BankTransactionId = bankTransactionId;
        ConfirmedManuallyBy = operatorName;
        ManualReason = reason.Trim();
        return Result.Success();
    }

    public void Replace() { if (Status == QrPaymentStatus.Pending) Status = QrPaymentStatus.Replaced; }
    public void Expire() { if (Status == QrPaymentStatus.Pending) Status = QrPaymentStatus.Expired; }
}

public enum NotificationResult { Applied, Duplicate, Expired, AmountMismatch, Unknown }

/// <summary>Cada aviso del Banco tal como llegó: idempotencia y evidencia para conciliar.</summary>
public sealed class PaymentNotification
{
    private PaymentNotification() { } // EF Core

    public long Id { get; private set; }
    public Guid? QrPaymentId { get; private set; }
    public string BankTransactionId { get; private set; } = null!;
    public string RawPayload { get; private set; } = null!;
    public DateTimeOffset ReceivedAt { get; private set; }
    public NotificationResult Result { get; private set; }

    public static PaymentNotification Record(Guid? qrPaymentId, string bankTransactionId, string rawPayload, NotificationResult result, DateTimeOffset now) => new()
    {
        QrPaymentId = qrPaymentId, BankTransactionId = bankTransactionId, RawPayload = rawPayload, Result = result, ReceivedAt = now
    };
}
