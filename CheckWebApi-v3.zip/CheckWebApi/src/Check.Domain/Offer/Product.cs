namespace Check.Domain.Offer;

public sealed class Product
{
    private readonly List<Plan> _plans = [];
    private Product() { } // EF Core

    public long Id { get; private set; }
    public string Code { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }
    public bool IsActive { get; private set; }

    public IReadOnlyList<Plan> Plans => _plans;
}

public sealed class Plan
{
    private readonly List<Coverage> _coverages = [];
    private readonly List<Assistance> _assistances = [];
    private readonly List<Exclusion> _exclusions = [];

    private Plan() { } // EF Core

    public long Id { get; private set; }
    public long ProductId { get; private set; }
    public string Code { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? Description { get; private set; }
    public bool IsActive { get; private set; }

    public Product Product { get; private set; } = null!;
    public IReadOnlyList<Coverage> Coverages => _coverages;
    public IReadOnlyList<Assistance> Assistances => _assistances;
    public IReadOnlyList<Exclusion> Exclusions => _exclusions;
}

public sealed class Coverage
{
    private Coverage() { } // EF Core

    public long Id { get; private set; }
    public long PlanId { get; private set; }
    public string Name { get; private set; } = null!;
    public string Type { get; private set; } = null!;
    public decimal? InsuredAmount { get; private set; }
    public string? Currency { get; private set; }
    public string Description { get; private set; } = null!;
    public int SortOrder { get; private set; }
    public bool IsActive { get; private set; }
}

public sealed class Assistance
{
    private Assistance() { } // EF Core

    public long Id { get; private set; }
    public long PlanId { get; private set; }
    public string Name { get; private set; } = null!;
    public string Service { get; private set; } = null!;
    public string Description { get; private set; } = null!;
    public int SortOrder { get; private set; }
    public bool IsActive { get; private set; }
}

public sealed class Exclusion
{
    private Exclusion() { } // EF Core

    public long Id { get; private set; }
    public long PlanId { get; private set; }
    public string Description { get; private set; } = null!;
    public int SortOrder { get; private set; }
    public bool IsActive { get; private set; }
}

public sealed class Faq
{
    private Faq() { } // EF Core

    public long Id { get; private set; }
    public long ProductId { get; private set; }
    public string Question { get; private set; } = null!;
    public string Answer { get; private set; } = null!;
    public int SortOrder { get; private set; }
    public bool IsActive { get; private set; }
}
