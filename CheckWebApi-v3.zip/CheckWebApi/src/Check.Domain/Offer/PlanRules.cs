using Check.Domain.Common;

namespace Check.Domain.Offer;

/// <summary>Códigos del diccionario offer.parameter_definitions que el backend conoce.</summary>
public static class ParameterCodes
{
    public const string DurationDays = "DURATION_DAYS";
    public const string PremiumAmount = "PREMIUM_AMOUNT";
    public const string PremiumCurrency = "PREMIUM_CURRENCY";
    public const string MinAge = "MIN_AGE";
    public const string MaxAge = "MAX_AGE";
    public const string MaxBeneficiaries = "MAX_BENEFICIARIES";
    public const string IsRenewable = "IS_RENEWABLE";
    public const string BrokerSaleEnabled = "BROKER_SALE_ENABLED";
    public const string QrLifetimeMinutes = "QR_LIFETIME_MINUTES";
    public const string NetPremiumRate = "NET_PREMIUM_RATE";
    public const string CededPremiumRate = "CEDED_PREMIUM_RATE";
}

/// <summary>
/// Reglas de negocio de un plan a una fecha, ya tipadas.
/// Se construyen a partir de offer.plan_parameters (cada plan tiene su propio conjunto).
/// </summary>
public sealed record PlanRules(
    string PlanCode,
    int DurationDays,
    Money Premium,
    int MinAge,
    int MaxAge,
    int MaxBeneficiaries,
    bool IsRenewable,
    bool BrokerSaleEnabled,
    int QrLifetimeMinutes,
    decimal? NetPremiumRate,
    decimal? CededPremiumRate)
{
    public bool AllowsAge(int age) => age >= MinAge && age <= MaxAge;
}
