using System.Globalization;
using Check.Domain.Common;

namespace Check.Domain.Offer;

public enum FieldDataType
{
    Text,
    Integer,
    Decimal,
    Boolean,
    Date,
    Option
}

/// <summary>Campo propio de un producto que se pide al contratar (origen, destino, IMEI...).</summary>
public sealed class ContractFieldDefinition
{
    private ContractFieldDefinition() { } // EF Core

    public long Id { get; private set; }
    public long ProductId { get; private set; }
    public string Code { get; private set; } = null!;
    public string Label { get; private set; } = null!;
    public FieldDataType DataType { get; private set; }
    public string? CatalogTopic { get; private set; }
    public bool IsRequired { get; private set; }
    public int? MaxLength { get; private set; }
    public int SortOrder { get; private set; }
    public bool IsActive { get; private set; }

    /// <summary>Valida la forma del valor. Las opciones de catálogo se validan aparte.</summary>
    public Result Validate(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return IsRequired
                ? Error.Validation("FIELD_REQUIRED", $"El campo '{Label}' es obligatorio.")
                : Result.Success();

        if (MaxLength is { } max && value.Length > max)
            return Error.Validation("FIELD_TOO_LONG", $"El campo '{Label}' no puede superar {max} caracteres.");

        var valid = DataType switch
        {
            FieldDataType.Integer => long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out _),
            FieldDataType.Decimal => decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out _),
            FieldDataType.Boolean => bool.TryParse(value, out _),
            FieldDataType.Date => DateOnly.TryParseExact(value, "yyyy-MM-dd", out _),
            _ => true
        };

        return valid
            ? Result.Success()
            : Error.Validation("FIELD_INVALID_FORMAT", $"El campo '{Label}' no tiene el formato esperado ({DataType}).");
    }
}
