using Check.Domain.Common;

namespace Check.Domain.Offer;

/// <summary>Empresa cliente que negocia convenios corporativos desde el backoffice.</summary>
public sealed class Company
{
    private Company() { } // EF Core

    public Guid Id { get; private set; }
    public string TaxId { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? ContactName { get; private set; }
    public string? ContactEmail { get; private set; }
    public string? ContactPhone { get; private set; }

    public static Result<Company> Create(string taxId, string name, string? contactName, string? contactEmail, string? contactPhone)
    {
        taxId = (taxId ?? string.Empty).Trim();
        if (taxId.Length is < 5 or > 15 || !taxId.All(char.IsDigit))
            return Error.Validation("COMPANY_INVALID_TAX_ID", "El NIT debe tener entre 5 y 15 dígitos.");
        if (string.IsNullOrWhiteSpace(name))
            return Error.Validation("COMPANY_NAME_REQUIRED", "La razón social es obligatoria.");
        return new Company
        {
            Id = Guid.CreateVersion7(), TaxId = taxId, Name = name.Trim(),
            ContactName = contactName?.Trim(), ContactEmail = contactEmail?.Trim(), ContactPhone = contactPhone?.Trim()
        };
    }
}

public enum AgreementStatus { Draft, Active, Closed }

/// <summary>Condiciones con que se contrata: las del plan o las de un convenio.</summary>
public sealed record ContractTerms(Money Premium, int CoverageDays, Guid? AgreementId)
{
    public static ContractTerms FromPlan(PlanRules rules) => new(rules.Premium, rules.DurationDays, null);
}

/// <summary>
/// Convenio corporativo: prima y días de cobertura negociados con una empresa a cambio de
/// un cupo de personas. Lo negocia un ejecutivo y lo aprueba otra persona (cuatro ojos).
/// </summary>
public sealed class Agreement
{
    private Agreement() { } // EF Core

    public Guid Id { get; private set; }
    public string Code { get; private set; } = null!;
    public Guid CompanyId { get; private set; }
    public long PlanId { get; private set; }
    public decimal PremiumAmount { get; private set; }
    public string Currency { get; private set; } = null!;
    public int CoverageDays { get; private set; }
    public int Quota { get; private set; }
    public DateOnly ValidFrom { get; private set; }
    public DateOnly ValidTo { get; private set; }
    public AgreementStatus Status { get; private set; }
    public string NegotiatedBy { get; private set; } = null!;
    public string? ApprovedBy { get; private set; }
    public DateTimeOffset? ApprovedAt { get; private set; }
    public string? Notes { get; private set; }

    public Company Company { get; private set; } = null!;
    public Plan Plan { get; private set; } = null!;

    public ContractTerms Terms => new(Money.Create(PremiumAmount, Currency).Value, CoverageDays, Id);

    public static Result<Agreement> Negotiate(string code, Company company, Plan plan, Money premium, int coverageDays,
        int quota, DateOnly validFrom, DateOnly validTo, string negotiatedBy, string? notes)
    {
        code = (code ?? string.Empty).Trim().ToUpperInvariant();
        if (code.Length is < 4 or > 30)
            return Error.Validation("AGREEMENT_INVALID_CODE", "El código del convenio debe tener entre 4 y 30 caracteres.");
        if (premium.Amount <= 0)
            return Error.Validation("AGREEMENT_INVALID_PREMIUM", "La prima negociada debe ser mayor a cero.");
        if (coverageDays is < 1 or > 366)
            return Error.Validation("AGREEMENT_INVALID_COVERAGE", "Los días de cobertura deben estar entre 1 y 366.");
        if (quota < 1)
            return Error.Validation("AGREEMENT_INVALID_QUOTA", "El cupo debe ser de al menos una persona.");
        if (validTo < validFrom)
            return Error.Validation("AGREEMENT_INVALID_PERIOD", "La vigencia del convenio no es válida.");

        return new Agreement
        {
            Id = Guid.CreateVersion7(), Code = code, CompanyId = company.Id, Company = company, PlanId = plan.Id, Plan = plan,
            PremiumAmount = premium.Amount, Currency = premium.Currency, CoverageDays = coverageDays, Quota = quota,
            ValidFrom = validFrom, ValidTo = validTo, Status = AgreementStatus.Draft, NegotiatedBy = negotiatedBy,
            Notes = string.IsNullOrWhiteSpace(notes) ? null : notes.Trim()
        };
    }

    /// <summary>Aprueba el convenio. Quien lo negoció no puede aprobarlo.</summary>
    public Result Approve(string approver, DateTimeOffset now)
    {
        if (Status != AgreementStatus.Draft)
            return Error.Conflict("AGREEMENT_NOT_DRAFT", "Solo se puede aprobar un convenio en borrador.");
        if (string.Equals(approver, NegotiatedBy, StringComparison.OrdinalIgnoreCase))
            return Error.BusinessRule("AGREEMENT_SAME_APPROVER", "Quien negoció el convenio no puede aprobarlo.");
        Status = AgreementStatus.Active;
        ApprovedBy = approver;
        ApprovedAt = now;
        return Result.Success();
    }

    public Result Close()
    {
        if (Status == AgreementStatus.Closed)
            return Error.Conflict("AGREEMENT_ALREADY_CLOSED", "El convenio ya está cerrado.");
        Status = AgreementStatus.Closed;
        return Result.Success();
    }

    /// <summary>¿Puede usarse hoy para contratar este plan, con el cupo ya consumido?</summary>
    public Result CanBeUsed(long planId, DateOnly today, int used)
    {
        if (Status != AgreementStatus.Active || today < ValidFrom || today > ValidTo)
            return Error.BusinessRule("AGREEMENT_NOT_AVAILABLE", "El convenio no está vigente.");
        if (planId != PlanId)
            return Error.BusinessRule("AGREEMENT_PLAN_MISMATCH", "El convenio no corresponde al plan elegido.");
        if (used >= Quota)
            return Error.BusinessRule("AGREEMENT_QUOTA_EXHAUSTED", "El convenio ya completó su cupo de personas.");
        return Result.Success();
    }
}
