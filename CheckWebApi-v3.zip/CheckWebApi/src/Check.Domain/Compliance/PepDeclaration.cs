using Check.Domain.Common;
using Check.Domain.People;

namespace Check.Domain.Compliance;

/// <summary>
/// Declaración PEP de una persona. Se guarda el historial: la vigente es la que no fue
/// reemplazada (SupersededAt nulo) y cada parte del contrato apunta a la que regía al contratar.
/// </summary>
public sealed class PepDeclaration
{
    private readonly List<PepRelative> _relatives = [];
    private readonly List<PepPartner> _partners = [];

    private PepDeclaration() { } // EF Core

    public long Id { get; private set; }
    public Guid PersonId { get; private set; }
    public bool IsPep { get; private set; }
    public string? Position { get; private set; }
    public string? Institution { get; private set; }
    public DateOnly? PeriodStart { get; private set; }
    public DateOnly? PeriodEnd { get; private set; }
    public DateTimeOffset DeclaredAt { get; private set; }
    public DateTimeOffset? SupersededAt { get; private set; }

    public IReadOnlyList<PepRelative> Relatives => _relatives;
    public IReadOnlyList<PepPartner> Partners => _partners;

    public static Result<PepDeclaration> Create(Guid personId, bool isPep, string? position, string? institution,
        DateOnly? periodStart, DateOnly? periodEnd, IEnumerable<PepRelative> relatives, IEnumerable<PepPartner> partners, DateTimeOffset now)
    {
        var declaration = new PepDeclaration { PersonId = personId, IsPep = isPep, DeclaredAt = now };
        if (!isPep) return declaration;

        if (string.IsNullOrWhiteSpace(position) || string.IsNullOrWhiteSpace(institution))
            return Error.Validation("PEP_DATA_REQUIRED", "Una persona expuesta políticamente debe declarar su cargo y su institución.");
        if (periodStart is not null && periodEnd is not null && periodEnd < periodStart)
            return Error.Validation("PEP_INVALID_PERIOD", "El periodo del cargo no es válido.");

        declaration.Position = position.Trim();
        declaration.Institution = institution.Trim();
        declaration.PeriodStart = periodStart;
        declaration.PeriodEnd = periodEnd;
        declaration._relatives.AddRange(relatives);
        declaration._partners.AddRange(partners);

        if (declaration._relatives.Count == 0)
            return Error.BusinessRule("PEP_RELATIVE_REQUIRED", "Una persona expuesta políticamente debe declarar al menos un familiar.");
        return declaration;
    }

    /// <summary>¿Dice lo mismo que otra declaración? Evita duplicar el historial en cada contrato.</summary>
    public bool IsEquivalentTo(PepDeclaration other) =>
        IsPep == other.IsPep && Position == other.Position && Institution == other.Institution &&
        PeriodStart == other.PeriodStart && PeriodEnd == other.PeriodEnd &&
        _relatives.Select(r => r.Key).Order().SequenceEqual(other._relatives.Select(r => r.Key).Order()) &&
        _partners.Select(p => p.Key).Order().SequenceEqual(other._partners.Select(p => p.Key).Order());

    public void Supersede(DateTimeOffset now) => SupersededAt ??= now;
}

public sealed class PepRelative
{
    private PepRelative() { } // EF Core

    public long Id { get; private set; }
    public long PepDeclarationId { get; private set; }
    public long RelationshipId { get; private set; }
    public string Names { get; private set; } = null!;
    public string? PaternalLastname { get; private set; }
    public string? MaternalLastname { get; private set; }
    public string? DocumentNumber { get; private set; }

    internal string Key => $"{RelationshipId}|{Names}|{PaternalLastname}|{MaternalLastname}|{DocumentNumber}";

    public static PepRelative Create(long relationshipId, PersonName name, string? documentNumber) => new()
    {
        RelationshipId = relationshipId, Names = name.Names, PaternalLastname = name.PaternalLastname,
        MaternalLastname = name.MaternalLastname, DocumentNumber = documentNumber
    };
}

public sealed class PepPartner
{
    private PepPartner() { } // EF Core

    public long Id { get; private set; }
    public long PepDeclarationId { get; private set; }
    public string Names { get; private set; } = null!;
    public string? PaternalLastname { get; private set; }
    public string? MaternalLastname { get; private set; }
    public string? DocumentNumber { get; private set; }
    public string? CompanyName { get; private set; }

    internal string Key => $"{Names}|{PaternalLastname}|{MaternalLastname}|{DocumentNumber}|{CompanyName}";

    public static PepPartner Create(PersonName name, string? documentNumber, string? companyName) => new()
    {
        Names = name.Names, PaternalLastname = name.PaternalLastname, MaternalLastname = name.MaternalLastname,
        DocumentNumber = documentNumber, CompanyName = companyName
    };
}

public enum IdentityReadingStatus { Pending, Completed, Failed }

/// <summary>Lectura OCR del anverso y reverso del carnet con LlamitAI.</summary>
public sealed class IdentityReading
{
    private IdentityReading() { } // EF Core

    public Guid Id { get; private set; }
    public Guid? PersonId { get; private set; }
    public Guid? ContractId { get; private set; }
    public string Provider { get; private set; } = "LlamitAI";
    public string FrontImagePath { get; private set; } = null!;
    public string BackImagePath { get; private set; } = null!;
    public IdentityReadingStatus Status { get; private set; }
    public string? ExtractedText { get; private set; }
    public string? ExtractedFields { get; private set; }
    public string? RawResponse { get; private set; }
    public bool? MatchesDeclared { get; private set; }
    public string? Differences { get; private set; }
    public string? FailureReason { get; private set; }
    public string? ClientIp { get; private set; }
    public DateTimeOffset RequestedAt { get; private set; }
    public DateTimeOffset? RespondedAt { get; private set; }

    public static IdentityReading Request(Guid id, string frontImagePath, string backImagePath, string? clientIp, DateTimeOffset now) => new()
    {
        Id = id, FrontImagePath = frontImagePath, BackImagePath = backImagePath,
        Status = IdentityReadingStatus.Pending, ClientIp = clientIp, RequestedAt = now
    };

    public void Complete(string extractedText, string extractedFieldsJson, string rawResponse, DateTimeOffset now)
    {
        Status = IdentityReadingStatus.Completed;
        ExtractedText = extractedText;
        ExtractedFields = extractedFieldsJson;
        RawResponse = rawResponse;
        RespondedAt = now;
    }

    public void Fail(string reason, DateTimeOffset now)
    {
        Status = IdentityReadingStatus.Failed;
        FailureReason = reason;
        RespondedAt = now;
    }

    /// <summary>Vincula la lectura a la persona y al contrato, y anota en qué campos difiere de lo declarado.</summary>
    public void LinkTo(Guid personId, Guid contractId, IReadOnlyList<string> differingFields)
    {
        PersonId = personId;
        ContractId = contractId;
        MatchesDeclared = differingFields.Count == 0;
        Differences = System.Text.Json.JsonSerializer.Serialize(differingFields);
    }
}
