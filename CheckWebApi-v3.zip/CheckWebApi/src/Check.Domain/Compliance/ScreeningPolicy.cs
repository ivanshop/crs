using Check.Domain.Common;
using Check.Domain.Contracts;

namespace Check.Domain.Compliance;

public sealed record ScreeningDecision(bool IsApproved, string? Reason);

/// <summary>
/// Domain service: con los resultados de SEGIP, AMLC y Archivo Negativo de cada parte
/// decide si el contrato es apto. Una excepción de lista blanca vigente cuenta como aprobado.
/// </summary>
public static class ScreeningPolicy
{
    public static ScreeningDecision Decide(IEnumerable<(PartyRole Role, Screening Screening)> results)
    {
        var failed = results.FirstOrDefault(r => !r.Screening.IsApproved);
        if (failed.Screening is null)
            return new ScreeningDecision(true, null);

        var who = failed.Role == PartyRole.Contractor ? "del contratante" : "del asegurado";
        var reason = failed.Screening.Provider switch
        {
            ScreeningProvider.Segip => $"Los datos {who} no coinciden con SEGIP.",
            ScreeningProvider.Amlc => $"El documento {who} figura en listas internacionales (AMLC).",
            ScreeningProvider.NegativeFile => $"El documento {who} figura en el Archivo Negativo.",
            _ => $"El documento {who} no superó las validaciones."
        };
        return new ScreeningDecision(false, reason);
    }

    public static readonly Error AlreadyScreened =
        Error.Conflict("CONTRACT_ALREADY_SCREENED", "Las validaciones de este contrato ya fueron realizadas.");
}
