using Check.Domain.Common;

namespace Check.Domain.Compliance;

public enum ScreeningProvider
{
    Segip,
    Amlc,
    NegativeFile
}

/// <summary>Una consulta a SEGIP, AMLC o Archivo Negativo de una persona, dentro de un contrato. Inmutable.</summary>
public sealed class Screening
{
    private readonly List<ScreeningItem> _items = [];

    private Screening() { } // EF Core

    public long Id { get; private set; }
    public Guid PersonId { get; private set; }
    public Guid ContractId { get; private set; }
    public ScreeningProvider Provider { get; private set; }
    /// <summary>SEGIP: todos los datos coinciden. AMLC / AN: la persona no aparece.</summary>
    public bool IsClear { get; private set; }
    /// <summary>JSON con el detalle (coincidencia por campo en SEGIP).</summary>
    public string? Detail { get; private set; }
    /// <summary>Respuesta íntegra del servicio, como evidencia.</summary>
    public string RawResponse { get; private set; } = null!;
    public long? ExceptionId { get; private set; }
    public DateTimeOffset RequestedAt { get; private set; }
    public DateTimeOffset RespondedAt { get; private set; }

    public IReadOnlyList<ScreeningItem> Items => _items;

    /// <summary>Aprobado: limpio o exceptuado por la lista blanca.</summary>
    public bool IsApproved => IsClear || ExceptionId is not null;

    public static Screening Record(
        Guid personId,
        Guid contractId,
        ScreeningProvider provider,
        bool isClear,
        string? detail,
        string rawResponse,
        IEnumerable<ScreeningItem> items,
        DateTimeOffset requestedAt,
        DateTimeOffset respondedAt)
    {
        var screening = new Screening
        {
            PersonId = personId,
            ContractId = contractId,
            Provider = provider,
            IsClear = isClear,
            Detail = detail,
            RawResponse = rawResponse,
            RequestedAt = requestedAt,
            RespondedAt = respondedAt
        };
        screening._items.AddRange(items);
        return screening;
    }

    /// <summary>Aplica una excepción de lista blanca a un resultado no limpio.</summary>
    public void ApplyException(ScreeningException exception)
    {
        if (!IsClear && exception.Provider == Provider)
            ExceptionId = exception.Id;
    }
}

/// <summary>Una aparición en AMLC (listas internacionales) o Archivo Negativo.</summary>
public sealed class ScreeningItem
{
    private ScreeningItem() { } // EF Core

    public long Id { get; private set; }
    public long ScreeningId { get; private set; }
    public string FoundIn { get; private set; } = null!;
    public string? Code { get; private set; }
    public string? Position { get; private set; }
    public string? Entity { get; private set; }
    public string? Year { get; private set; }
    public string? Observation { get; private set; }

    public static ScreeningItem Create(string foundIn, string? code, string? position, string? entity, string? year, string? observation) =>
        new() { FoundIn = foundIn, Code = code, Position = position, Entity = entity, Year = year, Observation = observation };
}

/// <summary>Lista blanca: excepción aprobada por Cumplimiento para una persona y un proveedor, con vigencia.</summary>
public sealed class ScreeningException
{
    private ScreeningException() { } // EF Core

    public long Id { get; private set; }
    public Guid PersonId { get; private set; }
    public ScreeningProvider Provider { get; private set; }
    public string Reason { get; private set; } = null!;
    public string ApprovedBy { get; private set; } = null!;
    public DateOnly ValidFrom { get; private set; }
    public DateOnly ValidUntil { get; private set; }

    public bool IsValidOn(DateOnly date) => ValidFrom <= date && ValidUntil >= date;

    public static Result<ScreeningException> Create(Guid personId, ScreeningProvider provider, string reason, string approvedBy, DateOnly validFrom, DateOnly validUntil)
    {
        if (provider == ScreeningProvider.Segip)
            return Error.Validation("EXCEPTION_INVALID_PROVIDER", "La lista blanca solo aplica a AMLC o Archivo Negativo.");
        if (validUntil < validFrom)
            return Error.Validation("EXCEPTION_INVALID_PERIOD", "La vigencia de la excepción no es válida.");
        if (string.IsNullOrWhiteSpace(reason))
            return Error.Validation("EXCEPTION_REASON_REQUIRED", "Debes indicar el motivo de la excepción.");
        return new ScreeningException { PersonId = personId, Provider = provider, Reason = reason.Trim(), ApprovedBy = approvedBy, ValidFrom = validFrom, ValidUntil = validUntil };
    }
}
