using Check.Domain.Common;

namespace Check.Domain.People;

public sealed record PersonName
{
    private PersonName(string names, string? paternalLastname, string? maternalLastname)
    {
        Names = names;
        PaternalLastname = paternalLastname;
        MaternalLastname = maternalLastname;
    }

    public string Names { get; }
    public string? PaternalLastname { get; }
    public string? MaternalLastname { get; }

    public string FullName => string.Join(' ', new[] { Names, PaternalLastname, MaternalLastname }.Where(p => !string.IsNullOrEmpty(p)));

    public static Result<PersonName> Create(string? names, string? paternalLastname, string? maternalLastname)
    {
        names = Clean(names);
        paternalLastname = Clean(paternalLastname);
        maternalLastname = Clean(maternalLastname);

        if (names is null)
            return Error.Validation("NAME_REQUIRED", "Los nombres son obligatorios.");
        if (paternalLastname is null && maternalLastname is null)
            return Error.Validation("LASTNAME_REQUIRED", "Debe registrar al menos un apellido.");
        if (names.Length > 100 || paternalLastname?.Length > 100 || maternalLastname?.Length > 100)
            return Error.Validation("NAME_TOO_LONG", "Los nombres y apellidos no pueden superar 100 caracteres.");

        return new PersonName(names, paternalLastname, maternalLastname);
    }

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : string.Join(' ', value.Split(' ', StringSplitOptions.RemoveEmptyEntries));
}
