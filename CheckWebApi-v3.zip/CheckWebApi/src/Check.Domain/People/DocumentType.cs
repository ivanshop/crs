namespace Check.Domain.People;

public enum DocumentType
{
    /// <summary>Cédula de identidad boliviana.</summary>
    CI,
    /// <summary>Cédula de extranjero.</summary>
    CE
}

public enum Gender
{
    Male,
    Female
}
