using System.Text.RegularExpressions;
using Check.Domain.Common;

namespace Check.Domain.People;

public sealed partial record IdentityDocument
{
    public static readonly string[] Extensions = ["LP", "CB", "SC", "OR", "PT", "CH", "TJ", "BE", "PD"];

    private IdentityDocument(DocumentType type, string number, string? complement, string? extension)
    {
        Type = type;
        Number = number;
        Complement = complement;
        Extension = extension;
    }

    public DocumentType Type { get; }
    public string Number { get; }
    public string? Complement { get; }
    public string? Extension { get; }

    public bool IsBolivian => Type == DocumentType.CI;

    /// <summary>Texto canónico para el hash de búsqueda: tipo|número|complemento.</summary>
    public string CanonicalKey => $"{Type}|{Number}|{Complement ?? string.Empty}";

    public static Result<IdentityDocument> Create(DocumentType type, string? number, string? complement, string? extension)
    {
        number = number?.Trim();
        complement = string.IsNullOrWhiteSpace(complement) ? null : complement.Trim().ToUpperInvariant();
        extension = string.IsNullOrWhiteSpace(extension) ? null : extension.Trim().ToUpperInvariant();

        if (string.IsNullOrEmpty(number) || !NumberPattern().IsMatch(number))
            return Error.Validation("DOCUMENT_INVALID_NUMBER", "El número de documento debe tener entre 4 y 12 dígitos.");

        if (complement is not null && !ComplementPattern().IsMatch(complement))
            return Error.Validation("DOCUMENT_INVALID_COMPLEMENT", "El complemento del documento no es válido.");

        if (type == DocumentType.CI)
        {
            if (extension is null || !Extensions.Contains(extension))
                return Error.Validation("DOCUMENT_INVALID_EXTENSION", "La extensión del carnet no es válida.");
        }
        else
        {
            extension = null;
        }

        return new IdentityDocument(type, number, complement, extension);
    }

    [GeneratedRegex(@"^\d{4,12}$")]
    private static partial Regex NumberPattern();

    [GeneratedRegex(@"^[0-9A-Z]{1,3}$")]
    private static partial Regex ComplementPattern();
}
