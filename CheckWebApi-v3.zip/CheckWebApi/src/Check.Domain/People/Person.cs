namespace Check.Domain.People;

/// <summary>Datos de una persona tal como los declara al contratar (ya validados).</summary>
public sealed record PartyData(
    IdentityDocument Document,
    PersonName Name,
    DateOnly Birthdate,
    Gender Gender,
    short NationalityId,
    string? Address,
    string? City,
    PhoneNumber? Cellphone,
    Email? Email,
    string? MaritalStatus,
    string? Occupation,
    string? EconomicActivity,
    string? MonthlyIncomeRange);

/// <summary>
/// Persona única por documento, con sus datos ACTUALES. Asegurado, contratante y agente
/// son roles; la copia de los datos con que se firmó cada contrato vive en ContractParty.
/// </summary>
public sealed class Person
{
    private Person() { } // EF Core

    public Guid Id { get; private set; }
    public DocumentType DocumentType { get; private set; }
    public string DocumentNumber { get; private set; } = null!;
    public string? DocumentComplement { get; private set; }
    public string? DocumentExtension { get; private set; }
    public byte[] DocumentHash { get; private set; } = null!;
    public string Names { get; private set; } = null!;
    public string? PaternalLastname { get; private set; }
    public string? MaternalLastname { get; private set; }
    public DateOnly Birthdate { get; private set; }
    public Gender Gender { get; private set; }
    public short NationalityId { get; private set; }
    public string? Address { get; private set; }
    public string? Cellphone { get; private set; }
    public string? Email { get; private set; }
    public string? City { get; private set; }
    public string? MaritalStatus { get; private set; }
    public string? Occupation { get; private set; }
    public string? EconomicActivity { get; private set; }
    public string? MonthlyIncomeRange { get; private set; }

    public string FullName => string.Join(' ', new[] { Names, PaternalLastname, MaternalLastname }.Where(p => !string.IsNullOrEmpty(p)));

    public static Person Create(PartyData data, byte[] documentHash)
    {
        var person = new Person
        {
            Id = Guid.CreateVersion7(),
            DocumentType = data.Document.Type,
            DocumentNumber = data.Document.Number,
            DocumentComplement = data.Document.Complement,
            DocumentHash = documentHash
        };
        person.Update(data);
        return person;
    }

    /// <summary>Actualiza los datos actuales; los contratos anteriores conservan su copia.</summary>
    public void Update(PartyData data)
    {
        DocumentExtension = data.Document.Extension;
        Names = data.Name.Names;
        PaternalLastname = data.Name.PaternalLastname;
        MaternalLastname = data.Name.MaternalLastname;
        Birthdate = data.Birthdate;
        Gender = data.Gender;
        NationalityId = data.NationalityId;
        Address = data.Address ?? Address;
        Cellphone = data.Cellphone?.Value ?? Cellphone;
        Email = data.Email?.Value ?? Email;
        City = data.City ?? City;
        MaritalStatus = data.MaritalStatus ?? MaritalStatus;
        Occupation = data.Occupation ?? Occupation;
        EconomicActivity = data.EconomicActivity ?? EconomicActivity;
        MonthlyIncomeRange = data.MonthlyIncomeRange ?? MonthlyIncomeRange;
    }
}

/// <summary>Agencia de corredores (brokers).</summary>
public sealed class Agency
{
    private Agency() { } // EF Core

    public Guid Id { get; private set; }
    public string Code { get; private set; } = null!;
    public string Name { get; private set; } = null!;
    public string? LicenseNumber { get; private set; }
    public string? Email { get; private set; }
    public string? Phone { get; private set; }

    public static Agency Create(string code, string name, string? licenseNumber, string? email, string? phone) => new()
    {
        Id = Guid.CreateVersion7(), Code = code.Trim().ToUpperInvariant(), Name = name.Trim(),
        LicenseNumber = licenseNumber, Email = email, Phone = phone
    };
}

/// <summary>Persona acreditada para vender por una agencia.</summary>
public sealed class Agent
{
    private Agent() { } // EF Core

    public Guid Id { get; private set; }
    public Guid AgencyId { get; private set; }
    public Guid PersonId { get; private set; }
    public string Code { get; private set; } = null!;
    public string? LicenseNumber { get; private set; }
    public DateOnly ValidFrom { get; private set; }
    public DateOnly? ValidTo { get; private set; }

    public Person Person { get; private set; } = null!;
    public Agency Agency { get; private set; } = null!;

    public bool IsValidOn(DateOnly date) => ValidFrom <= date && (ValidTo is null || ValidTo >= date);

    public static Agent Create(Agency agency, Person person, string code, string? licenseNumber, DateOnly validFrom, DateOnly? validTo) => new()
    {
        Id = Guid.CreateVersion7(), AgencyId = agency.Id, Agency = agency, PersonId = person.Id, Person = person,
        Code = code.Trim().ToUpperInvariant(), LicenseNumber = licenseNumber, ValidFrom = validFrom, ValidTo = validTo
    };
}
