using System.Net.Mail;
using System.Text.RegularExpressions;
using Check.Domain.Common;

namespace Check.Domain.People;

public sealed partial record Email
{
    private Email(string value) => Value = value;
    public string Value { get; }

    public static Result<Email> Create(string? value)
    {
        value = value?.Trim().ToLowerInvariant();
        if (string.IsNullOrEmpty(value) || value.Length > 150 || !MailAddress.TryCreate(value, out _))
            return Error.Validation("EMAIL_INVALID", "El correo electrónico no es válido.");
        return new Email(value);
    }
}

public sealed partial record PhoneNumber
{
    private PhoneNumber(string value) => Value = value;
    public string Value { get; }

    /// <summary>Celular boliviano: 8 dígitos que empiezan con 6 o 7.</summary>
    public static Result<PhoneNumber> Create(string? value)
    {
        value = value?.Replace(" ", string.Empty).Replace("-", string.Empty);
        if (value?.StartsWith("+591") == true) value = value[4..];
        if (string.IsNullOrEmpty(value) || !CellphonePattern().IsMatch(value))
            return Error.Validation("CELLPHONE_INVALID", "El número de celular no es válido.");
        return new PhoneNumber(value);
    }

    [GeneratedRegex(@"^[67]\d{7}$")]
    private static partial Regex CellphonePattern();
}
