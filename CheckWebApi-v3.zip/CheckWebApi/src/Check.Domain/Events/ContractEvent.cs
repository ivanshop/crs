using Check.Domain.Common;

namespace Check.Domain.Events;

public enum ContractEventType
{
    ContractStarted, ScreeningCompleted, ContractRejected, OtpVerified, QrGenerated,
    PaymentConfirmed, WelcomeEmail, ClientFolder, ContractExpired
}

public enum ContractEventStatus { Recorded, Pending, Published, Completed, Failed }

/// <summary>
/// Bitácora del contrato y, a la vez, outbox hacia Azure Service Bus.
/// Sin cola: solo se registra. Con cola: Pending → Published (enviado) → Completed / Failed (confirma el consumidor).
/// </summary>
public sealed class ContractEvent
{
    public const string WelcomeEmailQueue = "policy-welcome-email";
    public const string ClientFolderQueue = "client-folder";

    private ContractEvent() { } // EF Core

    public Guid Id { get; private set; }
    public Guid ContractId { get; private set; }
    public ContractEventType Type { get; private set; }
    public string? Queue { get; private set; }
    public string Payload { get; private set; } = "{}";
    public ContractEventStatus Status { get; private set; }
    public short Attempts { get; private set; }
    public DateTimeOffset? NextAttemptAt { get; private set; }
    public DateTimeOffset? PublishedAt { get; private set; }
    public DateTimeOffset? CompletedAt { get; private set; }
    public string? LastError { get; private set; }
    public DateTimeOffset CreatedAt { get; private set; }

    /// <summary>Hecho que solo se anota en la bitácora.</summary>
    public static ContractEvent Record(Guid contractId, ContractEventType type, string payloadJson, DateTimeOffset now) => new()
    {
        Id = Guid.CreateVersion7(), ContractId = contractId, Type = type, Payload = payloadJson,
        Status = ContractEventStatus.Recorded, CreatedAt = now
    };

    /// <summary>Mensaje que el publicador enviará a una cola de Service Bus.</summary>
    public static ContractEvent Enqueue(Guid contractId, ContractEventType type, string queue, string payloadJson, DateTimeOffset now) => new()
    {
        Id = Guid.CreateVersion7(), ContractId = contractId, Type = type, Queue = queue, Payload = payloadJson,
        Status = ContractEventStatus.Pending, NextAttemptAt = now, CreatedAt = now
    };

    public void MarkPublished(DateTimeOffset now)
    {
        Status = ContractEventStatus.Published;
        PublishedAt = now;
        Attempts++;
        NextAttemptAt = null;
        LastError = null;
    }

    /// <summary>Falló el envío: reintenta con espera creciente y se rinde al agotar los intentos.</summary>
    public void MarkPublishFailed(string error, DateTimeOffset now, int maxAttempts)
    {
        Attempts++;
        LastError = error.Length > 2000 ? error[..2000] : error;
        if (Attempts >= maxAttempts)
        {
            Status = ContractEventStatus.Failed;
            NextAttemptAt = null;
        }
        else
        {
            NextAttemptAt = now.AddSeconds(Math.Min(900, 15 * Math.Pow(2, Attempts)));
        }
    }

    /// <summary>El consumidor (correo, DocumentEngine) confirma el resultado.</summary>
    public Result Confirm(bool succeeded, string? error, DateTimeOffset now)
    {
        if (Queue is null)
            return Error.Conflict("EVENT_NOT_QUEUED", "Este evento no se publica en ninguna cola.");
        Status = succeeded ? ContractEventStatus.Completed : ContractEventStatus.Failed;
        CompletedAt = succeeded ? now : null;
        LastError = succeeded ? null : error;
        return Result.Success();
    }

    /// <summary>Reenvío pedido por soporte.</summary>
    public Result Requeue(DateTimeOffset now)
    {
        if (Queue is null)
            return Error.Conflict("EVENT_NOT_QUEUED", "Este evento no se publica en ninguna cola.");
        Status = ContractEventStatus.Pending;
        NextAttemptAt = now;
        Attempts = 0;
        LastError = null;
        return Result.Success();
    }
}
