using Check.Domain.Common;

namespace Check.Domain.Contracts;

public static class ContractErrors
{
    public static readonly Error NotFound =
        Error.NotFound("CONTRACT_NOT_FOUND", "El contrato no existe.");

    public static Error InvalidStatus(ContractStatus current, string action) =>
        Error.Conflict("CONTRACT_INVALID_STATUS", $"No se puede {action} un contrato en estado {current}.");

    public static readonly Error ContractorMustBeAdult =
        Error.BusinessRule("CONTRACTOR_MUST_BE_ADULT", "El contratante debe ser mayor de edad.");

    public static readonly Error ContractorContactRequired =
        Error.Validation("CONTRACTOR_CONTACT_REQUIRED", "El contratante debe registrar celular y correo electrónico.");

    public static Error InsuredAgeOutOfRange(int age, int min, int max) =>
        Error.BusinessRule("INSURED_AGE_OUT_OF_RANGE", $"La edad del asegurado ({age} años) está fuera del rango permitido por el plan: de {min} a {max} años.");

    public static readonly Error InsuredHasActiveContract =
        Error.BusinessRule("INSURED_HAS_ACTIVE_CONTRACT", "El asegurado ya tiene una póliza vigente de este producto.");

    public static readonly Error MinorRequiresDifferentContractor =
        Error.BusinessRule("MINOR_REQUIRES_CONTRACTOR", "Un asegurado menor de edad requiere un contratante mayor de edad distinto.");

    public static readonly Error BrokerSaleDisabled =
        Error.BusinessRule("BROKER_SALE_DISABLED", "Este plan no está habilitado para la venta por agencias de brokers.");

    public static readonly Error AgentNotValid =
        Error.BusinessRule("AGENT_NOT_VALID", "El agente no existe o su acreditación no está vigente.");

    public static readonly Error ConsentsRequired =
        Error.BusinessRule("CONSENTS_REQUIRED", "Debes aceptar el condicionado general y la política de tratamiento de datos antes de continuar.");
}
