using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Domain.People;

namespace Check.Domain.Contracts;

/// <summary>
/// El contrato con el cliente. Nace al iniciar la compra y, al pagarse el QR,
/// recibe número de póliza y vigencia (sin periodo de carencia).
/// </summary>
public sealed class Contract
{
    private readonly List<ContractParty> _parties = [];
    private readonly List<ContractDetail> _details = [];
    private readonly List<Beneficiary> _beneficiaries = [];
    private readonly List<Consent> _consents = [];

    private Contract() { } // EF Core

    public Guid Id { get; private set; }
    public string? Number { get; private set; }
    public long PlanId { get; private set; }
    public ContractStatus Status { get; private set; }
    public string? RejectionReason { get; private set; }
    public Guid? AgreementId { get; private set; }
    public decimal PremiumAmount { get; private set; }
    public int CoverageDays { get; private set; }
    public string Currency { get; private set; } = null!;
    public DateTimeOffset? CoverageFrom { get; private set; }
    public DateTimeOffset? CoverageTo { get; private set; }
    public SalesChannel Channel { get; private set; }
    public string? ClientIp { get; private set; }
    public DateTimeOffset CreatedAt { get; private set; }

    public IReadOnlyList<ContractParty> Parties => _parties;
    public IReadOnlyList<ContractDetail> Details => _details;
    public IReadOnlyList<Beneficiary> Beneficiaries => _beneficiaries;
    public IReadOnlyList<Consent> Consents => _consents;

    public ContractParty Contractor => _parties.Single(p => p.Role == PartyRole.Contractor);
    public ContractParty Insured => _parties.Single(p => p.Role == PartyRole.Insured);
    public ContractParty? Agent => _parties.SingleOrDefault(p => p.Role == PartyRole.Agent);

    /// <summary>Contratante y asegurado (las partes que se validan y declaran).</summary>
    public IEnumerable<ContractParty> Customers => _parties.Where(p => p.Role != PartyRole.Agent);

    public static Contract Start(
        long planId, ContractTerms terms,
        Person contractor, PartyData contractorData,
        Person insured, PartyData insuredData,
        Agent? agent,
        IReadOnlyDictionary<long, string> details,
        string? clientIp, DateTimeOffset now)
    {
        var contract = new Contract
        {
            Id = Guid.CreateVersion7(),
            PlanId = planId,
            Status = ContractStatus.Started,
            AgreementId = terms.AgreementId,
            PremiumAmount = terms.Premium.Amount,
            Currency = terms.Premium.Currency,
            CoverageDays = terms.CoverageDays,
            Channel = agent is null ? SalesChannel.Web : SalesChannel.Broker,
            ClientIp = clientIp,
            CreatedAt = now
        };

        contract._parties.Add(ContractParty.ForCustomer(contractor, PartyRole.Contractor, contractorData));
        contract._parties.Add(ContractParty.ForCustomer(insured, PartyRole.Insured, insuredData));
        if (agent is not null) contract._parties.Add(ContractParty.ForAgent(agent));
        foreach (var (fieldId, value) in details)
            contract._details.Add(ContractDetail.Create(fieldId, value));

        return contract;
    }

    public Result MarkValidated() => Move(ContractStatus.Started, ContractStatus.Validated, "validar");

    public Result Reject(string reason)
    {
        var move = Move(ContractStatus.Started, ContractStatus.Rejected, "rechazar");
        if (move.IsSuccess) RejectionReason = reason;
        return move;
    }

    /// <summary>Registra beneficiarios (vacío = herederos legales). Se puede corregir hasta verificar el OTP.</summary>
    public Result Declare(IEnumerable<Beneficiary> beneficiaries)
    {
        if (Status is not (ContractStatus.Validated or ContractStatus.Declared))
            return ContractErrors.InvalidStatus(Status, "registrar las declaraciones de");
        _beneficiaries.Clear();
        _beneficiaries.AddRange(beneficiaries);
        Status = ContractStatus.Declared;
        return Result.Success();
    }

    /// <summary>Registra o reemplaza la aceptación de un documento.</summary>
    public Result Accept(ConsentDocumentType type, string code, string version, byte[] contentHash,
        string ipAddress, string? userAgent, DateTimeOffset now)
    {
        if (Status != ContractStatus.Declared)
            return ContractErrors.InvalidStatus(Status, "registrar aceptaciones en");
        _consents.RemoveAll(c => c.DocumentType == type);
        _consents.Add(Consent.Create(Contractor, type, code, version, contentHash, ipAddress, userAgent, now));
        return Result.Success();
    }

    public bool HasRequiredConsents =>
        _consents.Any(c => c.DocumentType == ConsentDocumentType.GeneralConditions) &&
        _consents.Any(c => c.DocumentType == ConsentDocumentType.DataPrivacy);

    /// <summary>OTP validado: las aceptaciones quedan firmadas con ese código.</summary>
    public Result MarkVerified(long otpChallengeId)
    {
        if (!HasRequiredConsents) return ContractErrors.ConsentsRequired;
        var move = Move(ContractStatus.Declared, ContractStatus.Verified, "verificar");
        if (move.IsSuccess)
            foreach (var consent in _consents) consent.SignWith(otpChallengeId);
        return move;
    }

    public Result MarkPendingPayment()
    {
        if (Status is not (ContractStatus.Verified or ContractStatus.PendingPayment))
            return ContractErrors.InvalidStatus(Status, "generar el QR de");
        Status = ContractStatus.PendingPayment;
        return Result.Success();
    }

    /// <summary>Pago confirmado: la cobertura empieza en ese instante.</summary>
    public Result Activate(string number, DateTimeOffset paidAt)
    {
        if (Status == ContractStatus.Active) return Result.Success(); // idempotente
        if (Status is not (ContractStatus.PendingPayment or ContractStatus.Verified))
            return ContractErrors.InvalidStatus(Status, "activar");
        Number = number;
        CoverageFrom = paidAt;
        CoverageTo = paidAt.AddDays(CoverageDays);
        Status = ContractStatus.Active;
        return Result.Success();
    }

    private Result Move(ContractStatus from, ContractStatus to, string action)
    {
        if (Status != from) return ContractErrors.InvalidStatus(Status, action);
        Status = to;
        return Result.Success();
    }
}

/// <summary>
/// Contratante, asegurado o agente de un contrato, con la copia (snapshot)
/// de sus datos al momento de contratar.
/// </summary>
public sealed class ContractParty
{
    private ContractParty() { } // EF Core

    public long Id { get; private set; }
    public Guid ContractId { get; private set; }
    public Guid PersonId { get; private set; }
    public PartyRole Role { get; private set; }
    public Guid? AgentId { get; private set; }
    public long? PepDeclarationId { get; private set; }

    public string DocumentNumber { get; private set; } = null!;
    public string? DocumentComplement { get; private set; }
    public string? DocumentExtension { get; private set; }
    public string Names { get; private set; } = null!;
    public string? PaternalLastname { get; private set; }
    public string? MaternalLastname { get; private set; }
    public DateOnly? Birthdate { get; private set; }
    public string? Address { get; private set; }
    public string? Cellphone { get; private set; }
    public string? Email { get; private set; }
    public Gender? Gender { get; private set; }
    public short? NationalityId { get; private set; }
    public string? City { get; private set; }
    public string? MaritalStatus { get; private set; }
    public string? Occupation { get; private set; }
    public string? EconomicActivity { get; private set; }
    public string? MonthlyIncomeRange { get; private set; }

    public Person Person { get; private set; } = null!;

    public string FullName => string.Join(' ', new[] { Names, PaternalLastname, MaternalLastname }.Where(p => !string.IsNullOrEmpty(p)));

    /// <summary>Apunta a la declaración PEP vigente de la persona al contratar.</summary>
    public void LinkPepDeclaration(long pepDeclarationId) => PepDeclarationId = pepDeclarationId;

    internal static ContractParty ForCustomer(Person person, PartyRole role, PartyData data) => new()
    {
        PersonId = person.Id,
        Person = person,
        Role = role,
        DocumentNumber = data.Document.Number,
        DocumentComplement = data.Document.Complement,
        DocumentExtension = data.Document.Extension,
        Names = data.Name.Names,
        PaternalLastname = data.Name.PaternalLastname,
        MaternalLastname = data.Name.MaternalLastname,
        Birthdate = data.Birthdate,
        Address = data.Address,
        Cellphone = data.Cellphone?.Value,
        Email = data.Email?.Value,
        Gender = data.Gender,
        NationalityId = data.NationalityId,
        City = data.City,
        MaritalStatus = data.MaritalStatus,
        Occupation = data.Occupation,
        EconomicActivity = data.EconomicActivity,
        MonthlyIncomeRange = data.MonthlyIncomeRange
    };

    internal static ContractParty ForAgent(Agent agent) => new()
    {
        PersonId = agent.PersonId,
        Person = agent.Person,
        Role = PartyRole.Agent,
        AgentId = agent.Id,
        DocumentNumber = agent.Person.DocumentNumber,
        DocumentComplement = agent.Person.DocumentComplement,
        DocumentExtension = agent.Person.DocumentExtension,
        Names = agent.Person.Names,
        PaternalLastname = agent.Person.PaternalLastname,
        MaternalLastname = agent.Person.MaternalLastname
    };
}

/// <summary>Valor de un campo propio del producto (ver ContractFieldDefinition).</summary>
public sealed class ContractDetail
{
    private ContractDetail() { } // EF Core

    public long Id { get; private set; }
    public Guid ContractId { get; private set; }
    public long FieldDefinitionId { get; private set; }
    public string Value { get; private set; } = null!;

    internal static ContractDetail Create(long fieldDefinitionId, string value) =>
        new() { FieldDefinitionId = fieldDefinitionId, Value = value };
}

public sealed class Beneficiary
{
    private Beneficiary() { } // EF Core

    public long Id { get; private set; }
    public Guid ContractId { get; private set; }
    public long RelationshipId { get; private set; }
    public string? DocumentNumber { get; private set; }
    public string Names { get; private set; } = null!;
    public string? PaternalLastname { get; private set; }
    public string? MaternalLastname { get; private set; }
    public decimal Percentage { get; private set; }

    public static Beneficiary Create(long relationshipId, PersonName name, string? documentNumber, decimal percentage) => new()
    {
        RelationshipId = relationshipId, Names = name.Names, PaternalLastname = name.PaternalLastname,
        MaternalLastname = name.MaternalLastname, DocumentNumber = documentNumber, Percentage = percentage
    };
}

/// <summary>Prueba del consentimiento expreso: qué documento, qué versión y qué texto exacto aceptó el contratante.</summary>
public sealed class Consent
{
    private Consent() { } // EF Core

    public long Id { get; private set; }
    public Guid ContractId { get; private set; }
    public long ContractPartyId { get; private set; }
    public long? OtpChallengeId { get; private set; }
    public ConsentDocumentType DocumentType { get; private set; }
    public string DocumentCode { get; private set; } = null!;
    public string DocumentVersion { get; private set; } = null!;
    public byte[] ContentHash { get; private set; } = null!;
    public DateTimeOffset AcceptedAt { get; private set; }
    public string IpAddress { get; private set; } = null!;
    public string? UserAgent { get; private set; }

    public ContractParty ContractParty { get; private set; } = null!;

    internal void SignWith(long otpChallengeId) => OtpChallengeId = otpChallengeId;

    internal static Consent Create(ContractParty party, ConsentDocumentType type, string code, string version,
        byte[] contentHash, string ipAddress, string? userAgent, DateTimeOffset now) => new()
    {
        ContractParty = party, DocumentType = type, DocumentCode = code, DocumentVersion = version,
        ContentHash = contentHash, AcceptedAt = now, IpAddress = ipAddress, UserAgent = userAgent
    };
}

public enum SurveyType { ConditionsComprehension, PurchaseEase }

public sealed class SurveyResponse
{
    private SurveyResponse() { } // EF Core

    public long Id { get; private set; }
    public Guid ContractId { get; private set; }
    public SurveyType Type { get; private set; }
    public short Score { get; private set; }
    public string? Comment { get; private set; }

    public static Result<SurveyResponse> Create(Guid contractId, SurveyType type, int score, string? comment)
    {
        var max = type == SurveyType.ConditionsComprehension ? 5 : 10;
        if (score < 1 || score > max)
            return Error.Validation("SURVEY_INVALID_SCORE", $"La calificación debe estar entre 1 y {max}.");
        return new SurveyResponse { ContractId = contractId, Type = type, Score = (short)score, Comment = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim() };
    }
}
