namespace Check.Domain.Contracts;

public enum ContractStatus
{
    /// <summary>Plan elegido y datos de contratante y asegurado registrados.</summary>
    Started,
    /// <summary>Pasó SEGIP, AMLC y Archivo Negativo (o la lista blanca lo exceptuó).</summary>
    Validated,
    /// <summary>No apto. Estado final.</summary>
    Rejected,
    /// <summary>Beneficiarios y declaraciones PEP completos.</summary>
    Declared,
    /// <summary>Aceptaciones registradas y OTP validado.</summary>
    Verified,
    /// <summary>Hay un QR vigente esperando pago.</summary>
    PendingPayment,
    /// <summary>Pago confirmado: póliza vigente con número y cobertura.</summary>
    Active,
    /// <summary>Terminó la cobertura.</summary>
    Expired,
    Cancelled,
    /// <summary>Sin avance en el tiempo configurado. Estado final.</summary>
    Abandoned
}

public enum PartyRole { Contractor, Insured, Agent }

public enum SalesChannel { Web, Broker }

public enum ConsentDocumentType { GeneralConditions, ParticularConditions, DataPrivacy, PepStatement, BeneficiaryStatement }
