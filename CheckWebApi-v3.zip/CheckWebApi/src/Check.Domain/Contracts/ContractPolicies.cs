using System.Security.Cryptography;
using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Domain.People;

namespace Check.Domain.Contracts;

/// <summary>
/// Domain service: ¿puede esta persona contratar este plan hoy? Edad dentro del rango,
/// contratante adulto y sin póliza vigente del mismo producto (no un Diario con un Mensual activo).
/// </summary>
public static class EligibilityPolicy
{
    public static Result Check(PlanRules rules, PartyData contractor, PartyData insured,
        bool contractorIsInsured, bool insuredHasActiveContractOfProduct, bool viaBroker, DateOnly today)
    {
        if (viaBroker && !rules.BrokerSaleEnabled)
            return ContractErrors.BrokerSaleDisabled;

        if (Age.At(contractor.Birthdate, today) < Age.AdultAge)
            return contractorIsInsured ? ContractErrors.MinorRequiresDifferentContractor : ContractErrors.ContractorMustBeAdult;

        if (contractor.Cellphone is null || contractor.Email is null)
            return ContractErrors.ContractorContactRequired;

        var insuredAge = Age.At(insured.Birthdate, today);
        if (!rules.AllowsAge(insuredAge))
            return ContractErrors.InsuredAgeOutOfRange(insuredAge, rules.MinAge, rules.MaxAge);

        return insuredHasActiveContractOfProduct ? ContractErrors.InsuredHasActiveContract : Result.Success();
    }
}

public sealed record BeneficiaryDraft(long RelationshipId, bool RelationshipIsUnique, decimal Percentage);

/// <summary>
/// Domain service: los beneficiarios suman 100 %, no superan el máximo del plan y no repiten
/// parentescos únicos. Sin beneficiarios aplican los herederos legales; es obligatorio si el asegurado es menor.
/// </summary>
public static class BeneficiaryPolicy
{
    public static Result Check(IReadOnlyList<BeneficiaryDraft> beneficiaries, PlanRules rules, bool insuredIsMinor)
    {
        if (beneficiaries.Count == 0) return Result.Success();

        if (insuredIsMinor)
            return Error.BusinessRule("MINOR_LEGAL_HEIRS_ONLY", "Si el asegurado es menor de edad, los beneficiarios son sus herederos legales.");
        if (beneficiaries.Count > rules.MaxBeneficiaries)
            return Error.BusinessRule("BENEFICIARIES_LIMIT", $"Este plan admite como máximo {rules.MaxBeneficiaries} beneficiarios.");
        if (beneficiaries.Any(b => b.Percentage <= 0 || b.Percentage > 100))
            return Error.Validation("BENEFICIARY_INVALID_PERCENTAGE", "El porcentaje de cada beneficiario debe ser mayor a 0 y como máximo 100.");
        if (beneficiaries.Sum(b => b.Percentage) != 100m)
            return Error.BusinessRule("BENEFICIARIES_MUST_SUM_100", "Los porcentajes de los beneficiarios deben sumar 100 %.");
        if (beneficiaries.Where(b => b.RelationshipIsUnique).GroupBy(b => b.RelationshipId).Any(g => g.Count() > 1))
            return Error.BusinessRule("BENEFICIARY_RELATIONSHIP_REPEATED", "Hay un parentesco que solo puede declararse una vez (por ejemplo, cónyuge).");

        return Result.Success();
    }
}

/// <summary>Número de póliza legible y no adivinable: TDS-2026-7K4QM92X.</summary>
public static class ContractNumber
{
    private const string Alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // Crockford: sin I, L, O, U

    public static string Generate(string productCode, int year) =>
        $"{productCode}-{year}-{RandomNumberGenerator.GetString(Alphabet, 8)}";
}
