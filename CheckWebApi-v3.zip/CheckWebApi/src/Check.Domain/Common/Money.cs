namespace Check.Domain.Common;

public sealed record Money
{
    public static readonly string[] SupportedCurrencies = ["BOB", "USD"];

    private Money(decimal amount, string currency)
    {
        Amount = amount;
        Currency = currency;
    }

    public decimal Amount { get; }
    public string Currency { get; }

    public static Result<Money> Create(decimal amount, string currency)
    {
        if (amount <= 0)
            return Error.Validation("MONEY_INVALID_AMOUNT", "El monto debe ser mayor a cero.");
        if (!SupportedCurrencies.Contains(currency))
            return Error.Validation("MONEY_INVALID_CURRENCY", $"La moneda '{currency}' no está soportada.");
        return new Money(decimal.Round(amount, 2), currency);
    }
}
