namespace Check.Domain.Common;

/// <summary>Tipo de error esperado; la Api lo traduce a un código HTTP.</summary>
public enum ErrorType
{
    Validation,
    NotFound,
    Conflict,
    BusinessRule,
    Unauthorized,
    ExternalService
}

/// <summary>Error esperado del negocio: código estable en inglés y mensaje en español.</summary>
public sealed record Error(string Code, string Message, ErrorType Type)
{
    public static Error Validation(string code, string message) => new(code, message, ErrorType.Validation);
    public static Error NotFound(string code, string message) => new(code, message, ErrorType.NotFound);
    public static Error Conflict(string code, string message) => new(code, message, ErrorType.Conflict);
    public static Error BusinessRule(string code, string message) => new(code, message, ErrorType.BusinessRule);
    public static Error Unauthorized(string code, string message) => new(code, message, ErrorType.Unauthorized);
    public static Error ExternalService(string code, string message) => new(code, message, ErrorType.ExternalService);
}
