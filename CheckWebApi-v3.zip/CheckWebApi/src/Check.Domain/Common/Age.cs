namespace Check.Domain.Common;

public static class Age
{
    /// <summary>Años cumplidos a una fecha.</summary>
    public static int At(DateOnly birthdate, DateOnly date)
    {
        var age = date.Year - birthdate.Year;
        if (birthdate > date.AddYears(-age)) age--;
        return age;
    }

    public const int AdultAge = 18;
}
