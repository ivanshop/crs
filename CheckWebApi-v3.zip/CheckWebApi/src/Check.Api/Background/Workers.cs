using Check.Application.Internal;

namespace Check.Api.Background;

public sealed class WorkerOptions
{
    public const string Section = "Workers";
    public bool Enabled { get; init; } = true;
    /// <summary>Cada cuántos segundos se buscan eventos pendientes de publicar.</summary>
    public int EventPublisherSeconds { get; init; } = 5;
    public int HousekeepingSeconds { get; init; } = 60;
}

/// <summary>Outbox: publica en Service Bus los eventos Pending de sales.contract_events.</summary>
public sealed class EventPublisherWorker(IServiceScopeFactory scopes, IConfiguration configuration, ILogger<EventPublisherWorker> logger)
    : PeriodicWorker(scopes, logger, "publicador de eventos", configuration.GetSection(WorkerOptions.Section).Get<WorkerOptions>() ?? new(), o => o.EventPublisherSeconds)
{
    protected override async Task RunOnceAsync(IServiceProvider services, CancellationToken ct) =>
        await services.GetRequiredService<PublishPendingEventsUseCase>().ExecuteAsync(ct);
}

/// <summary>Vence QR, abandona contratos sin avance y cierra coberturas terminadas.</summary>
public sealed class HousekeepingWorker(IServiceScopeFactory scopes, IConfiguration configuration, ILogger<HousekeepingWorker> logger)
    : PeriodicWorker(scopes, logger, "mantenimiento", configuration.GetSection(WorkerOptions.Section).Get<WorkerOptions>() ?? new(), o => o.HousekeepingSeconds)
{
    protected override Task RunOnceAsync(IServiceProvider services, CancellationToken ct) =>
        services.GetRequiredService<HousekeepingUseCase>().ExecuteAsync(ct);
}

/// <summary>Tarea periódica: un fallo se registra y no detiene el servicio.</summary>
public abstract class PeriodicWorker(
    IServiceScopeFactory scopes, ILogger logger, string name, WorkerOptions options, Func<WorkerOptions, int> seconds) : BackgroundService
{
    protected abstract Task RunOnceAsync(IServiceProvider services, CancellationToken ct);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!options.Enabled)
        {
            logger.LogWarning("El servicio de {Servicio} está deshabilitado por configuración.", name);
            return;
        }

        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(Math.Max(1, seconds(options))));
        logger.LogInformation("Servicio de {Servicio} iniciado.", name);
        try
        {
            while (await timer.WaitForNextTickAsync(stoppingToken))
            {
                try
                {
                    await using var scope = scopes.CreateAsyncScope();
                    await RunOnceAsync(scope.ServiceProvider, stoppingToken);
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    logger.LogError(ex, "Falló una ejecución del servicio de {Servicio}.", name);
                }
            }
        }
        catch (OperationCanceledException) { /* apagado normal */ }
    }
}
