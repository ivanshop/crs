using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Infrastructure;

/// <summary>Excepciones no controladas → ProblemDetails 500, sin exponer detalles internos.</summary>
public sealed class GlobalExceptionHandler(
    IProblemDetailsService problemDetails,
    ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext context, Exception exception, CancellationToken ct)
    {
        if (exception is OperationCanceledException && context.RequestAborted.IsCancellationRequested)
        {
            logger.LogInformation("La solicitud {Metodo} {Ruta} fue cancelada por el cliente.", context.Request.Method, context.Request.Path);
            context.Response.StatusCode = 499;
            return true;
        }

        logger.LogError(exception, "Error no controlado en {Metodo} {Ruta}.", context.Request.Method, context.Request.Path);

        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        return await problemDetails.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = context,
            Exception = exception,
            ProblemDetails = new ProblemDetails
            {
                Status = StatusCodes.Status500InternalServerError,
                Title = "Ocurrió un error inesperado.",
                Detail = "Estamos revisando el problema. Intenta nuevamente en unos minutos.",
                Type = "https://tools.ietf.org/html/rfc9110#section-15.6.1",
                Extensions = { ["code"] = "UNEXPECTED_ERROR" }
            }
        });
    }
}
