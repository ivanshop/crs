using System.Threading.RateLimiting;

namespace Check.Api.Infrastructure;

public static class RateLimits
{
    public const string Token = "token";
    /// <summary>Iniciar contrato: protege contra bots (cada contrato lleva a consultas pagadas a SEGIP).</summary>
    public const string ContractStart = "contract-start";
    public const string Screening = "screening";
    /// <summary>Envío y verificación de OTP y lectura del carnet: cada llamada tiene costo.</summary>
    public const string Otp = "otp";
    public const string IdentityReading = "identity-reading";

    public static IServiceCollection AddCheckRateLimiting(this IServiceCollection services, IConfiguration configuration)
    {
        var section = configuration.GetSection("RateLimiting");
        services.AddRateLimiter(o =>
        {
            o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
            o.OnRejected = (ctx, _) => new ValueTask(AuthExtensions.WriteProblem(ctx.HttpContext.Response, 429,
                "Demasiadas solicitudes.", "Superaste el límite de intentos. Espera un momento antes de volver a intentar.", "RATE_LIMITED"));

            AddPerIp(o, Token, section.GetValue("TokenPerMinute", 20));
            AddPerIp(o, ContractStart, section.GetValue("ContractStartPerMinute", 10));
            AddPerIp(o, Otp, section.GetValue("OtpPerMinute", 6));
            AddPerIp(o, IdentityReading, section.GetValue("IdentityReadingPerMinute", 6));
            AddPerIp(o, Screening, section.GetValue("ScreeningPerMinute", 5));
        });
        return services;
    }

    private static void AddPerIp(Microsoft.AspNetCore.RateLimiting.RateLimiterOptions o, string name, int permitsPerMinute) =>
        o.AddPolicy(name, ctx => RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = permitsPerMinute, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
}
