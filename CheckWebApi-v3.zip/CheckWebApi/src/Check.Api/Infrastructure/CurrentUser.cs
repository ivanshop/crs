using Check.Application.Abstractions;

namespace Check.Api.Infrastructure;

/// <summary>Usuario para auditoría: el "sub" del JWT (cliente web, compra o usuario interno).</summary>
public sealed class CurrentUser(IHttpContextAccessor accessor) : ICurrentUser
{
    public string Name => accessor.HttpContext?.User.FindFirst("sub")?.Value ?? "system";
}
