using System.Net;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace Check.Api.Infrastructure;

public sealed class BankCallbackOptions
{
    public const string Section = "BankCallback";

    /// <summary>Secreto compartido con el Banco para firmar el cuerpo (HMAC-SHA256). Obligatorio.</summary>
    public string Secret { get; init; } = string.Empty;
    public string SignatureHeader { get; init; } = "X-Signature";
    /// <summary>Si tiene elementos, solo se aceptan avisos desde estas IP.</summary>
    public List<string> AllowedIps { get; init; } = [];
}

/// <summary>Autentica el aviso del Banco: IP permitida y firma HMAC-SHA256 del cuerpo en hexadecimal.</summary>
public sealed class BankCallbackValidator(IOptions<BankCallbackOptions> options)
{
    private readonly BankCallbackOptions _options = options.Value;

    public bool IsAuthentic(HttpContext context, string rawBody)
    {
        if (string.IsNullOrEmpty(_options.Secret)) return false;

        if (_options.AllowedIps.Count > 0)
        {
            var ip = context.Connection.RemoteIpAddress;
            if (ip is null || !_options.AllowedIps.Any(a => IPAddress.TryParse(a, out var allowed) && allowed.Equals(ip.MapToIPv4()) || a == ip.ToString()))
                return false;
        }

        var header = context.Request.Headers[_options.SignatureHeader].ToString();
        if (string.IsNullOrEmpty(header)) return false;
        if (header.StartsWith("sha256=", StringComparison.OrdinalIgnoreCase)) header = header[7..];

        byte[] received;
        try { received = Convert.FromHexString(header); }
        catch (FormatException) { return false; }

        var expected = HMACSHA256.HashData(Encoding.UTF8.GetBytes(_options.Secret), Encoding.UTF8.GetBytes(rawBody));
        return CryptographicOperations.FixedTimeEquals(expected, received);
    }
}

public static class HttpContextExtensions
{
    public static string? ClientIp(this HttpContext context) => context.Connection.RemoteIpAddress?.ToString();

    public static IActionResult ProblemWithCode(this ControllerBase controller, int status, string title, string detail, string code)
    {
        var problem = controller.ProblemDetailsFactory.CreateProblemDetails(controller.HttpContext, status, title, detail: detail);
        problem.Extensions["code"] = code;
        return new ObjectResult(problem) { StatusCode = status, ContentTypes = { "application/problem+json" } };
    }
}
