using Check.Domain.Common;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Infrastructure;

/// <summary>Traduce un Result del use case a una respuesta HTTP (ProblemDetails si falló).</summary>
public static class ResultExtensions
{
    public static IActionResult ToActionResult<T>(this Result<T> result, ControllerBase controller, int successStatus = StatusCodes.Status200OK) =>
        result.IsSuccess
            ? controller.StatusCode(successStatus, result.Value)
            : result.Error!.ToProblem(controller);

    public static IActionResult ToProblem(this Error error, ControllerBase controller)
    {
        var (status, title) = error.Type switch
        {
            ErrorType.Validation => (StatusCodes.Status400BadRequest, "Los datos enviados no son válidos."),
            ErrorType.NotFound => (StatusCodes.Status404NotFound, "No se encontró el recurso."),
            ErrorType.Conflict => (StatusCodes.Status409Conflict, "La operación no es posible en el estado actual."),
            ErrorType.BusinessRule => (StatusCodes.Status422UnprocessableEntity, "La operación no cumple una regla del negocio."),
            ErrorType.Unauthorized => (StatusCodes.Status401Unauthorized, "No autorizado."),
            ErrorType.ExternalService => (StatusCodes.Status503ServiceUnavailable, "Un servicio externo no está disponible."),
            _ => (StatusCodes.Status500InternalServerError, "Ocurrió un error inesperado.")
        };

        var problem = controller.ProblemDetailsFactory.CreateProblemDetails(controller.HttpContext, status, title, detail: error.Message);
        problem.Extensions["code"] = error.Code;
        return new ObjectResult(problem) { StatusCode = status, ContentTypes = { "application/problem+json" } };
    }
}
