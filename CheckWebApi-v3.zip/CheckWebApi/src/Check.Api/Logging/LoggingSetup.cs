using System.Text.Json;
using ZLogger;
using ZLogger.Formatters;
using ZLogger.Providers;

namespace Check.Api.Logging;

/// <summary>
/// Sección "Logs" de appsettings: destinos, formato y nombres de campos.
/// Los niveles por categoría siguen en la sección estándar "Logging:LogLevel".
/// </summary>
public sealed class LogOptions
{
    public const string Section = "Logs";

    /// <summary>Nombre del servicio; se escribe en cada línea para filtrar en Elasticsearch.</summary>
    public string Application { get; init; } = "check-api";
    public bool UseUtcTimestamp { get; init; } = true;
    /// <summary>Incluye los datos del scope (traceId, ip, contractId) en cada línea.</summary>
    public bool IncludeScopes { get; init; } = true;
    public ConsoleLogOptions Console { get; init; } = new();
    public FileLogOptions File { get; init; } = new();
    public LogFieldNames Fields { get; init; } = new();
}

public sealed class ConsoleLogOptions
{
    public bool Enabled { get; init; } = true;
    /// <summary>Json (una línea por evento) o Text (legible, para desarrollo).</summary>
    public string Format { get; init; } = "Json";
}

public sealed class FileLogOptions
{
    public bool Enabled { get; init; } = true;
    public string Format { get; init; } = "Json";
    public string Directory { get; init; } = "logs";
    public string FilePrefix { get; init; } = "check-api";
    /// <summary>Day, Hour, Month, Year o Infinite.</summary>
    public string RollingInterval { get; init; } = "Day";
    /// <summary>Tamaño máximo de cada archivo antes de abrir el siguiente del mismo periodo.</summary>
    public int RollingSizeKb { get; init; } = 10240;
}

/// <summary>Por defecto, los nombres de Elastic Common Schema (ECS): Filebeat y Elastic Agent los indexan sin transformar.</summary>
public sealed class LogFieldNames
{
    public string Timestamp { get; init; } = "@timestamp";
    public string Level { get; init; } = "log.level";
    public string Category { get; init; } = "log.logger";
    public string Message { get; init; } = "message";
    public string Exception { get; init; } = "error";
    public string Application { get; init; } = "service.name";
    public string Environment { get; init; } = "service.environment";
}

public static class LoggingSetup
{
    /// <summary>Reemplaza los proveedores por ZLogger: consola y archivo rotativo, según appsettings.</summary>
    public static ILoggingBuilder AddCheckLogging(this ILoggingBuilder logging, IConfiguration configuration, IHostEnvironment environment)
    {
        var options = configuration.GetSection(LogOptions.Section).Get<LogOptions>() ?? new LogOptions();

        logging.ClearProviders();
        logging.AddConfiguration(configuration.GetSection("Logging"));

        if (options.Console.Enabled)
            logging.AddZLoggerConsole(o => Configure(o, options, options.Console.Format, environment));

        if (options.File.Enabled)
        {
            var directory = Path.GetFullPath(options.File.Directory);
            Directory.CreateDirectory(directory);
            var interval = Enum.TryParse<RollingInterval>(options.File.RollingInterval, true, out var parsed) ? parsed : RollingInterval.Day;

            logging.AddZLoggerRollingFile(o =>
            {
                o.FilePathSelector = (timestamp, sequence) =>
                    Path.Combine(directory, $"{options.File.FilePrefix}-{timestamp.ToLocalTime():yyyy-MM-dd}_{sequence:000}.log");
                o.RollingInterval = interval;
                o.RollingSizeKB = options.File.RollingSizeKb;
                Configure(o, options, options.File.Format, environment);
            });
        }

        return logging;
    }

    private static void Configure(ZLoggerOptions o, LogOptions options, string format, IHostEnvironment environment)
    {
        o.IncludeScopes = options.IncludeScopes;

        if (!string.Equals(format, "Json", StringComparison.OrdinalIgnoreCase))
        {
            o.UsePlainTextFormatter();
            return;
        }

        var application = JsonEncodedText.Encode(options.Fields.Application);
        var environmentField = JsonEncodedText.Encode(options.Fields.Environment);

        o.UseJsonFormatter(formatter =>
        {
            formatter.UseUtcTimestamp = options.UseUtcTimestamp;
            formatter.IncludeProperties =
                IncludeProperties.Timestamp | IncludeProperties.LogLevel | IncludeProperties.CategoryName |
                IncludeProperties.Message | IncludeProperties.Exception |
                IncludeProperties.ParameterKeyValues | IncludeProperties.ScopeKeyValues;
            formatter.JsonPropertyNames = JsonPropertyNames.Default with
            {
                Timestamp = JsonEncodedText.Encode(options.Fields.Timestamp),
                LogLevel = JsonEncodedText.Encode(options.Fields.Level),
                Category = JsonEncodedText.Encode(options.Fields.Category),
                Message = JsonEncodedText.Encode(options.Fields.Message),
                Exception = JsonEncodedText.Encode(options.Fields.Exception)
            };
            formatter.AdditionalFormatter = (Utf8JsonWriter writer, in LogInfo _) =>
            {
                writer.WriteString(application, options.Application);
                writer.WriteString(environmentField, environment.EnvironmentName);
            };
        });
    }
}
