using System.Net;
using System.Text.Json.Serialization;
using Check.Api.Background;
using Check.Api.Infrastructure;
using Check.Api.Logging;
using Check.Application;
using Check.Application.Abstractions;
using Check.Infrastructure;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.AddCheckLogging(builder.Configuration, builder.Environment);

builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUser, CurrentUser>();
builder.Services.AddOptions<BankCallbackOptions>().Bind(builder.Configuration.GetSection(BankCallbackOptions.Section));
builder.Services.AddSingleton<BankCallbackValidator>();
builder.Services.AddHostedService<EventPublisherWorker>();
builder.Services.AddHostedService<HousekeepingWorker>();

// Detrás de un proxy o balanceador: la IP real del cliente llega en X-Forwarded-For.
var proxies = builder.Configuration.GetSection("ForwardedHeaders:KnownProxies").Get<string[]>() ?? [];
builder.Services.Configure<ForwardedHeadersOptions>(o =>
{
    o.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    foreach (var proxy in proxies)
        if (IPAddress.TryParse(proxy, out var address)) o.KnownProxies.Add(address);
});

builder.Services
    .AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()))
    .ConfigureApiBehaviorOptions(o =>
    {
        // Errores de forma del request (DataAnnotations / JSON mal formado) en español
        o.InvalidModelStateResponseFactory = ctx =>
        {
            var problem = new ValidationProblemDetails(ctx.ModelState)
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "Los datos enviados no son válidos.",
                Detail = "Revisa los campos indicados en 'errors'."
            };
            problem.Extensions["code"] = "VALIDATION_ERROR";
            problem.Extensions["traceId"] = ctx.HttpContext.TraceIdentifier;
            return new BadRequestObjectResult(problem) { ContentTypes = { "application/problem+json" } };
        };
    });

builder.Services.AddProblemDetails(o => o.CustomizeProblemDetails = ctx =>
    ctx.ProblemDetails.Extensions.TryAdd("traceId", ctx.HttpContext.TraceIdentifier));
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();

builder.Services.AddCheckAuth(builder.Configuration);
builder.Services.AddCheckRateLimiting(builder.Configuration);
builder.Services.AddOpenApi();

var app = builder.Build();

if (proxies.Length > 0) app.UseForwardedHeaders();
app.UseMiddleware<RequestLoggingMiddleware>();
app.UseExceptionHandler();
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
    app.MapOpenApi("openapi");

app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Logger.LogInformation("Check Web API iniciada en el entorno {Entorno}.", app.Environment.EnvironmentName);
app.Run();
