using Check.Api.Infrastructure;
using Check.Application.Internal;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

/// <summary>Operación interna: soporte, Cumplimiento, administración comercial y consumidores de eventos.</summary>
[ApiController]
[Route("api/v1/internal")]
[Authorize(Policy = Policies.Internal)]
public sealed class InternalController : ControllerBase
{
    /// <summary>Bitácora de un contrato.</summary>
    [HttpGet("contracts/{id:guid}/events")]
    public async Task<IActionResult> Events(Guid id, [FromServices] ContractEventsUseCase useCase, CancellationToken ct) =>
        (await useCase.ListAsync(id, ct)).ToActionResult(this);

    /// <summary>Reenvía el correo de bienvenida (WelcomeEmail) o regenera la Carpeta de Cliente (ClientFolder).</summary>
    [HttpPost("contracts/{id:guid}/events/{type}/resend")]
    public async Task<IActionResult> Resend(Guid id, string type, [FromServices] ContractEventsUseCase useCase, CancellationToken ct) =>
        (await useCase.ResendAsync(id, type, ct)).ToActionResult(this, StatusCodes.Status202Accepted);

    /// <summary>El consumidor (correo, DocumentEngine) confirma que terminó o que falló.</summary>
    [HttpPost("events/{eventId:guid}/confirmation")]
    public async Task<IActionResult> Confirm(Guid eventId, EventConfirmationRequest request, [FromServices] ContractEventsUseCase useCase, CancellationToken ct) =>
        (await useCase.ConfirmAsync(eventId, request, ct)).ToActionResult(this);

    /// <summary>Conciliación manual de un pago que el Banco no notificó.</summary>
    [HttpPost("qr-payments/{qrPaymentId:guid}/manual-confirmation")]
    public async Task<IActionResult> ConfirmPayment(Guid qrPaymentId, ManualPaymentRequest request, [FromServices] ConfirmPaymentManuallyUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(qrPaymentId, request, ct)).ToActionResult(this);

    /// <summary>Lista blanca: exceptúa a una persona de AMLC o Archivo Negativo.</summary>
    [HttpPost("screening-exceptions")]
    public async Task<IActionResult> CreateException(ScreeningExceptionRequest request, [FromServices] CreateScreeningExceptionUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(request, ct)).ToActionResult(this, StatusCodes.Status201Created);

    /// <summary>Backoffice: registra una empresa cliente.</summary>
    [HttpPost("companies")]
    public async Task<IActionResult> CreateCompany(CompanyRequest request, [FromServices] AgreementsUseCase useCase, CancellationToken ct) =>
        (await useCase.CreateCompanyAsync(request, ct)).ToActionResult(this, StatusCodes.Status201Created);

    /// <summary>Backoffice: registra un convenio negociado (queda en borrador).</summary>
    [HttpPost("agreements")]
    public async Task<IActionResult> Negotiate(AgreementRequest request, [FromServices] AgreementsUseCase useCase, CancellationToken ct) =>
        (await useCase.NegotiateAsync(request, ct)).ToActionResult(this, StatusCodes.Status201Created);

    /// <summary>Backoffice: aprueba un convenio. Debe hacerlo alguien distinto de quien lo negoció.</summary>
    [HttpPost("agreements/{code}/approval")]
    public async Task<IActionResult> Approve(string code, [FromServices] AgreementsUseCase useCase, CancellationToken ct) =>
        (await useCase.ApproveAsync(code, ct)).ToActionResult(this);

    [HttpPost("agreements/{code}/closure")]
    public async Task<IActionResult> Close(string code, [FromServices] AgreementsUseCase useCase, CancellationToken ct) =>
        (await useCase.CloseAsync(code, ct)).ToActionResult(this);

    /// <summary>Backoffice: condiciones del convenio y cupo usado.</summary>
    [HttpGet("agreements/{code}")]
    public async Task<IActionResult> GetAgreement(string code, [FromServices] AgreementsUseCase useCase, CancellationToken ct) =>
        (await useCase.GetAsync(code, ct)).ToActionResult(this);

    [HttpPost("agencies")]
    public async Task<IActionResult> CreateAgency(AgencyRequest request, [FromServices] AgenciesUseCase useCase, CancellationToken ct) =>
        (await useCase.CreateAgencyAsync(request, ct)).ToActionResult(this, StatusCodes.Status201Created);

    [HttpPost("agencies/{agencyCode}/agents")]
    public async Task<IActionResult> CreateAgent(string agencyCode, AgentRequest request, [FromServices] AgenciesUseCase useCase, CancellationToken ct) =>
        (await useCase.CreateAgentAsync(agencyCode, request, ct)).ToActionResult(this, StatusCodes.Status201Created);
}
