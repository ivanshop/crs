using Check.Api.Infrastructure;
using Check.Application.Contracts;
using Check.Application.Payments;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Check.Api.Controllers;

/// <summary>
/// El flujo de contratación, en orden: iniciar → validar → declarar → aceptar → OTP → QR.
/// Desde el segundo paso se usa el token del contrato que devuelve el primero.
/// </summary>
[ApiController]
[Route("api/v1/contracts")]
public sealed class ContractsController : ControllerBase
{
    /// <summary>1. Inicia el contrato: plan, contratante, asegurado y (si aplica) agente.</summary>
    [HttpPost]
    [Authorize(Policy = Policies.WebClient)]
    [EnableRateLimiting(RateLimits.ContractStart)]
    public async Task<IActionResult> Start(StartContractRequest request, [FromServices] StartContractUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(request, HttpContext.ClientIp(), ct)).ToActionResult(this, StatusCodes.Status201Created);

    /// <summary>2. Valida contratante y asegurado con SEGIP, AMLC y Archivo Negativo.</summary>
    [HttpPost("{id:guid}/screening")]
    [Authorize(Policy = Policies.ContractOwner)]
    [EnableRateLimiting(RateLimits.Screening)]
    public async Task<IActionResult> Screen(Guid id, [FromServices] ScreenContractUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, ct)).ToActionResult(this);

    /// <summary>3. Beneficiarios (vacío = herederos legales) y declaraciones PEP.</summary>
    [HttpPut("{id:guid}/declarations")]
    [Authorize(Policy = Policies.ContractOwner)]
    public async Task<IActionResult> Declare(Guid id, DeclarationsRequest request, [FromServices] DeclareUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, request, ct)).ToActionResult(this);

    /// <summary>4. Aceptación del condicionado y de la política de datos.</summary>
    [HttpPut("{id:guid}/consents")]
    [Authorize(Policy = Policies.ContractOwner)]
    public async Task<IActionResult> Accept(Guid id, ConsentsRequest request, [FromServices] AcceptConsentsUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, request, HttpContext.ClientIp() ?? "0.0.0.0", Request.Headers.UserAgent.ToString(), ct)).ToActionResult(this);

    /// <summary>5a. Envía el código OTP al contratante.</summary>
    [HttpPost("{id:guid}/otp")]
    [Authorize(Policy = Policies.ContractOwner)]
    [EnableRateLimiting(RateLimits.Otp)]
    public async Task<IActionResult> SendOtp(Guid id, SendOtpRequest request, [FromServices] SendOtpUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, request, ct)).ToActionResult(this);

    /// <summary>5b. Verifica el código OTP: firma las aceptaciones.</summary>
    [HttpPost("{id:guid}/otp/verification")]
    [Authorize(Policy = Policies.ContractOwner)]
    [EnableRateLimiting(RateLimits.Otp)]
    public async Task<IActionResult> VerifyOtp(Guid id, VerifyOtpRequest request, [FromServices] VerifyOtpUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, request, ct)).ToActionResult(this);

    /// <summary>6. Genera el QR de pago (o devuelve el vigente). Si venció, genera otro sin nuevo OTP.</summary>
    [HttpPost("{id:guid}/qr")]
    [Authorize(Policy = Policies.ContractOwner)]
    public async Task<IActionResult> GenerateQr(Guid id, [FromServices] GenerateQrUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, ct)).ToActionResult(this);

    /// <summary>Estado del contrato; la web lo consulta mientras espera el pago.</summary>
    [HttpGet("{id:guid}")]
    [Authorize(Policy = Policies.ContractOwner)]
    public async Task<IActionResult> Get(Guid id, [FromServices] GetContractUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, ct)).ToActionResult(this);

    /// <summary>Encuestas: comprensión del condicionado (1 a 5) y facilidad de compra (1 a 10).</summary>
    [HttpPost("{id:guid}/surveys")]
    [Authorize(Policy = Policies.ContractOwner)]
    public async Task<IActionResult> Survey(Guid id, SurveyRequest request, [FromServices] SubmitSurveyUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(id, request, ct)).ToActionResult(this, StatusCodes.Status201Created);
}
