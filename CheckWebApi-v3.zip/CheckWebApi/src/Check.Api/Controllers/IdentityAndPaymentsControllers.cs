using System.Text;
using System.Text.Json;
using Check.Api.Infrastructure;
using Check.Application.Compliance;
using Check.Application.Payments;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/identity-readings")]
[Authorize(Policy = Policies.WebClient)]
public sealed class IdentityReadingsController : ControllerBase
{
    /// <summary>Lee el anverso y el reverso del carnet con LlamitAI para precargar el formulario.</summary>
    [HttpPost]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(12 * 1024 * 1024)]
    [EnableRateLimiting(RateLimits.IdentityReading)]
    public async Task<IActionResult> Read(IFormFile front, IFormFile back, [FromServices] ReadIdentityUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(await ToImage(front, ct), await ToImage(back, ct), HttpContext.ClientIp(), ct))
            .ToActionResult(this, StatusCodes.Status201Created);

    private static async Task<IdentityImage> ToImage(IFormFile file, CancellationToken ct)
    {
        using var memory = new MemoryStream();
        await file.CopyToAsync(memory, ct);
        return new IdentityImage(memory.ToArray(), Path.GetExtension(file.FileName));
    }
}

/// <summary>
/// Aviso de pago del Banco. No usa JWT: el Banco firma el cuerpo con HMAC-SHA256 (cabecera X-Signature)
/// y, si se configura, solo se aceptan sus direcciones IP.
/// </summary>
[ApiController]
[Route("api/v1/payments")]
[AllowAnonymous]
public sealed class PaymentsController(BankCallbackValidator validator, ILogger<PaymentsController> logger) : ControllerBase
{
    [HttpPost("notifications")]
    [RequestSizeLimit(64 * 1024)]
    public async Task<IActionResult> Notify([FromServices] ProcessPaymentNotificationUseCase useCase, CancellationToken ct)
    {
        using var reader = new StreamReader(Request.Body, Encoding.UTF8);
        var raw = await reader.ReadToEndAsync(ct);

        if (!validator.IsAuthentic(HttpContext, raw))
        {
            logger.LogWarning("Aviso de pago rechazado desde {Ip}: firma o IP no válidas.", HttpContext.ClientIp());
            return this.ProblemWithCode(StatusCodes.Status401Unauthorized, "No autenticado.", "La firma del aviso no es válida.", "INVALID_SIGNATURE");
        }

        PaymentNotificationRequest? request;
        try { request = JsonSerializer.Deserialize<PaymentNotificationRequest>(raw, JsonSerializerOptions.Web); }
        catch (JsonException) { request = null; }

        if (request is null || !TryValidateModel(request))
            return this.ProblemWithCode(StatusCodes.Status400BadRequest, "Los datos enviados no son válidos.", "El aviso de pago no tiene el formato esperado.", "VALIDATION_ERROR");

        return (await useCase.ExecuteAsync(request, raw, ct)).ToActionResult(this);
    }
}
