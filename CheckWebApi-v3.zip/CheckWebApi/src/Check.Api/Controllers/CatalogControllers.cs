using Check.Api.Infrastructure;
using Check.Application.Catalog;
using Check.Application.Internal;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/products")]
[Authorize(Policy = Policies.WebClient)]
public sealed class ProductsController : ControllerBase
{
    /// <summary>Productos con sus planes, prima, coberturas, asistencias, exclusiones y campos propios.</summary>
    [HttpGet]
    public async Task<IActionResult> GetAll([FromServices] GetProductsUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(ct)).ToActionResult(this);

    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code, [FromServices] GetProductUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(code, ct)).ToActionResult(this);
}

[ApiController]
[Route("api/v1/faqs")]
[Authorize(Policy = Policies.WebClient)]
public sealed class FaqsController : ControllerBase
{
    /// <summary>Preguntas frecuentes de todos los productos o, si se indica, de uno.</summary>
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string? productCode, [FromServices] GetFaqsUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(productCode, ct)).ToActionResult(this);
}

[ApiController]
[Route("api/v1/catalogs")]
[Authorize(Policy = Policies.WebClient)]
public sealed class CatalogsController : ControllerBase
{
    /// <summary>Listas para la web: document_extension, marital_status, country...</summary>
    [HttpGet("{topic}")]
    public async Task<IActionResult> Get(string topic, [FromServices] GetCatalogUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(topic, ct)).ToActionResult(this);
}

[ApiController]
[Route("api/v1/agreements")]
[Authorize(Policy = Policies.WebClient)]
public sealed class AgreementsController : ControllerBase
{
    /// <summary>Condiciones de un convenio vigente, para el empleado que ingresa el código en la web.</summary>
    [HttpGet("{code}")]
    public async Task<IActionResult> Get(string code, [FromServices] AgreementsUseCase useCase, CancellationToken ct) =>
        (await useCase.GetOfferAsync(code, ct)).ToActionResult(this);
}

[ApiController]
[Route("api/v1/relationships")]
[Authorize(Policy = Policies.WebClient)]
public sealed class RelationshipsController : ControllerBase
{
    /// <summary>Parentescos para beneficiarios y familiares PEP.</summary>
    [HttpGet]
    public async Task<IActionResult> Get([FromServices] GetRelationshipsUseCase useCase, CancellationToken ct) =>
        (await useCase.ExecuteAsync(ct)).ToActionResult(this);
}
