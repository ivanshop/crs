using Check.Domain.Contracts;
using Check.Domain.Payments;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 8: encuestas y conciliación manual de pagos.</summary>
public class Sprint8SurveyAndReconciliationTests
{
    [Theory]
    [InlineData(SurveyType.ConditionsComprehension, 5, true)]
    [InlineData(SurveyType.ConditionsComprehension, 6, false)]
    [InlineData(SurveyType.PurchaseEase, 10, true)]
    [InlineData(SurveyType.PurchaseEase, 0, false)]
    public void Cada_encuesta_tiene_su_escala(SurveyType type, int score, bool valid) =>
        Assert.Equal(valid, SurveyResponse.Create(Guid.NewGuid(), type, score, null).IsSuccess);

    [Fact]
    public void La_conciliacion_manual_exige_justificacion()
    {
        var qr = QrPayment.Create(Guid.NewGuid(), Guid.NewGuid(), TestData.Bob(5m), null, "qr", TestData.Now.AddMinutes(30));

        Assert.Equal("MANUAL_REASON_REQUIRED", qr.ConfirmManually("TX-9", "soporte1", " ", TestData.Now).Error!.Code);
    }

    [Fact]
    public void La_conciliacion_manual_registra_al_operador_y_no_se_repite()
    {
        var qr = QrPayment.Create(Guid.NewGuid(), Guid.NewGuid(), TestData.Bob(5m), null, "qr", TestData.Now.AddMinutes(30));

        Assert.True(qr.ConfirmManually("TX-9", "soporte1", "El Banco confirmó el pago por correo", TestData.Now).IsSuccess);
        Assert.Equal("soporte1", qr.ConfirmedManuallyBy);
        Assert.Equal("QR_ALREADY_PAID", qr.ConfirmManually("TX-9", "soporte1", "otra vez", TestData.Now).Error!.Code);
    }
}
