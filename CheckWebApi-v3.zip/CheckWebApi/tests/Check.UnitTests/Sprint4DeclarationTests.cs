using System.Security.Cryptography;
using System.Text;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.Payments;
using Check.Domain.People;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 4: beneficiarios, PEP, aceptaciones y OTP.</summary>
public class Sprint4DeclarationTests
{
    private static byte[] Hash(string code) => SHA256.HashData(Encoding.UTF8.GetBytes(code));

    [Fact]
    public void Sin_beneficiarios_aplican_los_herederos_legales() =>
        Assert.True(BeneficiaryPolicy.Check([], TestData.Rules(), insuredIsMinor: false).IsSuccess);

    [Fact]
    public void Los_porcentajes_deben_sumar_100()
    {
        var result = BeneficiaryPolicy.Check([new(1, true, 60m), new(2, false, 30m)], TestData.Rules(), false);

        Assert.Equal("BENEFICIARIES_MUST_SUM_100", result.Error!.Code);
    }

    [Fact]
    public void Un_asegurado_menor_solo_admite_herederos_legales()
    {
        var result = BeneficiaryPolicy.Check([new(2, false, 100m)], TestData.Rules(), insuredIsMinor: true);

        Assert.Equal("MINOR_LEGAL_HEIRS_ONLY", result.Error!.Code);
    }

    [Fact]
    public void El_conyuge_no_puede_declararse_dos_veces()
    {
        var result = BeneficiaryPolicy.Check([new(1, true, 50m), new(1, true, 50m)], TestData.Rules(), false);

        Assert.Equal("BENEFICIARY_RELATIONSHIP_REPEATED", result.Error!.Code);
    }

    [Fact]
    public void Un_PEP_debe_declarar_al_menos_un_familiar()
    {
        var pep = PepDeclaration.Create(Guid.NewGuid(), true, "Concejal", "GAMLP", null, null, [], [], TestData.Now);

        Assert.Equal("PEP_RELATIVE_REQUIRED", pep.Error!.Code);
    }

    [Fact]
    public void Una_declaracion_identica_se_reconoce_como_equivalente()
    {
        var name = PersonName.Create("María", "Pérez", null).Value;
        var a = PepDeclaration.Create(Guid.Empty, true, "Concejal", "GAMLP", null, null, [PepRelative.Create(1, name, null)], [], TestData.Now).Value;
        var b = PepDeclaration.Create(Guid.Empty, true, "Concejal", "GAMLP", null, null, [PepRelative.Create(1, name, null)], [], TestData.Now).Value;

        Assert.True(a.IsEquivalentTo(b));
    }

    [Fact]
    public void Sin_aceptaciones_obligatorias_no_se_puede_verificar()
    {
        var contract = TestData.StartContract();
        contract.MarkValidated();
        contract.Declare([]);

        var verified = contract.MarkVerified(otpChallengeId: 1);

        Assert.Equal("CONSENTS_REQUIRED", verified.Error!.Code);
    }

    [Fact]
    public void El_OTP_correcto_firma_las_aceptaciones()
    {
        var contract = TestData.StartContract();
        contract.MarkValidated();
        contract.Declare([]);
        contract.Accept(ConsentDocumentType.GeneralConditions, "TDS-CG", "2.1", Hash("texto"), "10.0.0.1", null, TestData.Now);
        contract.Accept(ConsentDocumentType.DataPrivacy, "PRIV", "1.0", Hash("texto"), "10.0.0.1", null, TestData.Now);

        Assert.True(contract.MarkVerified(otpChallengeId: 7).IsSuccess);
        Assert.Equal(ContractStatus.Verified, contract.Status);
        Assert.All(contract.Consents, c => Assert.Equal(7L, c.OtpChallengeId));
    }

    [Fact]
    public void El_OTP_se_bloquea_al_tercer_intento_fallido()
    {
        var otp = OtpChallenge.Create(Guid.NewGuid(), OtpChannel.Sms, "71234567", Hash("123456"), TestData.Now, 5, 3);

        otp.Verify(Hash("000000"), TestData.Now);
        otp.Verify(Hash("000000"), TestData.Now);
        otp.Verify(Hash("000000"), TestData.Now);
        var fourth = otp.Verify(Hash("123456"), TestData.Now);

        Assert.Equal("OTP_ATTEMPTS_EXCEEDED", fourth.Error!.Code);
    }

    [Fact]
    public void Un_OTP_vencido_se_rechaza()
    {
        var otp = OtpChallenge.Create(Guid.NewGuid(), OtpChannel.Sms, "71234567", Hash("123456"), TestData.Now, 5, 3);

        var result = otp.Verify(Hash("123456"), TestData.Now.AddMinutes(6));

        Assert.Equal("OTP_EXPIRED", result.Error!.Code);
    }
}
