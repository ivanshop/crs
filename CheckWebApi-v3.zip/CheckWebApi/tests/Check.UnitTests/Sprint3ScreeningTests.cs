using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 3: validaciones SEGIP, AMLC y Archivo Negativo, y lista blanca.</summary>
public class Sprint3ScreeningTests
{
    private static readonly Guid PersonId = Guid.NewGuid();
    private static readonly Guid ContractId = Guid.NewGuid();

    private static Screening Result(ScreeningProvider provider, bool clear) =>
        Screening.Record(PersonId, ContractId, provider, clear, null, "{}", [], TestData.Now, TestData.Now);

    private static List<(PartyRole, Screening)> AllClear() =>
    [
        (PartyRole.Contractor, Result(ScreeningProvider.Segip, true)),
        (PartyRole.Contractor, Result(ScreeningProvider.Amlc, true)),
        (PartyRole.Contractor, Result(ScreeningProvider.NegativeFile, true))
    ];

    [Fact]
    public void Si_las_tres_consultas_son_aptas_el_contrato_se_aprueba() =>
        Assert.True(ScreeningPolicy.Decide(AllClear()).IsApproved);

    [Fact]
    public void Una_aparicion_en_Archivo_Negativo_rechaza_el_contrato()
    {
        var results = AllClear();
        results[2] = (PartyRole.Contractor, Result(ScreeningProvider.NegativeFile, false));

        var decision = ScreeningPolicy.Decide(results);

        Assert.False(decision.IsApproved);
        Assert.NotNull(decision.Reason);
    }

    [Fact]
    public void Una_excepcion_vigente_de_lista_blanca_permite_continuar()
    {
        var personId = Guid.NewGuid();
        var listed = Screening.Record(personId, ContractId, ScreeningProvider.NegativeFile, false, null, "{}", [], TestData.Now, TestData.Now);
        var exception = ScreeningException.Create(personId, ScreeningProvider.NegativeFile, "Deuda de 2015 cancelada", "cumplimiento",
            TestData.Today.AddDays(-1), TestData.Today.AddMonths(6)).Value;

        listed.ApplyException(exception);

        Assert.True(listed.IsApproved);
        Assert.False(listed.IsClear);   // el resultado original se conserva
    }

    [Fact]
    public void SEGIP_no_admite_excepciones()
    {
        var exception = ScreeningException.Create(Guid.NewGuid(), ScreeningProvider.Segip, "Motivo", "cumplimiento", TestData.Today, TestData.Today);

        Assert.Equal("EXCEPTION_INVALID_PROVIDER", exception.Error!.Code);
    }

    [Fact]
    public void Un_contrato_rechazado_guarda_el_motivo_y_no_puede_validarse_despues()
    {
        var contract = TestData.StartContract();

        contract.Reject("Archivo Negativo");

        Assert.Equal(ContractStatus.Rejected, contract.Status);
        Assert.True(contract.MarkValidated().IsFailure);
    }
}
