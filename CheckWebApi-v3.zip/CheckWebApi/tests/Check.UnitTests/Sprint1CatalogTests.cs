using Check.Domain.Common;
using Check.Domain.Offer;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 1: catálogo de productos y reglas del plan.</summary>
public class Sprint1CatalogTests
{
    [Theory]
    [InlineData(2, false)]
    [InlineData(3, true)]
    [InlineData(64, true)]
    [InlineData(65, false)]
    public void Edad_de_afiliacion_respeta_el_rango_del_plan(int age, bool allowed) =>
        Assert.Equal(allowed, TestData.Rules(minAge: 3, maxAge: 64).AllowsAge(age));

    [Fact]
    public void Las_condiciones_del_contrato_salen_del_plan_si_no_hay_convenio()
    {
        var terms = ContractTerms.FromPlan(TestData.Rules(days: 30));

        Assert.Equal(5m, terms.Premium.Amount);
        Assert.Equal(30, terms.CoverageDays);
        Assert.Null(terms.AgreementId);
    }

    [Fact]
    public void Una_moneda_no_soportada_se_rechaza()
    {
        var money = Money.Create(5m, "EUR");

        Assert.True(money.IsFailure);
    }
}
