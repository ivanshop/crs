using Check.Domain.Contracts;
using Check.Domain.Offer;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 7: backoffice de convenios corporativos.</summary>
public class Sprint7AgreementTests
{
    private static readonly Company Andina = Company.Create("1020304050", "Constructora Andina S.A.", null, null, null).Value;

    private static Agreement Draft(int quota = 120) => Agreement.Negotiate("andina-tds-2026", Andina, TestData.Plan(1),
        TestData.Bob(3.5m), 30, quota, TestData.Today.AddDays(-1), TestData.Today.AddYears(1), "ejecutivo1", null).Value;

    [Fact]
    public void El_convenio_nace_en_borrador_con_el_codigo_en_mayusculas()
    {
        var agreement = Draft();

        Assert.Equal(AgreementStatus.Draft, agreement.Status);
        Assert.Equal("ANDINA-TDS-2026", agreement.Code);
    }

    [Fact]
    public void Un_cupo_de_cero_personas_se_rechaza()
    {
        var result = Agreement.Negotiate("ANDINA-X", Andina, TestData.Plan(1), TestData.Bob(3.5m), 30, 0,
            TestData.Today, TestData.Today, "ejecutivo1", null);

        Assert.Equal("AGREEMENT_INVALID_QUOTA", result.Error!.Code);
    }

    [Fact]
    public void Quien_negocia_no_puede_aprobar()
    {
        var agreement = Draft();

        Assert.Equal("AGREEMENT_SAME_APPROVER", agreement.Approve("EJECUTIVO1", TestData.Now).Error!.Code);
        Assert.True(agreement.Approve("gerente1", TestData.Now).IsSuccess);
        Assert.Equal(AgreementStatus.Active, agreement.Status);
    }

    [Fact]
    public void Un_borrador_no_se_puede_usar_para_contratar() =>
        Assert.Equal("AGREEMENT_NOT_AVAILABLE", Draft().CanBeUsed(1, TestData.Today, 0).Error!.Code);

    [Theory]
    [InlineData(1, 119, null)]
    [InlineData(1, 120, "AGREEMENT_QUOTA_EXHAUSTED")]
    [InlineData(2, 0, "AGREEMENT_PLAN_MISMATCH")]
    public void Un_convenio_activo_respeta_plan_y_cupo(long planId, int used, string? expected)
    {
        var agreement = Draft(quota: 120);
        agreement.Approve("gerente1", TestData.Now);

        var result = agreement.CanBeUsed(planId, TestData.Today, used);

        Assert.Equal(expected, result.Error?.Code);
    }

    [Fact]
    public void El_contrato_con_convenio_congela_la_prima_y_los_dias_negociados()
    {
        var agreement = Draft();
        agreement.Approve("gerente1", TestData.Now);

        var contract = TestData.StartContract(agreement.Terms);

        Assert.Equal(3.5m, contract.PremiumAmount);
        Assert.Equal(30, contract.CoverageDays);
        Assert.Equal(agreement.Id, contract.AgreementId);
    }

    [Fact]
    public void Un_convenio_cerrado_ya_no_se_usa()
    {
        var agreement = Draft();
        agreement.Approve("gerente1", TestData.Now);
        agreement.Close();

        Assert.True(agreement.CanBeUsed(1, TestData.Today, 0).IsFailure);
        Assert.True(agreement.Close().IsFailure);
    }
}
