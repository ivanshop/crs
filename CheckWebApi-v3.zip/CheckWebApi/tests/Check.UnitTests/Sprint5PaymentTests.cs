using Check.Domain.Contracts;
using Check.Domain.Offer;
using Check.Domain.Payments;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 5: pago con QR, aviso del Banco y activación del contrato.</summary>
public class Sprint5PaymentTests
{
    private static QrPayment NewQr() =>
        QrPayment.Create(Guid.NewGuid(), Guid.NewGuid(), TestData.Bob(5m), null, "qr", TestData.Now.AddMinutes(30));

    [Fact]
    public void Un_aviso_valido_aplica_el_pago()
    {
        var qr = NewQr();

        Assert.Equal(NotificationResult.Applied, qr.Apply(5m, "BOB", "TX-1", TestData.Now.AddMinutes(10)));
        Assert.Equal(QrPaymentStatus.Paid, qr.Status);
    }

    [Fact]
    public void Un_aviso_repetido_no_aplica_dos_veces()
    {
        var qr = NewQr();
        qr.Apply(5m, "BOB", "TX-1", TestData.Now);

        Assert.Equal(NotificationResult.Duplicate, qr.Apply(5m, "BOB", "TX-1", TestData.Now));
    }

    [Fact]
    public void Un_pago_despues_del_vencimiento_no_se_procesa() =>
        Assert.Equal(NotificationResult.Expired, NewQr().Apply(5m, "BOB", "TX-1", TestData.Now.AddMinutes(31)));

    [Fact]
    public void Un_monto_distinto_no_se_aplica() =>
        Assert.Equal(NotificationResult.AmountMismatch, NewQr().Apply(4m, "BOB", "TX-1", TestData.Now));

    [Fact]
    public void Al_activarse_la_cobertura_empieza_en_el_pago_y_dura_los_dias_congelados()
    {
        var contract = TestData.StartContract(ContractTerms.FromPlan(TestData.Rules(days: 30)));
        var paidAt = TestData.Now.AddHours(1);

        Assert.True(contract.Activate("TDS-2026-7K4QM92X", paidAt).IsFailure);   // aún en Started

        contract.MarkValidated();
        contract.Declare([]);
        contract.Accept(ConsentDocumentType.GeneralConditions, "TDS-CG", "2.1", [1], "10.0.0.1", null, TestData.Now);
        contract.Accept(ConsentDocumentType.DataPrivacy, "PRIV", "1.0", [1], "10.0.0.1", null, TestData.Now);
        contract.MarkVerified(otpChallengeId: 1);
        contract.MarkPendingPayment();
        Assert.True(contract.Activate("TDS-2026-7K4QM92X", paidAt).IsSuccess);
        Assert.Equal(paidAt, contract.CoverageFrom);
        Assert.Equal(paidAt.AddDays(30), contract.CoverageTo);
        Assert.True(contract.Activate("TDS-2026-OTRO0000", paidAt).IsSuccess);   // idempotente
        Assert.Equal("TDS-2026-7K4QM92X", contract.Number);
    }

    [Fact]
    public void El_numero_de_poliza_es_legible_y_no_correlativo()
    {
        var first = ContractNumber.Generate("TDS", 2026);
        var second = ContractNumber.Generate("TDS", 2026);

        Assert.Matches("^TDS-2026-[0-9A-HJKMNP-TV-Z]{8}$", first);
        Assert.NotEqual(first, second);
    }
}
