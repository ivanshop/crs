using Check.Domain.Contracts;
using Check.Domain.People;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 2: inicio del contrato, datos de las personas y elegibilidad.</summary>
public class Sprint2ContractStartTests
{
    [Theory]
    [InlineData("123", false)]
    [InlineData("1234", true)]
    [InlineData("123456789012", true)]
    [InlineData("1234567890123", false)]
    [InlineData("12A456", false)]
    public void El_numero_de_carnet_tiene_de_4_a_12_digitos(string number, bool valid) =>
        Assert.Equal(valid, IdentityDocument.Create(DocumentType.CI, number, null, "LP").IsSuccess);

    [Fact]
    public void Un_carnet_boliviano_exige_extension()
    {
        var document = IdentityDocument.Create(DocumentType.CI, "1234567", null, null);

        Assert.Equal("DOCUMENT_INVALID_EXTENSION", document.Error!.Code);
    }

    [Theory]
    [InlineData("71234567", true)]
    [InlineData("+591 61234567", true)]
    [InlineData("21234567", false)]
    [InlineData("7123456", false)]
    public void El_celular_tiene_8_digitos_y_empieza_con_6_o_7(string value, bool valid) =>
        Assert.Equal(valid, PhoneNumber.Create(value).IsSuccess);

    [Fact]
    public void Un_asegurado_fuera_del_rango_de_edad_no_puede_contratar()
    {
        var baby = TestData.Party("7654321", new DateOnly(2025, 1, 1), withContact: false);

        var result = EligibilityPolicy.Check(TestData.Rules(), TestData.Adult(), baby, false, false, false, TestData.Today);

        Assert.Equal("INSURED_AGE_OUT_OF_RANGE", result.Error!.Code);
    }

    [Fact]
    public void Un_menor_no_puede_contratar_para_si_mismo()
    {
        var minor = TestData.Party("7654321", new DateOnly(2012, 1, 1));

        var result = EligibilityPolicy.Check(TestData.Rules(), minor, minor, true, false, false, TestData.Today);

        Assert.Equal("MINOR_REQUIRES_CONTRACTOR", result.Error!.Code);
    }

    [Fact]
    public void No_se_vende_si_el_asegurado_tiene_una_poliza_vigente_del_producto()
    {
        var result = EligibilityPolicy.Check(TestData.Rules(), TestData.Adult(), TestData.Adult(), true, true, false, TestData.Today);

        Assert.Equal("INSURED_HAS_ACTIVE_CONTRACT", result.Error!.Code);
    }

    [Fact]
    public void La_venta_por_broker_requiere_que_el_plan_la_permita()
    {
        var result = EligibilityPolicy.Check(TestData.Rules(broker: false), TestData.Adult(), TestData.Adult(), true, false, true, TestData.Today);

        Assert.Equal("BROKER_SALE_DISABLED", result.Error!.Code);
    }

    [Fact]
    public void El_contrato_nace_en_Started_con_contratante_y_asegurado()
    {
        var contract = TestData.StartContract();

        Assert.Equal(ContractStatus.Started, contract.Status);
        Assert.Equal(2, contract.Parties.Count);
        Assert.Equal(SalesChannel.Web, contract.Channel);
        Assert.Null(contract.Number);
    }

    [Fact]
    public void Con_agente_el_contrato_tiene_tres_partes_y_canal_Broker()
    {
        var agentPerson = TestData.PersonOf(TestData.Adult("4445556"));
        var agent = Agent.Create(Agency.Create("AG1", "Agencia Uno", null, null, null), agentPerson, "AGT-001", null, TestData.Today, null);

        var contract = TestData.StartContract(agent: agent);

        Assert.Equal(3, contract.Parties.Count);
        Assert.Equal(SalesChannel.Broker, contract.Channel);
        Assert.Equal(PartyRole.Agent, contract.Agent!.Role);
    }
}
