using System.Reflection;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Check.Domain.Offer;
using Check.Domain.People;

namespace Check.UnitTests;

/// <summary>Datos de prueba reutilizables. Ningún dato corresponde a una persona real.</summary>
internal static class TestData
{
    public static readonly DateOnly Today = new(2026, 11, 25);
    public static readonly DateTimeOffset Now = new(2026, 11, 25, 14, 0, 0, TimeSpan.Zero);

    public static Money Bob(decimal amount) => Money.Create(amount, "BOB").Value;

    public static PlanRules Rules(int minAge = 3, int maxAge = 64, int maxBeneficiaries = 5, bool broker = false, int days = 1) =>
        new("TDS-DIA", days, Bob(5m), minAge, maxAge, maxBeneficiaries, false, broker, 30, null, null);

    public static PartyData Party(string number, DateOnly birthdate, bool withContact = true) => new(
        IdentityDocument.Create(DocumentType.CI, number, null, "LP").Value,
        PersonName.Create("Cliente", "De", "Prueba").Value,
        birthdate, Gender.Male, 1, "Calle 1", "La Paz",
        withContact ? PhoneNumber.Create("71234567").Value : null,
        withContact ? Email.Create("cliente@ejemplo.com").Value : null,
        null, null, null, null);

    public static PartyData Adult(string number = "1234567") => Party(number, new DateOnly(1990, 1, 1));

    public static Person PersonOf(PartyData data) => Person.Create(data, [1, 2, 3]);

    public static Contract StartContract(ContractTerms? terms = null, Agent? agent = null)
    {
        var data = Adult();
        var person = PersonOf(data);
        return Contract.Start(1, terms ?? ContractTerms.FromPlan(Rules()), person, data, person, data, agent,
            new Dictionary<long, string>(), "10.0.0.1", Now);
    }

    /// <summary>Plan sin constructor público (lo crea EF Core): se arma por reflexión solo para las pruebas.</summary>
    public static Plan Plan(long id, string code = "TDS-DIA")
    {
        var plan = (Plan)Activator.CreateInstance(typeof(Plan), nonPublic: true)!;
        Set(plan, nameof(Domain.Offer.Plan.Id), id);
        Set(plan, nameof(Domain.Offer.Plan.Code), code);
        Set(plan, nameof(Domain.Offer.Plan.Name), "Diario");
        return plan;
    }

    private static void Set(object target, string property, object value) =>
        target.GetType().GetProperty(property, BindingFlags.Instance | BindingFlags.Public)!.SetValue(target, value);
}
