using Check.Domain.Events;
using Xunit;

namespace Check.UnitTests;

/// <summary>Sprint 6: eventos del contrato (bitácora y Outbox).</summary>
public class Sprint6EventTests
{
    private static ContractEvent Email() =>
        ContractEvent.Enqueue(Guid.NewGuid(), ContractEventType.WelcomeEmail, ContractEvent.WelcomeEmailQueue, "{}", TestData.Now);

    [Fact]
    public void Un_evento_con_cola_nace_pendiente_y_pasa_a_publicado()
    {
        var e = Email();
        Assert.Equal(ContractEventStatus.Pending, e.Status);

        e.MarkPublished(TestData.Now);

        Assert.Equal(ContractEventStatus.Published, e.Status);
        Assert.Equal(1, e.Attempts);
    }

    [Fact]
    public void Un_fallo_de_publicacion_reprograma_con_espera_creciente()
    {
        var e = Email();

        e.MarkPublishFailed("timeout", TestData.Now, maxAttempts: 8);
        var first = e.NextAttemptAt!.Value - TestData.Now;
        e.MarkPublishFailed("timeout", TestData.Now, maxAttempts: 8);
        var second = e.NextAttemptAt!.Value - TestData.Now;

        Assert.Equal(ContractEventStatus.Pending, e.Status);
        Assert.True(second > first);
    }

    [Fact]
    public void Al_agotar_los_intentos_el_evento_queda_fallido()
    {
        var e = Email();
        for (var i = 0; i < 8; i++) e.MarkPublishFailed("timeout", TestData.Now, maxAttempts: 8);

        Assert.Equal(ContractEventStatus.Failed, e.Status);
        Assert.Null(e.NextAttemptAt);
    }

    [Fact]
    public void Soporte_puede_reencolar_un_evento_fallido()
    {
        var e = Email();
        for (var i = 0; i < 8; i++) e.MarkPublishFailed("timeout", TestData.Now, maxAttempts: 8);

        Assert.True(e.Requeue(TestData.Now).IsSuccess);
        Assert.Equal(ContractEventStatus.Pending, e.Status);
        Assert.Equal(0, e.Attempts);
    }

    [Fact]
    public void Un_evento_de_bitacora_no_se_confirma_ni_se_reenvia()
    {
        var e = ContractEvent.Record(Guid.NewGuid(), ContractEventType.PaymentConfirmed, "{}", TestData.Now);

        Assert.Equal("EVENT_NOT_QUEUED", e.Confirm(true, null, TestData.Now).Error!.Code);
        Assert.True(e.Requeue(TestData.Now).IsFailure);
    }
}
