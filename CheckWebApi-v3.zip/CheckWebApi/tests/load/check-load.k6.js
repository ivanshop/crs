// Prueba de carga y estrés de Check Web API con k6 (https://k6.io).
// Uso: k6 run -e BASE=https://qa.check.local -e CLIENT_SECRET=... tests/load/check-load.k6.js
// Requiere en QA límites de uso altos para la IP del generador de carga.
import http from 'k6/http';
import { check } from 'k6';

const BASE = __ENV.BASE || 'http://localhost:5080';

export const options = {
  scenarios: {
    catalogo: {            // carga creciente hasta 200 usuarios virtuales
      executor: 'ramping-vus', exec: 'catalogo', startVUs: 0,
      stages: [{ duration: '1m', target: 50 }, { duration: '2m', target: 100 }, { duration: '2m', target: 200 }, { duration: '1m', target: 0 }],
    },
    contratos: {           // inicio de contratos: escribe en la base
      executor: 'ramping-vus', exec: 'contratos', startVUs: 0, startTime: '30s',
      stages: [{ duration: '2m', target: 25 }, { duration: '2m', target: 50 }, { duration: '1m', target: 0 }],
    },
  },
  thresholds: {            // metas del capítulo IV: la prueba falla si no se cumplen
    'http_req_failed': ['rate<0.01'],
    'http_req_duration{scenario:catalogo}': ['p(95)<300'],
    'http_req_duration{scenario:contratos}': ['p(95)<800'],
  },
};

export function setup() {
  const r = http.post(`${BASE}/api/v1/auth/token`, JSON.stringify({ clientId: 'check-web', clientSecret: __ENV.CLIENT_SECRET }),
    { headers: { 'Content-Type': 'application/json' } });
  return { token: r.json('accessToken') };
}

export function catalogo(data) {
  const r = http.get(`${BASE}/api/v1/products`, { headers: { Authorization: `Bearer ${data.token}` } });
  check(r, { 'catálogo 200': (x) => x.status === 200 });
}

export function contratos(data) {
  const ci = String(Math.floor(10000000 + Math.random() * 89999999));   // carnet ficticio
  const body = { planCode: 'TDS-DIA', contractor: { documentType: 'CI', documentNumber: ci, documentExtension: 'LP',
    names: 'Carga', paternalLastname: 'Prueba', birthdate: '1990-01-01', gender: 'Male', nationality: 'BO',
    cellphone: '71234567', email: 'carga@ejemplo.com' } };
  const r = http.post(`${BASE}/api/v1/contracts`, JSON.stringify(body),
    { headers: { Authorization: `Bearer ${data.token}`, 'Content-Type': 'application/json' } });
  check(r, { 'contrato 201': (x) => x.status === 201 });
}
