using Microsoft.AspNetCore.Components;
using Check.Web.Services;

namespace Check.Web.Components.Purchase;

/// <summary>Base for every purchase step: shared state plus the next and back callbacks.</summary>
public abstract class StepBase : ComponentBase
{
    [Inject] protected PurchaseState State { get; set; } = default!;
    [Parameter] public EventCallback OnNext { get; set; }
    [Parameter] public EventCallback OnBack { get; set; }
}
