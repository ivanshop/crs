namespace Check.Web.Components.Purchase.Customer;

/// <summary>Whose data the person form is editing.</summary>
public enum DataMode { Insured, Minor, Holder }
