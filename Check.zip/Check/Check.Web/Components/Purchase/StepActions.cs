using Microsoft.AspNetCore.Components;

namespace Check.Web.Components.Purchase;

/// <summary>Next and back callbacks handed to a product-specific step.</summary>
public sealed record StepActions(EventCallback Next, EventCallback Back);
