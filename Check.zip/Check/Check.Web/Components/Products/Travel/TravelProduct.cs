using Check.Web.Models;
using Check.Web.Services;

namespace Check.Web.Components.Products.Travel;

public sealed class TravelProduct : ProductDefinition
{
    public const string LatamPlanId = "latam";

    private static readonly string[] Details =
        ["Medicamentos recetados por médico autorizado por la Central", "Línea de consultas 24 horas", "Consultas consulares, sanitarias o turísticas"];

    // Declared after the static data it uses, so that data is already initialized.
    public static readonly TravelProduct Instance = new();

    public override Product Product => Product.Travel;
    public override string Slug => "viajes";
    public override string Name => "Tu Destino Seguro";
    public override string Tagline => "Protégete mientras viajas a cualquier parte del mundo. Elige tu plan y arma tu itinerario en minutos.";
    public override string Note => "Disponible para personas de hasta 65 años.";
    public override DetailsStepInfo DetailsStep { get; } = new("Itinerario", "Tu itinerario");

    public override IReadOnlyList<Plan> Plans { get; } =
    [
        new(LatamPlanId, "Plan latinoamericano", "Protección básica", 16, "al día", null,
            ["USD 5,000 en asistencia médica por accidente", "USD 250 por pérdida total de equipaje", "USD 100 en emergencia dental"], Details),
        new("world", "Plan mundial", "Protección completa", 23, "al día", null,
            ["USD 35,000 en asistencia médica por accidente", "Protección de equipaje", "USD 100 en vuelo demorado o cancelado"], Details)
    ];

    public override IReadOnlyList<InfoCard> Benefits { get; } =
    [
        new("Protección de equipaje", "Pérdida de equipaje en avión o crucero: complemento posterior a la indemnización de aerolínea o naviera.", ""),
        new("Vuelo demorado o cancelado", "Aplica por demora mayor a 6 horas, con certificado de aerolínea y recibos.", ""),
        new("Medicamentos recetados incluidos", "Deben ser recetados por médico autorizado por la Central.", ""),
        new("Línea de consultas 24 horas", "Permite contactar a la Central para consultas consulares, sanitarias o turísticas.", "")
    ];

    public override IReadOnlyList<InfoCard> PolicyHighlights { get; } =
    [
        new("¿Quién puede contratarlo?", "Personas de hasta 65 años.", ""),
        new("Vuelo demorado o cancelado", "Aplica por demora mayor a 6 horas, con certificado de aerolínea y recibos.", ""),
        new("Medicamentos", "Deben ser recetados por médico autorizado por la Central.", "")
    ];

    public static readonly Destination[] Destinations =
    [
        new("Argentina",-64,-34,true), new("Belice",-88.5,17,true), new("Brasil",-51,-12,true), new("Chile",-71,-33,true),
        new("Colombia",-74,4,true), new("Costa Rica",-84,10,true), new("Ecuador",-78,-1,true), new("El Salvador",-89,14,true),
        new("Guatemala",-90.5,15.5,true), new("Guyana",-59,5,true), new("Honduras",-87,15,true), new("Nicaragua",-85,13,true),
        new("Panamá",-80,9,true), new("Paraguay",-58,-23,true), new("Perú",-75,-10,true), new("Surinam",-56,4,true),
        new("Uruguay",-56,-33,true), new("Venezuela",-66,7,true),
        new("México",-102,23,false), new("República Dominicana",-70,19,false), new("Alemania",10,51,false), new("Canadá",-106,56,false),
        new("China",104,35,false), new("Emiratos Árabes Unidos",54,24,false), new("España",-4,40,false), new("Estados Unidos",-98,39,false),
        new("Francia",2,46,false), new("Italia",12,43,false), new("Japón",138,36,false), new("Reino Unido",-2,54,false), new("Turquía",35,39,false)
    ];

    public static bool IsLatam(Plan? plan) => plan?.Id == LatamPlanId;

    public override IEnumerable<SummaryRow> PaymentSummary(PurchaseState state) =>
        [new("Destino", state.Destination?.Name ?? "—")];

    public override string DoneSummary(PurchaseState state) => $"Bolivia a {state.Destination?.Name}";
}
