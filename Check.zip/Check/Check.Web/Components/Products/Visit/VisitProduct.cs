using Check.Web.Models;
using Check.Web.Services;

namespace Check.Web.Components.Products.Visit;

public sealed class VisitProduct : ProductDefinition
{
    public static readonly VisitProduct Instance = new();

    public override Product Product => Product.Visit;
    public override string Slug => "visitas";
    public override string Name => "Tu Visita Segura";
    public override string Tagline => "Seguro que te permite ingresar a plantas industriales cumpliendo el requisito obligatorio y te protege ante fallecimiento accidental.";
    public override string Note => "Seguro disponible para personas de 14 hasta 65 años.";
    public override string InfoTitle => "Todo lo que tienes que saber";
    public override bool AllowsChild => false;
    public override DetailsStepInfo DetailsStep { get; } = new("Tu visita", "Tu visita");

    public override IReadOnlyList<Plan> Plans { get; } =
    [
        new("visit", "Plan A", "", 10, "por día", null,
            ["Cobertura: Bs. 70,000", "Muerte accidental: hasta Bs. 70,000"], ["Muerte accidental: hasta Bs. 70,000"])
    ];

    public override IReadOnlyList<InfoCard> Benefits { get; } =
    [
        new("Cumple el requisito", "Te permite ingresar a plantas industriales cumpliendo el requisito obligatorio.", ""),
        new("Protección", "Te protege ante fallecimiento accidental.", ""),
        new("Documentos digitales", "Recibes tu póliza directo por correo.", "")
    ];

    public override IReadOnlyList<InfoCard> Info { get; } =
    [
        new("Características", "Cobertura de muerte accidental hasta Bs. 70,000.", ""),
        new("¿Quién puede contratarlo?", "Personas de 14 hasta 65 años.", ""),
        new("Precio", "Bs. 10 por día de visita.", "")
    ];

    public override IReadOnlyList<InfoCard> PolicyHighlights { get; } =
    [
        new("¿Quién puede contratarlo?", "Personas de 14 hasta 65 años.", ""),
        new("Requisito de ingreso", "Te permite ingresar a plantas industriales cumpliendo el requisito obligatorio.", ""),
        new("Cobertura", "Muerte accidental hasta Bs. 70,000.", "")
    ];

    public override IEnumerable<SummaryRow> PaymentSummary(PurchaseState state) =>
        [new("Planta industrial", state.PlantName)];

    public override string DoneSummary(PurchaseState state) => $"visita a {state.PlantName}";
}
