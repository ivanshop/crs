using Check.Web.Models;
using Check.Web.Services;

namespace Check.Web.Components.Products.Sports;

public sealed class SportsProduct : ProductDefinition
{
    private static readonly string[] Details =
        ["Gastos médicos y rehabilitación", "Estudios tras un accidente", "Indemnización a beneficiarios", "10 sesiones de fisioterapia al año"];

    // Plan ids are the plan codes in Check.Api.
    // Declared after the static data it uses, so that data is already initialized.
    public static readonly SportsProduct Instance = new();

    public override Product Product => Product.Sports;
    public override string Slug => "deportes";
    public override string? ApiProductCode => "DEP-SEG";
    public override string Name => "Tu Deporte Seguro";
    public override string Tagline => "Protégete mientras practicas el deporte que más te gusta. Lo contratas en minutos, desde donde estés.";
    public override string Note => "Tu póliza inicia el día y hora del pago por QR.";

    public override IReadOnlyList<Plan> Plans { get; } =
    [
        Plan("DIA", "Plan diario", 5, "por día", 1, "Bs. 1,400", "Bs. 7,000"),
        Plan("MEN", "Plan mensual", 20, "por mes", 30, "Bs. 1,800", "Bs. 9,000"),
        Plan("SEM", "Plan semestral", 120, "por semestre", 180, "Bs. 7,000", "Bs. 35,000"),
        Plan("ANU", "Plan anual", 270, "por año", 365, "Bs. 14,000", "Bs. 70,000")
    ];

    public override IReadOnlyList<InfoCard> Benefits { get; } =
    [
        new("Rápido y sin filas", "Lo contratas en minutos, desde donde estés.", ""),
        new("Gastos médicos por accidente", "Te cubrimos gastos médicos por accidente, en la clínica que prefieras.", ""),
        new("Indemnización", "Cuentas con indemnización para tus beneficiarios o herederos legales.", ""),
        new("Fisioterapia", "Límite de 10 sesiones anuales, excluyendo tratamientos con ondas de choque.", "")
    ];

    public override IReadOnlyList<InfoCard> Info { get; } =
    [
        new("Ve a la clínica", "Elige la clínica de tu preferencia y pide las facturas a nombre de Crediseguro S.A. Seguros Personales, NIT 191310020.", ""),
        new("Reporta el siniestro", "Escríbenos por WhatsApp indicando que quieres reportar un siniestro. Luego brinda tus datos y adjunta tus documentos.", ""),
        new("Recibe tu reembolso", "Tu seguro es de sistema abierto: te reembolsamos tus gastos médicos por accidente según las condiciones de tu póliza.", "")
    ];

    public override IReadOnlyList<InfoCard> PolicyHighlights { get; } =
    [
        new("¿Qué deportes cubre?", "Accidentes en la práctica de los deportes incluidos en tu póliza.", ""),
        new("Sistema abierto", "Vas a la clínica que prefieras y recibes el reembolso según tu póliza.", ""),
        new("Fisioterapia", "Límite de 10 sesiones anuales, excluyendo ondas de choque.", "")
    ];

    public override IEnumerable<SummaryRow> PaymentSummary(PurchaseState state) =>
        [new("Inicio de vigencia", "Día y hora del pago")];

    public override string DoneSummary(PurchaseState state) => "vigente desde el día y hora de tu pago";

    private static Plan Plan(string id, string name, decimal rate, string unit, int days, string medical, string death) =>
        new(id, name, "", rate, unit, days, [$"Gastos médicos por accidente: {medical}", $"Muerte accidental: {death}"], Details);
}
