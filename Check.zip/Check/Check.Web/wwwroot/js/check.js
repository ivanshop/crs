// GSAP animations and small helpers Blazor does not cover.
// Each function is independent and is called from a component through IJSRuntime.
gsap.registerPlugin(MotionPathPlugin);

window.check = (() => {
  const byId = (id) => document.getElementById(id);
  const reduceMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
  const clear = 'transform,opacity';

  let mapDots = null; // map data, downloaded once
  let flight = null;  // running plane animation
  const totals = new WeakMap();

  // Purchase step change. direction: 1 moves forward, -1 goes back.
  function step(direction) {
    window.scrollTo(0, 0);
    if (reduceMotion()) return;
    gsap.from('.stage > *', { x: 48 * direction, opacity: 0, duration: .5, stagger: .06, ease: 'power3.out', clearProps: clear });
    gsap.from('.bann h1', { y: 20, opacity: 0, duration: .5, ease: 'power3.out', clearProps: clear });
  }

  // Elements further down the page appear when scrolled into view.
  function reveal(selector) {
    if (reduceMotion()) return;
    const observer = new IntersectionObserver((entries) => {
      entries.filter((entry) => entry.isIntersecting).forEach((entry, i) => {
        observer.unobserve(entry.target);
        gsap.to(entry.target, { y: 0, opacity: 1, duration: .6, delay: i * .08, ease: 'power3.out', clearProps: clear });
      });
    }, { threshold: .15 });

    document.querySelectorAll(selector).forEach((node) => {
      if (node.getBoundingClientRect().top < window.innerHeight) return; // already visible
      gsap.set(node, { y: 28, opacity: 0 });
      observer.observe(node);
    });
  }

  // Animated count of the total in bolivianos.
  function total(id, value) {
    const node = byId(id);
    if (!node) return;
    const state = totals.get(node) ?? { v: 0 };
    totals.set(node, state);
    const paint = () => { node.textContent = 'BOB ' + Math.round(state.v); };
    gsap.killTweensOf(state);
    if (reduceMotion()) { state.v = value; paint(); return; }
    gsap.to(state, { v: value, duration: .45, ease: 'power2.out', onUpdate: paint, onComplete: paint });
  }

  // Draws the map dots for the plan: 'latam' or 'world'.
  async function map(plan) {
    mapDots ??= await (await fetch('data/land.json')).json();
    const covered = byId('landCov');
    const rest = byId('landRest');
    if (!covered || !rest) return;
    covered.setAttribute('d', plan === 'latam' ? mapDots.latCov : mapDots.worldRest);
    rest.setAttribute('d', plan === 'latam' ? mapDots.latRest : mapDots.worldLat);
  }

  // Traces the route, moves the plane and shows the destination on arrival.
  function fly() {
    const route = byId('route');
    const trace = byId('routeTrace');
    const plane = byId('plane');
    const pin = byId('destinationPin');
    if (!route || !trace || !plane) return;
    flight?.kill();
    if (reduceMotion()) { gsap.set(trace, { strokeDashoffset: 0 }); return; }

    flight = gsap.timeline({ defaults: { duration: 2.4, ease: 'power2.inOut' } });
    flight.fromTo(trace, { strokeDashoffset: 1 }, { strokeDashoffset: 0 }, 0);
    flight.fromTo(plane,
      { motionPath: { path: route, align: route, autoRotate: true, end: 0 } },
      { motionPath: { path: route, align: route, autoRotate: true, start: 0, end: 1 } }, 0);
    if (pin) {
      flight.fromTo(pin,
        { scale: 0, opacity: 0, transformOrigin: '50% 50%' },
        { scale: 1, opacity: 1, duration: .5, ease: 'back.out(2.5)' }, 2);
    }
  }

  function focus(id) { byId(id)?.focus(); }

  // Dropdown (SelectField): true when the list does not fit below the field and fits better above.
  function dropUp(el) {
    const rect = el.getBoundingClientRect();
    const below = innerHeight - rect.bottom;
    return below < 300 && rect.top > below;
  }

  function scrollToOption(id) { byId(id)?.scrollIntoView({ block: 'nearest' }); }

  // Moves to the first field highlighted as missing so the user can find it.
  function focusInvalid() {
    const field = document.querySelector('.field.invalid');
    if (!field) return;
    field.scrollIntoView({ behavior: reduceMotion() ? 'auto' : 'smooth', block: 'center' });
    field.querySelector('input,button,select,textarea')?.focus({ preventScroll: true });
  }

  // Blazor can't cancel a key conditionally, so the dropdown keys are cancelled here:
  // arrows never scroll the page and Enter never submits the form while choosing an option.
  document.addEventListener('keydown', (e) => {
    const trigger = e.target.closest?.('.seltrig');
    const open = trigger?.getAttribute('aria-expanded') === 'true';
    if (e.target.closest?.('.selq') && ['Enter', 'ArrowUp', 'ArrowDown'].includes(e.key)) e.preventDefault();
    else if (trigger && (['ArrowUp', 'ArrowDown'].includes(e.key) || (open && ['Enter', ' ', 'Home', 'End'].includes(e.key)))) e.preventDefault();
  });
  // Clicking the button of an open list with a search box keeps the focus in the search box, so the click closes it.
  document.addEventListener('mousedown', (e) => {
    const trigger = e.target.closest?.('.seltrig');
    if (trigger?.getAttribute('aria-expanded') === 'true') e.preventDefault();
  });

  return { step, reveal, total, map, fly, focus, dropUp, scrollToOption, focusInvalid };
})();
