using Check.Web.Components.Products.Travel;
using Check.Web.Models;
using Check.Web.Services.Api;

namespace Check.Web.Services;

/// <summary>
/// Purchase draft for the current circuit. In production every step should be
/// saved through the API so it survives a dropped circuit.
/// </summary>
public sealed class PurchaseState
{
    public ProductDefinition? Definition { get; private set; }
    public Product Product => Definition?.Product ?? default;
    public Plan? Plan { get; private set; }
    public bool ForChild { get; private set; }
    public PurchaseStep Step { get; private set; }

    public Destination? Destination { get; set; }
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public string PlantName { get; set; } = "";

    public Person Holder { get; private set; } = new();
    public Person Minor { get; private set; } = new();
    public bool ParentOath { get; set; }

    public bool DesignateBeneficiaries { get; set; } = true;
    public List<Beneficiary> Beneficiaries { get; } = [];
    public bool? IsPep { get; set; }
    public bool? IsPepAssociate { get; set; }
    public PepData Pep { get; private set; } = new();
    public PepAssociate Associate { get; private set; } = new();
    public List<Relative> Relatives { get; } = [];

    /// <summary>ID card reading of the insured person, linked to the contract when it is started.</summary>
    public Guid? IdentityReadingId { get; set; }
    /// <summary>Contract started in the API once the buyer confirms their data.</summary>
    public ContractSession? Contract { get; set; }
    public string? PolicyNumber { get; set; }

    public void Start(ProductDefinition definition, Plan plan, bool forChild)
    {
        // Keeps the chosen destination when the buyer comes back to a plan of the same region.
        var keepDestination = definition == Definition && Destination is not null
                              && Destination.IsLatam == TravelProduct.IsLatam(plan);
        Definition = definition;
        Plan = plan;
        ForChild = forChild && definition.AllowsChild;
        if (!keepDestination) Destination = null;
        if (definition.Product != Product.Travel) { StartDate = null; EndDate = null; }
        Holder = new Person();
        Minor = new Person();
        ParentOath = false;
        Beneficiaries.Clear();
        Relatives.Clear();
        IsPep = null;
        IsPepAssociate = null;
        Pep = new PepData();
        Associate = new PepAssociate();
        IdentityReadingId = null;
        Contract = null;
        PolicyNumber = null;
        Step = Steps[0];
    }

    /// <summary>Ordered steps for the current product and buyer.</summary>
    public IReadOnlyList<PurchaseStep> Steps
    {
        get
        {
            var steps = new List<PurchaseStep>();
            if (Definition?.DetailsStep is not null) steps.Add(PurchaseStep.ProductDetails);
            steps.AddRange([PurchaseStep.Policy, PurchaseStep.IdCard]);
            if (ForChild) steps.AddRange([PurchaseStep.MinorData, PurchaseStep.HolderData]);
            else steps.Add(PurchaseStep.InsuredData);
            steps.AddRange([PurchaseStep.Beneficiaries, PurchaseStep.Payment]);
            return steps;
        }
    }

    public int Index => Step == PurchaseStep.Done ? Steps.Count : Steps.ToList().IndexOf(Step);

    public bool IsFirstStep => Index == 0;

    public void Next()
    {
        var steps = Steps;
        Step = Index + 1 < steps.Count ? steps[Index + 1] : PurchaseStep.Done;
    }

    public void Back()
    {
        if (Index > 0) Step = Steps[Index - 1];
    }

    public void SetIdCard(bool isMinor, Person person)
    {
        person.Email = isMinor ? "" : Holder.Email;
        if (isMinor) Minor = person; else Holder = person;
    }

    public int Days => Plan?.ValidityDays
        ?? (StartDate is { } start && EndDate is { } end ? end.DayNumber - start.DayNumber + 1 : 0);

    public decimal Total => Plan is null ? 0 : Plan.ValidityDays is null ? Plan.Rate * Days : Plan.Rate;

    public int AssignedPercentage => Beneficiaries.Sum(b => b.Percentage);

    public Person Insured => ForChild ? Minor : Holder;
}
