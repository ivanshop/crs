using Check.Web.Services.Api;

namespace Check.Web.Services;

/// <summary>
/// API catalogs as the labels the forms show, plus the lookups that turn a label back into
/// the code or id the API expects. Loaded once and refreshed every few minutes.
/// </summary>
public sealed class Catalogs(IServiceScopeFactory scopes)
{
    private static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(10);
    private readonly SemaphoreSlim _lock = new(1, 1);
    private (CatalogSet Set, DateTimeOffset LoadedAt)? _cache;

    public async Task<CatalogSet> GetAsync(CancellationToken ct = default)
    {
        if (_cache is { } c && DateTimeOffset.UtcNow - c.LoadedAt < Lifetime) return c.Set;
        await _lock.WaitAsync(ct);
        try
        {
            if (_cache is { } fresh && DateTimeOffset.UtcNow - fresh.LoadedAt < Lifetime) return fresh.Set;
            using var scope = scopes.CreateScope();
            var api = scope.ServiceProvider.GetRequiredService<ICheckApi>();
            var set = new CatalogSet(await api.GetCatalogsAsync(ct), await api.GetProductsAsync(ct));
            _cache = (set, DateTimeOffset.UtcNow);
            return set;
        }
        finally
        {
            _lock.Release();
        }
    }
}

public sealed class CatalogSet
{
    // The API validates gender by name and has no catalog for it.
    public IReadOnlyList<string> Genders { get; } = ["Femenino", "Masculino"];

    public IReadOnlyList<string> DocumentTypes { get; }
    public IReadOnlyList<string> MaritalStatuses { get; }
    public IReadOnlyList<string> HolderRelationships { get; }
    public IReadOnlyList<string> PepRelationships { get; }
    public IReadOnlyList<string> PepPartnerLinks { get; }
    public IReadOnlyList<string> Relationships { get; }
    public IReadOnlyList<string> Nationalities { get; }
    public IReadOnlyList<string> Countries { get; }
    public IReadOnlyList<string> Occupations { get; }
    public IReadOnlyList<string> Cities { get; }
    public IReadOnlyList<ProductResponse> Products { get; }

    private readonly Dictionary<string, Dictionary<string, string>> _lists;
    private readonly CatalogsResponse _raw;

    public CatalogSet(CatalogsResponse raw, IReadOnlyList<ProductResponse> products)
    {
        _raw = raw;
        Products = products;
        _lists = raw.Lists.ToDictionary(l => l.Key, l => l.Value.ToDictionary(i => i.Value, i => i.Code));
        DocumentTypes = raw.Lists.GetValueOrDefault("Tipo-Documento-Identidad", [])
            .Where(i => i.Code is "CI" or "CE").Select(i => i.Value).ToList();
        MaritalStatuses = Names("Estado-Civil");
        HolderRelationships = Names("Parentesco-Contratante");
        PepRelationships = Names("Parentesco-PEP");
        PepPartnerLinks = Names("Vinculo-Socio-PEP");
        Relationships = raw.Relationships.Select(r => r.Name).ToList();
        Nationalities = raw.Nationalities.Select(n => n.Name).ToList();
        Countries = raw.Nationalities.Select(n => n.Country).OrderBy(c => c).ToList();
        Occupations = raw.Occupations.Select(o => o.Name).OrderBy(o => o).ToList();
        // City names repeat across departments, so the label carries the department.
        Cities = raw.Cities.Select(CityLabel).OrderBy(c => c).ToList();
    }

    public PlanResponse? Plan(string productCode, string planCode) =>
        Products.FirstOrDefault(p => p.Code == productCode)?.Plans.FirstOrDefault(p => p.Code == planCode);

    public string DocumentTypeCode(string name) => Code("Tipo-Documento-Identidad", name);
    public string MaritalStatusCode(string name) => Code("Estado-Civil", name);
    public string HolderRelationshipCode(string name) => Code("Parentesco-Contratante", name);
    public string PepRelationshipCode(string name) => Code("Parentesco-PEP", name);
    public string PepPartnerLinkCode(string name) => Code("Vinculo-Socio-PEP", name);
    public string RelationshipCode(string name) => _raw.Relationships.FirstOrDefault(r => r.Name == name)?.Code ?? name;
    public short? NationalityId(string name) => _raw.Nationalities.FirstOrDefault(n => n.Name == name)?.Id;
    public short? CountryId(string name) => _raw.Nationalities.FirstOrDefault(n => n.Country == name)?.Id;
    public short? OccupationId(string name) => _raw.Occupations.FirstOrDefault(o => o.Name == name)?.Id;
    public short? CityId(string label) => _raw.Cities.FirstOrDefault(c => CityLabel(c) == label)?.Id;

    /// <summary>Turns a value read from the ID card (code or name) into the label the form shows.</summary>
    public string DocumentTypeName(string? value) => Name("Tipo-Documento-Identidad", value);
    public string MaritalStatusName(string? value) => Name("Estado-Civil", value);
    public string OccupationName(string? value) =>
        _raw.Occupations.FirstOrDefault(o => Same(o.Name, value) || Same(o.Code, value))?.Name ?? "";

    /// <summary>Form labels of the fields SEGIP reports as mismatched.</summary>
    public static string FieldLabel(string field) => field switch
    {
        "documentNumber" => "número de documento",
        "complement" => "complemento",
        "names" => "nombres",
        "paternalLastname" => "apellido paterno",
        "maternalLastname" => "apellido materno",
        "birthdate" => "fecha de nacimiento",
        _ => field
    };

    private static string CityLabel(CityResponse city) => $"{city.Name} ({city.Department})";

    private IReadOnlyList<string> Names(string list) => _lists.GetValueOrDefault(list)?.Keys.ToList() ?? [];

    private string Code(string list, string name) => _lists.GetValueOrDefault(list)?.GetValueOrDefault(name) ?? name;

    private string Name(string list, string? value) =>
        _lists.GetValueOrDefault(list)?.FirstOrDefault(p => Same(p.Key, value) || Same(p.Value, value)).Key ?? "";

    private static bool Same(string? a, string? b) =>
        !string.IsNullOrWhiteSpace(b) && string.Equals(a?.Trim(), b.Trim(), StringComparison.OrdinalIgnoreCase);
}
