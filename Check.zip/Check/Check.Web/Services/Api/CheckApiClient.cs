using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Options;

namespace Check.Web.Services.Api;

public sealed class CheckApiOptions
{
    public const string Section = "CheckApi";
    public string BaseUrl { get; set; } = "";
    public string ClientId { get; set; } = "";
    public string ClientSecret { get; set; } = "";
    /// <summary>Code of the sports product in the API catalog.</summary>
    public string SportsProductCode { get; set; } = "DEP-SEG";
}

/// <summary>Error returned by the API as ProblemDetails. <see cref="Message"/> is safe to show to the buyer.</summary>
public sealed class CheckApiException(int status, string? code, string message, IReadOnlyDictionary<string, string[]>? errors)
    : Exception(message)
{
    public int Status { get; } = status;
    public string? Code { get; } = code;
    public IReadOnlyDictionary<string, string[]> Errors { get; } = errors ?? new Dictionary<string, string[]>();
}

/// <summary>Contract created in the API plus the token scoped to it, required by every /contracts/{id} call.</summary>
public sealed record ContractSession(Guid ContractId, string AccessToken);

/// <summary>Client credentials token for the calls that are not tied to a contract. Cached until shortly before it expires.</summary>
public sealed class ClientTokenProvider(IHttpClientFactory factory, IOptions<CheckApiOptions> options)
{
    private readonly SemaphoreSlim _lock = new(1, 1);
    private TokenResponse? _token;

    public async Task<string> GetAsync(CancellationToken ct)
    {
        if (_token is { } t && t.ExpiresAt > DateTimeOffset.UtcNow.AddMinutes(1)) return t.AccessToken;
        await _lock.WaitAsync(ct);
        try
        {
            if (_token is { } fresh && fresh.ExpiresAt > DateTimeOffset.UtcNow.AddMinutes(1)) return fresh.AccessToken;
            var http = factory.CreateClient(nameof(ClientTokenProvider));
            var o = options.Value;
            using var response = await http.PostAsJsonAsync("api/v1/auth/token", new TokenRequest(o.ClientId, o.ClientSecret), CheckApiClient.Json, ct);
            _token = await CheckApiClient.ReadAsync<TokenResponse>(response, ct);
            return _token.AccessToken;
        }
        finally
        {
            _lock.Release();
        }
    }
}

/// <summary>Typed HTTP client for Check.Api v1.</summary>
public sealed class CheckApiClient(HttpClient http, ClientTokenProvider tokens) : ICheckApi
{
    internal static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        NumberHandling = JsonNumberHandling.AllowReadingFromString,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public async Task<IReadOnlyList<ProductResponse>> GetProductsAsync(CancellationToken ct = default) =>
        await SendAsync<IReadOnlyList<ProductResponse>>(HttpMethod.Get, "api/v1/products", null, null, ct);

    public Task<CatalogsResponse> GetCatalogsAsync(CancellationToken ct = default) =>
        SendAsync<CatalogsResponse>(HttpMethod.Get, "api/v1/catalogs", null, null, ct);

    public async Task<IdentityReadingResponse> StartIdentityReadingAsync(long planId, Stream front, Stream back, CancellationToken ct = default)
    {
        using var form = new MultipartFormDataContent();
        form.Add(new StringContent(planId.ToString()), "PlanId");
        form.Add(Image(front), "Front", "front.jpg");
        form.Add(Image(back), "Back", "back.jpg");
        return await SendAsync<IdentityReadingResponse>(HttpMethod.Post, "api/v1/identity-readings", form, null, ct);
    }

    public Task<IdentityReadingResponse> GetIdentityReadingAsync(Guid id, CancellationToken ct = default) =>
        SendAsync<IdentityReadingResponse>(HttpMethod.Get, $"api/v1/identity-readings/{id}", null, null, ct);

    public async Task<ContractSession> StartContractAsync(StartContractRequest request, CancellationToken ct = default)
    {
        var started = await SendAsync<StartContractResponse>(HttpMethod.Post, "api/v1/contracts", JsonContent.Create(request, options: Json), null, ct);
        return new ContractSession(started.ContractId, started.AccessToken);
    }

    public Task<ScreeningResponse> ScreenAsync(ContractSession contract, CancellationToken ct = default) =>
        SendAsync<ScreeningResponse>(HttpMethod.Post, Path(contract, "screening"), null, contract, ct);

    /// <summary>Contract states (see the API guide, section 4.1).</summary>
    public const string StatusRejected = "Rechazado", StatusActive = "Activo";

    public Task<SendOtpResponse> SendOtpAsync(ContractSession contract, CancellationToken ct = default) =>
        SendAsync<SendOtpResponse>(HttpMethod.Post, Path(contract, "otp"), null, contract, ct);

    public Task VerifyOtpAsync(ContractSession contract, string code, CancellationToken ct = default) =>
        SendAsync<JsonElement>(HttpMethod.Post, Path(contract, "otp/verification"), JsonContent.Create(new VerifyOtpRequest(code), options: Json), contract, ct);

    public Task DeclareAsync(ContractSession contract, DeclareRequest request, CancellationToken ct = default) =>
        SendAsync<JsonElement>(HttpMethod.Put, Path(contract, "declarations"), JsonContent.Create(request, options: Json), contract, ct);

    public Task<QrResponse> CreateQrAsync(ContractSession contract, CancellationToken ct = default) =>
        SendAsync<QrResponse>(HttpMethod.Post, Path(contract, "qr"), null, contract, ct);

    public Task<ContractSummaryResponse> GetContractAsync(ContractSession contract, CancellationToken ct = default) =>
        SendAsync<ContractSummaryResponse>(HttpMethod.Get, $"api/v1/contracts/{contract.ContractId}", null, contract, ct);

    public Task SubmitSurveyAsync(ContractSession contract, int score, CancellationToken ct = default) =>
        SendAsync<JsonElement>(HttpMethod.Post, Path(contract, "survey"), JsonContent.Create(new SubmitSurveyRequest(score, null), options: Json), contract, ct);

    public Task SimulatePaymentAsync(ContractSession contract, CancellationToken ct = default) =>
        SendAsync<JsonElement>(HttpMethod.Post, $"api/v1/dev/contracts/{contract.ContractId}/simulate-payment",
            JsonContent.Create(new { amount = (decimal?)null }, options: Json), contract, ct);

    private static string Path(ContractSession contract, string action) => $"api/v1/contracts/{contract.ContractId}/{action}";

    private static StreamContent Image(Stream stream)
    {
        var content = new StreamContent(stream);
        content.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");
        return content;
    }

    // Contract calls use the contract token; the rest use the client token.
    private async Task<T> SendAsync<T>(HttpMethod method, string path, HttpContent? body, ContractSession? contract, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(method, path) { Content = body };
        var token = contract?.AccessToken ?? await tokens.GetAsync(ct);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await http.SendAsync(request, ct);
        return await ReadAsync<T>(response, ct);
    }

    internal static async Task<T> ReadAsync<T>(HttpResponseMessage response, CancellationToken ct)
    {
        if (!response.IsSuccessStatusCode)
        {
            ApiProblem? problem = null;
            try { problem = await response.Content.ReadFromJsonAsync<ApiProblem>(Json, ct); }
            catch (JsonException) { }
            var message = problem?.Detail ?? problem?.Title ?? "No pudimos completar la operación. Intenta de nuevo.";
            if (problem?.Errors is { Count: > 0 } errors) message = string.Join(" ", errors.Values.SelectMany(e => e));
            throw new CheckApiException((int)response.StatusCode, problem?.Code, message, problem?.Errors);
        }
        var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<T>>(Json, ct);
        return envelope is { Data: { } data } ? data : default!;
    }
}
