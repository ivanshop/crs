namespace Check.Web.Services.Api;

// Request and response bodies of Check.Api v1 (see /openapi on the API).
// Every response is wrapped in ApiEnvelope; errors come as ProblemDetails.

public sealed record ApiEnvelope<T>(string? TraceId, string? Message, T? Data);

public sealed record ApiProblem(string? Title, int? Status, string? Detail, string? Code,
    Dictionary<string, string[]>? Errors);

public sealed record TokenRequest(string ClientId, string ClientSecret);
public sealed record TokenResponse(string AccessToken, DateTimeOffset ExpiresAt);

public sealed record MoneyResponse(decimal Amount, string Currency);
public sealed record PlanResponse(long Id, string Code, string Name, string? Description, MoneyResponse? Premium);
public sealed record ProductResponse(string Code, string Name, string? Description, IReadOnlyList<PlanResponse> Plans);

public sealed record CatalogItem(string Code, string Value);
public sealed record NationalityResponse(short Id, string Iso, string Name, string Country);
public sealed record OccupationResponse(short Id, string Code, string Type, string Name, string? Profession);
public sealed record CityResponse(short Id, string Name, string Province, string Department);
public sealed record RelationshipResponse(long Id, string Code, string Name);

public sealed record CatalogsResponse(
    IReadOnlyList<NationalityResponse> Nationalities,
    IReadOnlyList<OccupationResponse> Occupations,
    IReadOnlyList<CityResponse> Cities,
    IReadOnlyList<RelationshipResponse> Relationships,
    Dictionary<string, IReadOnlyList<CatalogItem>> Lists);

public sealed record IdentityFields(
    string? DocumentType, string? DocumentNumber, string? Complement, string? Extension,
    string? Names, string? PaternalLastname, string? MaternalLastname, DateOnly? Birthdate,
    string? BirthPlace, string? Address, string? Occupation, string? MaritalStatus, bool? IsMinor);

public sealed record IdentityReadingResponse(Guid Id, string Status, IdentityFields? Fields);

public sealed record PersonRequest(
    string DocumentType, string DocumentNumber, string? Complement, string? Extension,
    string Names, string? PaternalLastname, string? MaternalLastname, DateOnly? Birthdate,
    string Gender, short? NationalityId, string BirthPlace, string Address, string Cellphone,
    string Email, short? CityId, string MaritalStatus, short? OccupationId);

public sealed record StartContractRequest(long PlanId, Guid? IdentityReadingId, PersonRequest Insured,
    PersonRequest? Contractor, string? ContractorRelationship);

public sealed record StartContractResponse(Guid ContractId, string Status, string AccessToken);

public sealed record PersonScreeningResponse(string Role, string Result, bool FoundInSegip, IReadOnlyList<string> MismatchedFields);
public sealed record ScreeningResponse(Guid ContractId, string Status, IReadOnlyList<PersonScreeningResponse> People);

public sealed record SendOtpResponse(string SentTo, DateTimeOffset ExpiresAt, DateTimeOffset ResendAvailableAt, int RemainingSends);
public sealed record VerifyOtpRequest(string Code);

public sealed record BeneficiaryRequest(string RelationshipCode, string? DocumentNumber, string Names,
    string? PaternalLastname, string? MaternalLastname, decimal Percentage);
public sealed record PepRelativeRequest(string RelationshipCode, string Names, string? PaternalLastname,
    string? MaternalLastname, string? DocumentNumber, short? NationalityId);
public sealed record PepPartnerRequest(string RelationshipCode, string Names, string? PaternalLastname,
    string? MaternalLastname, string Position);
public sealed record PepRequest(bool IsPep, bool HasPepPartners, string? Position, string? Institution,
    string? SourceFunds, short? ExerciseCountryId, DateOnly? PeriodStart, DateOnly? PeriodEnd,
    IReadOnlyList<PepRelativeRequest> Relatives, IReadOnlyList<PepPartnerRequest> Partners);
public sealed record DeclareRequest(IReadOnlyList<BeneficiaryRequest> Beneficiaries, PepRequest Pep);

public sealed record QrResponse(Guid QrPaymentId, string Status, string QrImage, decimal Amount,
    string Currency, string Description, DateTimeOffset ExpiresAt);

public sealed record QrSummaryResponse(Guid QrPaymentId, string Status, DateTimeOffset ExpiresAt, DateTimeOffset? PaidAt);
public sealed record ContractSummaryResponse(Guid ContractId, string Status, string? Number, string ProductName,
    string PlanName, decimal Premium, string Currency, DateTimeOffset? CoverageFrom, DateTimeOffset? CoverageTo,
    string? RejectionReason, QrSummaryResponse? Qr);

public sealed record SubmitSurveyRequest(int Score, string? Comment);
