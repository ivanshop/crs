using Check.Web.Models;

namespace Check.Web.Services.Api;

/// <summary>Converts between the form models (labels) and the API bodies (codes and ids).</summary>
public static class ApiMapper
{
    public static Person ToPerson(IdentityFields? fields, CatalogSet catalogs) => fields is null ? new Person() : new Person
    {
        PaternalSurname = fields.PaternalLastname ?? "",
        MaternalSurname = fields.MaternalLastname ?? "",
        FirstNames = fields.Names ?? "",
        DocumentType = catalogs.DocumentTypeName(fields.DocumentType),
        DocumentNumber = fields.DocumentNumber ?? "",
        Complement = fields.Complement ?? "",
        BirthDate = fields.Birthdate,
        BirthPlace = fields.BirthPlace ?? "",
        Address = fields.Address ?? "",
        Occupation = catalogs.OccupationName(fields.Occupation),
        MaritalStatus = catalogs.MaritalStatusName(fields.MaritalStatus)
    };

    // The minor has no phone, e-mail or occupation of their own: the contractor's are sent.
    public static PersonRequest ToRequest(Person person, CatalogSet catalogs, Person? contactFrom = null)
    {
        var contact = contactFrom ?? person;
        return new PersonRequest(
            catalogs.DocumentTypeCode(person.DocumentType), person.DocumentNumber.Trim(), Blank(person.Complement), null,
            person.FirstNames.Trim(), Blank(person.PaternalSurname), Blank(person.MaternalSurname), person.BirthDate,
            person.Gender, catalogs.NationalityId(person.Nationality), person.BirthPlace.Trim(), person.Address.Trim(),
            contact.MobilePhone.Trim(), contact.Email.Trim(), catalogs.CityId(person.Residence),
            catalogs.MaritalStatusCode(person.MaritalStatus), catalogs.OccupationId(contact.Occupation));
    }

    public static StartContractRequest ToStartContract(PurchaseState state, long planId, CatalogSet catalogs) =>
        state.ForChild
            ? new StartContractRequest(planId, state.IdentityReadingId, ToRequest(state.Minor, catalogs, state.Holder),
                ToRequest(state.Holder, catalogs), catalogs.HolderRelationshipCode(state.Holder.Relationship))
            : new StartContractRequest(planId, state.IdentityReadingId, ToRequest(state.Holder, catalogs), null, null);

    public static DeclareRequest ToDeclarations(PurchaseState state, CatalogSet catalogs)
    {
        var beneficiaries = state.DesignateBeneficiaries
            ? state.Beneficiaries.Select(b => new BeneficiaryRequest(catalogs.RelationshipCode(b.Relationship), null,
                b.FirstNames.Trim(), Blank(b.PaternalSurname), Blank(b.MaternalSurname), b.Percentage)).ToList()
            : [];

        var isPep = state.IsPep == true;
        var hasPartners = state.IsPepAssociate == true;
        var pep = state.Pep;
        var relatives = isPep
            ? state.Relatives.Select(r => new PepRelativeRequest(catalogs.PepRelationshipCode(r.Relationship), r.FirstName.Trim(),
                Blank(r.PaternalSurname), Blank(r.MaternalSurname), null, catalogs.NationalityId(r.Nationality))).ToList()
            : [];
        var partners = hasPartners
            ? new List<PepPartnerRequest>
            {
                new(catalogs.PepPartnerLinkCode(state.Associate.Link), state.Associate.FirstName.Trim(),
                    Blank(state.Associate.PaternalSurname), Blank(state.Associate.MaternalSurname), state.Associate.Position.Trim())
            }
            : [];

        return new DeclareRequest(beneficiaries, new PepRequest(isPep, hasPartners,
            isPep ? Blank(pep.Position) : null, isPep ? Blank(pep.Company) : null, isPep ? Blank(pep.FundsSource) : null,
            isPep ? catalogs.CountryId(pep.Country) : null, isPep ? pep.StartDate : null, isPep ? pep.EndDate : null,
            relatives, partners));
    }

    private static string? Blank(string value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
