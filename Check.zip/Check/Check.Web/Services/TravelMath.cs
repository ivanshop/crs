using Check.Web.Models;

namespace Check.Web.Services;

public static class TravelMath
{
    private const double BoliviaLat = -16.5, BoliviaLon = -65, SpeedKmH = 850;

    /// <summary>Approximate hours of a direct flight from Bolivia, based on distance.</summary>
    public static double FlightHours(Destination destination)
    {
        const double rad = Math.PI / 180;
        var a = Math.Pow(Math.Sin((destination.Lat - BoliviaLat) * rad / 2), 2)
                + Math.Cos(BoliviaLat * rad) * Math.Cos(destination.Lat * rad)
                * Math.Pow(Math.Sin((destination.Lon - BoliviaLon) * rad / 2), 2);
        var km = 12742 * Math.Asin(Math.Sqrt(a));
        return Math.Max(1, Math.Round((km / SpeedKmH + .5) * 2) / 2);
    }
}
