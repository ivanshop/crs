using Check.Web.Services.Api;

namespace Check.Web.Services;

/// <summary>Contract with Check.Api. The presentation layer has no database and never calls the OCR directly.</summary>
public interface ICheckApi
{
    Task<IReadOnlyList<ProductResponse>> GetProductsAsync(CancellationToken ct = default);
    Task<CatalogsResponse> GetCatalogsAsync(CancellationToken ct = default);

    Task<IdentityReadingResponse> StartIdentityReadingAsync(long planId, Stream front, Stream back, CancellationToken ct = default);
    Task<IdentityReadingResponse> GetIdentityReadingAsync(Guid id, CancellationToken ct = default);

    Task<ContractSession> StartContractAsync(StartContractRequest request, CancellationToken ct = default);
    Task<ScreeningResponse> ScreenAsync(ContractSession contract, CancellationToken ct = default);
    Task<SendOtpResponse> SendOtpAsync(ContractSession contract, CancellationToken ct = default);
    Task VerifyOtpAsync(ContractSession contract, string code, CancellationToken ct = default);
    Task DeclareAsync(ContractSession contract, DeclareRequest request, CancellationToken ct = default);
    Task<QrResponse> CreateQrAsync(ContractSession contract, CancellationToken ct = default);
    Task<ContractSummaryResponse> GetContractAsync(ContractSession contract, CancellationToken ct = default);
    Task SubmitSurveyAsync(ContractSession contract, int score, CancellationToken ct = default);

    /// <summary>Development only: does what the bank does when the pending QR is paid.</summary>
    Task SimulatePaymentAsync(ContractSession contract, CancellationToken ct = default);
}
