using Check.Web.Components;
using Check.Web.Services;
using Check.Web.Services.Api;
using Microsoft.Extensions.Options;
using ZLogger;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddZLoggerConsole();

builder.Services.AddRazorComponents().AddInteractiveServerComponents();

// Check.Api: base URL and client credentials come from the "CheckApi" section
// (the secret lives in user-secrets during development, in environment variables in production).
builder.Services.AddOptions<CheckApiOptions>().BindConfiguration(CheckApiOptions.Section)
    .Validate(o => Uri.TryCreate(o.BaseUrl, UriKind.Absolute, out _) && o.ClientId != "" && o.ClientSecret != "",
        "CheckApi:BaseUrl, CheckApi:ClientId and CheckApi:ClientSecret are required.")
    .ValidateOnStart();
void UseApiBaseUrl(IServiceProvider sp, HttpClient http)
{
    http.BaseAddress = new Uri(sp.GetRequiredService<IOptions<CheckApiOptions>>().Value.BaseUrl.TrimEnd('/') + "/");
    http.Timeout = TimeSpan.FromSeconds(30);
}
builder.Services.AddHttpClient(nameof(ClientTokenProvider), UseApiBaseUrl);
builder.Services.AddHttpClient<ICheckApi, CheckApiClient>(UseApiBaseUrl);
builder.Services.AddSingleton<ClientTokenProvider>();
builder.Services.AddSingleton<Catalogs>();
builder.Services.AddScoped<PurchaseState>();

var app = builder.Build();

if (!app.Environment.IsDevelopment()) app.UseHsts();

app.UseAntiforgery();
app.MapStaticAssets();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();
app.Run();
