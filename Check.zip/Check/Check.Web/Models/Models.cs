namespace Check.Web.Models;

public enum Product { Sports, Travel, Visit }

public enum PurchaseStep
{
    ProductDetails, Policy, IdCard, InsuredData,
    MinorData, HolderData, Beneficiaries, Payment, Done
}

public sealed record Plan(
    string Id, string Name, string Tag, decimal Rate, string Unit,
    int? ValidityDays, IReadOnlyList<string> Coverages, IReadOnlyList<string> Details);

public sealed record Destination(string Name, double Lon, double Lat, bool IsLatam);

public sealed record InfoCard(string Title, string Text, string Icon);

public sealed class Person
{
    public string PaternalSurname { get; set; } = "";
    public string MaternalSurname { get; set; } = "";
    public string FirstNames { get; set; } = "";
    public string DocumentType { get; set; } = "";
    public string DocumentNumber { get; set; } = "";
    public string Complement { get; set; } = "";
    public DateOnly? BirthDate { get; set; }
    public string BirthPlace { get; set; } = "";
    public string Address { get; set; } = "";
    public string Occupation { get; set; } = "";
    public string Nationality { get; set; } = "";
    public string Residence { get; set; } = "";
    public string MaritalStatus { get; set; } = "";
    public string MobilePhone { get; set; } = "";
    public string Email { get; set; } = "";
    public string Gender { get; set; } = "";
    public string Relationship { get; set; } = "";
}

public sealed class Beneficiary
{
    public string Relationship { get; set; } = "";
    public string FirstNames { get; set; } = "";
    public string PaternalSurname { get; set; } = "";
    public string MaternalSurname { get; set; } = "";
    public int Percentage { get; set; }
    public string Initials =>
        $"{FirstNames.FirstOrDefault()}{PaternalSurname.FirstOrDefault()}".ToUpperInvariant();
}

public sealed class Relative
{
    public string FirstName { get; set; } = "";
    public string PaternalSurname { get; set; } = "";
    public string MaternalSurname { get; set; } = "";
    public string Nationality { get; set; } = "";
    public string Relationship { get; set; } = "";
}

public sealed class PepData
{
    public string FundsSource { get; set; } = "";
    public string Position { get; set; } = "";
    public string Company { get; set; } = "";
    public string Country { get; set; } = "";
    public DateOnly? StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public bool IsComplete => new[] { FundsSource, Position, Company, Country }.All(x => !string.IsNullOrWhiteSpace(x))
                              && StartDate is not null;
}

public sealed class PepAssociate
{
    public string FirstName { get; set; } = "";
    public string PaternalSurname { get; set; } = "";
    public string MaternalSurname { get; set; } = "";
    public string Position { get; set; } = "";
    public string Link { get; set; } = "";
    public bool IsComplete => new[] { FirstName, PaternalSurname, MaternalSurname, Position, Link }
        .All(x => !string.IsNullOrWhiteSpace(x));
}
