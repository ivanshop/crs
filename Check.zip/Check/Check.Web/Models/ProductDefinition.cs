using Check.Web.Services;

namespace Check.Web.Models;

/// <summary>Product-specific step shown before the common purchase flow.</summary>
public sealed record DetailsStepInfo(string Label, string BannerTitle);

/// <summary>Row shown in the payment summary.</summary>
public sealed record SummaryRow(string Label, string Value);

/// <summary>
/// Everything a product (sports, travel, visit) customizes. The common flow
/// (policy, ID card, data, beneficiaries, QR payment and NPS) reads from here.
/// </summary>
public abstract class ProductDefinition
{
    public abstract Product Product { get; }
    public abstract string Slug { get; }
    public abstract string Name { get; }
    public abstract string Tagline { get; }
    public abstract string Note { get; }
    public abstract IReadOnlyList<Plan> Plans { get; }
    public abstract IReadOnlyList<InfoCard> Benefits { get; }
    public abstract IReadOnlyList<InfoCard> PolicyHighlights { get; }

    public virtual string InfoTitle => "Si tienes un accidente";
    public virtual IReadOnlyList<InfoCard> Info => [];

    /// <summary>Product code in Check.Api, or null while the API does not sell it yet (the product stays hidden).</summary>
    public virtual string? ApiProductCode => null;

    public bool IsAvailable => ApiProductCode is not null;

    /// <summary>Whether the product can be bought for a child.</summary>
    public virtual bool AllowsChild => true;

    /// <summary>Product-specific first step, or null when the flow starts at the policy.</summary>
    public virtual DetailsStepInfo? DetailsStep => null;

    public abstract IEnumerable<SummaryRow> PaymentSummary(PurchaseState state);

    /// <summary>Short description shown on the confirmation screen.</summary>
    public abstract string DoneSummary(PurchaseState state);
}
