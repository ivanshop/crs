# Check

Frontend de Check en Blazor Server (.NET 10) y Bootstrap.

```bash
dotnet run --project Check.Web
```

Abre http://localhost:5180. En desarrollo, el paso de pago muestra "Simular pago".

El código (clases, variables, componentes y comentarios) está en inglés.
El español se usa solo en los textos que ve el usuario y en las rutas públicas (`/deportes`, `/viajes`, `/visitas`).

## Estructura de Check.Web

| Carpeta | Contenido |
|---|---|
| `Components/Layout` | Barra superior, pie de página y modo oscuro. |
| `Components/Pages` | Las páginas con ruta: `Home`, `ProductPage` (los tres seguros) y `PurchasePage`. |
| `Components/Steps` | Un componente por paso (`...Step`) y sus partes: `TravelMap`, `DestinationPicker`, `DocumentUpload`, `OtpDialog`, `BeneficiaryDialog`, `PepSection`, `ProgressBar`. |
| `Components/Shared` | Piezas reutilizables: `Modal`, `Calendar`, `SelectField`, `Expander`, `AnimatedTotal`, `ProductIcon`, `BrandMark`, `PlantScene`. |
| `Models` | Datos de la compra (`Models.cs`) y contenido de los seguros (`Catalog.cs`). |
| `Services` | `PurchaseState` (borrador de la compra), `ICheckApi` (contrato con el API), `TravelMath` y las simulaciones `FakeCheckApi` y `FakePayments`. |
| `wwwroot/css` | `app.css` (estilos) y `animations.css` (movimiento y mapa). |
| `wwwroot/js/check.js` | Animaciones con GSAP: `step`, `reveal`, `total`, `map`, `fly`. |
| `wwwroot/data/land.json` | Puntos del mapa de viajes. |

## Cómo fluye una compra

1. `ProductPage` llama a `PurchaseState.Start` con el seguro, el plan y si es para un hijo.
2. `PurchasePage` muestra el componente del paso actual (`PurchaseState.Step`).
3. Cada paso avisa con `OnNext` u `OnBack`; `PurchaseState.Steps` define el orden según el seguro.

## Conexión con Check.Api

El front usa Check.Api (`CheckApi:BaseUrl`, por defecto http://localhost:5080). En desarrollo el secreto va en user-secrets:

```bash
dotnet user-secrets set "CheckApi:ClientSecret" "<secreto>" --project Check.Web
```

- `Services/Api/CheckApiClient.cs`: cliente HTTP. Usa el token del cliente (`/auth/token`) y, desde que se crea el contrato, el token propio del contrato.
- `Services/Catalogs.cs`: catálogos y productos en caché. Los formularios muestran nombres y `ApiMapper` los convierte a los códigos o ids que espera el API.
- Flujo: lectura del carnet → contrato → screening → OTP → declaraciones → QR → consulta del estado cada 5 s → encuesta.
- Solo se muestran los productos con `ApiProductCode` (hoy, Deportes) y solo se pueden comprar los planes que tienen prima en el API.
- El borrador sigue en memoria; si se pierde el circuito, la compra se reinicia.
