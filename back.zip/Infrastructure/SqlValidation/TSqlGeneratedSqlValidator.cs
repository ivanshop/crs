using Application.Metadata;
using Application.Ports;
using Application.UseCase;
using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace Infrastructure.SqlValidation;

public sealed class TSqlGeneratedSqlValidator : IGeneratedSqlValidator
{
    public string Validate(string sql, DatabaseSchemaSnapshot schema)
    {
        ArgumentNullException.ThrowIfNull(schema);

        if (string.IsNullOrWhiteSpace(sql))
        {
            throw new InvalidGeneratedSqlException("El modelo no devolvió ninguna sentencia SQL.");
        }

        var parser = new TSql160Parser(initialQuotedIdentifiers: true);
        TSqlFragment fragment;
        IList<ParseError> errors;
        using (var reader = new StringReader(sql))
        {
            fragment = parser.Parse(reader, out errors);
        }

        if (errors.Count > 0)
        {
            throw new InvalidGeneratedSqlException(
                "SQL con errores de sintaxis: "
                + string.Join("; ", errors.Take(3).Select(error => $"línea {error.Line}, columna {error.Column}: {error.Message}")));
        }

        if (fragment is not TSqlScript { Batches: [{ Statements: [SelectStatement select] }] })
        {
            throw new InvalidGeneratedSqlException(
                "Solo se permite una única sentencia SELECT (se admiten CTEs, funciones de ventana y subconsultas).");
        }

        if (select.Into is not null || select.On is not null)
        {
            throw new InvalidGeneratedSqlException("SELECT ... INTO no está permitido.");
        }

        var allowedObjects = schema.Objects
            .Select(item => $"{item.Schema}.{item.Name}")
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var cteCollector = new CteNameCollector();
        select.Accept(cteCollector);

        var visitor = new SafetyVisitor(allowedObjects, cteCollector.Names);
        select.Accept(visitor);
        if (visitor.Violations.Count > 0)
        {
            throw new InvalidGeneratedSqlException(string.Join(" ", visitor.Violations));
        }

        return sql.Trim().TrimEnd(';').TrimEnd();
    }

    private sealed class CteNameCollector : TSqlFragmentVisitor
    {
        public HashSet<string> Names { get; } = new(StringComparer.OrdinalIgnoreCase);

        public override void ExplicitVisit(CommonTableExpression node)
        {
            Names.Add(node.ExpressionName.Value);
            base.ExplicitVisit(node);
        }
    }

    private sealed class SafetyVisitor(HashSet<string> allowedObjects, HashSet<string> cteNames)
        : TSqlFragmentVisitor
    {
        private static readonly string[] ForbiddenFunctionPrefixes = ["xp_", "sp_", "fn_"];

        public HashSet<string> Violations { get; } = [];

        public override void ExplicitVisit(NamedTableReference node)
        {
            var name = node.SchemaObject;
            if (name.ServerIdentifier is not null || name.DatabaseIdentifier is not null)
            {
                Violations.Add($"No se permiten referencias entre bases de datos o servidores ({Describe(name)}).");
            }
            else if (name.SchemaIdentifier is null && cteNames.Contains(name.BaseIdentifier.Value))
            {
                // Referencia a una CTE definida en la misma consulta.
            }
            else
            {
                var schema = name.SchemaIdentifier?.Value ?? "dbo";
                if (!allowedObjects.Contains($"{schema}.{name.BaseIdentifier.Value}"))
                {
                    Violations.Add(
                        $"La tabla '{schema}.{name.BaseIdentifier.Value}' no existe en el esquema disponible o no está permitida.");
                }
            }

            base.ExplicitVisit(node);
        }

        public override void ExplicitVisit(SchemaObjectFunctionTableReference node) =>
            Violations.Add("No se permiten funciones de tabla definidas por el usuario.");

        public override void ExplicitVisit(OpenRowsetTableReference node) =>
            Violations.Add("OPENROWSET no está permitido.");

        public override void ExplicitVisit(OpenQueryTableReference node) =>
            Violations.Add("OPENQUERY no está permitido.");

        public override void ExplicitVisit(AdHocTableReference node) =>
            Violations.Add("OPENDATASOURCE no está permitido.");

        public override void ExplicitVisit(BulkOpenRowset node) =>
            Violations.Add("OPENROWSET(BULK) no está permitido.");

        public override void ExplicitVisit(InternalOpenRowset node) =>
            Violations.Add("OPENROWSET no está permitido.");

        public override void ExplicitVisit(FunctionCall node)
        {
            var functionName = node.FunctionName.Value;
            if (node.CallTarget is not null
                || ForbiddenFunctionPrefixes.Any(prefix =>
                    functionName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)))
            {
                Violations.Add($"No se permite llamar a la función '{functionName}'.");
            }

            base.ExplicitVisit(node);
        }

        private static string Describe(SchemaObjectName name) =>
            string.Join('.', name.Identifiers.Select(item => item.Value));
    }
}
