using Microsoft.Data.SqlClient;

namespace Infrastructure.DatabaseDiscovery;

public sealed class SqlServerConnectionOptions
{
    public const string SectionName = "SqlServer";

    public string Host { get; set; } = string.Empty;

    public string User { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;

    public bool Encrypt { get; set; } = true;

    public bool TrustServerCertificate { get; set; }

    public int ConnectTimeoutSeconds { get; set; } = 15;
}

public static class SqlServerConnectionStringFactory
{
    public static string Build(SqlServerConnectionOptions options, string databaseName)
    {
        ArgumentNullException.ThrowIfNull(options);

        if (string.IsNullOrWhiteSpace(options.Host))
        {
            throw new InvalidOperationException("Configure SqlServer:Host.");
        }

        if (string.IsNullOrWhiteSpace(options.User))
        {
            throw new InvalidOperationException("Configure SqlServer:User.");
        }

        if (string.IsNullOrWhiteSpace(options.Password))
        {
            throw new InvalidOperationException("Configure SqlServer:Password.");
        }

        if (string.IsNullOrWhiteSpace(databaseName))
        {
            throw new InvalidOperationException("Configure DatabaseDiscovery:DatabaseName.");
        }

        if (options.ConnectTimeoutSeconds <= 0)
        {
            throw new InvalidOperationException("SqlServer:ConnectTimeoutSeconds debe ser mayor que cero.");
        }

        var builder = new SqlConnectionStringBuilder
        {
            DataSource = options.Host,
            InitialCatalog = databaseName,
            UserID = options.User,
            Password = options.Password,
            IntegratedSecurity = false,
            Encrypt = options.Encrypt,
            TrustServerCertificate = options.TrustServerCertificate,
            ConnectTimeout = options.ConnectTimeoutSeconds,
            ApplicationName = "API_IA Database Discovery"
        };

        return builder.ConnectionString;
    }
}