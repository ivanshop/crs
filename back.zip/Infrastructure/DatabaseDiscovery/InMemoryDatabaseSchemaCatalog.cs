using Application.Metadata;
using Application.Ports;

namespace Infrastructure.DatabaseDiscovery;

public sealed class InMemoryDatabaseSchemaCatalog : IDatabaseSchemaCatalog
{
    private DatabaseSchemaSnapshot? _current;

    public DatabaseSchemaSnapshot? Current => Volatile.Read(ref _current);

    public void Replace(DatabaseSchemaSnapshot snapshot)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        Interlocked.Exchange(ref _current, snapshot);
    }
}