using Application.Ports;
using Application.UseCase;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Infrastructure.DatabaseDiscovery;

public sealed class DatabaseSchemaRefreshService : BackgroundService
{
    private readonly DiscoverDatabaseSchemaUseCase _discoverSchema;
    private readonly DatabaseDiscoveryOptions _options;
    private readonly ILogger<DatabaseSchemaRefreshService> _logger;

    public DatabaseSchemaRefreshService(
        DiscoverDatabaseSchemaUseCase discoverSchema,
        IOptions<DatabaseDiscoveryOptions> options,
        ILogger<DatabaseSchemaRefreshService> logger)
    {
        _discoverSchema = discoverSchema;
        _options = options.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!_options.Enabled)
        {
            _logger.LogInformation("Database discovery está deshabilitado.");
            return;
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var snapshot = await _discoverSchema.ExecuteAsync(stoppingToken);
                _logger.LogInformation(
                    "Database discovery actualizado: {ObjectCount} objetos detectados.",
                    snapshot.Objects.Count);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception,
                    "No se pudo actualizar database discovery. Se conserva el último snapshot válido.");
            }

            try
            {
                await Task.Delay(
                    TimeSpan.FromMinutes(_options.RefreshIntervalMinutes),
                    stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
        }
    }
}