using System.Data;
using Application.Metadata;
using Application.Ports;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace Infrastructure.DatabaseDiscovery;

public sealed class SqlServerSchemaReader : IDatabaseSchemaReader
{
    private const string SchemaFilter = "{0}.name IN ({1})";
    private const string TableFilter = "{0}.name IN ({1})";
    private readonly DatabaseDiscoveryOptions _options;
    private readonly SqlServerConnectionOptions _connectionOptions;

    public SqlServerSchemaReader(
        IOptions<DatabaseDiscoveryOptions> options,
        IOptions<SqlServerConnectionOptions> connectionOptions)
    {
        _options = options.Value;
        _connectionOptions = connectionOptions.Value;
    }

    public async Task<DatabaseSchemaSnapshot> DiscoverAsync(
        CancellationToken cancellationToken = default)
    {
        if (!_options.Enabled)
        {
            throw new InvalidOperationException("Database discovery está deshabilitado.");
        }

        if (_options.IncludedSchemas is not { Length: > 0 }
            || (!_options.IncludeAllTables && _options.IncludedTables is not { Length: > 0 }))
        {
            throw new InvalidOperationException(
                "DatabaseDiscovery requiere al menos un esquema y, si IncludeAllTables es falso, una tabla permitida.");
        }

        var connectionString = SqlServerConnectionStringFactory.Build(
            _connectionOptions,
            _options.DatabaseName);
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        var objects = await ReadObjectsAsync(connection, cancellationToken);
        await ReadForeignKeysAsync(connection, objects, cancellationToken);

        return new DatabaseSchemaSnapshot(
            DateTimeOffset.UtcNow,
            objects.Values
                .OrderBy(item => item.Schema, StringComparer.OrdinalIgnoreCase)
                .ThenBy(item => item.Name, StringComparer.OrdinalIgnoreCase)
                .Select(item => item.ToMetadata())
                .ToArray());
    }

    private async Task<Dictionary<(string Schema, string Name), MutableDatabaseObject>>
        ReadObjectsAsync(SqlConnection connection, CancellationToken cancellationToken)
    {
        var commandText = $"""
            SELECT s.name AS schema_name,
                   o.name AS object_name,
                   o.type AS object_type,
                   c.name AS column_name,
                   c.column_id,
                   ty.name AS sql_type,
                   c.max_length,
                   c.precision,
                   c.scale,
                   c.is_nullable,
                   c.is_identity,
                   c.is_computed,
                   pkc.key_ordinal
            FROM sys.objects AS o
            INNER JOIN sys.schemas AS s ON s.schema_id = o.schema_id
            INNER JOIN sys.columns AS c ON c.object_id = o.object_id
            INNER JOIN sys.types AS ty ON ty.user_type_id = c.user_type_id
            LEFT JOIN sys.indexes AS pki
                ON pki.object_id = o.object_id AND pki.is_primary_key = 1
            LEFT JOIN sys.index_columns AS pkc
                ON pkc.object_id = pki.object_id
               AND pkc.index_id = pki.index_id
               AND pkc.column_id = c.column_id
            WHERE o.is_ms_shipped = 0
              AND o.type IN ({(_options.IncludeViews ? "'U', 'V'" : "'U'")})
              AND {BuildObjectFilters("s", "o")}
            ORDER BY s.name, o.name, c.column_id;
            """;

        await using var command = new SqlCommand(commandText, connection);
        AddListParameters(command, "schema", _options.IncludedSchemas);
        if (!_options.IncludeAllTables)
        {
            AddListParameters(command, "table", _options.IncludedTables);
        }

        var result = new Dictionary<(string Schema, string Name), MutableDatabaseObject>(
            SchemaObjectKeyComparer.Instance);

        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var schema = reader.GetString(0);
            var name = reader.GetString(1);
            var key = (schema, name);
            if (!result.TryGetValue(key, out var databaseObject))
            {
                databaseObject = new MutableDatabaseObject(
                    schema,
                    name,
                    reader.GetString(2) == "V"
                        ? DatabaseObjectType.View
                        : DatabaseObjectType.Table);
                result.Add(key, databaseObject);
            }

            databaseObject.Columns.Add(new DatabaseColumnMetadata(
                reader.GetString(3),
                reader.GetInt32(4),
                reader.GetString(5),
                reader.GetInt16(6),
                reader.GetByte(7),
                reader.GetByte(8),
                reader.GetBoolean(9),
                reader.GetBoolean(10),
                reader.GetBoolean(11),
                reader.IsDBNull(12) ? null : Convert.ToInt32(reader.GetValue(12))));
        }

        return result;
    }

    private async Task ReadForeignKeysAsync(
        SqlConnection connection,
        Dictionary<(string Schema, string Name), MutableDatabaseObject> objects,
        CancellationToken cancellationToken)
    {
        var commandText = $"""
            SELECT fk.name AS foreign_key_name,
                   ps.name AS parent_schema,
                   pt.name AS parent_table,
                   pc.name AS parent_column,
                   rs.name AS referenced_schema,
                   rt.name AS referenced_table,
                   rc.name AS referenced_column,
                   fkc.constraint_column_id
            FROM sys.foreign_keys AS fk
            INNER JOIN sys.foreign_key_columns AS fkc
                ON fkc.constraint_object_id = fk.object_id
            INNER JOIN sys.tables AS pt ON pt.object_id = fk.parent_object_id
            INNER JOIN sys.schemas AS ps ON ps.schema_id = pt.schema_id
            INNER JOIN sys.columns AS pc
                ON pc.object_id = pt.object_id AND pc.column_id = fkc.parent_column_id
            INNER JOIN sys.tables AS rt ON rt.object_id = fk.referenced_object_id
            INNER JOIN sys.schemas AS rs ON rs.schema_id = rt.schema_id
            INNER JOIN sys.columns AS rc
                ON rc.object_id = rt.object_id AND rc.column_id = fkc.referenced_column_id
            WHERE {BuildObjectFilters("ps", "pt")}
            ORDER BY ps.name, pt.name, fk.name, fkc.constraint_column_id;
            """;

        await using var command = new SqlCommand(commandText, connection);
        AddListParameters(command, "schema", _options.IncludedSchemas);
        if (!_options.IncludeAllTables)
        {
            AddListParameters(command, "table", _options.IncludedTables);
        }

        var foreignKeys = new Dictionary<ForeignKeyKey, List<DatabaseForeignKeyColumnPair>>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var parentSchema = reader.GetString(1);
            var parentTable = reader.GetString(2);
            if (!objects.TryGetValue((parentSchema, parentTable), out var parentObject))
            {
                continue;
            }

            var key = new ForeignKeyKey(
                parentSchema,
                parentTable,
                reader.GetString(0),
                reader.GetString(4),
                reader.GetString(5));
            if (!foreignKeys.TryGetValue(key, out var columns))
            {
                columns = [];
                foreignKeys.Add(key, columns);
            }

            columns.Add(new DatabaseForeignKeyColumnPair(
                reader.GetString(3),
                reader.GetString(6),
                reader.GetInt32(7)));
        }

        foreach (var (key, columns) in foreignKeys)
        {
            if (objects.TryGetValue((key.ParentSchema, key.ParentTable), out var parentObject))
            {
                parentObject.ForeignKeys.Add(new DatabaseForeignKeyMetadata(
                    key.Name,
                    key.ReferencedSchema,
                    key.ReferencedTable,
                    columns.OrderBy(column => column.Ordinal).ToArray()));
            }
        }
    }

    private static string ParameterNames(string prefix, int count) =>
        string.Join(", ", Enumerable.Range(0, count)
            .Select(index => $"@{prefix}{index}"));

    private string ParameterNames(string prefix) =>
        ParameterNames(prefix, prefix == "schema"
            ? _options.IncludedSchemas.Length
            : _options.IncludedTables.Length);

    private string BuildObjectFilters(string schemaAlias, string objectAlias)
    {
        var schemaFilter = string.Format(
            SchemaFilter,
            schemaAlias,
            ParameterNames("schema", _options.IncludedSchemas.Length));

        return _options.IncludeAllTables
            ? schemaFilter
            : $"{schemaFilter} AND {string.Format(
                TableFilter,
                objectAlias,
                ParameterNames("table", _options.IncludedTables.Length))}";
    }

    private static void AddListParameters(SqlCommand command, string prefix, string[] values)
    {
        for (var index = 0; index < values.Length; index++)
        {
            command.Parameters.Add($"@{prefix}{index}", SqlDbType.NVarChar, 128).Value = values[index];
        }
    }

    private sealed class MutableDatabaseObject(
        string schema,
        string name,
        DatabaseObjectType type)
    {
        public string Schema { get; } = schema;
        public string Name { get; } = name;
        public DatabaseObjectType Type { get; } = type;
        public List<DatabaseColumnMetadata> Columns { get; } = [];
        public List<DatabaseForeignKeyMetadata> ForeignKeys { get; } = [];

        public DatabaseObjectMetadata ToMetadata() => new(
            Schema,
            Name,
            Type,
            Columns.ToArray(),
            ForeignKeys.ToArray());
    }

    private sealed record ForeignKeyKey(
        string ParentSchema,
        string ParentTable,
        string Name,
        string ReferencedSchema,
        string ReferencedTable);

    private sealed class SchemaObjectKeyComparer : IEqualityComparer<(string Schema, string Name)>
    {
        public static SchemaObjectKeyComparer Instance { get; } = new();

        public bool Equals((string Schema, string Name) x, (string Schema, string Name) y) =>
            StringComparer.OrdinalIgnoreCase.Equals(x.Schema, y.Schema)
            && StringComparer.OrdinalIgnoreCase.Equals(x.Name, y.Name);

        public int GetHashCode((string Schema, string Name) value) =>
            HashCode.Combine(
                StringComparer.OrdinalIgnoreCase.GetHashCode(value.Schema),
                StringComparer.OrdinalIgnoreCase.GetHashCode(value.Name));
    }
}