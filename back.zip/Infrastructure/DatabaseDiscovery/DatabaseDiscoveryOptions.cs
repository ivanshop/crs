namespace Infrastructure.DatabaseDiscovery;

public sealed class DatabaseDiscoveryOptions
{
    public const string SectionName = "DatabaseDiscovery";

    public bool Enabled { get; set; }

    public int RefreshIntervalMinutes { get; set; } = 60;

    public bool IncludeViews { get; set; }

    public bool IncludeAllTables { get; set; }

    public string DatabaseName { get; set; } = string.Empty;

    public string[] IncludedSchemas { get; set; } = ["dbo"];

    public string[] IncludedTables { get; set; } = [];
}
