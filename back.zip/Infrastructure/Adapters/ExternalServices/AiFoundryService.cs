﻿#pragma warning disable OPENAI001

using Application.Ports;
using Microsoft.Extensions.Configuration;
using OpenAI;
using OpenAI.Responses;
using System;
using System.ClientModel;
using System.Threading.Tasks;

namespace Infrastructure.Adapters.ExternalServices
{
    public class AiFoundryService : IAiFoundryService
    {
        private readonly ResponsesClient _client;
        private readonly string _model;

        public AiFoundryService(IConfiguration configuration)
        {
            var endpoint = configuration["Foundry:Endpoint"];
            var apiKey = configuration["Foundry:ApiKey"];
            _model = configuration["Foundry:Model"]
                ?? throw new InvalidOperationException("Configure Foundry:Model.");

            if (string.IsNullOrWhiteSpace(endpoint))
            {
                throw new InvalidOperationException("Configure Foundry:Endpoint.");
            }

            if (string.IsNullOrWhiteSpace(apiKey))
            {
                throw new InvalidOperationException("Configure Foundry:ApiKey.");
            }

            var openAiClient = new OpenAIClient(
                credential: new ApiKeyCredential(apiKey),
                options: new OpenAIClientOptions
                {
                    Endpoint = new Uri(endpoint)
                });

            _client = openAiClient.GetResponsesClient();
        }

        public async Task<string> AskAsync(string question, CancellationToken cancellationToken = default)
        {
            var options = new CreateResponseOptions
            {
                Model = _model
            };

            options.InputItems.Add(
                ResponseItem.CreateUserMessageItem(question));

            var response = await _client.CreateResponseAsync(options, cancellationToken);

            return response.Value.GetOutputText();
        }
    }
}

#pragma warning restore OPENAI001