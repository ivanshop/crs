using Application.Ports;
using Application.UseCase;
using Infrastructure.DatabaseDiscovery;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Options;

namespace Infrastructure.Adapters.Repository;

public sealed class QueryRepository : IQueryRepository
{
    private const int CommandTimeoutSeconds = 30;
    private const int MaxRows = 1000;

    // Clases 11-16: errores que el autor de la consulta puede corregir (sintaxis, objeto o columna inexistente, tipos...).
    private const int MinimumCorrectableClass = 11;
    private const int MaximumCorrectableClass = 16;

    private readonly SqlServerConnectionOptions _connectionOptions;
    private readonly DatabaseDiscoveryOptions _discoveryOptions;

    public QueryRepository(
        IOptions<SqlServerConnectionOptions> connectionOptions,
        IOptions<DatabaseDiscoveryOptions> discoveryOptions)
    {
        _connectionOptions = connectionOptions.Value;
        _discoveryOptions = discoveryOptions.Value;
    }

    public async Task<QueryResult> ExecuteAsync(string sql, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sql);

        var connectionString = SqlServerConnectionStringFactory.Build(_connectionOptions, _discoveryOptions.DatabaseName);
        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection)
        {
            CommandTimeout = CommandTimeoutSeconds
        };

        try
        {
            await using var reader = await command.ExecuteReaderAsync(cancellationToken);
            var columns = Enumerable.Range(0, reader.FieldCount)
                .Select(reader.GetName)
                .ToArray();
            var rows = new List<IReadOnlyList<object?>>();
            var truncated = false;

            while (await reader.ReadAsync(cancellationToken))
            {
                if (rows.Count == MaxRows)
                {
                    truncated = true;
                    command.Cancel();
                    break;
                }
                var row = new object?[reader.FieldCount];
                for (var index = 0; index < reader.FieldCount; index++)
                {
                    row[index] = await reader.IsDBNullAsync(index, cancellationToken) ? null : reader.GetValue(index);
                }
                rows.Add(row);
            }

            return new QueryResult(columns, rows, truncated);
        }
        catch (SqlException exception)
            when (exception.Class is >= MinimumCorrectableClass and <= MaximumCorrectableClass)
        {
            throw new QueryExecutionException(exception.Message, exception);
        }
    }
}
