using Application.Metadata;
using Application.Ports;
using System.Text;

namespace Infrastructure.PromptEngineering
{
    public class PromptBuilder : IPromptBuilder
    {
        public string Build(string question, DatabaseSchemaSnapshot schema, SqlGenerationFeedback? feedback = null)
        {
            ArgumentNullException.ThrowIfNull(schema);
            var sb = new StringBuilder();
            sb.AppendLine("""
Eres un experto en SQL Server (T-SQL) y análisis de datos.
Traduces preguntas en lenguaje natural a UNA consulta SELECT de solo lectura.
ESQUEMA DISPONIBLE (base de datos descubierta)
""");

            foreach (var table in schema.Objects.OrderBy(
item => $"{item.Schema}.{item.Name}", StringComparer.OrdinalIgnoreCase))
            {
                sb.AppendLine($"{(table.Type == DatabaseObjectType.View ? "VISTA" : "TABLA")} {table.Schema}.{table.Name}");

                foreach (var column in table.Columns.OrderBy(item => item.Ordinal))
                {
                    var typeDescription = column.SqlType switch
                    {
                        "nvarchar" or "nchar" when column.MaxLength > 0 =>
                            $"{column.SqlType}({column.MaxLength / 2})",
                        "varchar" or "char" or "varbinary" or "binary" when column.MaxLength > 0 =>
                            $"{column.SqlType}({column.MaxLength})",
                        "decimal" or "numeric" =>
                            $"{column.SqlType}({column.Precision},{column.Scale})",
                        _ => column.SqlType
                    };

                    var flags = string.Concat(
                        column.PrimaryKeyOrdinal is not null ? ", PK" : string.Empty,
                        column.IsNullable ? ", nullable" : string.Empty);
                    sb.AppendLine($"- {column.Name} ({typeDescription}{flags})");
                }

                foreach (var foreignKey in table.ForeignKeys)
                {
                    foreach (var pair in foreignKey.Columns.OrderBy(item => item.Ordinal))
                    {
                        sb.AppendLine(
                            $"RELACIÓN (FK) {table.Schema}.{table.Name}.{pair.Column} -> " +
                            $"{foreignKey.ReferencedSchema}.{foreignKey.ReferencedObject}.{pair.ReferencedColumn}");
                    }
                }

                sb.AppendLine();
            }

            var implicitRelations = ImplicitRelationInferer.Infer(schema);
            if (implicitRelations.Count > 0)
            {
                sb.AppendLine("RELACIONES IMPLÍCITAS (sin FK declarada; inferidas por el nombre y tipo de las columnas)");
                foreach (var relation in implicitRelations)
                {
                    sb.AppendLine(
                        $"- {relation.Child.Schema}.{relation.Child.Name}.{relation.ChildColumn.Name} -> " +
                        $"{relation.Parent.Schema}.{relation.Parent.Name}.{relation.ParentColumn.Name} " +
                        $"(confianza {(relation.Confidence == ImplicitRelationConfidence.High ? "alta" : "media")})");
                }

                sb.AppendLine();
            }

            sb.AppendLine("""
REGLAS
- Responde SOLO con la sentencia SQL, sin explicaciones ni markdown.
- Genera exactamente una sentencia SELECT en T-SQL. Se permiten CTEs (WITH), funciones de ventana, subconsultas, APPLY, UNION y agregaciones cuando hagan la consulta más clara o eficiente.
- Prohibido: INSERT, UPDATE, DELETE, MERGE, DDL, EXEC, SELECT INTO, variables, tablas temporales y funciones definidas por el usuario.
- Usa únicamente las tablas y columnas listadas, siempre con nombre calificado schema.tabla y alias. No consultes sys.*, INFORMATION_SCHEMA ni otras bases de datos.
- Une tablas por las RELACIONES (FK) declaradas siempre que existan.
- Si dos tablas necesarias no tienen FK, puedes unirlas mediante una RELACIÓN IMPLÍCITA de la lista. Si ninguna aplica, puedes inferir una unión solo si las columnas tienen casi el mismo nombre (p. ej. ProductID y ProductId, o CustomerID y Customer_ID), el mismo tipo y el significado es evidente; no inventes uniones por nombres genéricos como Name, Date o Status.
- Al usar una relación implícita de confianza media, o una inferida por ti, usa INNER JOIN solo si la pregunta lo exige; en caso de duda prefiere LEFT JOIN para no perder filas.
- Para listados limita el resultado con TOP o OFFSET/FETCH (máximo 500 filas), con ORDER BY determinista. Los resúmenes agregados no necesitan límite.
- Evita SELECT *; devuelve nombres de columna claros con alias legibles.
- Si la pregunta no se puede responder con el esquema, devuelve igualmente la consulta más cercana posible usando solo objetos listados.
""");

            if (feedback is not null)
            {
                sb.AppendLine();
                sb.AppendLine("INTENTO ANTERIOR RECHAZADO");
                sb.AppendLine(feedback.Sql);
                sb.AppendLine($"Error: {feedback.Error}");
                sb.AppendLine("Corrige la consulta y responde únicamente con el SQL corregido.");
            }

            sb.AppendLine();
            sb.AppendLine("Pregunta:");
            sb.AppendLine(question);

            return sb.ToString();
        }
    }
}
