using Application.Metadata;
using Application.Ports;

namespace Application.UseCase;

public sealed class DiscoverDatabaseSchemaUseCase
{
    private readonly IDatabaseSchemaReader _reader;
    private readonly IDatabaseSchemaCatalog _catalog;

    public DiscoverDatabaseSchemaUseCase(
        IDatabaseSchemaReader reader,
        IDatabaseSchemaCatalog catalog)
    {
        _reader = reader;
        _catalog = catalog;
    }

    public async Task<DatabaseSchemaSnapshot> ExecuteAsync(
        CancellationToken cancellationToken = default)
    {
        var snapshot = await _reader.DiscoverAsync(cancellationToken);
        _catalog.Replace(snapshot);
        return snapshot;
    }
}