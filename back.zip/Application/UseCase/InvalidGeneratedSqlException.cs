namespace Application.UseCase;

public sealed class InvalidGeneratedSqlException(string message) : InvalidOperationException(message);
