namespace Application.UseCase;

public sealed class DatabaseSchemaUnavailableException : InvalidOperationException
{
    public DatabaseSchemaUnavailableException()
        : base("El esquema descubierto no está disponible. Verifique database discovery.")
    {
    }
}