using Application.Ports;
using System.Text.RegularExpressions;

namespace Application.UseCase;

public sealed record GeneratedQuery(string Sql, QueryResult? Result);

public sealed partial class QueryUseCase
{
    private const int MaxAttempts = 2;

    private readonly IAiFoundryService _aiFoundryService;
    private readonly IPromptBuilder _promptBuilder;
    private readonly IDatabaseSchemaCatalog _schemaCatalog;
    private readonly IGeneratedSqlValidator _sqlValidator;
    private readonly IQueryRepository _queryRepository;

    public QueryUseCase(
        IPromptBuilder promptBuilder,
        IAiFoundryService aiFoundryService,
        IDatabaseSchemaCatalog schemaCatalog,
        IGeneratedSqlValidator sqlValidator,
        IQueryRepository queryRepository)
    {
        _promptBuilder = promptBuilder;
        _aiFoundryService = aiFoundryService;
        _schemaCatalog = schemaCatalog;
        _sqlValidator = sqlValidator;
        _queryRepository = queryRepository;
    }

    public async Task<string> Execute(string question, CancellationToken cancellationToken = default) =>
        (await RunAsync(question, execute: false, cancellationToken)).Sql;

    public Task<GeneratedQuery> ExecuteResultsAsync(string question, CancellationToken cancellationToken = default) =>
        RunAsync(question, execute: true, cancellationToken);

    private async Task<GeneratedQuery> RunAsync(string question, bool execute, CancellationToken cancellationToken)
    {
        var schema = _schemaCatalog.Current ?? throw new DatabaseSchemaUnavailableException();

        SqlGenerationFeedback? feedback = null;
        for (var attempt = 1; ; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var prompt = _promptBuilder.Build(question, schema, feedback);
            var response = await _aiFoundryService.AskAsync(prompt, cancellationToken);
            var generated = ExtractSql(response);

            try
            {
                var sql = _sqlValidator.Validate(generated, schema);
                if (!execute)
                {
                    return new GeneratedQuery(sql, null);
                }

                cancellationToken.ThrowIfCancellationRequested();
                var result = await _queryRepository.ExecuteAsync(sql, cancellationToken);
                return new GeneratedQuery(sql, result);
            }
            catch (Exception exception) when (attempt < MaxAttempts && exception is InvalidGeneratedSqlException or QueryExecutionException)
            {
                feedback = new SqlGenerationFeedback(generated, exception.Message);
            }
        }
    }

    private static string ExtractSql(string response)
    {
        var match = SqlFence().Match(response);
        return (match.Success ? match.Groups[1].Value : response).Trim();
    }

    [GeneratedRegex(@"```(?:sql|tsql)?\s*(.*?)```", RegexOptions.Singleline | RegexOptions.IgnoreCase)]
    private static partial Regex SqlFence();
}
