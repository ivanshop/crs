using Application.Metadata;
using Application.Ports;

namespace Application.UseCase;

public sealed class GetDatabaseSchemaUseCase
{
    private readonly IDatabaseSchemaCatalog _catalog;

    public GetDatabaseSchemaUseCase(IDatabaseSchemaCatalog catalog)
    {
        _catalog = catalog;
    }

    public DatabaseSchemaSnapshot? Execute() => _catalog.Current;
}