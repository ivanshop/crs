using Application.Charts;
using Application.Dto;
using Application.Ports;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Application.UseCase;

public sealed partial class SuggestChartUseCase
{
    private const int MinimumRowsToChart = 10;
    private const int MaxSampleRows = 10;

    private static readonly string[] ChartTypes = ["bar", "line", "pie", "doughnut", "scatter", "radar"];
    private static readonly string[] Aggregations = ["none", "sum", "avg", "count", "min", "max"];
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly IAiFoundryService _aiFoundryService;

    public SuggestChartUseCase(IAiFoundryService aiFoundryService)
    {
        _aiFoundryService = aiFoundryService;
    }

    public async Task<ChartSuggestion> ExecuteAsync(ChartSuggestionRequestDto request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        if (request.Columns.Count == 0)
        {
            throw new ArgumentException("Debe indicar al menos una columna.");
        }

        if (request.Total <= MinimumRowsToChart)
        {
            return ChartSuggestion.NotChartable($"Se requieren más de {MinimumRowsToChart} registros para sugerir una gráfica.");
        }

        var response = await _aiFoundryService.AskAsync(BuildPrompt(request), cancellationToken);
        return Validate(Parse(response), request);
    }

    private static string BuildPrompt(ChartSuggestionRequestDto request)
    {
        var sb = new StringBuilder();
        sb.AppendLine("""
Eres un experto en visualización de datos con Chart.js.
Recibes el resultado de una consulta (columnas, una muestra de filas, el total de filas y un perfil por columna) y decides si se puede graficar y cómo.

REGLAS
- chartType solo puede ser: bar, line, pie, doughnut, scatter, radar.
- line: el eje X es fecha o tiempo (puede combinar columnas, p. ej. year y month).
- bar: X categórica con pocos valores distintos (menos de 30) y Y numérica.
- pie/doughnut: una categórica con 7 valores distintos o menos y una métrica.
- scatter: dos columnas numéricas.
- No es graficable (chartable=false): identificadores, texto libre, columnas con demasiados valores distintos o sin métrica numérica ni conteo posible.
- Una columna numérica con pocos valores distintos (year, month, día) suele ser un eje de tiempo o categoría, no una métrica.
- Usa SOLO nombres de columna exactos de la lista de columnas.
- aggregation: none, sum, avg, count, min o max. Usa count si no hay métrica numérica.
- groupBy es opcional (una columna categórica para generar varias series); si no aplica, null.

Responde ÚNICAMENTE con un JSON válido, sin texto adicional, con esta forma:
{"chartable":true,"chartType":"line","x":["year","month"],"y":["sales"],"groupBy":null,"aggregation":"none","reason":"explicación breve"}
Si no es graficable: {"chartable":false,"chartType":null,"x":[],"y":[],"groupBy":null,"aggregation":null,"reason":"motivo"}

DATOS
""");
        sb.AppendLine($"total: {request.Total}");
        sb.AppendLine($"columns: {JsonSerializer.Serialize(request.Columns, JsonOptions)}");
        sb.AppendLine($"rows (muestra): {JsonSerializer.Serialize(request.Rows.Take(MaxSampleRows), JsonOptions)}");
        if (request.Profile is { Count: > 0 })
        {
            sb.AppendLine($"profile: {JsonSerializer.Serialize(request.Profile, JsonOptions)}");
        }

        return sb.ToString();
    }

    private static ChartSuggestion? Parse(string response)
    {
        var match = JsonObject().Match(response);
        if (!match.Success)
        {
            return null;
        }

        try
        {
            return JsonSerializer.Deserialize<ChartSuggestion>(match.Value, JsonOptions);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static ChartSuggestion Validate(ChartSuggestion? suggestion, ChartSuggestionRequestDto request)
    {
        if (suggestion is null)
        {
            return ChartSuggestion.NotChartable("No se pudo interpretar la sugerencia del modelo.");
        }

        if (!suggestion.Chartable)
        {
            return ChartSuggestion.NotChartable(suggestion.Reason ?? "Los datos no son adecuados para graficar.");
        }

        var x = suggestion.X ?? [];
        var y = suggestion.Y ?? [];
        var aggregation = suggestion.Aggregation ?? "none";
        var columns = request.Columns.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var types = request.Profile?.ToDictionary(item => item.Name, item => item.Type, StringComparer.OrdinalIgnoreCase);

        var valid =
            suggestion.ChartType is not null && ChartTypes.Contains(suggestion.ChartType)
            && Aggregations.Contains(aggregation)
            && x.Count > 0
            && x.Concat(y).All(columns.Contains)
            && (suggestion.GroupBy is null || columns.Contains(suggestion.GroupBy))
            && (aggregation == "count" || y.Count > 0)
            && (aggregation == "count" || types is null
                || y.All(name => types.TryGetValue(name, out var type) && type == "number"));

        return valid
            ? suggestion with { X = x, Y = y, Aggregation = aggregation }
            : ChartSuggestion.NotChartable("La sugerencia del modelo no es consistente con las columnas recibidas.");
    }

    [GeneratedRegex(@"\{.*\}", RegexOptions.Singleline)]
    private static partial Regex JsonObject();
}
