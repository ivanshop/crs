namespace Application.UseCase;

public sealed class QueryExecutionException(string message, Exception innerException)
    : InvalidOperationException(message, innerException);
