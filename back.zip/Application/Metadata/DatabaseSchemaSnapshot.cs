namespace Application.Metadata;

public sealed record DatabaseSchemaSnapshot(
    DateTimeOffset DiscoveredAtUtc,
    IReadOnlyList<DatabaseObjectMetadata> Objects);

public sealed record DatabaseObjectMetadata(
    string Schema,
    string Name,
    DatabaseObjectType Type,
    IReadOnlyList<DatabaseColumnMetadata> Columns,
    IReadOnlyList<DatabaseForeignKeyMetadata> ForeignKeys);

public enum DatabaseObjectType
{
    Table,
    View
}

public sealed record DatabaseColumnMetadata(
    string Name,
    int Ordinal,
    string SqlType,
    short MaxLength,
    byte Precision,
    byte Scale,
    bool IsNullable,
    bool IsIdentity,
    bool IsComputed,
    int? PrimaryKeyOrdinal);

public sealed record DatabaseForeignKeyMetadata(
    string Name,
    string ReferencedSchema,
    string ReferencedObject,
    IReadOnlyList<DatabaseForeignKeyColumnPair> Columns);

public sealed record DatabaseForeignKeyColumnPair(
    string Column,
    string ReferencedColumn,
    int Ordinal);