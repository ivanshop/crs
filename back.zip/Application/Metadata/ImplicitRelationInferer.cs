namespace Application.Metadata;

public enum ImplicitRelationConfidence
{
    /// <summary>El nombre de la columna coincide con el de la clave primaria de la otra tabla.</summary>
    High,

    /// <summary>El nombre de la columna termina con el de la clave primaria (p. ej. ShipToAddressID → AddressID).</summary>
    Medium
}

public sealed record ImplicitRelation(
    DatabaseObjectMetadata Child,
    DatabaseColumnMetadata ChildColumn,
    DatabaseObjectMetadata Parent,
    DatabaseColumnMetadata ParentColumn,
    ImplicitRelationConfidence Confidence);

/// <summary>
/// Infiere relaciones no declaradas como clave foránea comparando nombres y tipos
/// de columnas con las claves primarias de una sola columna.
/// </summary>
public static class ImplicitRelationInferer
{
    private const int MinimumSuffixKeyLength = 4;
    private static readonly string[] GenericKeyNames = ["id", "key", "code", "codigo"];

    public static IReadOnlyList<ImplicitRelation> Infer(DatabaseSchemaSnapshot schema)
    {
        ArgumentNullException.ThrowIfNull(schema);

        var declared = DeclaredColumnPairs(schema);
        var parents = schema.Objects
            .Select(item => (Object: item, Key: SinglePrimaryKey(item)))
            .Where(item => item.Key is not null)
            .ToArray();

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var relations = new List<ImplicitRelation>();

        foreach (var child in schema.Objects)
        {
            foreach (var column in child.Columns)
            {
                foreach (var (parent, key) in parents)
                {
                    if (ReferenceEquals(child, parent)
                        || !string.Equals(column.SqlType, key!.SqlType, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    var confidence = Match(column.Name, parent, key);
                    if (confidence is null
                        || declared.Contains(PairKey(child, column.Name, parent, key.Name)))
                    {
                        continue;
                    }

                    // Claves primarias compartidas (1:1) aparecerían en ambos sentidos.
                    var pair = string.CompareOrdinal(Qualified(child, column.Name), Qualified(parent, key.Name)) <= 0
                        ? $"{Qualified(child, column.Name)}|{Qualified(parent, key.Name)}"
                        : $"{Qualified(parent, key.Name)}|{Qualified(child, column.Name)}";
                    if (seen.Add(pair))
                    {
                        relations.Add(new ImplicitRelation(child, column, parent, key, confidence.Value));
                    }
                }
            }
        }

        return relations
            .OrderBy(item => item.Child.Schema, StringComparer.OrdinalIgnoreCase)
            .ThenBy(item => item.Child.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(item => item.ChildColumn.Ordinal)
            .ToArray();
    }

    private static ImplicitRelationConfidence? Match(
        string columnName,
        DatabaseObjectMetadata parent,
        DatabaseColumnMetadata key)
    {
        var column = Normalize(columnName);
        var keyName = Normalize(key.Name);

        if (GenericKeyNames.Contains(keyName))
        {
            // Clave "Id": la columna debe llevar el nombre de la tabla (Customers.Id ← CustomerId).
            var table = Normalize(parent.Name);
            return column == table + keyName || column == table.TrimEnd('s') + keyName
                ? ImplicitRelationConfidence.High
                : null;
        }

        if (column == keyName)
        {
            return ImplicitRelationConfidence.High;
        }

        return keyName.Length >= MinimumSuffixKeyLength
            && column.Length > keyName.Length
            && column.EndsWith(keyName, StringComparison.Ordinal)
                ? ImplicitRelationConfidence.Medium
                : null;
    }

    private static DatabaseColumnMetadata? SinglePrimaryKey(DatabaseObjectMetadata databaseObject)
    {
        var keys = databaseObject.Columns.Where(item => item.PrimaryKeyOrdinal is not null).ToArray();
        return keys.Length == 1 ? keys[0] : null;
    }

    private static HashSet<string> DeclaredColumnPairs(DatabaseSchemaSnapshot schema)
    {
        var objects = schema.Objects.ToDictionary(
            item => Qualified(item, null),
            item => item,
            StringComparer.OrdinalIgnoreCase);
        var pairs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var databaseObject in schema.Objects)
        {
            foreach (var foreignKey in databaseObject.ForeignKeys)
            {
                if (!objects.TryGetValue($"{foreignKey.ReferencedSchema}.{foreignKey.ReferencedObject}", out var referenced))
                {
                    continue;
                }

                foreach (var columns in foreignKey.Columns)
                {
                    pairs.Add(PairKey(databaseObject, columns.Column, referenced, columns.ReferencedColumn));
                    pairs.Add(PairKey(referenced, columns.ReferencedColumn, databaseObject, columns.Column));
                }
            }
        }

        return pairs;
    }

    private static string PairKey(
        DatabaseObjectMetadata child,
        string childColumn,
        DatabaseObjectMetadata parent,
        string parentColumn) =>
        $"{Qualified(child, childColumn)}->{Qualified(parent, parentColumn)}";

    private static string Qualified(DatabaseObjectMetadata item, string? column) =>
        column is null ? $"{item.Schema}.{item.Name}" : $"{item.Schema}.{item.Name}.{column}";

    private static string Normalize(string name) => name.Replace("_", string.Empty).ToLowerInvariant();
}
