namespace Application.Charts;

public sealed record ChartSuggestion(
    bool Chartable,
    string? ChartType,
    IReadOnlyList<string> X,
    IReadOnlyList<string> Y,
    string? GroupBy,
    string? Aggregation,
    string? Reason)
{
    public static ChartSuggestion NotChartable(string reason) =>
        new(false, null, [], [], null, null, reason);
}
