namespace Application.Charts;

public sealed record ColumnProfile(string Name, string Type, int Distinct, object? Min, object? Max);
