using Application.Ports;

namespace Application.Charts;

public static class ColumnProfiler
{
    public static IReadOnlyList<ColumnProfile> Build(QueryResult result)
    {
        ArgumentNullException.ThrowIfNull(result);

        var profile = new List<ColumnProfile>(result.Columns.Count);
        for (var index = 0; index < result.Columns.Count; index++)
        {
            var values = new List<object>(result.Rows.Count);
            foreach (var row in result.Rows)
            {
                if (row[index] is { } value)
                {
                    values.Add(value);
                }
            }

            var type = InferType(values);
            var distinct = values.Distinct().Count();
            object? min = null, max = null;
            if (type is "number" or "date")
            {
                min = values.Min();
                max = values.Max();
            }

            profile.Add(new ColumnProfile(result.Columns[index], type, distinct, min, max));
        }

        return profile;
    }

    private static string InferType(List<object> values)
    {
        if (values.Count == 0) return "empty";
        if (values.All(value => value is byte or short or int or long or float or double or decimal)) return "number";
        if (values.All(value => value is DateTime or DateTimeOffset or DateOnly)) return "date";
        if (values.All(value => value is bool)) return "boolean";
        return "string";
    }
}
