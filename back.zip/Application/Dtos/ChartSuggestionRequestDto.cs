using System.Text.Json;
using Application.Charts;

namespace Application.Dto;

public class ChartSuggestionRequestDto
{
    public required List<string> Columns { get; set; }

    public required List<List<JsonElement>> Rows { get; set; }

    public required int Total { get; set; }

    public List<ColumnProfile>? Profile { get; set; }
}
