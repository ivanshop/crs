namespace Application.Dto;

public class QuestionRequestDto
{
    public required string Question { get; set; }
}
