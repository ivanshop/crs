using Application.Metadata;

namespace Application.Ports;

public sealed record SqlGenerationFeedback(string Sql, string Error);

public interface IPromptBuilder
{
    string Build(string question, DatabaseSchemaSnapshot schema, SqlGenerationFeedback? feedback = null);
}
