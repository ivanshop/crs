using Application.Metadata;

namespace Application.Ports;

public interface IGeneratedSqlValidator
{
    /// <summary>
    /// Valida que <paramref name="sql"/> sea una única sentencia SELECT de solo lectura
    /// sobre objetos del esquema descubierto y devuelve el SQL normalizado.
    /// </summary>
    /// <exception cref="Application.UseCase.InvalidGeneratedSqlException">El SQL no es válido o no está permitido.</exception>
    string Validate(string sql, DatabaseSchemaSnapshot schema);
}
