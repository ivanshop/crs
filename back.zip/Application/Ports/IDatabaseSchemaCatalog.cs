using Application.Metadata;

namespace Application.Ports;

public interface IDatabaseSchemaCatalog
{
    DatabaseSchemaSnapshot? Current { get; }

    void Replace(DatabaseSchemaSnapshot snapshot);
}