namespace Application.Ports;

public interface IQueryRepository
{
    Task<QueryResult> ExecuteAsync(string sql, CancellationToken cancellationToken = default);
}
