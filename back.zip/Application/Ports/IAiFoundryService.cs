﻿
namespace Application.Ports
{
    public interface IAiFoundryService
    {
        Task<string> AskAsync(string question, CancellationToken cancellationToken = default);
    }
}
