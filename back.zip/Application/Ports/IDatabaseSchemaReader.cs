using Application.Metadata;

namespace Application.Ports;

public interface IDatabaseSchemaReader
{
    Task<DatabaseSchemaSnapshot> DiscoverAsync(CancellationToken cancellationToken = default);
}