using Application.Ports;
using Application.UseCase;
using Infrastructure.Adapters.ExternalServices;
using Infrastructure.Adapters.Repository;
using Infrastructure.DatabaseDiscovery;
using Infrastructure.PromptEngineering;
using Infrastructure.SqlValidation;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddOpenApi();

// Inyecci�n de dependencias
builder.Services.AddSingleton<IGeneratedSqlValidator, TSqlGeneratedSqlValidator>();
builder.Services.AddScoped<IQueryRepository, QueryRepository>();
builder.Services.AddScoped<IPromptBuilder, PromptBuilder>();
builder.Services.AddScoped<QueryUseCase>();
builder.Services.AddScoped<SuggestChartUseCase>();
builder.Services.AddScoped<IAiFoundryService, AiFoundryService>();

builder.Services.AddOptions<SqlServerConnectionOptions>()
    .Bind(builder.Configuration.GetSection(SqlServerConnectionOptions.SectionName))
    .Validate(options => !builder.Configuration.GetValue<bool>($"{DatabaseDiscoveryOptions.SectionName}:Enabled")
        || (!string.IsNullOrWhiteSpace(options.Host)
            && !string.IsNullOrWhiteSpace(options.User)
            && !string.IsNullOrWhiteSpace(options.Password)),
        "Configure SqlServer:Host, SqlServer:User y SqlServer:Password para habilitar database discovery.")
    .Validate(options => !builder.Configuration.GetValue<bool>($"{DatabaseDiscoveryOptions.SectionName}:Enabled")
        || options.ConnectTimeoutSeconds > 0,
        "SqlServer:ConnectTimeoutSeconds debe ser mayor que cero.")
    .ValidateOnStart();

builder.Services.AddOptions<DatabaseDiscoveryOptions>()
    .Bind(builder.Configuration.GetSection(DatabaseDiscoveryOptions.SectionName))
    .Validate(options => !options.Enabled || options.RefreshIntervalMinutes > 0,
        "DatabaseDiscovery:RefreshIntervalMinutes debe ser mayor que cero.")
    .Validate(options => !options.Enabled || !string.IsNullOrWhiteSpace(options.DatabaseName),
        "Configure DatabaseDiscovery:DatabaseName.")
    .Validate(options => !options.Enabled
        || (options.IncludedSchemas is { Length: > 0 }
            && (options.IncludeAllTables || options.IncludedTables is { Length: > 0 })),
        "DatabaseDiscovery requiere esquemas y una allowlist de tablas, o IncludeAllTables habilitado.")
    .ValidateOnStart();
builder.Services.AddSingleton<IDatabaseSchemaReader, SqlServerSchemaReader>();
builder.Services.AddSingleton<IDatabaseSchemaCatalog, InMemoryDatabaseSchemaCatalog>();
builder.Services.AddSingleton<DiscoverDatabaseSchemaUseCase>();
builder.Services.AddSingleton<GetDatabaseSchemaUseCase>();
builder.Services.AddHostedService<DatabaseSchemaRefreshService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
