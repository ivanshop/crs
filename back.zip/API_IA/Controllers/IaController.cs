using Application.Charts;
using Application.Dto;
using Application.UseCase;
using Microsoft.AspNetCore.Mvc;

namespace API_IA.Controllers
{
    [ApiController]
    [Route("api/ia")]
    public class IaController : ControllerBase
    {
        private readonly QueryUseCase _useCase;
        private readonly SuggestChartUseCase _suggestChartUseCase;
        private readonly ILogger<IaController> _logger;

        public IaController(QueryUseCase useCase, SuggestChartUseCase suggestChartUseCase, ILogger<IaController> logger)
        {
            _useCase = useCase;
            _suggestChartUseCase = suggestChartUseCase;
            _logger = logger;
        }

        [HttpPost("query")]
        [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public async Task<IActionResult> Generate([FromBody] QuestionRequestDto request,  CancellationToken cancellationToken)
        {
            try
            {
                var result = await _useCase.Execute(request.Question, cancellationToken);
                return Ok(new { sql = result });
            }
            catch (DatabaseSchemaUnavailableException exception)
            {
                return Problem(
                    statusCode: StatusCodes.Status503ServiceUnavailable,
                    title: "El esquema de base de datos no está disponible.",
                    detail: exception.Message);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (InvalidGeneratedSqlException exception)
            {
                return Problem(
                    statusCode: StatusCodes.Status400BadRequest,
                    title: "No se pudo generar una consulta válida.",
                    detail: exception.Message);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Falló la generación de la consulta.");
                return Problem(
                    statusCode: StatusCodes.Status503ServiceUnavailable,
                    title: "No fue posible generar la consulta.",
                    detail: "Revise los registros del servidor para conocer la causa técnica.");
            }
        }

        [HttpPost("query/results")]
        [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public async Task<IActionResult> ExecuteQuery([FromBody] QuestionRequestDto request, CancellationToken cancellationToken)
        {
            try
            {
                var query = await _useCase.ExecuteResultsAsync(request.Question, cancellationToken);
                var result = query.Result!;
                return Ok(new
                {
                    sql = query.Sql,
                    columns = result.Columns,
                    rows = result.Rows,
                    rowCount = result.Rows.Count,
                    truncated = result.Truncated,
                    profile = ColumnProfiler.Build(result)
                });
            }
            catch (DatabaseSchemaUnavailableException exception)
            {
                return Problem(
                    statusCode: StatusCodes.Status503ServiceUnavailable,
                    title: "El esquema de base de datos no está disponible.",
                    detail: exception.Message);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (ArgumentException exception)
            {
                return Problem(
                    statusCode: StatusCodes.Status400BadRequest,
                    title: "No se pudo generar una consulta válida.",
                    detail: exception.Message);
            }
            catch (InvalidOperationException exception)
            {
                return Problem(
                    statusCode: StatusCodes.Status400BadRequest,
                    title: "La consulta solicitada no se puede resolver.",
                    detail: exception.Message);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Falló la ejecución de la consulta solicitada.");
                return Problem(
                    statusCode: StatusCodes.Status503ServiceUnavailable,
                    title: "No fue posible obtener los resultados de la base de datos.",
                    detail: "Verifique la disponibilidad del servicio de IA y de SQL Server.");
            }
        }

        [HttpPost("query/chart-suggestion")]
        [ProducesResponseType(typeof(ChartSuggestion), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
        public async Task<IActionResult> SuggestChart([FromBody] ChartSuggestionRequestDto request, CancellationToken cancellationToken)
        {
            try
            {
                return Ok(await _suggestChartUseCase.ExecuteAsync(request, cancellationToken));
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (ArgumentException exception)
            {
                return Problem(
                    statusCode: StatusCodes.Status400BadRequest,
                    title: "La solicitud de sugerencia de gráfica no es válida.",
                    detail: exception.Message);
            }
            catch (Exception exception)
            {
                _logger.LogError(exception, "Falló la sugerencia de gráfica.");
                return Problem(
                    statusCode: StatusCodes.Status503ServiceUnavailable,
                    title: "No fue posible obtener la sugerencia de gráfica.",
                    detail: "Verifique la disponibilidad del servicio de IA.");
            }
        }

    }
}
