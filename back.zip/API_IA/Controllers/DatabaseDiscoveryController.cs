using Application.Metadata;
using Application.UseCase;
using Microsoft.AspNetCore.Mvc;

namespace API_IA.Controllers;

[ApiController]
[Route("api/database-discovery")]
[Produces("application/json")]
public sealed class DatabaseDiscoveryController : ControllerBase
{
    private readonly GetDatabaseSchemaUseCase _getSchema;
    private readonly DiscoverDatabaseSchemaUseCase _discoverSchema;
    private readonly ILogger<DatabaseDiscoveryController> _logger;

    public DatabaseDiscoveryController(
        GetDatabaseSchemaUseCase getSchema,
        DiscoverDatabaseSchemaUseCase discoverSchema,
        ILogger<DatabaseDiscoveryController> logger)
    {
        _getSchema = getSchema;
        _discoverSchema = discoverSchema;
        _logger = logger;
    }

    [HttpGet("schema")]
    [ProducesResponseType(typeof(DatabaseSchemaSnapshot), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public ActionResult<DatabaseSchemaSnapshot> GetSchema()
    {
        var snapshot = _getSchema.Execute();
        if (snapshot is null)
        {
            return Problem(
                statusCode: StatusCodes.Status503ServiceUnavailable,
                title: "El esquema todavía no está disponible.",
                detail: "Database discovery no se ha completado correctamente.");
        }

        return Ok(snapshot);
    }

    [HttpPost("refresh")]
    [ProducesResponseType(typeof(DatabaseSchemaSnapshot), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status503ServiceUnavailable)]
    public async Task<ActionResult<DatabaseSchemaSnapshot>> RefreshSchema(
        CancellationToken cancellationToken)
    {
        try
        {
            var snapshot = await _discoverSchema.ExecuteAsync(cancellationToken);
            return Ok(snapshot);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception exception)
        {
            _logger.LogError(exception, "Falló el refresco manual de database discovery.");
            return Problem(
                statusCode: StatusCodes.Status503ServiceUnavailable,
                title: "No se pudo refrescar el esquema.",
                detail: "Verifique que database discovery esté habilitado y que SQL Server sea accesible.");
        }
    }
}