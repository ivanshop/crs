# Check Web API

API de la plataforma de venta digital de seguros de Crediseguro S.A. (.NET 10, PostgreSQL 18).

## Estructura

| Proyecto | Contenido |
|---|---|
| `Check.Domain` | Entidades, value objects y reglas del negocio. Sin dependencias. Incluye `Result` y `Error`. |
| `Check.Application` | Un caso de uso por acción (`ExecuteAsync`) y las interfaces que necesita. Sin CQRS, mediador ni mapeadores. |
| `Check.Infrastructure` | EF Core + Npgsql (DB-first, `Persistence/Scaffolded`) y emisión de JWT. |
| `Check.Api` | Controllers, autenticación, límites de uso, ProblemDetails y logs con ZLogger. |

El código está en inglés; los mensajes de error, éxito y log, en español.

## Puesta en marcha

1. Revisar `src/Check.Api/appsettings.Development.json` (cadena de conexión y llaves de desarrollo).
2. `dotnet run --project src/Check.Api` y probar con `src/Check.Api/Check.Api.http`.

## Base de datos (DB-first)

El modelo de EF Core se genera desde la BD en `src/Check.Infrastructure/Persistence/Check`
(`CheckDbContext` y `Entities/`). Para regenerarlo tras un cambio en la BD: `./scripts/scaffold.sh`.
Esos archivos se sobrescriben: no se editan a mano.

## Seguridad

- `POST /api/v1/auth/token`: token JWT de cliente (client credentials) con roles `web` o `internal`.
- Políticas disponibles: `Policies.WebClient` y `Policies.Internal`.
- Límite de uso por IP en la emisión de tokens (`RateLimiting:TokenPerMinute`).
- Detrás de un proxy, configurar `ForwardedHeaders:KnownProxies` para que la IP del cliente sea la real.

## Logs (ZLogger)

Todo se configura en `appsettings.json`:

- `Logging:LogLevel`: nivel por categoría (estándar de .NET).
- `Logs:Console` y `Logs:File`: activar o desactivar cada destino y elegir `Json` o `Text`.
- `Logs:File`: carpeta, prefijo, rotación (`Day`, `Hour`…) y tamaño máximo por archivo.
- `Logs:Fields`: nombres de los campos. Por defecto son los de Elastic Common Schema
  (`@timestamp`, `log.level`, `log.logger`, `message`, `error`, `service.name`), así Filebeat o Elastic Agent
  indexan cada línea sin transformarla.

Cada línea es un objeto JSON. Los parámetros de los mensajes y los del scope
(`traceId`, `clientIp`) salen como campos propios y se pueden filtrar. No se registran cuerpos de solicitudes.
