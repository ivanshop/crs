#!/usr/bin/env bash
# Regenera Persistence/Check (CheckDbContext + Entities) desde la BD.
# La cadena de conexión se lee de ConnectionStrings:Check en appsettings.Development.json.
# No edites esos archivos a mano: se sobrescriben. Extiende con clases parciales en otro archivo.
set -euo pipefail
cd "$(dirname "$0")/.."

ASPNETCORE_ENVIRONMENT=Development dotnet ef dbcontext scaffold "Name=ConnectionStrings:Check" \
  Npgsql.EntityFrameworkCore.PostgreSQL \
  --project src/Check.Infrastructure --startup-project src/Check.Api \
  --context CheckDbContext \
  --context-dir Persistence/Check --output-dir Persistence/Check/Entities \
  --context-namespace Check.Infrastructure.Persistence.Check \
  --namespace Check.Infrastructure.Persistence.Check.Entities \
  --schema core --schema offer --schema sales --schema compliance --schema feedback \
  --no-onconfiguring --force
