# Check Web API — Guía para el cliente Blazor

API de venta digital de seguros **Check**. Este documento describe todo lo que necesita el front (Blazor) para
integrarse: autenticación, formato de respuestas, el flujo de compra paso a paso, cada endpoint con su request y
response, los estados del contrato, los códigos de error y recomendaciones de implementación.

- Versión de la API: `v1` (todas las rutas empiezan con `/api/v1`).
- Formato: JSON en `camelCase`. Fechas `yyyy-MM-dd`; fechas con hora en ISO 8601 **UTC** (`2026-11-24T14:54:33Z`).
- Los mensajes (`message`, `title`, `detail`) vienen en **español** y se pueden mostrar al usuario.

---

## 1. Ambientes

| Ambiente | URL base | Notas |
|---|---|---|
| Desarrollo local | `http://localhost:5080` | SEGIP, OTP y banco son **simulados** (ver §9). Llamita (lectura del carnet) es real. |
| QA / Producción | _por definir_ | |

---

## 2. Autenticación: dos tokens

La API usa **dos tokens JWT** distintos. Ambos se envían en la cabecera `Authorization: Bearer <token>`.

| Token | Cómo se obtiene | Para qué sirve | Vigencia |
|---|---|---|---|
| **Token web** | `POST /api/v1/auth/token` con el `clientId`/`clientSecret` de la web | Catálogo, productos, planes, lectura del carnet e **iniciar** el contrato | 60 min |
| **Token del contrato** | Lo devuelve `POST /api/v1/contracts` (`accessToken`) | Todos los pasos siguientes de **ese** contrato: `/api/v1/contracts/{id}/...` | 60 min |

- El token del contrato **solo** sirve para el contrato cuyo `id` lleva dentro. Usarlo con otro id → `403`.
- El token web **no** sirve para `/contracts/{id}/...` → `403`.
- Si un token vence → `401` con `code: "UNAUTHENTICATED"`. Para el token web, pedir uno nuevo. Para el del contrato,
  el usuario debe completar la compra dentro de los 60 minutos desde que la inició.
- Guardar los tokens **en memoria** (un servicio `Scoped`/`Singleton` del circuito o de la app), no en `localStorage`.

> ⚠️ **Seguridad — Blazor WebAssembly:** el `clientSecret` **no puede** viajar al navegador: cualquiera lo vería con
> las herramientas de desarrollo. Si el front es **Blazor WebAssembly**, el token web debe pedirlo un backend propio
> (patrón *BFF*) o un endpoint de la web en el servidor. Si es **Blazor Server** o **Blazor Web App con render en
> servidor**, el secreto queda en el servidor (`appsettings` / Key Vault) y no hay problema.

### `POST /api/v1/auth/token`

Request:
```json
{ "clientId": "check-web", "clientSecret": "********" }
```

Response `200`:
```json
{
  "traceId": "c1e1053ad406c6a8d145adbc2a650c72",
  "message": "Token emitido correctamente.",
  "data": { "accessToken": "eyJhbGciOi...", "expiresAt": "2026-11-24T15:45:00+00:00" }
}
```

Errores: `400 VALIDATION_ERROR`, `401 INVALID_CLIENT`, `429 RATE_LIMITED` (20 por minuto por IP).

---

## 3. Formato de respuestas

### 3.1 Éxito — siempre el mismo sobre

```json
{
  "traceId": "ea3ce2e8e4421f7c91524667890e44c6",
  "message": "Texto en español para mostrar al usuario.",
  "data": { }
}
```

| Campo | Descripción |
|---|---|
| `traceId` | 32 caracteres hexadecimales. Es el mismo identificador que aparece en los logs de la API: incluirlo al reportar un problema. |
| `message` | Mensaje en español, apto para mostrar. |
| `data` | El contenido propio de cada endpoint (objeto o lista). |

### 3.2 Error — ProblemDetails (`application/problem+json`)

```json
{
  "title": "Los datos enviados no son válidos.",
  "status": 400,
  "detail": "Los porcentajes deben sumar 100 % (suman 90 %).",
  "code": "BENEFICIARIES_TOTAL_INVALID",
  "traceId": "128851d78212a62f05ccbae62109fd72"
}
```

- `code`: código estable en inglés. **El front decide qué hacer según `code`**, no según el texto.
- `detail`: mensaje en español para mostrar al usuario.
- Errores de formato del request (campos obligatorios, tipos, rangos) traen además `errors` por campo:

```json
{
  "title": "Los datos enviados no son válidos.",
  "status": 400,
  "detail": "Revisa los campos indicados en 'errors'.",
  "errors": {
    "Insured.Email": ["El correo electrónico no es válido."],
    "Insured.Names": ["Los nombres son obligatorios."]
  },
  "code": "VALIDATION_ERROR",
  "traceId": "fa8a453e7fcf279dfecc8446860d163c"
}
```

### 3.3 Códigos HTTP

| HTTP | Significado | Qué hacer en el front |
|---|---|---|
| `200` / `201` / `202` | Correcto | Leer `data` |
| `400` | Datos inválidos | Mostrar `detail` o los `errors` junto a cada campo |
| `401` | Token ausente, inválido o vencido | Pedir token nuevo / reiniciar la compra |
| `403` | El token no tiene permiso para ese recurso | Error de integración (token equivocado) |
| `404` | No existe | Mostrar `detail` |
| `409` | El contrato no está en el estado que el paso necesita | Consultar `GET /contracts/{id}` y llevar al usuario al paso correcto |
| `422` | No cumple una regla del negocio | Mostrar `detail` (es un mensaje para el usuario) |
| `429` | Demasiados intentos | Pedir que espere un momento |
| `500` | Error inesperado | Mensaje genérico + `traceId` |
| `503` | Un servicio externo (SEGIP, OTP, banco, Llamita) no respondió | Ofrecer reintentar |

---

## 4. Flujo de compra

```
 Pantalla                                Endpoint                                     Token      Estado del contrato
 ─────────────────────────────────────── ──────────────────────────────────────────── ────────── ───────────────────
 Productos                               GET  /products                               web
 Planes del producto                     (de la misma respuesta de /products)         web
 Términos y condiciones                  (solo front, por ahora)
 Formularios (listas desplegables)       GET  /catalogs                               web
 Foto del carnet (opcional)              POST /identity-readings + GET /identity-readings/{id}   web
 Datos personales → Continuar            POST /contracts                              web        Iniciado
 Validación SEGIP                        POST /contracts/{id}/screening               contrato   Validado | Rechazado
 Enviar código OTP                       POST /contracts/{id}/otp                     contrato   Validado
 Verificar código OTP                    POST /contracts/{id}/otp/verification        contrato   Verificado
 Beneficiarios y PEP                     PUT  /contracts/{id}/declarations            contrato   Declarado
 QR de pago                              POST /contracts/{id}/qr                      contrato   PendientePago
 Esperando el pago (consultar)           GET  /contracts/{id}                         contrato   PendientePago → Activo
 Encuesta (opcional)                     POST /contracts/{id}/survey                  contrato   Activo
```

### 4.1 Estados del contrato (`status`)

| Estado | Significado | Siguiente paso permitido |
|---|---|---|
| `Iniciado` | Datos personales registrados | `POST /screening` |
| `Rechazado` | SEGIP no validó los datos (`rejectionReason`) | `POST /screening` de nuevo (máx. 3 intentos por contrato) |
| `Validado` | SEGIP aprobó | `POST /otp`, `POST /otp/verification` |
| `Verificado` | El contratante confirmó con el código OTP | `PUT /declarations` |
| `Declarado` | Beneficiarios y PEP registrados | `PUT /declarations` (corregir) o `POST /qr` |
| `PendientePago` | QR generado, se espera el pago | `GET /contracts/{id}` (consultar); `POST /qr` para generar otro |
| `Activo` | Pagado: póliza vigente con número y cobertura | `POST /survey` (opcional) |

> Si el usuario recarga la página o vuelve más tarde, `GET /contracts/{id}` dice en qué paso quedó.

---

## 5. Endpoints

### 5.1 Productos — `GET /api/v1/products` (token web)

Productos activos con sus planes, coberturas y asistencias activos. Solo aparecen productos con al menos un plan activo.

```json
{
  "traceId": "…",
  "message": "Productos obtenidos correctamente.",
  "data": [
    {
      "code": "DEP-SEG",
      "name": "Tu Deporte Seguro",
      "description": "Seguro de accidentes para deportes.",
      "plans": [
        {
          "id": 3,
          "code": "DIA",
          "name": "Diario",
          "description": "Seguro para deportes contra accidentes diario.",
          "premium": { "amount": 5, "currency": "BOB" },
          "coverages": [
            {
              "name": "Gastos médicos por accidente",
              "type": "Principal",
              "insuredAmount": { "amount": 1400.0, "currency": "BOB" },
              "description": "Cobertura en caso de gastos hospitalarios por accidente…",
              "waitingPeriodDays": 0
            }
          ],
          "assistances": []
        }
      ]
    }
  ]
}
```

- `plans[].id` es el **`planId`** que piden `POST /contracts`, `POST /identity-readings` y `GET /plans/{id}/rules`.
- `premium` es `null` si el plan no tiene prima configurada (ese plan todavía no se puede contratar).
- `insuredAmount` es `null` en coberturas sin monto.
- Pantalla de productos: "Hasta Bs. 70,000" = la cobertura de mayor monto entre los planes del producto (calcularlo en el front).

### 5.2 Reglas de un plan — `GET /api/v1/plans/{id}/rules` (token web)

Reglas de suscripción del plan (edades, prima, duración…). Útil para validar en el formulario antes de enviar.

```json
{
  "data": {
    "planId": 3,
    "planCode": "DIA",
    "planName": "Diario",
    "rules": [
      { "code": "DIAS_VIGENCIA",        "name": "Días de vigencia",  "dataType": "Integer", "value": "1" },
      { "code": "EDAD_MAXIMA_INGRESO",  "name": "Edad máxima…",      "dataType": "Integer", "value": "64" },
      { "code": "EDAD_MINIMA_INGRESO",  "name": "Edad mínima…",      "dataType": "Integer", "value": "3" },
      { "code": "MAXIMO_BENEFICIARIOS", "name": "Máximo de beneficiarios", "dataType": "Integer", "value": "5" },
      { "code": "MONEDA_PRIMA",         "name": "Moneda",            "dataType": "Text",    "value": "BOB" },
      { "code": "MONTO_PRIMA",          "name": "Prima",             "dataType": "Decimal", "value": "5" }
    ]
  }
}
```

- `value` llega como texto; convertirlo según `dataType` (`Text`, `Integer`, `Decimal`, `Boolean`, `Date`).
  Formato invariante: decimales con punto, fechas `yyyy-MM-dd`, booleanos `true`/`false`.
- Errores: `404 PLAN_NOT_FOUND`.

### 5.3 Catálogos — `GET /api/v1/catalogs` (token web)

Todas las listas de los formularios en una sola llamada. Conviene pedirla **una vez** y guardarla en memoria.

```json
{
  "data": {
    "nationalities": [ { "id": 1, "iso": "BO", "name": "Boliviano(a)", "country": "Bolivia" } ],
    "occupations":   [ { "id": 6, "code": "ABG", "type": "Ocupación", "name": "Abogado(a)", "profession": "Derecho" } ],
    "cities":        [ { "id": 30, "name": "La Paz", "province": "Pedro Domingo Murillo", "department": "La Paz" } ],
    "relationships": [ { "id": 3, "code": "HI", "name": "Hijo(a)" } ],
    "lists": {
      "Departamento":           [ { "code": "LP", "value": "La Paz" } ],
      "Estado-Civil":           [ { "code": "S",  "value": "Soltero(a)" } ],
      "Parentesco-Contratante": [ { "code": "P",  "value": "Padre" }, { "code": "M", "value": "Madre" } ],
      "Parentesco-PEP":         [ { "code": "CO", "value": "Cónyuge" } ],
      "Vinculo-Socio-PEP":      [ { "code": "SO", "value": "Socio(a) en sociedad o empresa" } ],
      "Tipo-Documento-Identidad": [ { "code": "CI", "value": "…" } ]
    }
  }
}
```

**Qué se envía en cada campo: id o código.** Es el error más común de integración:

| Campo del request | Se envía | Sale de |
|---|---|---|
| `nationalityId`, `exerciseCountryId` | **id** numérico | `nationalities[].id` |
| `cityId` (lugar de residencia) | **id** numérico | `cities[].id` |
| `occupationId` | **id** numérico | `occupations[].id` |
| `extension` (expedido) | **código** | `lists["Departamento"][].code` (`LP`, `CB`, `SC`…) |
| `maritalStatus` | **código** | `lists["Estado-Civil"][].code` (`S`, `C`, `V`, `D`) |
| `contractorRelationship` | **código** | `lists["Parentesco-Contratante"][].code` (`P`, `M`) |
| `beneficiaries[].relationshipCode` | **código** | `relationships[].code` (`PA`, `MA`, `HI`, `HE`, `TI`, `SO`, `CO`) |
| `pep.relatives[].relationshipCode` | **código** | `lists["Parentesco-PEP"][].code` |
| `pep.partners[].relationshipCode` | **código** | `lists["Vinculo-Socio-PEP"][].code` |
| `documentType` | valor fijo | `CI` o `CE` |
| `gender` | valor fijo | `Masculino` o `Femenino` |

### 5.4 Lectura del carnet (opcional) — Llamita

Sirve para **precargar** el formulario con la foto del carnet. Es asíncrona: se suben las fotos y se consulta el resultado.

#### `POST /api/v1/identity-readings` (token web, `multipart/form-data`)

| Campo | Tipo | |
|---|---|---|
| `planId` | número | Id del plan elegido |
| `front` | archivo | Anverso. JPG o PNG, máx. 5 MB |
| `back` | archivo | Reverso. JPG o PNG, máx. 5 MB |

Response `202`:
```json
{ "message": "Estamos leyendo tu carnet.", "data": { "id": "01a20d25-e002-…", "status": "Pendiente", "fields": null } }
```

Límite: 6 subidas por minuto por IP (`429`).

#### `GET /api/v1/identity-readings/{id}` (token web)

Consultar **cada 2–3 segundos** hasta que `status` deje de ser `Pendiente` (en pruebas tarda ~20 s; a los 60 s se da por fallida).

```json
{
  "message": "Carnet leído correctamente. Revisa tus datos.",
  "data": {
    "id": "01a20d25-e002-…",
    "status": "Completado",
    "fields": {
      "documentType": "CI",
      "documentNumber": "1234567",
      "complement": null,
      "extension": null,
      "names": "MARÍA RENEE",
      "paternalLastname": "RODRIGUEZ",
      "maternalLastname": "GONZALEZ",
      "birthdate": "2003-04-05",
      "birthPlace": "SANTA CRUZ-ANDRES IBAÑEZ-SANTA CRUZ DE LA SIERRA",
      "address": "C. SANCHEZ LIMA NO.2520 Z. SOPOCACHI",
      "occupation": null,
      "maritalStatus": null,
      "issuedAt": "2023-11-01",
      "expiresAt": "2028-11-01",
      "isMinor": false
    }
  }
}
```

| `status` | Qué hacer |
|---|---|
| `Pendiente` | Seguir consultando |
| `Completado` | Precargar el formulario con `fields` (cualquier campo puede venir `null`) y pedir que el usuario revise |
| `Fallido` | Mostrar `message` y dejar que el usuario llene a mano |

Notas:
- `occupation` y `maritalStatus` son **texto leído del carnet**, no ids ni códigos: buscar la opción equivalente en `/catalogs`.
- `extension` llega como lo leyó Llamita; validar que exista en `lists["Departamento"]`.
- El resultado solo se puede consultar durante 30 minutos (datos personales); después → `404`.
- Guardar el `id` de la lectura para enviarlo como `identityReadingId` al iniciar el contrato.
- **Comprimir las fotos en el front** antes de subirlas (≈1600 px, JPEG 80 %): suben más rápido y Llamita tarda menos.
  En iPhone, usar `accept="image/jpeg,image/png"` para que Safari convierta HEIC a JPEG.

Errores: `400 IDENTITY_IMAGE_REQUIRED | IDENTITY_IMAGE_TOO_LARGE | IDENTITY_IMAGE_INVALID`, `404 PLAN_NOT_FOUND`,
`422 IDENTITY_READING_NOT_AVAILABLE`, `503 IDENTITY_READING_UNAVAILABLE`, `404 IDENTITY_READING_NOT_FOUND`.

### 5.5 Iniciar contrato — `POST /api/v1/contracts` (token web)

Se llama al presionar **Continuar** en la pantalla de datos personales.

Reglas:
- **Asegurado mayor de 18:** compra para sí mismo → `contractor: null`, `contractorRelationship: null`.
- **Asegurado menor de 18:** contrata su **padre o madre** → `contractor` obligatorio (mayor de edad) y
  `contractorRelationship` = `P` (padre, género Masculino) o `M` (madre, género Femenino).
- La edad del asegurado debe estar dentro de las edades del plan.
- Al menos un apellido por persona.

Request (adulto que compra para sí mismo):
```json
{
  "planId": 3,
  "identityReadingId": null,
  "insured": {
    "documentType": "CI",
    "documentNumber": "6760315",
    "complement": null,
    "extension": "LP",
    "names": "Ivan Patricio",
    "paternalLastname": "Quispe",
    "maternalLastname": "Chura",
    "birthdate": "1988-07-12",
    "gender": "Masculino",
    "nationalityId": 1,
    "birthPlace": "La Paz, Murillo",
    "address": "Villa Bolivar Municipal",
    "cellphone": "75214327",
    "email": "correo@ejemplo.com",
    "cityId": 30,
    "maritalStatus": "S",
    "occupationId": 6
  },
  "contractor": null,
  "contractorRelationship": null
}
```

Request (menor de edad; contrata la madre): igual, con `insured` = datos del menor y
```json
  "contractor": { …mismos campos que insured, con gender "Femenino"… },
  "contractorRelationship": "M"
```

| Campo | Obligatorio | Validación |
|---|---|---|
| `documentType` | sí | `CI` o `CE` |
| `documentNumber` | sí | solo dígitos, 4 a 15 |
| `complement` | no | letras y números, máx. 5 |
| `extension` | no | código de `Departamento` |
| `names` | sí | máx. 100 |
| `paternalLastname` / `maternalLastname` | al menos uno | máx. 60 c/u |
| `birthdate` | sí | `yyyy-MM-dd` |
| `gender` | sí | `Masculino` / `Femenino` |
| `nationalityId`, `cityId`, `occupationId` | sí | ids de `/catalogs` |
| `birthPlace` | sí | máx. 150 |
| `address` | sí | máx. 200 |
| `cellphone` | sí | 7 a 15 dígitos, `+` opcional |
| `email` | sí | correo válido, máx. 120 |
| `maritalStatus` | sí | código de `Estado-Civil` |

Response `201`:
```json
{
  "message": "Contrato iniciado correctamente.",
  "data": {
    "contractId": "01a20d97-65f5-723f-9b8e-32f24f37ad6c",
    "status": "Iniciado",
    "accessToken": "eyJhbGciOi..."
  }
}
```

👉 Guardar `contractId` y `accessToken` (token del contrato) para todos los pasos siguientes.

Si se envía `identityReadingId`, la lectura debe estar `Completado`, ser del asegurado o del contratante (mismo número
de documento) y el carnet no debe estar vencido.

Errores: `400 VALIDATION_ERROR | INVALID_REFERENCES | LASTNAME_REQUIRED | BIRTHDATE_INVALID | CONTRACTOR_RELATIONSHIP_INVALID
| CONTRACTOR_GENDER_MISMATCH | CONTRACTOR_SAME_AS_INSURED | IDENTITY_READING_INVALID | IDENTITY_READING_MISMATCH`,
`404 PLAN_NOT_FOUND`, `422 PLAN_NOT_SELLABLE | INSURED_AGE_OUT_OF_RANGE | CONTRACTOR_REQUIRED | CONTRACTOR_NOT_ALLOWED
| CONTRACTOR_MUST_BE_ADULT | DOCUMENT_EXPIRED`.

`INVALID_REFERENCES` indica en `detail` qué campos no existen en los catálogos (ej. `insured.cityId, insured.maritalStatus`).

### 5.6 Validación SEGIP — `POST /api/v1/contracts/{id}/screening` (token del contrato)

Sin body. Valida con SEGIP al asegurado y, si hay, al contratante (número de documento, complemento, nombres,
apellidos y fecha de nacimiento).

Response `200`:
```json
{
  "message": "Tus datos no coinciden con los registrados en SEGIP.",
  "data": {
    "contractId": "…",
    "status": "Rechazado",
    "people": [
      { "role": "Asegurado",   "result": "Aprobado",  "foundInSegip": true,  "mismatchedFields": [] },
      { "role": "Contratante", "result": "Observado", "foundInSegip": true,  "mismatchedFields": ["names", "birthdate"] }
    ]
  }
}
```

| `data.status` | Qué hacer |
|---|---|
| `Validado` | Pasar al OTP |
| `Rechazado` | Marcar en el formulario los campos de `mismatchedFields` (`documentNumber`, `complement`, `names`, `paternalLastname`, `maternalLastname`, `birthdate`) o, si `foundInSegip` es `false`, indicar que el documento no se encontró. Se puede reintentar sobre el **mismo contrato** (máx. 3 intentos). |

Errores: `409 CONTRACT_INVALID_STATUS`, `422 SEGIP_ATTEMPTS_EXCEEDED`, `503 SEGIP_UNAVAILABLE` (reintentar; no cuenta como rechazo).

### 5.7 Código OTP

El código lo envía el banco **al contratante** (o al asegurado si compra para sí mismo) por **SMS, correo y WhatsApp**.

#### `POST /api/v1/contracts/{id}/otp` (token del contrato) — enviar / reenviar

Sin body. Requiere el contrato `Validado`.

```json
{
  "message": "Te enviamos el código de verificación.",
  "data": {
    "sentTo": "Código OTP enviado a SMS: XXXXXX27 Correo: XXXXX@gmail.com WhatsApp: XXXXXX27",
    "expiresAt": "2026-11-24T14:00:31Z",
    "resendAvailableAt": "2026-11-24T13:56:31Z",
    "remainingSends": 4
  }
}
```

- Mostrar `sentTo` tal cual (ya viene enmascarado).
- El código vence a los **5 minutos** (`expiresAt`).
- El botón "Reenviar" se habilita en `resendAvailableAt` (60 s). Máximo **5 envíos** por contrato.

Errores: `409 CONTRACT_INVALID_STATUS`, `422 OTP_RESEND_TOO_SOON | OTP_SENDS_EXCEEDED`, `503 OTP_UNAVAILABLE`.

#### `POST /api/v1/contracts/{id}/otp/verification` (token del contrato)

```json
{ "code": "123456" }
```

Response `200`:
```json
{ "message": "Código verificado correctamente.", "data": { "contractId": "…", "status": "Verificado" } }
```

- 3 intentos por código. Si se agotan o el código vence, pedir uno nuevo con `POST /otp`.

Errores: `400 VALIDATION_ERROR | OTP_INVALID` (el `detail` dice cuántos intentos quedan),
`409 CONTRACT_INVALID_STATUS | OTP_ALREADY_VERIFIED`, `422 OTP_NOT_SENT | OTP_EXPIRED | OTP_ATTEMPTS_EXCEEDED`,
`503 OTP_UNAVAILABLE` (no consume intentos).

### 5.8 Beneficiarios y PEP — `PUT /api/v1/contracts/{id}/declarations` (token del contrato)

Requiere el contrato `Verificado`. También acepta `Declarado` para **corregir** antes de generar el QR
(cada envío reemplaza lo anterior).

```json
{
  "beneficiaries": [
    { "relationshipCode": "HI", "documentNumber": null, "names": "ANA",   "paternalLastname": "PEREZ", "maternalLastname": null,     "percentage": 60 },
    { "relationshipCode": "CO", "documentNumber": null, "names": "MARIA", "paternalLastname": "LOPEZ", "maternalLastname": "QUISPE", "percentage": 40 }
  ],
  "pep": {
    "isPep": false,
    "hasPepPartners": false
  }
}
```

**Beneficiarios**
- `beneficiaries: []` = **herederos legales**. Es obligatorio si el asegurado es menor de edad.
- Máximo según el plan (`MAXIMO_BENEFICIARIOS`, 5 en el plan Diario).
- Los porcentajes deben **sumar exactamente 100** (cada uno de 0,01 a 100, hasta 2 decimales).
- Padre, Madre y Cónyuge solo pueden aparecer **una vez**.
- `documentNumber` es opcional. Al menos un apellido por beneficiario.

**PEP** (lo declara el contratante)

Ejemplo de persona PEP con socio:
```json
"pep": {
  "isPep": true,
  "position": "Concejal",
  "institution": "Gobierno Autónomo Municipal de La Paz",
  "sourceFunds": "Sueldo",
  "exerciseCountryId": 1,
  "periodStart": "2021-05-03",
  "periodEnd": null,
  "relatives": [
    { "relationshipCode": "CO", "names": "MARIA", "paternalLastname": "LOPEZ", "maternalLastname": null, "documentNumber": null, "nationalityId": 1 }
  ],
  "hasPepPartners": true,
  "partners": [
    { "relationshipCode": "SO", "names": "PEDRO", "paternalLastname": "ROJAS", "maternalLastname": null, "position": "Gerente" }
  ]
}
```

| Si… | Entonces |
|---|---|
| `isPep: true` | Obligatorios `position`, `institution`, `sourceFunds`, `exerciseCountryId`, `periodStart` (no futura); `periodEnd` opcional (≥ inicio); de **1 a 10** `relatives` |
| `isPep: false` | `relatives` vacío; los datos del cargo se ignoran |
| `hasPepPartners: true` | Al menos un `partners` |
| `hasPepPartners: false` | `partners` vacío |

Response `200`:
```json
{
  "message": "Declaraciones registradas correctamente.",
  "data": { "contractId": "…", "status": "Declarado", "legalHeirs": false, "beneficiaries": 2, "isPep": false, "hasPepPartners": false }
}
```

Errores: `400 VALIDATION_ERROR | INVALID_REFERENCES | BENEFICIARIES_TOTAL_INVALID | BENEFICIARY_PERCENTAGE_INVALID
| BENEFICIARY_RELATIONSHIP_REPEATED | BENEFICIARY_IS_INSURED | BENEFICIARY_LASTNAME_REQUIRED | PEP_DATA_REQUIRED
| PEP_PERIOD_INVALID | PEP_RELATIVES_INVALID | PEP_RELATIVES_NOT_ALLOWED | PEP_PARTNERS_REQUIRED | PEP_PARTNERS_NOT_ALLOWED
| PEP_LASTNAME_REQUIRED`, `409 CONTRACT_INVALID_STATUS`, `422 BENEFICIARIES_NOT_ALLOWED | BENEFICIARIES_EXCEEDED`.

### 5.9 QR de pago — `POST /api/v1/contracts/{id}/qr` (token del contrato)

Sin body. Requiere el contrato `Declarado`. Si ya hay un QR pendiente (por ejemplo, venció), genera uno nuevo y el
anterior queda reemplazado. Máximo 5 QR por contrato.

Response `201`:
```json
{
  "message": "QR generado. Escanéalo desde la app de tu banco.",
  "data": {
    "qrPaymentId": "01a20df7-ebfd-…",
    "status": "Pendiente",
    "qrImage": "data:image/png;base64,iVBORw0K…",
    "amount": 5.0,
    "currency": "BOB",
    "description": "Tu Deporte Seguro - Plan Diario",
    "expiresAt": "2026-11-24T15:01:21Z"
  }
}
```

- `qrImage` es un data URI: usarlo directo en `<img src="@qr.QrImage" />`.
- Ofrecer **descargar** la imagen (útil si el usuario paga desde la app del banco en el mismo celular).
- Mostrar una cuenta regresiva hasta `expiresAt` (30 minutos). Al vencer, ofrecer "Generar nuevo QR".
- Después de generar el QR **ya no se pueden corregir** las declaraciones.

Errores: `409 CONTRACT_INVALID_STATUS`, `422 QR_LIMIT_EXCEEDED`, `503 QR_UNAVAILABLE`.

### 5.10 Estado del contrato — `GET /api/v1/contracts/{id}` (token del contrato)

Mientras se muestra el QR, **consultar cada 3–5 segundos** hasta que `status` sea `Activo`.

```json
{
  "message": "Contrato obtenido correctamente.",
  "data": {
    "contractId": "01a20e0d-…",
    "status": "Activo",
    "number": "DEP-SEG-2026-SMNC1TRG",
    "productName": "Tu Deporte Seguro",
    "planName": "Diario",
    "premium": 5.0,
    "currency": "BOB",
    "coverageFrom": "2026-11-24T14:54:33Z",
    "coverageTo": "2026-11-25T14:54:33Z",
    "rejectionReason": null,
    "qr": { "qrPaymentId": "01a20e0d-…", "status": "Pagado", "expiresAt": "2026-11-24T15:24:33Z", "paidAt": "2026-11-24T14:54:33Z" }
  }
}
```

| Situación | Cómo se detecta |
|---|---|
| Pagado | `status == "Activo"` → mostrar `number`, `coverageFrom`, `coverageTo` y la encuesta |
| Sigue esperando | `status == "PendientePago"` y `qr.status == "Pendiente"` |
| QR vencido | `qr.expiresAt` ya pasó (o `qr.status == "Vencido"`) → ofrecer `POST /qr` |
| Retomar la compra | Usar `status` para llevar al usuario al paso que corresponde (§4.1) |

Las fechas vienen en UTC: mostrarlas en hora de Bolivia (UTC−4).

### 5.11 Encuesta (opcional) — `POST /api/v1/contracts/{id}/survey` (token del contrato)

"¿Qué te pareció la experiencia de comprar tu seguro?" — solo con el contrato `Activo`, una vez por contrato.
Si el usuario cierra la página sin responder, no pasa nada.

```json
{ "score": 9, "comment": "Muy fácil y rápido" }
```

- `score`: entero de **1 a 10** (obligatorio). `comment`: opcional, máx. 500.

Response `201`:
```json
{ "message": "¡Gracias por tu opinión!", "data": { "contractId": "…", "score": 9 } }
```

Errores: `400 VALIDATION_ERROR`, `409 CONTRACT_INVALID_STATUS | SURVEY_ALREADY_ANSWERED`.

---

## 6. Catálogo de códigos de error (`code`)

| HTTP | `code` | Cuándo |
|---|---|---|
| 400 | `VALIDATION_ERROR` | Formato del request (ver `errors`) |
| 400 | `INVALID_REFERENCES` | Un id o código no existe en `/catalogs` (`detail` dice cuáles) |
| 400 | `LASTNAME_REQUIRED`, `BIRTHDATE_INVALID` | Datos de una persona |
| 400 | `CONTRACTOR_RELATIONSHIP_INVALID`, `CONTRACTOR_GENDER_MISMATCH`, `CONTRACTOR_SAME_AS_INSURED` | Contratante |
| 400 | `IDENTITY_IMAGE_REQUIRED`, `IDENTITY_IMAGE_TOO_LARGE`, `IDENTITY_IMAGE_INVALID` | Fotos del carnet |
| 400 | `IDENTITY_READING_INVALID`, `IDENTITY_READING_MISMATCH` | Lectura enviada al iniciar el contrato |
| 400 | `OTP_INVALID` | Código OTP incorrecto |
| 400 | `BENEFICIARIES_TOTAL_INVALID`, `BENEFICIARY_PERCENTAGE_INVALID`, `BENEFICIARY_RELATIONSHIP_REPEATED`, `BENEFICIARY_IS_INSURED`, `BENEFICIARY_LASTNAME_REQUIRED` | Beneficiarios |
| 400 | `PEP_DATA_REQUIRED`, `PEP_PERIOD_INVALID`, `PEP_RELATIVES_INVALID`, `PEP_RELATIVES_NOT_ALLOWED`, `PEP_PARTNERS_REQUIRED`, `PEP_PARTNERS_NOT_ALLOWED`, `PEP_LASTNAME_REQUIRED` | Declaración PEP |
| 401 | `UNAUTHENTICATED` | Token ausente, inválido o vencido |
| 401 | `INVALID_CLIENT` | `clientId`/`clientSecret` incorrectos |
| 403 | `FORBIDDEN` | Token sin permiso (p. ej. token de otro contrato) |
| 404 | `PLAN_NOT_FOUND`, `CONTRACT_NOT_FOUND`, `IDENTITY_READING_NOT_FOUND` | No existe |
| 409 | `CONTRACT_INVALID_STATUS` | El contrato no está en el estado que el paso requiere |
| 409 | `OTP_ALREADY_VERIFIED`, `SURVEY_ALREADY_ANSWERED` | Ya hecho |
| 422 | `PLAN_NOT_SELLABLE`, `INSURED_AGE_OUT_OF_RANGE` | Plan / edad |
| 422 | `CONTRACTOR_REQUIRED`, `CONTRACTOR_NOT_ALLOWED`, `CONTRACTOR_MUST_BE_ADULT` | Regla de contratante |
| 422 | `DOCUMENT_EXPIRED` | Carnet vencido |
| 422 | `IDENTITY_READING_NOT_AVAILABLE` | El producto no tiene lectura del carnet |
| 422 | `SEGIP_ATTEMPTS_EXCEEDED` | Más de 3 validaciones SEGIP |
| 422 | `OTP_NOT_SENT`, `OTP_EXPIRED`, `OTP_ATTEMPTS_EXCEEDED`, `OTP_RESEND_TOO_SOON`, `OTP_SENDS_EXCEEDED` | OTP |
| 422 | `BENEFICIARIES_NOT_ALLOWED`, `BENEFICIARIES_EXCEEDED` | Beneficiarios según plan / edad |
| 422 | `QR_LIMIT_EXCEEDED` | Más de 5 QR |
| 429 | `RATE_LIMITED` | Demasiadas solicitudes |
| 500 | `UNEXPECTED_ERROR` | Error inesperado |
| 503 | `SEGIP_UNAVAILABLE`, `OTP_UNAVAILABLE`, `QR_UNAVAILABLE`, `IDENTITY_READING_UNAVAILABLE` | Servicio externo caído: reintentar |

---

## 7. Integración en Blazor

### 7.1 Modelos (C#)

```csharp
public sealed record ApiResponse<T>(string TraceId, string Message, T Data);

public sealed class ApiProblem
{
    public string? Title { get; init; }
    public int Status { get; init; }
    public string? Detail { get; init; }
    public string? Code { get; init; }
    public string? TraceId { get; init; }
    public Dictionary<string, string[]>? Errors { get; init; }
}

public sealed class ApiException(ApiProblem problem) : Exception(problem.Detail ?? problem.Title)
{
    public ApiProblem Problem { get; } = problem;
    public string? Code => Problem.Code;
}

public sealed record TokenResponse(string AccessToken, DateTimeOffset ExpiresAt);
public sealed record StartContractResponse(Guid ContractId, string Status, string AccessToken);

public sealed record MoneyResponse(decimal Amount, string Currency);
public sealed record CoverageResponse(string Name, string Type, MoneyResponse? InsuredAmount, string Description, int WaitingPeriodDays);
public sealed record AssistanceResponse(string Name, string Service, string Description, int WaitingPeriodDays);
public sealed record PlanResponse(long Id, string Code, string Name, string? Description, MoneyResponse? Premium,
    IReadOnlyList<CoverageResponse> Coverages, IReadOnlyList<AssistanceResponse> Assistances);
public sealed record ProductResponse(string Code, string Name, string? Description, IReadOnlyList<PlanResponse> Plans);

public sealed record QrResponse(Guid QrPaymentId, string Status, string QrImage, decimal Amount, string Currency,
    string Description, DateTimeOffset ExpiresAt);
public sealed record QrSummaryResponse(Guid QrPaymentId, string Status, DateTimeOffset ExpiresAt, DateTimeOffset? PaidAt);
public sealed record ContractSummaryResponse(Guid ContractId, string Status, string? Number, string ProductName,
    string PlanName, decimal Premium, string Currency, DateTimeOffset? CoverageFrom, DateTimeOffset? CoverageTo,
    string? RejectionReason, QrSummaryResponse? Qr);
// … el resto sigue exactamente los JSON de la sección 5.
```

Usar `JsonSerializerOptions.Web` (camelCase, sin distinguir mayúsculas). Es el default de `GetFromJsonAsync` /
`PostAsJsonAsync`.

### 7.2 Cliente HTTP con manejo uniforme de respuestas

```csharp
public sealed class CheckApiClient(HttpClient http)
{
    public Task<T> GetAsync<T>(string url, string token, CancellationToken ct = default) =>
        SendAsync<T>(new HttpRequestMessage(HttpMethod.Get, url), token, ct);

    public Task<T> PostAsync<T>(string url, object? body, string token, CancellationToken ct = default) =>
        SendAsync<T>(new HttpRequestMessage(HttpMethod.Post, url) { Content = body is null ? null : JsonContent.Create(body) }, token, ct);

    public Task<T> PutAsync<T>(string url, object body, string token, CancellationToken ct = default) =>
        SendAsync<T>(new HttpRequestMessage(HttpMethod.Put, url) { Content = JsonContent.Create(body) }, token, ct);

    private async Task<T> SendAsync<T>(HttpRequestMessage request, string token, CancellationToken ct)
    {
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var response = await http.SendAsync(request, ct);

        if (response.IsSuccessStatusCode)
            return (await response.Content.ReadFromJsonAsync<ApiResponse<T>>(ct))!.Data;

        var problem = await response.Content.ReadFromJsonAsync<ApiProblem>(ct)
                      ?? new ApiProblem { Status = (int)response.StatusCode, Detail = "Ocurrió un error inesperado." };
        throw new ApiException(problem);
    }
}

// Program.cs
builder.Services.AddHttpClient<CheckApiClient>(c => c.BaseAddress = new Uri("http://localhost:5080/"));
```

Para obtener también `message` (por ejemplo, en el SEGIP o el OTP), devolver `ApiResponse<T>` completo en lugar de `Data`.

### 7.3 Estado de la compra

Un servicio que guarde en memoria lo necesario entre pantallas:

```csharp
public sealed class PurchaseState
{
    public string? WebToken { get; set; }
    public long? PlanId { get; set; }
    public Guid? IdentityReadingId { get; set; }
    public Guid? ContractId { get; set; }
    public string? ContractToken { get; set; }
}
```

Registrarlo `Scoped` (Blazor Server: uno por circuito/usuario) o `Singleton` (Blazor WebAssembly: uno por pestaña).

### 7.4 Subir las fotos del carnet (`IBrowserFile`)

```csharp
async Task<Guid> UploadIdentityAsync(long planId, IBrowserFile front, IBrowserFile back)
{
    const long maxBytes = 5 * 1024 * 1024;
    using var content = new MultipartFormDataContent
    {
        { new StringContent(planId.ToString()), "planId" },
        { new StreamContent(front.OpenReadStream(maxBytes)) { Headers = { ContentType = new(front.ContentType) } }, "front", front.Name },
        { new StreamContent(back.OpenReadStream(maxBytes))  { Headers = { ContentType = new(back.ContentType)  } }, "back",  back.Name }
    };
    using var request = new HttpRequestMessage(HttpMethod.Post, "api/v1/identity-readings") { Content = content };
    request.Headers.Authorization = new("Bearer", state.WebToken);
    // … leer ApiResponse<IdentityReadingResponse> y devolver data.Id
}
```

Para reducir el tamaño antes de subir: `await file.RequestImageFileAsync("image/jpeg", 1600, 1600)` (Blazor
redimensiona en el navegador).

### 7.5 Consultas periódicas (lectura del carnet y pago)

```csharp
using var timer = new PeriodicTimer(TimeSpan.FromSeconds(3));
while (await timer.WaitForNextTickAsync(ct))
{
    var contract = await api.GetAsync<ContractSummaryResponse>($"api/v1/contracts/{state.ContractId}", state.ContractToken!, ct);
    if (contract.Status == "Activo") { /* pantalla de éxito + encuesta */ break; }
    if (contract.Qr is { } qr && qr.ExpiresAt <= DateTimeOffset.UtcNow) { /* QR vencido: ofrecer generar otro */ break; }
}
```

- Cancelar el `CancellationToken` al salir de la página (`IDisposable` / `IAsyncDisposable` en el componente).
- Lectura del carnet: cada 2–3 s, como máximo ~60 s.
- Pago: cada 3–5 s, mientras el QR esté vigente.

### 7.6 Reaccionar a los errores

```csharp
try { await api.PostAsync<object>($"api/v1/contracts/{id}/otp", null, state.ContractToken!); }
catch (ApiException ex) when (ex.Code == "OTP_RESEND_TOO_SOON") { /* mostrar ex.Message y esperar */ }
catch (ApiException ex) when (ex.Code == "CONTRACT_INVALID_STATUS") { /* GET /contracts/{id} y redirigir al paso correcto */ }
catch (ApiException ex) when (ex.Problem.Status == 503) { /* "Intenta nuevamente" */ }
catch (ApiException ex) when (ex.Problem.Errors is not null) { /* pintar ex.Problem.Errors por campo */ }
catch (ApiException ex) { /* mostrar ex.Message; registrar ex.Problem.TraceId */ }
```

Los nombres de campo en `errors` siguen la ruta del objeto: `Insured.Email`, `Contractor.Birthdate`,
`Beneficiaries[0].Percentage`, etc.

---

## 8. Recomendaciones de UX ligadas a la API

- **Validar en el front lo mismo que la API** (formatos, obligatorios, edades del plan, suma 100 %): la API vuelve a
  validar todo, pero así el usuario corrige antes de enviar.
- **Botones con estado "procesando"** en los pasos que llaman a servicios externos (SEGIP, OTP, QR): pueden tardar
  varios segundos. Evitar doble clic.
- **Retomar la compra:** con `contractId` y su token, `GET /contracts/{id}` indica el paso exacto.
- **Menores de edad:** si la fecha de nacimiento del asegurado da menos de 18 años, mostrar los campos del contratante
  y el parentesco (Padre / Madre), y forzar beneficiarios = herederos legales.
- **No guardar datos personales** en `localStorage` ni en la URL.

---

## 9. Desarrollo local

En `Development`, SEGIP, OTP y banco son **simulados**:

| Servicio | Comportamiento simulado |
|---|---|
| SEGIP | Aprueba siempre. CI que termina en `000` → nombres no coinciden. CI que termina en `999` → no encontrado. |
| OTP | No envía nada. El código válido es **`123456`**. |
| QR del banco | Devuelve un QR real (escaneable) con los datos del pago; no se puede pagar de verdad. |
| Llamita | Real (lee el carnet de verdad). |

### Simular el pago — `POST /api/v1/dev/contracts/{id}/simulate-payment` (token del contrato)

Solo existe en desarrollo. Hace lo mismo que haría el banco al recibir el pago del QR pendiente: el contrato pasa a
`Activo`. Útil para probar la pantalla de "Esperando el pago".

```json
{ "amount": null }
```

`amount` opcional: enviar otro monto para probar el caso "Monto Diferente" (el contrato no se activa).

Response:
```json
{ "message": "Pago simulado.", "data": { "result": "Aplicado", "contractId": "…", "contractNumber": "DEP-SEG-2026-MJ03N9X5" } }
```

### Recorrido completo de prueba

1. `POST /auth/token` → token web.
2. `GET /products` → elegir `plans[].id` (el plan Diario, id `3`, es el único con prima hoy).
3. `GET /catalogs` → ids y códigos.
4. `POST /contracts` → `contractId` + token del contrato.
5. `POST /contracts/{id}/screening` → `Validado`.
6. `POST /contracts/{id}/otp` → `POST /contracts/{id}/otp/verification` con `123456` → `Verificado`.
7. `PUT /contracts/{id}/declarations` con `beneficiaries: []` y `pep.isPep: false` → `Declarado`.
8. `POST /contracts/{id}/qr` → mostrar la imagen.
9. `POST /dev/contracts/{id}/simulate-payment` → `GET /contracts/{id}` muestra `Activo` y el número de póliza.
10. `POST /contracts/{id}/survey` con `score` 1–10.

El archivo `src/Check.Api/Check.Api.http` del repositorio tiene todas estas peticiones listas para ejecutar.

---

## 10. Pendiente en la API (puede cambiar el contrato)

- **Aceptación de Términos y Condiciones / Declaración de Veracidad:** hoy solo en el front. Se agregará su registro
  (probablemente como un campo más al iniciar el contrato).
- **Notificación del pago en tiempo real** (para evitar las consultas periódicas): en evaluación.
- **Corrección de datos personales** después de un rechazo de SEGIP: hoy se reintenta con los mismos datos.
- **AMLC y Archivo Negativo** se sumarán a la validación de `/screening` (misma respuesta, más proveedores).
