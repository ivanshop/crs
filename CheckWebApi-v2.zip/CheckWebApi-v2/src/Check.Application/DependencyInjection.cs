using Check.Application.Catalogs;
using Check.Application.Contracts;
using Check.Application.Declarations;
using Check.Application.IdentityReadings;
using Check.Application.Otp;
using Check.Application.Payments;
using Check.Application.Plans;
using Check.Application.Products;
using Check.Application.Screening;
using Check.Application.Surveys;
using Microsoft.Extensions.DependencyInjection;

namespace Check.Application;

/// <summary>Registro de los casos de uso: una clase por acción con un método ExecuteAsync.</summary>
public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddSingleton(TimeProvider.System);

        // Catálogos
        services.AddScoped<GetCatalogsUseCase>();

        // Productos
        services.AddScoped<GetProductsUseCase>();

        // Planes
        services.AddScoped<GetPlanRulesUseCase>();

        // Lectura del carnet (Llamita)
        services.AddScoped<StartIdentityReadingUseCase>();
        services.AddScoped<GetIdentityReadingUseCase>();

        // Contratos
        services.AddScoped<StartContractUseCase>();
        services.AddScoped<GetContractUseCase>();
        services.AddScoped<ScreenContractUseCase>();
        services.AddScoped<SendOtpUseCase>();
        services.AddScoped<VerifyOtpUseCase>();
        services.AddScoped<DeclareUseCase>();
        services.AddScoped<GenerateQrUseCase>();
        services.AddScoped<ProcessPaymentNotificationUseCase>();
        services.AddScoped<SimulatePaymentUseCase>();
        services.AddScoped<SubmitSurveyUseCase>();

        return services;
    }
}
