using Check.Domain.Compliance;

namespace Check.Application.Screening;

/// <summary>Contrastación con SEGIP (servicio SOAP).</summary>
public interface ISegipClient
{
    Task<SegipResult> VerifyAsync(SegipQuery query, CancellationToken ct);
}

/// <summary>Persona del contrato a validar. Si compra para sí mismo, es una sola (rol Asegurado).</summary>
public sealed record ScreeningSubject(Guid PersonId, string Role, SegipQuery Query);

/// <summary>SegipAttempts: veces que ya se consultó SEGIP para este contrato.</summary>
public sealed record ContractForScreening(Guid ContractId, string Status, int SegipAttempts, IReadOnlyList<ScreeningSubject> Subjects);

/// <summary>Sección "Screening" de appsettings.</summary>
public sealed class ScreeningSettings
{
    public const string Section = "Screening";
    /// <summary>Máximo de validaciones SEGIP por contrato (cada consulta tiene costo).</summary>
    public int MaxSegipAttempts { get; init; } = 3;
}

/// <summary>Una fila de compliance.screenings. ResultJson se guarda cifrado.</summary>
public sealed record ScreeningRecord(Guid PersonId, string Provider, string Status, string? ResultJson);

public interface IScreeningRepository
{
    /// <summary>Contrato con sus personas (datos descifrados de contract_parties). Null si no existe.</summary>
    Task<ContractForScreening?> GetContractAsync(Guid contractId, CancellationToken ct);

    /// <summary>Guarda las consultas y, si se indica, el nuevo estado del contrato. Una sola transacción.</summary>
    Task SaveAsync(Guid contractId, IReadOnlyList<ScreeningRecord> records, string? newStatus, string? rejectionReason, CancellationToken ct);
}

public sealed record ScreeningResponse(Guid ContractId, string Status, IReadOnlyList<PersonScreeningResponse> People);

/// <summary>Result: Aprobado u Observado. MismatchedFields: campos del formulario que no coinciden con SEGIP.</summary>
public sealed record PersonScreeningResponse(string Role, string Result, bool FoundInSegip, IReadOnlyList<string> MismatchedFields);
