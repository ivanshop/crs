using System.Text.Json;
using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Screening;

/// <summary>
/// Valida con SEGIP a cada persona del contrato (asegurado y, si hay, contratante).
/// Todos aprobados → Validado. Alguno observado → Rechazado. SEGIP caído → no cambia el estado.
/// Un contrato Iniciado o Rechazado se puede volver a validar (mismo contrato) hasta MaxSegipAttempts veces.
/// </summary>
public sealed class ScreenContractUseCase(
    IScreeningRepository screenings,
    ISegipClient segip,
    ScreeningSettings settings,
    ILogger<ScreenContractUseCase> logger)
{
    public async Task<Result<ScreeningResponse>> ExecuteAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await screenings.GetContractAsync(contractId, ct);
        if (contract is null)
            return Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
        if (contract.Status is not (ContractStatus.Started or ContractStatus.Rejected))
            return Error.Conflict("CONTRACT_INVALID_STATUS", $"El contrato ya fue validado (estado {contract.Status}).");
        if (contract.SegipAttempts >= settings.MaxSegipAttempts)
            return Error.BusinessRule("SEGIP_ATTEMPTS_EXCEEDED", $"Superaste los {settings.MaxSegipAttempts} intentos de validación. Comunícate con nosotros para continuar.");

        var records = new List<ScreeningRecord>();
        var people = new List<PersonScreeningResponse>();

        foreach (var subject in contract.Subjects)
        {
            SegipResult result;
            try
            {
                result = await segip.VerifyAsync(subject.Query, ct);
            }
            catch (ExternalServiceException ex)
            {
                logger.LogWarning(ex, "SEGIP no respondió al validar el contrato {ContractId} ({Rol}).", contractId, subject.Role);
                records.Add(new ScreeningRecord(subject.PersonId, ScreeningProviders.Segip, ScreeningStatus.Error, null));
                await screenings.SaveAsync(contractId, records, null, null, ct);
                return Error.ExternalService("SEGIP_UNAVAILABLE", "No pudimos validar tus datos con SEGIP en este momento. Intenta nuevamente en unos minutos.");
            }

            var evaluation = SegipRules.Evaluate(subject.Query, result);
            var status = evaluation.Approved ? ScreeningStatus.Approved : ScreeningStatus.Observed;
            records.Add(new ScreeningRecord(subject.PersonId, ScreeningProviders.Segip, status, JsonSerializer.Serialize(result)));
            people.Add(new PersonScreeningResponse(subject.Role, status, evaluation.Found, evaluation.MismatchedFields));
        }

        var observed = people.Where(p => p.Result != ScreeningStatus.Approved).ToList();
        var newStatus = observed.Count == 0 ? ContractStatus.Validated : ContractStatus.Rejected;
        var reason = observed.Count == 0 ? null : "SEGIP: " + string.Join("; ", observed.Select(p =>
            p.FoundInSegip ? $"{p.Role} con datos que no coinciden ({string.Join(", ", p.MismatchedFields)})" : $"{p.Role} no encontrado"));

        await screenings.SaveAsync(contractId, records, newStatus, reason, ct);
        logger.LogInformation("Contrato {ContractId} validado con SEGIP: {Estado}.", contractId, newStatus);

        return new ScreeningResponse(contractId, newStatus, people);
    }
}
