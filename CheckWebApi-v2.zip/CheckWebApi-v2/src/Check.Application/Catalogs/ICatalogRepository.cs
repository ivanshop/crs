namespace Check.Application.Catalogs;

public interface ICatalogRepository
{
    /// <summary>Solo registros activos, en el orden en que se muestran.</summary>
    Task<CatalogsResponse> GetAllAsync(CancellationToken ct);
}
