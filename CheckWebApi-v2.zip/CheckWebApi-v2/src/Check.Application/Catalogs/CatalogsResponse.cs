namespace Check.Application.Catalogs;

/// <summary>Todas las listas de los formularios en una sola llamada.</summary>
public sealed record CatalogsResponse(
    IReadOnlyList<NationalityResponse> Nationalities,
    IReadOnlyList<OccupationResponse> Occupations,
    IReadOnlyList<CityResponse> Cities,
    IReadOnlyList<RelationshipResponse> Relationships,
    /// <summary>Listas simples de core.catalogs agrupadas por topic (marital_status, document_extension...).</summary>
    IReadOnlyDictionary<string, IReadOnlyList<CatalogItemResponse>> Lists);

public sealed record NationalityResponse(short Id, string Iso, string Name, string Country);

/// <summary>Type: Ocupación o Condición Laboral (esta última sin profesión).</summary>
public sealed record OccupationResponse(short Id, string Code, string Type, string Name, string? Profession);

public sealed record CityResponse(short Id, string Name, string Province, string Department);

public sealed record RelationshipResponse(long Id, string Code, string Name);

public sealed record CatalogItemResponse(string Code, string Value);
