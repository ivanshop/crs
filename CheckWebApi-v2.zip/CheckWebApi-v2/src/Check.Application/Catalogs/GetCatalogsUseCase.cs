namespace Check.Application.Catalogs;

public sealed class GetCatalogsUseCase(ICatalogRepository catalogs)
{
    public Task<CatalogsResponse> ExecuteAsync(CancellationToken ct) => catalogs.GetAllAsync(ct);
}
