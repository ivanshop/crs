using System.ComponentModel.DataAnnotations;

namespace Check.Application.Declarations;

public sealed class DeclareRequest
{
    /// <summary>Vacío = herederos legales.</summary>
    public List<BeneficiaryRequest> Beneficiaries { get; init; } = [];

    [Required(ErrorMessage = "La declaración PEP es obligatoria.")]
    public PepRequest Pep { get; init; } = null!;
}

public sealed class BeneficiaryRequest
{
    /// <summary>Código de /catalogs "relationships" (PA, MA, HI, HE, TI, SO, CO).</summary>
    [Required(ErrorMessage = "El parentesco del beneficiario es obligatorio.")]
    public string RelationshipCode { get; init; } = null!;

    [RegularExpression(@"^\d{4,15}$", ErrorMessage = "El documento del beneficiario debe tener solo dígitos.")]
    public string? DocumentNumber { get; init; }

    [Required(ErrorMessage = "Los nombres del beneficiario son obligatorios.")]
    [StringLength(100, ErrorMessage = "Los nombres admiten hasta 100 caracteres.")]
    public string Names { get; init; } = null!;

    [StringLength(60, ErrorMessage = "El apellido admite hasta 60 caracteres.")]
    public string? PaternalLastname { get; init; }

    [StringLength(60, ErrorMessage = "El apellido admite hasta 60 caracteres.")]
    public string? MaternalLastname { get; init; }

    [Required(ErrorMessage = "El porcentaje es obligatorio.")]
    public decimal? Percentage { get; init; }
}

public sealed class PepRequest
{
    [Required(ErrorMessage = "Indica si eres PEP.")]
    public bool? IsPep { get; init; }

    [Required(ErrorMessage = "Indica si tienes socios PEP.")]
    public bool? HasPepPartners { get; init; }

    [StringLength(150, ErrorMessage = "El cargo admite hasta 150 caracteres.")]
    public string? Position { get; init; }

    [StringLength(150, ErrorMessage = "La institución admite hasta 150 caracteres.")]
    public string? Institution { get; init; }

    [StringLength(200, ErrorMessage = "El origen de fondos admite hasta 200 caracteres.")]
    public string? SourceFunds { get; init; }

    /// <summary>Id de /catalogs "nationalities": país donde ejerce el cargo.</summary>
    public short? ExerciseCountryId { get; init; }

    public DateOnly? PeriodStart { get; init; }
    public DateOnly? PeriodEnd { get; init; }

    public List<PepRelativeRequest> Relatives { get; init; } = [];
    public List<PepPartnerRequest> Partners { get; init; } = [];
}

public sealed class PepRelativeRequest
{
    /// <summary>Código de /catalogs "Parentesco-PEP".</summary>
    [Required(ErrorMessage = "El parentesco del familiar es obligatorio.")]
    public string RelationshipCode { get; init; } = null!;

    [Required(ErrorMessage = "Los nombres del familiar son obligatorios.")]
    [StringLength(100, ErrorMessage = "Los nombres admiten hasta 100 caracteres.")]
    public string Names { get; init; } = null!;

    [StringLength(60, ErrorMessage = "El apellido admite hasta 60 caracteres.")]
    public string? PaternalLastname { get; init; }

    [StringLength(60, ErrorMessage = "El apellido admite hasta 60 caracteres.")]
    public string? MaternalLastname { get; init; }

    [RegularExpression(@"^\d{4,15}$", ErrorMessage = "El documento del familiar debe tener solo dígitos.")]
    public string? DocumentNumber { get; init; }

    [Required(ErrorMessage = "La nacionalidad del familiar es obligatoria.")]
    public short? NationalityId { get; init; }
}

public sealed class PepPartnerRequest
{
    /// <summary>Código de /catalogs "Vinculo-Socio-PEP".</summary>
    [Required(ErrorMessage = "El vínculo con el socio es obligatorio.")]
    public string RelationshipCode { get; init; } = null!;

    [Required(ErrorMessage = "Los nombres del socio son obligatorios.")]
    [StringLength(100, ErrorMessage = "Los nombres admiten hasta 100 caracteres.")]
    public string Names { get; init; } = null!;

    [StringLength(60, ErrorMessage = "El apellido admite hasta 60 caracteres.")]
    public string? PaternalLastname { get; init; }

    [StringLength(60, ErrorMessage = "El apellido admite hasta 60 caracteres.")]
    public string? MaternalLastname { get; init; }

    [Required(ErrorMessage = "El cargo del socio es obligatorio.")]
    [StringLength(150, ErrorMessage = "El cargo admite hasta 150 caracteres.")]
    public string Position { get; init; } = null!;
}
