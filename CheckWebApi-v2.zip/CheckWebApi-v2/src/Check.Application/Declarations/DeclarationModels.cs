using Check.Domain.Contracts;

namespace Check.Application.Declarations;

/// <summary>Lo que hace falta del contrato para validar la declaración (datos descifrados).</summary>
public sealed record DeclarationContext(
    Guid ContractId, string Status, long PlanId, DateOnly InsuredBirthdate, string InsuredDocumentNumber, Guid ContractorPersonId);

/// <summary>Códigos válidos (activos). Beneficiarios: código → is_unique.</summary>
public sealed record DeclarationCatalogs(
    IReadOnlyDictionary<string, bool> BeneficiaryRelationships,
    IReadOnlySet<string> PepRelationships,
    IReadOnlySet<string> PartnerTypes,
    IReadOnlySet<short> Nationalities);

public interface IDeclarationRepository
{
    Task<DeclarationContext?> GetContextAsync(Guid contractId, CancellationToken ct);

    Task<DeclarationCatalogs> GetCatalogsAsync(CancellationToken ct);

    /// <summary>
    /// En una transacción: reemplaza los beneficiarios (los anteriores quedan inactivos), reemplaza la declaración PEP
    /// vigente del contratante (superseded_at) por la nueva, la vincula a sus filas del contrato y deja el contrato Declarado.
    /// </summary>
    Task SaveAsync(DeclarationContext context, IReadOnlyList<BeneficiaryData> beneficiaries, PepDeclarationData pep, CancellationToken ct);
}

public sealed record DeclarationsResponse(
    Guid ContractId, string Status, bool LegalHeirs, int Beneficiaries, bool IsPep, bool HasPepPartners);
