using Check.Application.Common;
using Check.Application.Plans;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Declarations;

/// <summary>
/// Beneficiarios y declaración PEP del contratante. Se acepta con el contrato Verificado (OTP) o Declarado
/// (para corregir antes de pagar). Deja el contrato Declarado.
/// </summary>
public sealed class DeclareUseCase(
    IDeclarationRepository declarations,
    IPlanRepository plans,
    TimeProvider time,
    ILogger<DeclareUseCase> logger)
{
    public async Task<Result<DeclarationsResponse>> ExecuteAsync(Guid contractId, DeclareRequest request, CancellationToken ct)
    {
        var context = await declarations.GetContextAsync(contractId, ct);
        if (context is null)
            return Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
        if (context.Status is not (ContractStatus.Verified or ContractStatus.Declared))
            return Error.Conflict("CONTRACT_INVALID_STATUS", $"No se pueden registrar las declaraciones con el contrato en estado {context.Status}.");

        var beneficiaries = request.Beneficiaries.Select(b => new BeneficiaryData(
            Code(b.RelationshipCode), Clean(b.DocumentNumber), b.Names.Trim(), Clean(b.PaternalLastname), Clean(b.MaternalLastname),
            b.Percentage!.Value)).ToList();
        var pep = ToPep(request.Pep);

        var catalogs = await declarations.GetCatalogsAsync(ct);
        var invalid = FindInvalidCodes(beneficiaries, pep, catalogs);
        if (invalid.Count > 0)
            return Error.Validation("INVALID_REFERENCES", $"Estos datos no corresponden a ninguna opción válida: {string.Join(", ", invalid)}.");

        var today = time.BoliviaToday();
        var terms = await plans.GetTermsAsync(context.PlanId, today, ct);
        var insuredIsMinor = Age(context.InsuredBirthdate, today) < NewContract.AdultAge;

        var error = DeclarationRules.ValidateBeneficiaries(beneficiaries, terms?.MaxBeneficiaries, insuredIsMinor,
                        context.InsuredDocumentNumber, catalogs.BeneficiaryRelationships)
                    ?? DeclarationRules.ValidatePep(pep, today);
        if (error is not null) return error;

        await declarations.SaveAsync(context, beneficiaries, pep, ct);
        logger.LogInformation("Contrato {ContractId} declarado: {Beneficiarios} beneficiarios, PEP {EsPep}, socios PEP {Socios}.",
            contractId, beneficiaries.Count, pep.IsPep, pep.HasPepPartners);

        return new DeclarationsResponse(contractId, ContractStatus.Declared, beneficiaries.Count == 0, beneficiaries.Count, pep.IsPep, pep.HasPepPartners);
    }

    private static PepDeclarationData ToPep(PepRequest p)
    {
        var isPep = p.IsPep!.Value;
        return new PepDeclarationData(
            isPep,
            p.HasPepPartners!.Value,
            // Si no es PEP, los datos del cargo no se guardan aunque lleguen.
            isPep ? Clean(p.Position) : null,
            isPep ? Clean(p.Institution) : null,
            isPep ? Clean(p.SourceFunds) : null,
            isPep ? p.ExerciseCountryId : null,
            isPep ? p.PeriodStart : null,
            isPep ? p.PeriodEnd : null,
            p.Relatives.Select(r => new PepRelativeData(Code(r.RelationshipCode), r.Names.Trim(), Clean(r.PaternalLastname),
                Clean(r.MaternalLastname), Clean(r.DocumentNumber), r.NationalityId!.Value)).ToList(),
            p.Partners.Select(x => new PepPartnerData(Code(x.RelationshipCode), x.Names.Trim(), Clean(x.PaternalLastname),
                Clean(x.MaternalLastname), x.Position.Trim())).ToList());
    }

    private static List<string> FindInvalidCodes(List<BeneficiaryData> beneficiaries, PepDeclarationData pep, DeclarationCatalogs catalogs)
    {
        var invalid = new List<string>();
        for (var i = 0; i < beneficiaries.Count; i++)
            if (!catalogs.BeneficiaryRelationships.ContainsKey(beneficiaries[i].RelationshipCode))
                invalid.Add($"beneficiaries[{i}].relationshipCode");
        if (pep.ExerciseCountryId is { } country && !catalogs.Nationalities.Contains(country))
            invalid.Add("pep.exerciseCountryId");
        for (var i = 0; i < pep.Relatives.Count; i++)
        {
            if (!catalogs.PepRelationships.Contains(pep.Relatives[i].RelationshipCode)) invalid.Add($"pep.relatives[{i}].relationshipCode");
            if (!catalogs.Nationalities.Contains(pep.Relatives[i].NationalityId)) invalid.Add($"pep.relatives[{i}].nationalityId");
        }
        for (var i = 0; i < pep.Partners.Count; i++)
            if (!catalogs.PartnerTypes.Contains(pep.Partners[i].RelationshipCode)) invalid.Add($"pep.partners[{i}].relationshipCode");
        return invalid;
    }

    private static int Age(DateOnly birthdate, DateOnly today)
    {
        var age = today.Year - birthdate.Year;
        return birthdate > today.AddYears(-age) ? age - 1 : age;
    }

    private static string Code(string value) => value.Trim().ToUpperInvariant();
    private static string? Clean(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
