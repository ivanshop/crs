namespace Check.Application.Common;

/// <summary>Quién ejecuta la acción, para created_by / updated_by (el "sub" del token).</summary>
public interface ICurrentUser
{
    string Name { get; }
}
