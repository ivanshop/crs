namespace Check.Application.Common;

/// <summary>Las fechas del negocio (edades, vigencias) se evalúan con la fecha de Bolivia (UTC-4), no la del servidor.</summary>
public static class BoliviaTime
{
    private static readonly TimeZoneInfo Zone = TimeZoneInfo.FindSystemTimeZoneById("America/La_Paz");

    public static DateOnly BoliviaToday(this TimeProvider time) =>
        DateOnly.FromDateTime(TimeZoneInfo.ConvertTime(time.GetUtcNow(), Zone).DateTime);
}
