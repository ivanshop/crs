namespace Check.Application.Common;

public sealed record AccessTokenResult(string Value, DateTimeOffset ExpiresAt);

/// <summary>Token corto que solo da acceso a un contrato (los pasos siguientes de la compra).</summary>
public interface IContractTokenService
{
    /// <summary>clientId: el cliente (check-web) que inició la compra; queda en created_by / updated_by.</summary>
    AccessTokenResult IssueForContract(Guid contractId, string clientId);
}
