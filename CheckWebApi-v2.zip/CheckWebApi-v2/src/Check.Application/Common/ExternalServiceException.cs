namespace Check.Application.Common;

/// <summary>Un servicio externo no respondió o respondió con error. El mensaje va al log, no al cliente.</summary>
public sealed class ExternalServiceException(string service, string message, Exception? inner = null)
    : Exception($"{service}: {message}", inner)
{
    public string Service { get; } = service;
}
