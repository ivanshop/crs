using System.ComponentModel.DataAnnotations;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Surveys;

public sealed class SubmitSurveyRequest
{
    [Required(ErrorMessage = "La calificación es obligatoria.")]
    [Range(SurveyTypes.MinScore, SurveyTypes.MaxScore, ErrorMessage = "La calificación debe ser de 1 a 10.")]
    public int? Score { get; init; }

    [StringLength(500, ErrorMessage = "El comentario admite hasta 500 caracteres.")]
    public string? Comment { get; init; }
}

public sealed record SurveyResponse(Guid ContractId, int Score);

public interface ISurveyRepository
{
    /// <summary>Estado del contrato y si ya respondió la encuesta. Null si el contrato no existe.</summary>
    Task<(string Status, bool Answered)?> GetAsync(Guid contractId, string type, CancellationToken ct);

    Task AddAsync(Guid contractId, string type, int score, string? comment, CancellationToken ct);
}

/// <summary>Encuesta opcional al final de la compra: una sola respuesta por contrato, con la póliza ya activa.</summary>
public sealed class SubmitSurveyUseCase(ISurveyRepository surveys, ILogger<SubmitSurveyUseCase> logger)
{
    public async Task<Result<SurveyResponse>> ExecuteAsync(Guid contractId, SubmitSurveyRequest request, CancellationToken ct)
    {
        var contract = await surveys.GetAsync(contractId, SurveyTypes.PurchaseExperience, ct);
        if (contract is null)
            return Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
        if (contract.Value.Status != ContractStatus.Active)
            return Error.Conflict("CONTRACT_INVALID_STATUS", "La encuesta se responde después de pagar el seguro.");
        if (contract.Value.Answered)
            return Error.Conflict("SURVEY_ALREADY_ANSWERED", "Ya respondiste la encuesta. ¡Gracias!");

        var comment = string.IsNullOrWhiteSpace(request.Comment) ? null : request.Comment.Trim();
        await surveys.AddAsync(contractId, SurveyTypes.PurchaseExperience, request.Score!.Value, comment, ct);
        logger.LogInformation("Encuesta del contrato {ContractId}: {Calificacion}/10.", contractId, request.Score);

        return new SurveyResponse(contractId, request.Score.Value);
    }
}
