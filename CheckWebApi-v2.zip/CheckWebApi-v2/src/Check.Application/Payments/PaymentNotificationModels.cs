using System.ComponentModel.DataAnnotations;

namespace Check.Application.Payments;

/// <summary>Aviso de pago del banco (formato provisional hasta conocer su API).</summary>
public sealed class PaymentNotificationRequest
{
    [Required(ErrorMessage = "El bankTransactionId es obligatorio.")]
    [StringLength(100, ErrorMessage = "El bankTransactionId admite hasta 100 caracteres.")]
    public string BankTransactionId { get; init; } = null!;

    [Required(ErrorMessage = "El monto es obligatorio.")]
    public decimal? Amount { get; init; }

    [Required(ErrorMessage = "La moneda es obligatoria.")]
    [AllowedValues("BOB", "USD", ErrorMessage = "La moneda debe ser BOB o USD.")]
    public string Currency { get; init; } = null!;

    /// <summary>Glosa: la misma que se envió al generar el QR.</summary>
    [Required(ErrorMessage = "La glosa es obligatoria.")]
    [StringLength(200, ErrorMessage = "La glosa admite hasta 200 caracteres.")]
    public string Description { get; init; } = null!;

    /// <summary>Momento del pago según el banco. Si no viene, se usa la hora de recepción.</summary>
    public DateTimeOffset? PaidAt { get; init; }
}

/// <summary>Result: Aplicado, Duplicado, Vencido, Monto Diferente o Desconocido.</summary>
public sealed record PaymentNotificationResponse(string Result, Guid? ContractId, string? ContractNumber);

/// <summary>QR buscado por el id de transacción del banco.</summary>
public sealed record QrPaymentInfo(
    Guid Id, Guid ContractId, decimal Amount, string Currency, string Status, DateTimeOffset ExpiresAt,
    long PlanId, string ProductCode, string? ContractNumber);

/// <summary>Activación de la póliza: QR Pagado, contrato Activo con número y cobertura, y sus eventos.</summary>
public sealed record PaymentActivation(
    Guid QrPaymentId, Guid ContractId, string BankTransactionId, string RawPayload, DateTimeOffset PaidAt,
    string ContractNumber, DateTimeOffset CoverageFrom, DateTimeOffset CoverageTo, string EventPayload);

/// <summary>Para la simulación del aviso: el QR pendiente de un contrato.</summary>
public sealed record PendingQr(string BankTransactionId, decimal Amount, string Currency, string ProductName, string PlanName);

public interface IPaymentNotificationRepository
{
    Task<QrPaymentInfo?> FindQrAsync(string bankTransactionId, CancellationToken ct);

    /// <summary>Guarda el aviso tal como llegó, con su resultado (todos los casos menos Aplicado).</summary>
    Task SaveNotificationAsync(Guid? qrPaymentId, string bankTransactionId, string rawPayload, string result, CancellationToken ct);

    /// <summary>
    /// En una transacción: guarda el aviso (Aplicado), QR Pagado, contrato Activo y eventos. Devuelve false si otro
    /// aviso ya lo aplicó en paralelo (el QR dejó de estar Pendiente); en ese caso no cambia nada.
    /// </summary>
    Task<bool> ActivateAsync(PaymentActivation activation, CancellationToken ct);

    Task<PendingQr?> GetPendingQrAsync(Guid contractId, CancellationToken ct);
}
