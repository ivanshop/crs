using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Check.Domain.Payments;
using Microsoft.Extensions.Logging;

namespace Check.Application.Payments;

/// <summary>
/// Genera el QR de pago por la prima congelada del contrato. Requiere Declarado; también PendientePago
/// para generar uno nuevo (por ejemplo, si venció): el anterior queda Reemplazado.
/// </summary>
public sealed class GenerateQrUseCase(
    IPaymentRepository payments,
    IBankQrClient bank,
    QrSettings settings,
    TimeProvider time,
    ILogger<GenerateQrUseCase> logger)
{
    public async Task<Result<QrResponse>> ExecuteAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await payments.GetQrContextAsync(contractId, ct);
        if (contract is null)
            return Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
        if (contract.Status is not (ContractStatus.Declared or ContractStatus.PendingPayment))
            return Error.Conflict("CONTRACT_INVALID_STATUS", $"No se puede generar el QR con el contrato en estado {contract.Status}.");
        if (contract.QrCount >= settings.MaxPerContract)
            return Error.BusinessRule("QR_LIMIT_EXCEEDED", $"Ya generaste {settings.MaxPerContract} códigos QR. Comunícate con nosotros para continuar.");

        var id = Guid.CreateVersion7();
        var description = QrDescription.For(contract.ProductName, contract.PlanName);

        var request = new QrRequest(id, contract.Premium, contract.Currency, description,
            time.GetUtcNow().AddMinutes(settings.LifetimeMinutes), settings.SingleUse);

        QrResult qr;
        try
        {
            qr = await bank.GenerateAsync(request, ct);
        }
        catch (ExternalServiceException ex)
        {
            logger.LogWarning(ex, "No se pudo generar el QR del contrato {ContractId}.", contractId);
            return Error.ExternalService("QR_UNAVAILABLE", "No pudimos generar el QR en este momento. Intenta nuevamente en unos minutos.");
        }

        await payments.SaveQrAsync(new NewQrPayment(id, contractId, qr.Amount, qr.Currency, qr.BankTransactionId, qr.ExpiresAt), ct);
        logger.LogInformation("QR {QrPaymentId} generado para el contrato {ContractId} por {Monto} {Moneda}.", id, contractId, qr.Amount, qr.Currency);

        return new QrResponse(id, QrPaymentStatus.Pending, $"data:image/png;base64,{qr.ImagePngBase64}",
            qr.Amount, qr.Currency, qr.Description, qr.ExpiresAt);
    }
}
