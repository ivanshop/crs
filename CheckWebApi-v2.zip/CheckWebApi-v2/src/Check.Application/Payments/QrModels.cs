namespace Check.Application.Payments;

/// <summary>Lo que se pide al banco. Description = glosa que verá el cliente en su app.</summary>
public sealed record QrRequest(Guid QrPaymentId, decimal Amount, string Currency, string Description, DateTimeOffset ExpiresAt, bool SingleUse);

/// <summary>Respuesta del banco: id de su transacción, imagen PNG en Base64 y los datos con que la generó.</summary>
public sealed record QrResult(string BankTransactionId, string ImagePngBase64, decimal Amount, string Currency, string Description, DateTimeOffset ExpiresAt);

/// <summary>API del banco que genera el QR (con certificado de cliente en el real).</summary>
public interface IBankQrClient
{
    Task<QrResult> GenerateAsync(QrRequest request, CancellationToken ct);
}

/// <summary>Sección "Qr" de appsettings.</summary>
public sealed class QrSettings
{
    public const string Section = "Qr";

    public int LifetimeMinutes { get; init; } = 30;
    public bool SingleUse { get; init; } = true;
    /// <summary>Máximo de QR por contrato (cada uno reemplaza al anterior).</summary>
    public int MaxPerContract { get; init; } = 5;
}

public sealed record QrContext(
    Guid ContractId, string Status, decimal Premium, string Currency, string ProductName, string PlanName, int QrCount);

public sealed record NewQrPayment(Guid Id, Guid ContractId, decimal Amount, string Currency, string BankTransactionId, DateTimeOffset ExpiresAt);

public interface IPaymentRepository
{
    Task<QrContext?> GetQrContextAsync(Guid contractId, CancellationToken ct);

    /// <summary>En una transacción: el QR pendiente anterior queda Reemplazado, se guarda el nuevo y el contrato pasa a PendientePago.</summary>
    Task SaveQrAsync(NewQrPayment qr, CancellationToken ct);
}

/// <summary>QrImage: data URI listo para un &lt;img src&gt;.</summary>
public sealed record QrResponse(
    Guid QrPaymentId, string Status, string QrImage, decimal Amount, string Currency, string Description, DateTimeOffset ExpiresAt);
