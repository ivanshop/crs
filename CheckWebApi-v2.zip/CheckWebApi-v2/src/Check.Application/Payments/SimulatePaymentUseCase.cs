using Check.Domain.Common;
using Check.Domain.Payments;

namespace Check.Application.Payments;

/// <summary>
/// Solo desarrollo: arma el aviso que enviaría el banco por el QR pendiente del contrato y lo procesa
/// con el mismo caso de uso que el aviso real.
/// </summary>
public sealed class SimulatePaymentUseCase(IPaymentNotificationRepository notifications, ProcessPaymentNotificationUseCase process)
{
    public async Task<Result<PaymentNotificationResponse>> ExecuteAsync(Guid contractId, decimal? amount, CancellationToken ct)
    {
        var qr = await notifications.GetPendingQrAsync(contractId, ct);
        if (qr is null)
            return Error.Conflict("QR_NOT_PENDING", "El contrato no tiene un QR pendiente de pago.");

        return await process.ExecuteAsync(new PaymentNotificationRequest
        {
            BankTransactionId = qr.BankTransactionId,
            Amount = amount ?? qr.Amount,
            Currency = qr.Currency,
            Description = QrDescription.For(qr.ProductName, qr.PlanName)
        }, ct);
    }
}
