using System.Text.Json;
using Check.Application.Common;
using Check.Application.Plans;
using Check.Domain.Payments;
using Microsoft.Extensions.Logging;

namespace Check.Application.Payments;

/// <summary>
/// Aviso de pago del banco. Siempre queda registrado (evidencia para conciliar). Si corresponde a un QR pendiente,
/// vigente y por el monto correcto, activa la póliza: número, cobertura desde el pago y eventos.
/// Al banco siempre se le responde OK con el resultado, para que no reintente un aviso ya procesado.
/// </summary>
public sealed class ProcessPaymentNotificationUseCase(
    IPaymentNotificationRepository notifications,
    IPlanRepository plans,
    TimeProvider time,
    ILogger<ProcessPaymentNotificationUseCase> logger)
{
    public async Task<PaymentNotificationResponse> ExecuteAsync(PaymentNotificationRequest request, CancellationToken ct)
    {
        var raw = JsonSerializer.Serialize(request, JsonSerializerOptions.Web);
        var paidAt = request.PaidAt ?? time.GetUtcNow();
        var qr = await notifications.FindQrAsync(request.BankTransactionId, ct);

        var result = qr switch
        {
            null => PaymentNotificationResult.Unknown,
            { Status: QrPaymentStatus.Paid } => PaymentNotificationResult.Duplicate,
            { Status: not QrPaymentStatus.Pending } => PaymentNotificationResult.Expired,
            _ when paidAt > qr.ExpiresAt => PaymentNotificationResult.Expired,
            _ when request.Amount != qr.Amount || request.Currency != qr.Currency => PaymentNotificationResult.AmountMismatch,
            _ => PaymentNotificationResult.Applied
        };

        if (result == PaymentNotificationResult.Applied)
        {
            var activation = await BuildActivationAsync(qr!, request.BankTransactionId, raw, paidAt, ct);
            if (await notifications.ActivateAsync(activation, ct))
            {
                logger.LogInformation("Pago aplicado: contrato {ContractId} activo con número {Numero}, cobertura hasta {Hasta:yyyy-MM-dd HH:mm}.",
                    qr!.ContractId, activation.ContractNumber, activation.CoverageTo);
                return new PaymentNotificationResponse(result, qr.ContractId, activation.ContractNumber);
            }
            result = PaymentNotificationResult.Duplicate; // otro aviso lo aplicó en paralelo
        }

        await notifications.SaveNotificationAsync(qr?.Id, request.BankTransactionId, raw, result, ct);
        logger.LogWarning("Aviso de pago {Transaccion} no aplicado: {Resultado} (contrato {ContractId}).",
            request.BankTransactionId, result, qr?.ContractId);
        return new PaymentNotificationResponse(result, qr?.ContractId, qr?.ContractNumber);
    }

    private async Task<PaymentActivation> BuildActivationAsync(QrPaymentInfo qr, string bankTransactionId, string raw, DateTimeOffset paidAt, CancellationToken ct)
    {
        // La duración sale de las reglas vigentes a la fecha del pago (DIAS_VIGENCIA).
        var terms = await plans.GetTermsAsync(qr.PlanId, DateOnly.FromDateTime(paidAt.UtcDateTime), ct);
        var days = terms?.DurationDays is > 0 ? terms.DurationDays.Value
            : throw new InvalidOperationException($"El plan {qr.PlanId} no tiene DIAS_VIGENCIA vigente: no se puede activar la póliza.");

        var number = ContractNumber.New(qr.ProductCode, DateOnly.FromDateTime(paidAt.UtcDateTime));
        var coverageTo = paidAt.AddDays(days);
        var payload = JsonSerializer.Serialize(new
        {
            contractId = qr.ContractId, contractNumber = number, planId = qr.PlanId, productCode = qr.ProductCode,
            amount = qr.Amount, currency = qr.Currency, paidAt, coverageFrom = paidAt, coverageTo
        }, JsonSerializerOptions.Web);

        return new PaymentActivation(qr.Id, qr.ContractId, bankTransactionId, raw, paidAt, number, paidAt, coverageTo, payload);
    }
}
