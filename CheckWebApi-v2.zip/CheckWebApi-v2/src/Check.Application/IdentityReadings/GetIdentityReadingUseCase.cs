using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Microsoft.Extensions.Logging;

namespace Check.Application.IdentityReadings;

/// <summary>
/// El front la consulta cada pocos segundos. Mientras siga Pendiente se pregunta a Llamita;
/// al terminar se guarda el resultado y ya no se vuelve a llamar.
/// </summary>
public sealed class GetIdentityReadingUseCase(
    IIdentityOcrClient ocr,
    IIdentityReadingRepository readings,
    IdentityReadingSettings settings,
    TimeProvider time,
    ILogger<GetIdentityReadingUseCase> logger)
{
    public async Task<Result<IdentityReadingResponse>> ExecuteAsync(Guid id, CancellationToken ct)
    {
        var reading = await readings.GetAsync(id, ct);
        var age = reading is null ? TimeSpan.Zero : time.GetUtcNow() - reading.CreatedAt;

        // Pasado el plazo no se devuelven los datos: son personales.
        if (reading is null || age > TimeSpan.FromMinutes(settings.ResultAvailableMinutes))
            return Error.NotFound("IDENTITY_READING_NOT_FOUND", "No se encontró la lectura del carnet o ya no está disponible.");

        if (reading.Status != IdentityReadingStatus.Pending)
            return new IdentityReadingResponse(id, reading.Status, reading.Fields);

        if (age > TimeSpan.FromSeconds(settings.TimeoutSeconds) || reading.ProviderDocumentId is null)
            return await FailAsync(id, $"Llamita no terminó en {settings.TimeoutSeconds} segundos.", ct);

        OcrResult result;
        try
        {
            result = await ocr.GetResultAsync(reading.ProviderDocumentId, ct);
        }
        catch (ExternalServiceException ex)
        {
            // Un fallo puntual no cierra la lectura: el front vuelve a consultar hasta el plazo.
            logger.LogWarning(ex, "No se pudo consultar la lectura de carnet {IdentityReadingId}; se reintentará.", id);
            return new IdentityReadingResponse(id, IdentityReadingStatus.Pending, null);
        }

        switch (result.Status)
        {
            case OcrStatus.Completed when result.Fields is not null:
                await readings.CompleteAsync(id, result.Fields, ct);
                logger.LogInformation("Lectura de carnet {IdentityReadingId} completada en {Segundos:0} s.", id, age.TotalSeconds);
                return new IdentityReadingResponse(id, IdentityReadingStatus.Completed, result.Fields);

            case OcrStatus.Completed:
            case OcrStatus.Failed:
                return await FailAsync(id, result.FailureReason ?? "Llamita no pudo leer el carnet.", ct);

            default:
                return new IdentityReadingResponse(id, IdentityReadingStatus.Pending, null);
        }
    }

    private async Task<Result<IdentityReadingResponse>> FailAsync(Guid id, string reason, CancellationToken ct)
    {
        await readings.FailAsync(id, reason, ct);
        logger.LogWarning("Lectura de carnet {IdentityReadingId} fallida: {Motivo}", id, reason);
        return new IdentityReadingResponse(id, IdentityReadingStatus.Failed, null);
    }
}
