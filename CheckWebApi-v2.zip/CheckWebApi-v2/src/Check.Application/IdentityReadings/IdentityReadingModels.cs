namespace Check.Application.IdentityReadings;

public enum ImageFormat { Jpeg, Png }

public sealed record IdentityImage(byte[] Content, ImageFormat Format);

/// <summary>Datos del carnet que precargan el formulario. Null = no se reconoció.</summary>
public sealed record IdentityFields(
    string? DocumentType,          // CI o CE
    string? DocumentNumber,
    string? Complement,
    string? Extension,             // LA, CB, SC...
    string? Names,
    string? PaternalLastname,
    string? MaternalLastname,
    DateOnly? Birthdate,
    string? BirthPlace,
    string? Address,
    string? Occupation,            // texto leído del carnet (no es el id de core.occupations)
    string? MaritalStatus,         // texto leído del carnet (no es el código de core.catalogs)
    DateOnly? IssuedAt,
    DateOnly? ExpiresAt,
    bool? IsMinor);

public sealed record IdentityReadingResponse(Guid Id, string Status, IdentityFields? Fields);

/// <summary>Sección "IdentityReading" de appsettings.</summary>
public sealed class IdentityReadingSettings
{
    public const string Section = "IdentityReading";

    public int MaxImageKb { get; init; } = 5120;
    /// <summary>Si el proveedor no termina en este tiempo, la lectura se da por fallida.</summary>
    public int TimeoutSeconds { get; init; } = 60;
    /// <summary>Minutos durante los que se puede consultar el resultado (datos personales).</summary>
    public int ResultAvailableMinutes { get; init; } = 30;
}
