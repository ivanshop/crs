namespace Check.Application.IdentityReadings;

public enum OcrStatus { Pending, Completed, Failed }

public sealed record OcrResult(OcrStatus Status, IdentityFields? Fields, string? FailureReason);

/// <summary>Servicio de lectura del carnet (Llamita). Sube las fotos y luego se consulta el resultado.</summary>
public interface IIdentityOcrClient
{
    /// <summary>¿Hay un workspace configurado para este producto?</summary>
    bool Supports(string productCode);

    /// <summary>Sube anverso y reverso. Devuelve el id del documento en el proveedor.</summary>
    Task<string> UploadAsync(string productCode, string name, IdentityImage front, IdentityImage back, CancellationToken ct);

    Task<OcrResult> GetResultAsync(string providerDocumentId, CancellationToken ct);
}

/// <summary>Almacén privado de las fotos del carnet. Devuelve la ruta relativa guardada.</summary>
public interface IIdentityImageStore
{
    Task<string> SaveAsync(Guid readingId, string side, IdentityImage image, CancellationToken ct);
}

public sealed record NewIdentityReading(
    Guid Id, string FrontImagePath, string BackImagePath, string? ProviderDocumentId,
    string Status, string? FailureReason, string? ClientIp);

public sealed record IdentityReadingRecord(
    Guid Id, string Status, string? ProviderDocumentId, IdentityFields? Fields, string? FailureReason, DateTimeOffset CreatedAt);

public interface IIdentityReadingRepository
{
    Task AddAsync(NewIdentityReading reading, CancellationToken ct);
    Task<IdentityReadingRecord?> GetAsync(Guid id, CancellationToken ct);
    /// <summary>Solo actualiza si sigue Pendiente (dos consultas simultáneas no se pisan).</summary>
    Task CompleteAsync(Guid id, IdentityFields fields, CancellationToken ct);
    Task FailAsync(Guid id, string reason, CancellationToken ct);
}
