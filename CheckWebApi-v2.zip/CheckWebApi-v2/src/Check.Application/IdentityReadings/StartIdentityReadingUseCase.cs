using Check.Application.Common;
using Check.Application.Plans;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Microsoft.Extensions.Logging;

namespace Check.Application.IdentityReadings;

/// <summary>
/// Guarda las fotos del carnet y las envía a Llamita. Responde enseguida con el id de la lectura;
/// el resultado se consulta con GetIdentityReadingUseCase.
/// </summary>
public sealed class StartIdentityReadingUseCase(
    IPlanRepository plans,
    IIdentityOcrClient ocr,
    IIdentityImageStore images,
    IIdentityReadingRepository readings,
    IdentityReadingSettings settings,
    ILogger<StartIdentityReadingUseCase> logger)
{
    public async Task<Result<IdentityReadingResponse>> ExecuteAsync(
        long planId, byte[] front, byte[] back, string? clientIp, CancellationToken ct)
    {
        var frontImage = ToImage(front, "anverso");
        if (frontImage.IsFailure) return frontImage.Error!;
        var backImage = ToImage(back, "reverso");
        if (backImage.IsFailure) return backImage.Error!;

        var plan = await plans.GetSummaryAsync(planId, ct);
        if (plan is null)
            return Error.NotFound("PLAN_NOT_FOUND", $"No existe un plan activo con el id {planId}.");
        if (!ocr.Supports(plan.ProductCode))
            return Error.BusinessRule("IDENTITY_READING_NOT_AVAILABLE", "La lectura del carnet no está disponible para este producto.");

        var id = Guid.CreateVersion7();
        var frontPath = await images.SaveAsync(id, "front", frontImage.Value, ct);
        var backPath = await images.SaveAsync(id, "back", backImage.Value, ct);

        try
        {
            var providerId = await ocr.UploadAsync(plan.ProductCode, $"{plan.ProductCode}-{plan.PlanCode}-{id}", frontImage.Value, backImage.Value, ct);
            await readings.AddAsync(new NewIdentityReading(id, frontPath, backPath, providerId, IdentityReadingStatus.Pending, null, clientIp), ct);

            logger.LogInformation("Lectura de carnet {IdentityReadingId} enviada a Llamita ({ProviderDocumentId}).", id, providerId);
            return new IdentityReadingResponse(id, IdentityReadingStatus.Pending, null);
        }
        catch (ExternalServiceException ex)
        {
            logger.LogWarning(ex, "No se pudo enviar la lectura de carnet {IdentityReadingId} a Llamita.", id);
            await readings.AddAsync(new NewIdentityReading(id, frontPath, backPath, null, IdentityReadingStatus.Failed, "No se pudo enviar a Llamita.", clientIp), ct);
            return Error.ExternalService("IDENTITY_READING_UNAVAILABLE", "No pudimos leer tu carnet en este momento. Completa tus datos manualmente.");
        }
    }

    /// <summary>Valida tamaño y formato por el contenido (firma del archivo), no por la extensión.</summary>
    private Result<IdentityImage> ToImage(byte[] content, string side)
    {
        if (content.Length == 0)
            return Error.Validation("IDENTITY_IMAGE_REQUIRED", $"Falta la foto del {side} del carnet.");
        if (content.Length > settings.MaxImageKb * 1024)
            return Error.Validation("IDENTITY_IMAGE_TOO_LARGE", $"La foto del {side} supera el tamaño permitido ({settings.MaxImageKb / 1024} MB).");

        ReadOnlySpan<byte> jpeg = [0xFF, 0xD8, 0xFF];
        ReadOnlySpan<byte> png = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
        if (content.AsSpan().StartsWith(jpeg)) return new IdentityImage(content, ImageFormat.Jpeg);
        if (content.AsSpan().StartsWith(png)) return new IdentityImage(content, ImageFormat.Png);

        return Error.Validation("IDENTITY_IMAGE_INVALID", $"La foto del {side} debe ser JPG o PNG.");
    }
}
