using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Otp;

/// <summary>Envía el código OTP al contratante. Solo con el contrato Validado (SEGIP aprobado).</summary>
public sealed class SendOtpUseCase(
    IOtpRepository otps,
    IOtpClient client,
    OtpSettings settings,
    TimeProvider time,
    ILogger<SendOtpUseCase> logger)
{
    public async Task<Result<SendOtpResponse>> ExecuteAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await otps.GetContractAsync(contractId, ct);
        if (contract is null)
            return Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
        if (contract.Status != ContractStatus.Validated)
            return Error.Conflict("CONTRACT_INVALID_STATUS", $"No se puede enviar el código con el contrato en estado {contract.Status}.");
        if (contract.Sends >= settings.MaxSends)
            return Error.BusinessRule("OTP_SENDS_EXCEEDED", $"Ya pediste {settings.MaxSends} códigos. Comunícate con nosotros para continuar.");

        var now = time.GetUtcNow();
        if (contract.LastSentAt is { } last && now < last.AddSeconds(settings.ResendSeconds))
        {
            var wait = (int)Math.Ceiling((last.AddSeconds(settings.ResendSeconds) - now).TotalSeconds);
            return Error.BusinessRule("OTP_RESEND_TOO_SOON", $"Espera {wait} segundos para pedir otro código.");
        }

        string sentTo;
        try
        {
            sentTo = await client.SendAsync(contract.Payer, ct);
        }
        catch (ExternalServiceException ex)
        {
            logger.LogWarning(ex, "No se pudo enviar el OTP del contrato {ContractId}.", contractId);
            return Error.ExternalService("OTP_UNAVAILABLE", "No pudimos enviarte el código en este momento. Intenta nuevamente en unos minutos.");
        }

        var expiresAt = now.AddMinutes(settings.LifetimeMinutes);
        await otps.AddChallengeAsync(contractId, contract.Payer, expiresAt, settings.MaxAttempts, ct);
        logger.LogInformation("OTP enviado para el contrato {ContractId} (envío {Envio} de {Maximo}).", contractId, contract.Sends + 1, settings.MaxSends);

        return new SendOtpResponse(sentTo, expiresAt, now.AddSeconds(settings.ResendSeconds), settings.MaxSends - contract.Sends - 1);
    }
}
