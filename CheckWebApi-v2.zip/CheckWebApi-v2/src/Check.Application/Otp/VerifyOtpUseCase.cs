using Check.Application.Common;
using Check.Domain.Common;
using Check.Domain.Contracts;
using Microsoft.Extensions.Logging;

namespace Check.Application.Otp;

/// <summary>Valida el código con el banco. Correcto → contrato Verificado.</summary>
public sealed class VerifyOtpUseCase(
    IOtpRepository otps,
    IOtpClient client,
    TimeProvider time,
    ILogger<VerifyOtpUseCase> logger)
{
    public async Task<Result<VerifyOtpResponse>> ExecuteAsync(Guid contractId, string code, CancellationToken ct)
    {
        var contract = await otps.GetContractAsync(contractId, ct);
        if (contract is null)
            return Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
        if (contract.Status != ContractStatus.Validated)
            return Error.Conflict("CONTRACT_INVALID_STATUS", $"No se puede verificar el código con el contrato en estado {contract.Status}.");

        var challenge = await otps.GetLatestChallengeAsync(contractId, ct);
        if (challenge is null)
            return Error.BusinessRule("OTP_NOT_SENT", "Primero pide el código.");
        if (challenge.IsVerified)
            return Error.Conflict("OTP_ALREADY_VERIFIED", "Este código ya fue verificado.");
        if (time.GetUtcNow() > challenge.ExpiresAt)
            return Error.BusinessRule("OTP_EXPIRED", "El código venció. Pide uno nuevo.");
        if (challenge.Attempts >= challenge.MaxAttempts)
            return Error.BusinessRule("OTP_ATTEMPTS_EXCEEDED", "Superaste los intentos para este código. Pide uno nuevo.");

        OtpValidation validation;
        try
        {
            validation = await client.ValidateAsync(code, contract.Payer.DocumentNumber, ct);
        }
        catch (ExternalServiceException ex)
        {
            // Un fallo del banco no consume intentos.
            logger.LogWarning(ex, "No se pudo validar el OTP del contrato {ContractId}.", contractId);
            return Error.ExternalService("OTP_UNAVAILABLE", "No pudimos validar el código en este momento. Intenta nuevamente en unos minutos.");
        }

        if (!validation.IsValid)
        {
            await otps.RegisterFailedAttemptAsync(challenge.Id, ct);
            var remaining = challenge.MaxAttempts - challenge.Attempts - 1;
            logger.LogWarning("OTP incorrecto para el contrato {ContractId} (quedan {Intentos} intentos).", contractId, remaining);
            return remaining > 0
                ? Error.Validation("OTP_INVALID", remaining == 1 ? "El código no es correcto. Te queda 1 intento." : $"El código no es correcto. Te quedan {remaining} intentos.")
                : Error.BusinessRule("OTP_ATTEMPTS_EXCEEDED", "El código no es correcto y superaste los intentos. Pide uno nuevo.");
        }

        await otps.VerifyAsync(challenge.Id, contractId, code, validation.ProviderHash, ct);
        logger.LogInformation("OTP verificado: contrato {ContractId} pasa a Verificado.", contractId);

        return new VerifyOtpResponse(contractId, ContractStatus.Verified);
    }
}
