using System.ComponentModel.DataAnnotations;

namespace Check.Application.Otp;

public sealed class VerifyOtpRequest
{
    [Required(ErrorMessage = "El código es obligatorio.")]
    [RegularExpression(@"^\d{4,8}$", ErrorMessage = "El código debe tener solo dígitos.")]
    public string Code { get; init; } = null!;
}
