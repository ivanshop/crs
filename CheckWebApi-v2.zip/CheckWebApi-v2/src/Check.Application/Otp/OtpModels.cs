namespace Check.Application.Otp;

/// <summary>A quién se envía el código: el contratante (o el asegurado si compra para sí mismo).</summary>
public sealed record OtpRecipient(string DocumentNumber, string Cellphone, string Email);

public sealed record OtpValidation(bool IsValid, string? ProviderHash, string? Description);

/// <summary>Servicio OTP del banco: genera, envía (SMS, correo y WhatsApp) y valida el código.</summary>
public interface IOtpClient
{
    /// <summary>Devuelve el texto para mostrar ("Código OTP enviado a SMS: XXXXXX27 ...").</summary>
    Task<string> SendAsync(OtpRecipient recipient, CancellationToken ct);

    Task<OtpValidation> ValidateAsync(string code, string documentNumber, CancellationToken ct);
}

/// <summary>Sección "Otp" de appsettings (reglas propias; las credenciales del banco van en Infrastructure).</summary>
public sealed class OtpSettings
{
    public const string Section = "Otp";

    public int LifetimeMinutes { get; init; } = 5;
    public int MaxAttempts { get; init; } = 3;
    /// <summary>Máximo de códigos que se pueden pedir por contrato.</summary>
    public int MaxSends { get; init; } = 5;
    public int ResendSeconds { get; init; } = 60;
}

public sealed record OtpContract(Guid ContractId, string Status, OtpRecipient Payer, int Sends, DateTimeOffset? LastSentAt);

public sealed record OtpChallengeRecord(long Id, DateTimeOffset ExpiresAt, int Attempts, int MaxAttempts, bool IsVerified);

public interface IOtpRepository
{
    /// <summary>Contrato con los datos del contratante (descifrados) y los envíos ya hechos. Null si no existe.</summary>
    Task<OtpContract?> GetContractAsync(Guid contractId, CancellationToken ct);

    Task AddChallengeAsync(Guid contractId, OtpRecipient recipient, DateTimeOffset expiresAt, int maxAttempts, CancellationToken ct);

    /// <summary>El último código enviado: es el único que vale.</summary>
    Task<OtpChallengeRecord?> GetLatestChallengeAsync(Guid contractId, CancellationToken ct);

    Task RegisterFailedAttemptAsync(long challengeId, CancellationToken ct);

    /// <summary>Marca el código como verificado (guarda su HMAC y el hash del banco) y el contrato como Verificado.</summary>
    Task VerifyAsync(long challengeId, Guid contractId, string code, string? providerHash, CancellationToken ct);
}

public sealed record SendOtpResponse(string SentTo, DateTimeOffset ExpiresAt, DateTimeOffset ResendAvailableAt, int RemainingSends);

public sealed record VerifyOtpResponse(Guid ContractId, string Status);
