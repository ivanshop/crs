using System.ComponentModel.DataAnnotations;

namespace Check.Application.Contracts;

public sealed class StartContractRequest
{
    [Required(ErrorMessage = "El planId es obligatorio.")]
    public long? PlanId { get; init; }

    /// <summary>Lectura del carnet con Llamita (opcional). Se vincula a la persona y se valida que el carnet no esté vencido.</summary>
    public Guid? IdentityReadingId { get; init; }

    [Required(ErrorMessage = "Los datos del asegurado son obligatorios.")]
    public PersonRequest Insured { get; init; } = null!;

    /// <summary>Solo si el asegurado es menor de edad: su padre o madre.</summary>
    public PersonRequest? Contractor { get; init; }

    /// <summary>Código de /catalogs "Parentesco-Contratante": P (padre) o M (madre). Solo con contratante.</summary>
    public string? ContractorRelationship { get; init; }
}

public sealed class PersonRequest
{
    [Required(ErrorMessage = "El tipo de documento es obligatorio.")]
    [AllowedValues("CI", "CE", ErrorMessage = "El tipo de documento debe ser CI o CE.")]
    public string DocumentType { get; init; } = null!;

    [Required(ErrorMessage = "El número de documento es obligatorio.")]
    [RegularExpression(@"^\d{4,15}$", ErrorMessage = "El número de documento debe tener solo dígitos (4 a 15).")]
    public string DocumentNumber { get; init; } = null!;

    [RegularExpression(@"^[0-9A-Za-z]{1,5}$", ErrorMessage = "El complemento solo admite letras y números (máximo 5).")]
    public string? Complement { get; init; }

    /// <summary>Código de /catalogs "Departamento" (LP, CB, SC...).</summary>
    [StringLength(5, ErrorMessage = "La extensión no es válida.")]
    public string? Extension { get; init; }

    [Required(ErrorMessage = "Los nombres son obligatorios.")]
    [StringLength(100, ErrorMessage = "Los nombres admiten hasta 100 caracteres.")]
    public string Names { get; init; } = null!;

    [StringLength(60, ErrorMessage = "El apellido paterno admite hasta 60 caracteres.")]
    public string? PaternalLastname { get; init; }

    [StringLength(60, ErrorMessage = "El apellido materno admite hasta 60 caracteres.")]
    public string? MaternalLastname { get; init; }

    [Required(ErrorMessage = "La fecha de nacimiento es obligatoria.")]
    public DateOnly? Birthdate { get; init; }

    [Required(ErrorMessage = "El género es obligatorio.")]
    [AllowedValues("Masculino", "Femenino", ErrorMessage = "El género debe ser Masculino o Femenino.")]
    public string Gender { get; init; } = null!;

    [Required(ErrorMessage = "La nacionalidad es obligatoria.")]
    public short? NationalityId { get; init; }

    [Required(ErrorMessage = "El lugar de nacimiento es obligatorio.")]
    [StringLength(150, ErrorMessage = "El lugar de nacimiento admite hasta 150 caracteres.")]
    public string BirthPlace { get; init; } = null!;

    [Required(ErrorMessage = "La dirección es obligatoria.")]
    [StringLength(200, ErrorMessage = "La dirección admite hasta 200 caracteres.")]
    public string Address { get; init; } = null!;

    [Required(ErrorMessage = "El número de celular es obligatorio.")]
    [RegularExpression(@"^\+?\d{7,15}$", ErrorMessage = "El número de celular no es válido.")]
    public string Cellphone { get; init; } = null!;

    [Required(ErrorMessage = "El correo electrónico es obligatorio.")]
    [EmailAddress(ErrorMessage = "El correo electrónico no es válido.")]
    [StringLength(120, ErrorMessage = "El correo admite hasta 120 caracteres.")]
    public string Email { get; init; } = null!;

    [Required(ErrorMessage = "El lugar de residencia es obligatorio.")]
    public short? CityId { get; init; }

    /// <summary>Código de /catalogs "Estado-Civil" (S, C, V, D).</summary>
    [Required(ErrorMessage = "El estado civil es obligatorio.")]
    public string MaritalStatus { get; init; } = null!;

    [Required(ErrorMessage = "La profesión u ocupación es obligatoria.")]
    public short? OccupationId { get; init; }
}
