using Check.Domain.Contracts;
using Check.Domain.People;

namespace Check.Application.Contracts;

public interface IContractRepository
{
    /// <summary>
    /// En una transacción: crea o actualiza las personas (por document_hash), el contrato, sus partes
    /// (Contratante y Asegurado, con la copia de sus datos) y vincula la lectura del carnet si hay.
    /// </summary>
    Task CreateAsync(NewContract contract, IdentityReadingLink? reading, string? clientIp, CancellationToken ct);
}

/// <summary>Lectura del carnet a vincular: de quién es el carnet leído.</summary>
public sealed record IdentityReadingLink(Guid ReadingId, bool IsContractor);

public interface IContractReferenceValidator
{
    /// <summary>Campos cuyo id o código no existe (o está inactivo) en los catálogos. Vacío = todo bien.</summary>
    Task<IReadOnlyList<string>> FindInvalidAsync(PersonalData person, string prefix, CancellationToken ct);
}
