namespace Check.Application.Contracts;

/// <summary>AccessToken solo sirve para este contrato: se usa en los pasos siguientes de la compra.</summary>
public sealed record StartContractResponse(Guid ContractId, string Status, string AccessToken);
