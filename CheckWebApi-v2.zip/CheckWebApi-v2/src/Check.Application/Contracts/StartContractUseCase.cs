using Check.Application.Common;
using Check.Application.IdentityReadings;
using Check.Application.Plans;
using Check.Domain.Common;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Domain.People;
using Microsoft.Extensions.Logging;

namespace Check.Application.Contracts;

/// <summary>Primer paso de la compra: registra personas y contrato (Iniciado) y devuelve el token del contrato.</summary>
public sealed class StartContractUseCase(
    IPlanRepository plans,
    IContractReferenceValidator references,
    IIdentityReadingRepository readings,
    IContractRepository contracts,
    IContractTokenService tokens,
    ICurrentUser user,
    TimeProvider time,
    ILogger<StartContractUseCase> logger)
{
    public async Task<Result<StartContractResponse>> ExecuteAsync(StartContractRequest request, string? clientIp, CancellationToken ct)
    {
        var today = time.BoliviaToday();

        var terms = await plans.GetTermsAsync(request.PlanId!.Value, today, ct);
        if (terms is null)
            return Error.NotFound("PLAN_NOT_FOUND", $"No existe un plan activo con el id {request.PlanId}.");

        var insured = ToPersonalData(request.Insured);
        var contractor = request.Contractor is null ? null : ToPersonalData(request.Contractor);

        var invalid = (await references.FindInvalidAsync(insured, "insured", ct)).ToList();
        if (contractor is not null) invalid.AddRange(await references.FindInvalidAsync(contractor, "contractor", ct));
        if (invalid.Count > 0)
            return Error.Validation("INVALID_REFERENCES", $"Estos datos no corresponden a ninguna opción válida: {string.Join(", ", invalid)}.");

        var started = NewContract.Start(terms, insured, contractor, request.ContractorRelationship, today);
        if (started.IsFailure) return started.Error!;
        var contract = started.Value;

        IdentityReadingLink? reading = null;
        if (request.IdentityReadingId is { } readingId)
        {
            var validated = await ValidateReadingAsync(readingId, contract, today, ct);
            if (validated.IsFailure) return validated.Error!;
            reading = validated.Value;
        }

        await contracts.CreateAsync(contract, reading, clientIp, ct);
        var token = tokens.IssueForContract(contract.Id, user.Name);

        logger.LogInformation("Contrato {ContractId} iniciado para el plan {PlanId} ({Tipo}).",
            contract.Id, contract.PlanId, contract.Contractor is null ? "para sí mismo" : "con contratante");

        return new StartContractResponse(contract.Id, contract.Status, token.Value);
    }

    /// <summary>La lectura debe estar completada, ser del asegurado o del contratante, y el carnet no debe estar vencido.</summary>
    private async Task<Result<IdentityReadingLink>> ValidateReadingAsync(Guid readingId, NewContract contract, DateOnly today, CancellationToken ct)
    {
        var reading = await readings.GetAsync(readingId, ct);
        if (reading is not { Status: IdentityReadingStatus.Completed, Fields: { } fields })
            return Error.Validation("IDENTITY_READING_INVALID", "La lectura del carnet no existe o no se completó.");

        var number = fields.DocumentNumber;
        var isInsured = number == contract.Insured.DocumentNumber;
        var isContractor = contract.Contractor is not null && number == contract.Contractor.DocumentNumber;
        if (!isInsured && !isContractor)
            return Error.Validation("IDENTITY_READING_MISMATCH", "El carnet leído no corresponde al asegurado ni al contratante.");

        if (fields.ExpiresAt is { } expiresAt && expiresAt < today)
            return Error.BusinessRule("DOCUMENT_EXPIRED", $"El carnet venció el {expiresAt:dd/MM/yyyy}. Renuévalo para contratar el seguro.");

        return new IdentityReadingLink(readingId, isContractor);
    }

    private static PersonalData ToPersonalData(PersonRequest p) => new(
        p.DocumentType.Trim().ToUpperInvariant(),
        p.DocumentNumber.Trim(),
        string.IsNullOrWhiteSpace(p.Complement) ? null : p.Complement.Trim().ToUpperInvariant(),
        string.IsNullOrWhiteSpace(p.Extension) ? null : p.Extension.Trim().ToUpperInvariant(),
        p.Names.Trim(),
        string.IsNullOrWhiteSpace(p.PaternalLastname) ? null : p.PaternalLastname.Trim(),
        string.IsNullOrWhiteSpace(p.MaternalLastname) ? null : p.MaternalLastname.Trim(),
        p.Birthdate!.Value,
        p.Gender,
        p.NationalityId!.Value,
        p.BirthPlace.Trim(),
        p.Address.Trim(),
        p.Cellphone.Trim(),
        p.Email.Trim().ToLowerInvariant(),
        p.CityId!.Value,
        p.MaritalStatus.Trim().ToUpperInvariant(),
        p.OccupationId!.Value);
}
