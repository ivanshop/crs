using Check.Domain.Common;

namespace Check.Application.Contracts;

/// <summary>Estado del contrato para el front: en qué paso va y, si está activo, su número y cobertura.</summary>
public sealed record ContractSummaryResponse(
    Guid ContractId,
    string Status,
    string? Number,
    string ProductName,
    string PlanName,
    decimal Premium,
    string Currency,
    DateTimeOffset? CoverageFrom,
    DateTimeOffset? CoverageTo,
    string? RejectionReason,
    QrSummaryResponse? Qr);

/// <summary>El último QR generado (el único que se puede pagar si está Pendiente).</summary>
public sealed record QrSummaryResponse(Guid QrPaymentId, string Status, DateTimeOffset ExpiresAt, DateTimeOffset? PaidAt);

public interface IContractQueries
{
    Task<ContractSummaryResponse?> GetSummaryAsync(Guid contractId, CancellationToken ct);
}

public sealed class GetContractUseCase(IContractQueries contracts)
{
    public async Task<Result<ContractSummaryResponse>> ExecuteAsync(Guid contractId, CancellationToken ct) =>
        await contracts.GetSummaryAsync(contractId, ct) is { } summary
            ? summary
            : Error.NotFound("CONTRACT_NOT_FOUND", "No se encontró el contrato.");
}
