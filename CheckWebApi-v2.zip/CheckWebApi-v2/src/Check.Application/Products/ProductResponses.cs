namespace Check.Application.Products;

public sealed record ProductResponse(
    string Code,
    string Name,
    string? Description,
    IReadOnlyList<PlanResponse> Plans);

/// <summary>Id: el planId que piden POST /contracts, POST /identity-readings y GET /plans/{id}/rules.</summary>
public sealed record PlanResponse(
    long Id,
    string Code,
    string Name,
    string? Description,
    MoneyResponse? Premium,
    IReadOnlyList<CoverageResponse> Coverages,
    IReadOnlyList<AssistanceResponse> Assistances);

public sealed record MoneyResponse(decimal Amount, string Currency);

public sealed record CoverageResponse(
    string Name,
    string Type,
    MoneyResponse? InsuredAmount,
    string Description,
    int WaitingPeriodDays);

public sealed record AssistanceResponse(
    string Name,
    string Service,
    string Description,
    int WaitingPeriodDays);
