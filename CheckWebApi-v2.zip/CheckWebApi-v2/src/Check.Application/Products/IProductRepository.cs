namespace Check.Application.Products;

public interface IProductRepository
{
    Task<IReadOnlyList<ProductResponse>> GetActiveAsync(CancellationToken ct);
}
