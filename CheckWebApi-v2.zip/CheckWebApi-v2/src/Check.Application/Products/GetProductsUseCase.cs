namespace Check.Application.Products;

public sealed class GetProductsUseCase(IProductRepository products, TimeProvider time)
{
    public Task<IReadOnlyList<ProductResponse>> ExecuteAsync(CancellationToken ct)
    {
        return products.GetActiveAsync(ct);
    }
}
