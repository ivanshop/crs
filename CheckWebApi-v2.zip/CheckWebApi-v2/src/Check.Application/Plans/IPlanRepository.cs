using Check.Domain.Offer;

namespace Check.Application.Plans;

public sealed record PlanSummary(long PlanId, string PlanCode, string ProductCode);

public interface IPlanRepository
{
    /// <summary>Plan activo con sus reglas activas. Null si el plan no existe o no está activo.</summary>
    Task<PlanRulesResponse?> GetRulesAsync(long planId, CancellationToken ct);

    /// <summary>Plan activo de un producto activo. Null si no existe.</summary>
    Task<PlanSummary?> GetSummaryAsync(long planId, CancellationToken ct);

    /// <summary>Prima, moneda y edades del plan con sus reglas activas y vigentes a <paramref name="date"/>. Null si el plan no está activo.</summary>
    Task<PlanTerms?> GetTermsAsync(long planId, DateOnly date, CancellationToken ct);
}
