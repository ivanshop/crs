using Check.Domain.Common;

namespace Check.Application.Plans;

public sealed class GetPlanRulesUseCase(IPlanRepository plans)
{
    public async Task<Result<PlanRulesResponse>> ExecuteAsync(long planId, CancellationToken ct)
    {
        var rules = await plans.GetRulesAsync(planId, ct);
        return rules is null
            ? Error.NotFound("PLAN_NOT_FOUND", $"No existe un plan activo con el id {planId}.")
            : rules;
    }
}
