using Check.Domain.Common;

namespace Check.Application.Plans;

public sealed record PlanRulesResponse(
    long PlanId,
    string PlanCode,
    string PlanName,
    IReadOnlyList<RuleResponse> Rules);

public sealed record RuleResponse(
    string Code,
    string Name,
    DataType DataType,
    string Value);
