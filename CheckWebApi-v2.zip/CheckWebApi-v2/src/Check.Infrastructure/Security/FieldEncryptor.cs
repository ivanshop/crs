using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.Security;

public sealed class EncryptionOptions
{
    public const string Section = "Encryption";

    /// <summary>Llave AES-256 en Base64 (32 bytes). En producción viene de Azure Key Vault.</summary>
    public string DataKey { get; init; } = null!;

    /// <summary>Llave HMAC-SHA256 en Base64 para los hashes de búsqueda (document_hash).</summary>
    public string HashKey { get; init; } = null!;
}

/// <summary>
/// Cifra los datos personales de las columnas bytea con AES-256-GCM.
/// Formato: nonce (12) | tag (16) | texto cifrado.
/// </summary>
public sealed class FieldEncryptor
{
    private const int NonceSize = 12;
    private const int TagSize = 16;
    private readonly byte[] _key;
    private readonly byte[] _hashKey;

    public FieldEncryptor(IOptions<EncryptionOptions> options)
    {
        _key = Convert.FromBase64String(options.Value.DataKey ?? "");
        _hashKey = Convert.FromBase64String(options.Value.HashKey ?? "");
        if (_key.Length != 32)
            throw new InvalidOperationException("Encryption:DataKey debe ser una llave de 32 bytes en Base64.");
        if (_hashKey.Length < 32)
            throw new InvalidOperationException("Encryption:HashKey debe ser una llave de al menos 32 bytes en Base64.");
    }

    public byte[] Encrypt(string plain)
    {
        var data = Encoding.UTF8.GetBytes(plain);
        var output = new byte[NonceSize + TagSize + data.Length];
        var nonce = output.AsSpan(0, NonceSize);
        RandomNumberGenerator.Fill(nonce);

        using var aes = new AesGcm(_key, TagSize);
        aes.Encrypt(nonce, data, output.AsSpan(NonceSize + TagSize), output.AsSpan(NonceSize, TagSize));
        return output;
    }

    public string Decrypt(byte[] cipher)
    {
        var plain = new byte[cipher.Length - NonceSize - TagSize];
        using var aes = new AesGcm(_key, TagSize);
        aes.Decrypt(cipher.AsSpan(0, NonceSize), cipher.AsSpan(NonceSize + TagSize), cipher.AsSpan(NonceSize, TagSize), plain);
        return Encoding.UTF8.GetString(plain);
    }

    /// <summary>HMAC-SHA256 con llave secreta, para buscar sin descifrar (ej. people.document_hash).</summary>
    public byte[] Hash(string value) => HMACSHA256.HashData(_hashKey, Encoding.UTF8.GetBytes(value));
}
