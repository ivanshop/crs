using Check.Application.Catalogs;
using Check.Application.Common;
using Check.Application.Contracts;
using Check.Application.Declarations;
using Check.Application.IdentityReadings;
using Check.Application.Otp;
using Check.Application.Payments;
using Check.Application.Plans;
using Check.Application.Products;
using Check.Application.Screening;
using Check.Application.Surveys;
using Check.Infrastructure.ExternalServices.BankQr;
using Check.Infrastructure.ExternalServices.Llamita;
using Check.Infrastructure.ExternalServices.Otp;
using Check.Infrastructure.ExternalServices.Segip;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Repositories;
using Check.Infrastructure.Security;
using Check.Infrastructure.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Check");
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new InvalidOperationException("Falta la cadena de conexión 'ConnectionStrings:Check'.");

        // Seguridad
        services.AddOptions<JwtOptions>().Bind(configuration.GetSection(JwtOptions.Section)).ValidateOnStart();
        services.AddOptions<EncryptionOptions>().Bind(configuration.GetSection(EncryptionOptions.Section));
        services.AddSingleton<JwtTokenFactory>();
        services.AddSingleton<IContractTokenService>(sp => sp.GetRequiredService<JwtTokenFactory>());
        services.AddSingleton<FieldEncryptor>();

        // Persistencia
        services.AddDbContext<CheckDbContext>(o => o.UseNpgsql(connectionString));
        services.AddScoped<ICatalogRepository, CatalogRepository>();
        services.AddScoped<IProductRepository, ProductRepository>();
        services.AddScoped<IPlanRepository, PlanRepository>();
        services.AddScoped<IIdentityReadingRepository, IdentityReadingRepository>();
        services.AddScoped<IContractRepository, ContractRepository>();
        services.AddScoped<IContractQueries, ContractQueries>();
        services.AddScoped<IContractReferenceValidator, ContractReferenceValidator>();
        services.AddScoped<IScreeningRepository, ScreeningRepository>();
        services.AddScoped<IOtpRepository, OtpRepository>();
        services.AddScoped<IDeclarationRepository, DeclarationRepository>();
        services.AddScoped<IPaymentRepository, PaymentRepository>();
        services.AddScoped<IPaymentNotificationRepository, PaymentNotificationRepository>();
        services.AddScoped<ISurveyRepository, SurveyRepository>();

        // Lectura del carnet: fotos locales + Llamita
        services.AddSingleton(configuration.GetSection(IdentityReadingSettings.Section).Get<IdentityReadingSettings>() ?? new());
        services.AddOptions<StorageOptions>().Bind(configuration.GetSection(StorageOptions.Section));
        services.AddSingleton<IIdentityImageStore, LocalIdentityImageStore>();
        AddLlamita(services, configuration);

        // Validaciones externas
        services.AddSingleton(configuration.GetSection(ScreeningSettings.Section).Get<ScreeningSettings>() ?? new());
        AddSegip(services, configuration);

        // OTP del banco
        services.AddSingleton(configuration.GetSection(OtpSettings.Section).Get<OtpSettings>() ?? new());
        AddOtp(services, configuration);

        // QR de pago del banco (por ahora solo el falso; el real usará certificado de cliente)
        services.AddSingleton(configuration.GetSection(QrSettings.Section).Get<QrSettings>() ?? new());
        services.AddOptions<BankQrOptions>().Bind(configuration.GetSection(BankQrOptions.Section));
        services.AddSingleton<IBankQrClient, FakeBankQrClient>();

        return services;
    }

    private static void AddLlamita(IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<LlamitaOptions>().Bind(configuration.GetSection(LlamitaOptions.Section));

        if (configuration.GetValue<bool>($"{LlamitaOptions.Section}:UseFake"))
        {
            services.AddSingleton<IIdentityOcrClient, FakeLlamitaClient>();
            return;
        }

        services.AddHttpClient<IIdentityOcrClient, LlamitaClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<LlamitaOptions>>().Value;
            if (string.IsNullOrWhiteSpace(o.ApiKey))
                throw new InvalidOperationException("Falta Llamita:ApiKey (user-secrets en desarrollo, Key Vault en producción).");

            http.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
            http.Timeout = TimeSpan.FromSeconds(o.TimeoutSeconds);
            http.DefaultRequestHeaders.Add("X-Api-Key", o.ApiKey);
            http.DefaultRequestHeaders.Add("x-tenant", o.Tenant);
        });
    }

    private static void AddSegip(IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<SegipOptions>().Bind(configuration.GetSection(SegipOptions.Section));

        if (configuration.GetValue<bool>($"{SegipOptions.Section}:UseFake"))
        {
            services.AddSingleton<ISegipClient, FakeSegipClient>();
            return;
        }

        services.AddHttpClient<ISegipClient, SegipClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<SegipOptions>>().Value;
            if (o.InstitutionCode == 0 || string.IsNullOrWhiteSpace(o.User) || string.IsNullOrWhiteSpace(o.Password) || string.IsNullOrWhiteSpace(o.EndUserAccessKey))
                throw new InvalidOperationException("Faltan las credenciales de SEGIP (Segip:InstitutionCode, User, Password, EndUserAccessKey).");

            http.BaseAddress = new Uri(o.Url);
            http.Timeout = TimeSpan.FromSeconds(o.TimeoutSeconds);
        });
    }

    private static void AddOtp(IServiceCollection services, IConfiguration configuration)
    {
        services.AddOptions<OtpOptions>().Bind(configuration.GetSection(OtpOptions.Section));

        if (configuration.GetValue<bool>($"{OtpOptions.Section}:UseFake"))
        {
            services.AddSingleton<IOtpClient, FakeOtpClient>();
            return;
        }

        services.AddHttpClient<IOtpClient, OtpClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<OtpOptions>>().Value;
            if (string.IsNullOrWhiteSpace(o.BaseUrl) || string.IsNullOrWhiteSpace(o.Application) ||
                string.IsNullOrWhiteSpace(o.Channel) || string.IsNullOrWhiteSpace(o.Password))
                throw new InvalidOperationException("Faltan los datos del servicio OTP (Otp:BaseUrl, Application, Channel, Password).");

            http.BaseAddress = new Uri(o.BaseUrl.TrimEnd('/') + "/");
            http.Timeout = TimeSpan.FromSeconds(o.TimeoutSeconds);
        });
    }
}
