using Check.Application.IdentityReadings;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.Storage;

public sealed class StorageOptions
{
    public const string Section = "Storage";
    public string IdentityImagesPath { get; init; } = "data/identity";
}

/// <summary>
/// Guarda las fotos del carnet en una carpeta privada del servidor: {año}/{mes}/{lectura}_{lado}.{ext}.
/// Para Azure Blob Storage basta otra implementación de IIdentityImageStore.
/// </summary>
internal sealed class LocalIdentityImageStore(IOptions<StorageOptions> options, TimeProvider time) : IIdentityImageStore
{
    public async Task<string> SaveAsync(Guid readingId, string side, IdentityImage image, CancellationToken ct)
    {
        var now = time.GetUtcNow();
        var extension = image.Format == ImageFormat.Png ? "png" : "jpg";
        var relative = $"{now:yyyy}/{now:MM}/{readingId:N}_{side}.{extension}";
        var full = Path.Combine(Path.GetFullPath(options.Value.IdentityImagesPath), relative);

        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllBytesAsync(full, image.Content, ct);
        return relative;
    }
}
