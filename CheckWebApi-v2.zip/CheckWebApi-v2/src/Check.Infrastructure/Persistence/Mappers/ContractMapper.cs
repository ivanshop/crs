using Check.Domain.People;
using Check.Infrastructure.Persistence.Check.Entities;
using Check.Infrastructure.Security;

namespace Check.Infrastructure.Persistence.Mappers;

/// <summary>Datos del formulario (Domain) → filas de core.people y sales.contract_parties, con los datos personales cifrados.</summary>
internal static class ContractMapper
{
    private const string DateFormat = "yyyy-MM-dd";

    /// <summary>Copia los datos actuales de la persona (alta o actualización).</summary>
    public static void ApplyTo(this PersonalData data, Person person, FieldEncryptor crypto)
    {
        person.DocumentType = data.DocumentType;
        person.DocumentNumber = crypto.Encrypt(data.DocumentNumber);
        person.DocumentComplement = Encrypt(crypto, data.Complement);
        person.DocumentExtension = data.Extension;
        person.DocumentHash = crypto.Hash(data.DocumentKey);
        person.Names = crypto.Encrypt(data.Names);
        person.PaternalLastname = Encrypt(crypto, data.PaternalLastname);
        person.MaternalLastname = Encrypt(crypto, data.MaternalLastname);
        person.Birthdate = crypto.Encrypt(data.Birthdate.ToString(DateFormat));
        person.BirthPlace = crypto.Encrypt(data.BirthPlace);
        person.Gender = data.Gender;
        person.NationalityId = data.NationalityId;
        person.Address = crypto.Encrypt(data.Address);
        person.Cellphone = crypto.Encrypt(data.Cellphone);
        person.Email = crypto.Encrypt(data.Email);
        person.CityId = data.CityId;
        person.MaritalStatus = data.MaritalStatus;
        person.OccupationId = data.OccupationId;
        person.IsActive = true;
    }

    /// <summary>Copia (snapshot) de la persona tal como contrató. Ciudad, ocupación y estado civil van con su nombre.</summary>
    public static ContractParty ToParty(this PersonalData data, Guid contractId, Guid personId, string role,
        PartyNames names, long? relationshipId, FieldEncryptor crypto, string user) => new()
    {
        ContractId = contractId,
        PersonId = personId,
        Role = role,
        RelationshipId = relationshipId,
        DocumentNumber = crypto.Encrypt(data.DocumentNumber),
        DocumentComplement = Encrypt(crypto, data.Complement),
        DocumentExtension = data.Extension,
        Names = crypto.Encrypt(data.Names),
        PaternalLastname = Encrypt(crypto, data.PaternalLastname),
        MaternalLastname = Encrypt(crypto, data.MaternalLastname),
        Birthdate = crypto.Encrypt(data.Birthdate.ToString(DateFormat)),
        BirthPlace = crypto.Encrypt(data.BirthPlace),
        Address = crypto.Encrypt(data.Address),
        Cellphone = crypto.Encrypt(data.Cellphone),
        Email = crypto.Encrypt(data.Email),
        Gender = data.Gender,
        NationalityId = data.NationalityId,
        City = names.City,
        Occupation = names.Occupation,
        MaritalStatus = names.MaritalStatus,
        IsActive = true,
        CreatedBy = user
    };

    private static byte[]? Encrypt(FieldEncryptor crypto, string? value) =>
        string.IsNullOrEmpty(value) ? null : crypto.Encrypt(value);
}

/// <summary>Nombres legibles para el snapshot de contract_parties.</summary>
internal sealed record PartyNames(string City, string Occupation, string MaritalStatus);
