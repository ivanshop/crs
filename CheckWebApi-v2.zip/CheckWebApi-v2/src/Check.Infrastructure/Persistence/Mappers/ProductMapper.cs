using Check.Application.Products;
using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Infrastructure.Persistence.Check.Entities;

namespace Check.Infrastructure.Persistence.Mappers;

/// <summary>Entidades de BD (scaffold) → respuestas de ProductRepository.</summary>
internal static class ProductMapper
{
    public static ProductResponse ToResponse(this Product product) => new(
        product.Code,
        product.Name,
        product.Description,
        product.Plans.OrderBy(pl => pl.Id).Select(ToResponse).ToList());

    public static PlanResponse ToResponse(this Plan plan)
    {
        var rules = plan.SubscriptionRules.CurrentValues();
        var amount = rules.GetValueOrDefault(RuleCodes.PremiumAmount).AsDecimal();
        var currency = rules.GetValueOrDefault(RuleCodes.PremiumCurrency);

        return new PlanResponse(
            plan.Id,
            plan.Code,
            plan.Name,
            plan.Description,
            amount is null || currency is null ? null : new MoneyResponse(amount.Value, currency),
            plan.Coverages.Select(ToResponse).ToList(),
            plan.Assistances.Select(ToResponse).ToList());
    }

    public static CoverageResponse ToResponse(this Coverage coverage) => new(
        coverage.Name,
        coverage.Type,
        coverage.InsuredAmount is { } amount ? new MoneyResponse(amount, coverage.Currency!) : null,
        coverage.Description,
        coverage.WaitingPeriod);

    public static AssistanceResponse ToResponse(this Assistance assistance) => new(
        assistance.Name,
        assistance.Service,
        assistance.Description,
        assistance.WaitingPeriod);

    /// <summary>Código de regla → valor. Si hubiera dos vigentes, gana la de valid_from más reciente.</summary>
    private static Dictionary<string, string> CurrentValues(this IEnumerable<SubscriptionRule> rules) =>
        rules.GroupBy(r => r.Definition.Code, StringComparer.OrdinalIgnoreCase)
             .ToDictionary(g => g.Key, g => g.MaxBy(r => r.ValidFrom)!.Value, StringComparer.OrdinalIgnoreCase);
}
