using System.Linq.Expressions;
using Check.Application.Catalogs;
using Check.Infrastructure.Persistence.Check.Entities;

namespace Check.Infrastructure.Persistence.Mappers;

/// <summary>
/// Entidades de BD (scaffold) → respuestas de CatalogRepository.
/// Son expresiones para que EF las traduzca a SQL y lea solo las columnas necesarias.
/// </summary>
internal static class CatalogMapper
{
    public static readonly Expression<Func<Nationality, NationalityResponse>> ToNationality =
        n => new NationalityResponse(n.Id, n.Iso, n.Name, n.Country);

    public static readonly Expression<Func<Occupation, OccupationResponse>> ToOccupation =
        o => new OccupationResponse(o.Id, o.Code, o.Type, o.Name, o.Profession);

    public static readonly Expression<Func<City, CityResponse>> ToCity =
        c => new CityResponse(c.Id, c.Name, c.Province, c.Department);

    public static readonly Expression<Func<Relationship, RelationshipResponse>> ToRelationship =
        r => new RelationshipResponse(r.Id, r.Code, r.Name);
}
