using Check.Application.Plans;
using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Infrastructure.Persistence.Check.Entities;

namespace Check.Infrastructure.Persistence.Mappers;

/// <summary>Entidades de BD (scaffold) → respuestas de PlanRepository.</summary>
internal static class PlanMapper
{
    public static PlanRulesResponse ToRulesResponse(this Plan plan) => new(
        plan.Id,
        plan.Code,
        plan.Name,
        plan.SubscriptionRules
            // Si hubiera dos vigentes del mismo código, gana la de valid_from más reciente.
            .GroupBy(r => r.Definition.Code, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.MaxBy(r => r.ValidFrom)!.ToResponse())
            .OrderBy(r => r.Code)
            .ToList());

    /// <summary>
    /// Convierte el texto de subscription_rules.value al tipo de rule_definitions.data_type.
    /// Un tipo o valor inválido es un error de configuración: se lanza para que quede en el log.
    /// </summary>
    public static RuleResponse ToResponse(this SubscriptionRule rule)
    {
        var definition = rule.Definition;
        var type = definition.DataType.ToDataType()
            ?? throw new InvalidOperationException($"La regla {definition.Code} tiene un data_type desconocido: '{definition.DataType}'.");
        return new RuleResponse(definition.Code, definition.Name, type, rule.Value);
    }

    /// <summary>Reglas vigentes → condiciones de venta. Si hubiera dos del mismo código, gana la de valid_from más reciente.</summary>
    public static PlanTerms ToTerms(this Plan plan)
    {
        var values = plan.SubscriptionRules
            .GroupBy(r => r.Definition.Code, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.MaxBy(r => r.ValidFrom)!.Value, StringComparer.OrdinalIgnoreCase);

        return new PlanTerms(
            plan.Id,
            values.GetValueOrDefault(RuleCodes.PremiumAmount).AsDecimal(),
            values.GetValueOrDefault(RuleCodes.PremiumCurrency),
            values.GetValueOrDefault(RuleCodes.MinAge).AsInteger(),
            values.GetValueOrDefault(RuleCodes.MaxAge).AsInteger(),
            values.GetValueOrDefault(RuleCodes.MaxBeneficiaries).AsInteger(),
            values.GetValueOrDefault(RuleCodes.DurationDays).AsInteger());
    }
}
