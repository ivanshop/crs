﻿using System;
using System.Collections.Generic;
using Check.Infrastructure.Persistence.Check.Entities;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Check;

public partial class CheckDbContext : DbContext
{
    public CheckDbContext(DbContextOptions<CheckDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Agency> Agencies { get; set; }

    public virtual DbSet<Agent> Agents { get; set; }

    public virtual DbSet<Assistance> Assistances { get; set; }

    public virtual DbSet<Beneficiary> Beneficiaries { get; set; }

    public virtual DbSet<Catalog> Catalogs { get; set; }

    public virtual DbSet<City> Cities { get; set; }

    public virtual DbSet<Consent> Consents { get; set; }

    public virtual DbSet<Contract> Contracts { get; set; }

    public virtual DbSet<ContractDetail> ContractDetails { get; set; }

    public virtual DbSet<ContractEvent> ContractEvents { get; set; }

    public virtual DbSet<ContractFieldDefinition> ContractFieldDefinitions { get; set; }

    public virtual DbSet<ContractParty> ContractParties { get; set; }

    public virtual DbSet<Coverage> Coverages { get; set; }

    public virtual DbSet<Exclusion> Exclusions { get; set; }

    public virtual DbSet<Faq> Faqs { get; set; }

    public virtual DbSet<IdentityReading> IdentityReadings { get; set; }

    public virtual DbSet<Nationality> Nationalities { get; set; }

    public virtual DbSet<Occupation> Occupations { get; set; }

    public virtual DbSet<OtpChallenge> OtpChallenges { get; set; }

    public virtual DbSet<PaymentNotification> PaymentNotifications { get; set; }

    public virtual DbSet<PepDeclaration> PepDeclarations { get; set; }

    public virtual DbSet<PepPartner> PepPartners { get; set; }

    public virtual DbSet<PepRelative> PepRelatives { get; set; }

    public virtual DbSet<Person> People { get; set; }

    public virtual DbSet<Plan> Plans { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<QrPayment> QrPayments { get; set; }

    public virtual DbSet<Relationship> Relationships { get; set; }

    public virtual DbSet<RuleDefinition> RuleDefinitions { get; set; }

    public virtual DbSet<Screening> Screenings { get; set; }

    public virtual DbSet<ScreeningException> ScreeningExceptions { get; set; }

    public virtual DbSet<ScreeningItem> ScreeningItems { get; set; }

    public virtual DbSet<SubscriptionRule> SubscriptionRules { get; set; }

    public virtual DbSet<SurveyResponse> SurveyResponses { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("Npgsql:CollationDefinition:core.ci_ai", "und-u-ks-level1,und-u-ks-level1,icu,False");

        modelBuilder.Entity<Agency>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("agencies_pkey");

            entity.ToTable("agencies", "core");

            entity.HasIndex(e => e.Code, "agencies_code_uk").IsUnique();

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Email)
                .UseCollation("ci_ai")
                .HasColumnName("email");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.LicenseNumber)
                .UseCollation("ci_ai")
                .HasColumnName("license_number");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.Phone)
                .UseCollation("ci_ai")
                .HasColumnName("phone");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<Agent>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("agents_pkey");

            entity.ToTable("agents", "core");

            entity.HasIndex(e => new { e.AgencyId, e.PersonId }, "agents_agency_person_uk").IsUnique();

            entity.HasIndex(e => e.Code, "agents_code_uk").IsUnique();

            entity.HasIndex(e => e.PersonId, "agents_person_idx");

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.AgencyId).HasColumnName("agency_id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.LicenseNumber)
                .UseCollation("ci_ai")
                .HasColumnName("license_number");
            entity.Property(e => e.PersonId).HasColumnName("person_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.ValidFrom).HasColumnName("valid_from");
            entity.Property(e => e.ValidTo).HasColumnName("valid_to");

            entity.HasOne(d => d.Agency).WithMany(p => p.Agents)
                .HasForeignKey(d => d.AgencyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("agents_agency_id_fkey");

            entity.HasOne(d => d.Person).WithMany(p => p.Agents)
                .HasForeignKey(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("agents_person_id_fkey");
        });

        modelBuilder.Entity<Assistance>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("assistances_pkey");

            entity.ToTable("assistances", "offer");

            entity.HasIndex(e => e.PlanId, "assistances_plan_idx").HasFilter("is_active");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Description)
                .UseCollation("ci_ai")
                .HasColumnName("description");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.PlanId).HasColumnName("plan_id");
            entity.Property(e => e.Service)
                .UseCollation("ci_ai")
                .HasColumnName("service");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.WaitingPeriod).HasColumnName("waiting_period");

            entity.HasOne(d => d.Plan).WithMany(p => p.Assistances)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("assistances_plan_id_fkey");
        });

        modelBuilder.Entity<Beneficiary>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("beneficiaries_pkey");

            entity.ToTable("beneficiaries", "sales");

            entity.HasIndex(e => e.ContractId, "beneficiaries_contract_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DocumentNumber).HasColumnName("document_number");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.MaternalLastname).HasColumnName("maternal_lastname");
            entity.Property(e => e.Names).HasColumnName("names");
            entity.Property(e => e.PaternalLastname).HasColumnName("paternal_lastname");
            entity.Property(e => e.Percentage)
                .HasPrecision(5, 2)
                .HasColumnName("percentage");
            entity.Property(e => e.RelationshipId).HasColumnName("relationship_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Contract).WithMany(p => p.Beneficiaries)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("beneficiaries_contract_id_fkey");

            entity.HasOne(d => d.Relationship).WithMany(p => p.Beneficiaries)
                .HasForeignKey(d => d.RelationshipId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("beneficiaries_relationship_id_fkey");
        });

        modelBuilder.Entity<Catalog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("catalogs_pkey");

            entity.ToTable("catalogs", "core");

            entity.HasIndex(e => new { e.Topic, e.Code }, "catalogs_topic_code_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.Topic)
                .UseCollation("ci_ai")
                .HasColumnName("topic");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.Value)
                .UseCollation("ci_ai")
                .HasColumnName("value");
        });

        modelBuilder.Entity<City>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("cities_pkey");

            entity.ToTable("cities", "core");

            entity.HasIndex(e => e.Department, "cities_department_idx")
                .HasFilter("is_active")
                .UseCollation(new[] { "ci_ai" });

            entity.HasIndex(e => new { e.Department, e.Province, e.Name }, "cities_name_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Department)
                .UseCollation("ci_ai")
                .HasColumnName("department");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.Province)
                .UseCollation("ci_ai")
                .HasColumnName("province");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<Consent>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("consents_pkey");

            entity.ToTable("consents", "sales");

            entity.HasIndex(e => new { e.ContractId, e.DocumentType }, "consents_document_uk").IsUnique();

            entity.HasIndex(e => e.OtpChallengeId, "consents_otp_idx").HasFilter("(otp_challenge_id IS NOT NULL)");

            entity.HasIndex(e => e.ContractPartyId, "consents_party_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.ContractPartyId).HasColumnName("contract_party_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DocumentCode)
                .UseCollation("ci_ai")
                .HasColumnName("document_code");
            entity.Property(e => e.DocumentType)
                .UseCollation("ci_ai")
                .HasColumnName("document_type");
            entity.Property(e => e.DocumentVersion)
                .UseCollation("ci_ai")
                .HasColumnName("document_version");
            entity.Property(e => e.IpAddress).HasColumnName("ip_address");
            entity.Property(e => e.OtpChallengeId).HasColumnName("otp_challenge_id");
            entity.Property(e => e.UserAgent).HasColumnName("user_agent");

            entity.HasOne(d => d.Contract).WithMany(p => p.Consents)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("consents_contract_id_fkey");

            entity.HasOne(d => d.ContractParty).WithMany(p => p.Consents)
                .HasPrincipalKey(p => new { p.Id, p.ContractId })
                .HasForeignKey(d => new { d.ContractPartyId, d.ContractId })
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("consents_party_fk");

            entity.HasOne(d => d.OtpChallenge).WithMany(p => p.Consents)
                .HasPrincipalKey(p => new { p.Id, p.ContractId })
                .HasForeignKey(d => new { d.OtpChallengeId, d.ContractId })
                .HasConstraintName("consents_otp_fk");
        });

        modelBuilder.Entity<Contract>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("contracts_pkey");

            entity.ToTable("contracts", "sales");

            entity.HasIndex(e => e.Number, "contracts_number_uk").IsUnique();

            entity.HasIndex(e => e.PlanId, "contracts_plan_idx");

            entity.HasIndex(e => new { e.Status, e.UpdatedAt }, "contracts_status_idx").UseCollation(new[] { "ci_ai", null });

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.Channel)
                .HasDefaultValueSql("'Web'::text")
                .UseCollation("ci_ai")
                .HasColumnName("channel");
            entity.Property(e => e.ClientIp).HasColumnName("client_ip");
            entity.Property(e => e.CoverageFrom).HasColumnName("coverage_from");
            entity.Property(e => e.CoverageTo).HasColumnName("coverage_to");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Currency)
                .UseCollation("ci_ai")
                .HasColumnName("currency");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Number)
                .UseCollation("ci_ai")
                .HasColumnName("number");
            entity.Property(e => e.PlanId).HasColumnName("plan_id");
            entity.Property(e => e.PremiumAmount)
                .HasPrecision(12, 2)
                .HasColumnName("premium_amount");
            entity.Property(e => e.RejectionReason)
                .UseCollation("ci_ai")
                .HasColumnName("rejection_reason");
            entity.Property(e => e.Status)
                .HasDefaultValueSql("'Iniciado'::text")
                .UseCollation("ci_ai")
                .HasColumnName("status");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Plan).WithMany(p => p.Contracts)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contracts_plan_id_fkey");
        });

        modelBuilder.Entity<ContractDetail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("contract_details_pkey");

            entity.ToTable("contract_details", "sales");

            entity.HasIndex(e => e.FieldDefinitionId, "contract_details_field_idx");

            entity.HasIndex(e => new { e.ContractId, e.FieldDefinitionId }, "contract_details_field_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.FieldDefinitionId).HasColumnName("field_definition_id");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.Value)
                .UseCollation("ci_ai")
                .HasColumnName("value");

            entity.HasOne(d => d.Contract).WithMany(p => p.ContractDetails)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contract_details_contract_id_fkey");

            entity.HasOne(d => d.FieldDefinition).WithMany(p => p.ContractDetails)
                .HasForeignKey(d => d.FieldDefinitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contract_details_field_definition_id_fkey");
        });

        modelBuilder.Entity<ContractEvent>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("contract_events_pkey");

            entity.ToTable("contract_events", "sales");

            entity.HasIndex(e => new { e.ContractId, e.CreatedAt }, "contract_events_contract_idx");

            entity.HasIndex(e => e.NextAttemptAt, "contract_events_pending_idx").HasFilter("(status = 'Pendiente'::text)");

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.Attempts).HasColumnName("attempts");
            entity.Property(e => e.CompletedAt).HasColumnName("completed_at");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.LastError).HasColumnName("last_error");
            entity.Property(e => e.NextAttemptAt).HasColumnName("next_attempt_at");
            entity.Property(e => e.Payload)
                .HasDefaultValueSql("'{}'::jsonb")
                .HasColumnType("jsonb")
                .HasColumnName("payload");
            entity.Property(e => e.PublishedAt).HasColumnName("published_at");
            entity.Property(e => e.Queue).HasColumnName("queue");
            entity.Property(e => e.Status)
                .UseCollation("ci_ai")
                .HasColumnName("status");
            entity.Property(e => e.Type)
                .UseCollation("ci_ai")
                .HasColumnName("type");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Contract).WithMany(p => p.ContractEvents)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contract_events_contract_id_fkey");
        });

        modelBuilder.Entity<ContractFieldDefinition>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("contract_field_definitions_pkey");

            entity.ToTable("contract_field_definitions", "offer");

            entity.HasIndex(e => new { e.ProductId, e.Code }, "contract_field_definitions_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DataType)
                .UseCollation("ci_ai")
                .HasColumnName("data_type");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsRequired)
                .HasDefaultValue(true)
                .HasColumnName("is_required");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Product).WithMany(p => p.ContractFieldDefinitions)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contract_field_definitions_product_id_fkey");
        });

        modelBuilder.Entity<ContractParty>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("contract_parties_pkey");

            entity.ToTable("contract_parties", "sales");

            entity.HasIndex(e => e.AgentId, "contract_parties_agent_idx").HasFilter("(agent_id IS NOT NULL)");

            entity.HasIndex(e => new { e.Id, e.ContractId }, "contract_parties_contract_uk").IsUnique();

            entity.HasIndex(e => e.PersonId, "contract_parties_insured_idx").HasFilter("(role = 'Asegurado'::text)");

            entity.HasIndex(e => e.PepDeclarationId, "contract_parties_pep_idx").HasFilter("(pep_declaration_id IS NOT NULL)");

            entity.HasIndex(e => e.PersonId, "contract_parties_person_idx");

            entity.HasIndex(e => new { e.ContractId, e.Role }, "contract_parties_role_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Address).HasColumnName("address");
            entity.Property(e => e.AgentId).HasColumnName("agent_id");
            entity.Property(e => e.BirthPlace).HasColumnName("birth_place");
            entity.Property(e => e.Birthdate).HasColumnName("birthdate");
            entity.Property(e => e.Cellphone).HasColumnName("cellphone");
            entity.Property(e => e.City)
                .UseCollation("ci_ai")
                .HasColumnName("city");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DocumentComplement).HasColumnName("document_complement");
            entity.Property(e => e.DocumentExtension)
                .UseCollation("ci_ai")
                .HasColumnName("document_extension");
            entity.Property(e => e.DocumentNumber).HasColumnName("document_number");
            entity.Property(e => e.EconomicActivity)
                .UseCollation("ci_ai")
                .HasColumnName("economic_activity");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.Gender)
                .UseCollation("ci_ai")
                .HasColumnName("gender");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.MaritalStatus)
                .UseCollation("ci_ai")
                .HasColumnName("marital_status");
            entity.Property(e => e.MaternalLastname).HasColumnName("maternal_lastname");
            entity.Property(e => e.MonthlyIncomeRange)
                .UseCollation("ci_ai")
                .HasColumnName("monthly_income_range");
            entity.Property(e => e.Names).HasColumnName("names");
            entity.Property(e => e.NationalityId).HasColumnName("nationality_id");
            entity.Property(e => e.Occupation)
                .UseCollation("ci_ai")
                .HasColumnName("occupation");
            entity.Property(e => e.PaternalLastname).HasColumnName("paternal_lastname");
            entity.Property(e => e.PepDeclarationId).HasColumnName("pep_declaration_id");
            entity.Property(e => e.PersonId).HasColumnName("person_id");
            entity.Property(e => e.RelationshipId).HasColumnName("relationship_id");
            entity.Property(e => e.Role)
                .UseCollation("ci_ai")
                .HasColumnName("role");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Agent).WithMany(p => p.ContractParties)
                .HasForeignKey(d => d.AgentId)
                .HasConstraintName("contract_parties_agent_id_fkey");

            entity.HasOne(d => d.Contract).WithMany(p => p.ContractParties)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contract_parties_contract_id_fkey");

            entity.HasOne(d => d.Nationality).WithMany(p => p.ContractParties)
                .HasForeignKey(d => d.NationalityId)
                .HasConstraintName("contract_parties_nationality_id_fkey");

            entity.HasOne(d => d.PepDeclaration).WithMany(p => p.ContractParties)
                .HasForeignKey(d => d.PepDeclarationId)
                .HasConstraintName("contract_parties_pep_declaration_id_fkey");

            entity.HasOne(d => d.Person).WithMany(p => p.ContractParties)
                .HasForeignKey(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("contract_parties_person_id_fkey");

            entity.HasOne(d => d.Relationship).WithMany(p => p.ContractParties)
                .HasForeignKey(d => d.RelationshipId)
                .HasConstraintName("contract_parties_relationship_id_fkey");
        });

        modelBuilder.Entity<Coverage>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("coverages_pkey");

            entity.ToTable("coverages", "offer");

            entity.HasIndex(e => e.PlanId, "coverages_plan_idx").HasFilter("is_active");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Currency)
                .UseCollation("ci_ai")
                .HasColumnName("currency");
            entity.Property(e => e.Description)
                .UseCollation("ci_ai")
                .HasColumnName("description");
            entity.Property(e => e.InsuredAmount)
                .HasPrecision(12, 2)
                .HasColumnName("insured_amount");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.PlanId).HasColumnName("plan_id");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.Type)
                .UseCollation("ci_ai")
                .HasColumnName("type");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.WaitingPeriod).HasColumnName("waiting_period");

            entity.HasOne(d => d.Plan).WithMany(p => p.Coverages)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("coverages_plan_id_fkey");
        });

        modelBuilder.Entity<Exclusion>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("exclusions_pkey");

            entity.ToTable("exclusions", "offer");

            entity.HasIndex(e => e.PlanId, "exclusions_plan_idx").HasFilter("is_active");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Description)
                .UseCollation("ci_ai")
                .HasColumnName("description");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.PlanId).HasColumnName("plan_id");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Plan).WithMany(p => p.Exclusions)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("exclusions_plan_id_fkey");
        });

        modelBuilder.Entity<Faq>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("faqs_pkey");

            entity.ToTable("faqs", "offer");

            entity.HasIndex(e => e.ProductId, "faqs_product_idx").HasFilter("is_active");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Answer)
                .UseCollation("ci_ai")
                .HasColumnName("answer");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.Question)
                .UseCollation("ci_ai")
                .HasColumnName("question");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Product).WithMany(p => p.Faqs)
                .HasForeignKey(d => d.ProductId)
                .HasConstraintName("faqs_product_id_fkey");
        });

        modelBuilder.Entity<IdentityReading>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("identity_readings_pkey");

            entity.ToTable("identity_readings", "compliance");

            entity.HasIndex(e => e.ContractId, "identity_readings_contract_idx").HasFilter("(contract_id IS NOT NULL)");

            entity.HasIndex(e => e.PersonId, "identity_readings_person_idx").HasFilter("(person_id IS NOT NULL)");

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.BackImagePath).HasColumnName("back_image_path");
            entity.Property(e => e.ClientIp).HasColumnName("client_ip");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.ExtractedFields).HasColumnName("extracted_fields");
            entity.Property(e => e.FailureReason)
                .UseCollation("ci_ai")
                .HasColumnName("failure_reason");
            entity.Property(e => e.FrontImagePath).HasColumnName("front_image_path");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.PersonId).HasColumnName("person_id");
            entity.Property(e => e.Provider)
                .HasDefaultValueSql("'LlamitAI'::text")
                .UseCollation("ci_ai")
                .HasColumnName("provider");
            entity.Property(e => e.ProviderDocumentId).HasColumnName("provider_document_id");
            entity.Property(e => e.Status)
                .HasDefaultValueSql("'Pendiente'::text")
                .UseCollation("ci_ai")
                .HasColumnName("status");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Contract).WithMany(p => p.IdentityReadings)
                .HasForeignKey(d => d.ContractId)
                .HasConstraintName("identity_readings_contract_id_fkey");

            entity.HasOne(d => d.Person).WithMany(p => p.IdentityReadings)
                .HasForeignKey(d => d.PersonId)
                .HasConstraintName("identity_readings_person_id_fkey");
        });

        modelBuilder.Entity<Nationality>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("nationalities_pkey");

            entity.ToTable("nationalities", "core");

            entity.HasIndex(e => e.Country, "nationalities_country_uk").IsUnique();

            entity.HasIndex(e => e.Iso, "nationalities_iso_uk").IsUnique();

            entity.HasIndex(e => e.Name, "nationalities_name_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Country)
                .UseCollation("ci_ai")
                .HasColumnName("country");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Iso)
                .HasMaxLength(2)
                .IsFixedLength()
                .HasColumnName("iso");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<Occupation>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("occupations_pkey");

            entity.ToTable("occupations", "core");

            entity.HasIndex(e => e.Code, "occupations_code_uk").IsUnique();

            entity.HasIndex(e => e.Name, "occupations_name_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code).HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.Profession)
                .UseCollation("ci_ai")
                .HasColumnName("profession");
            entity.Property(e => e.Type)
                .UseCollation("ci_ai")
                .HasColumnName("type");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<OtpChallenge>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("otp_challenges_pkey");

            entity.ToTable("otp_challenges", "sales");

            entity.HasIndex(e => new { e.ContractId, e.CreatedAt }, "otp_challenges_contract_idx").IsDescending(false, true);

            entity.HasIndex(e => new { e.Id, e.ContractId }, "otp_challenges_contract_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Attempts).HasColumnName("attempts");
            entity.Property(e => e.Channel)
                .UseCollation("ci_ai")
                .HasColumnName("channel");
            entity.Property(e => e.CodeHash).HasColumnName("code_hash");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Destination).HasColumnName("destination");
            entity.Property(e => e.ExpiresAt).HasColumnName("expires_at");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.MaxAttempts)
                .HasDefaultValue((short)3)
                .HasColumnName("max_attempts");
            entity.Property(e => e.ProviderHash).HasColumnName("provider_hash");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.VerifiedAt).HasColumnName("verified_at");

            entity.HasOne(d => d.Contract).WithMany(p => p.OtpChallenges)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("otp_challenges_contract_id_fkey");
        });

        modelBuilder.Entity<PaymentNotification>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("payment_notifications_pkey");

            entity.ToTable("payment_notifications", "sales");

            entity.HasIndex(e => e.QrPaymentId, "payment_notifications_qr_idx").HasFilter("(qr_payment_id IS NOT NULL)");

            entity.HasIndex(e => e.BankTransactionId, "payment_notifications_tx_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.BankTransactionId).HasColumnName("bank_transaction_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.QrPaymentId).HasColumnName("qr_payment_id");
            entity.Property(e => e.RawPayload)
                .HasColumnType("jsonb")
                .HasColumnName("raw_payload");
            entity.Property(e => e.ReceivedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("received_at");
            entity.Property(e => e.Result)
                .UseCollation("ci_ai")
                .HasColumnName("result");

            entity.HasOne(d => d.QrPayment).WithMany(p => p.PaymentNotifications)
                .HasForeignKey(d => d.QrPaymentId)
                .HasConstraintName("payment_notifications_qr_payment_id_fkey");
        });

        modelBuilder.Entity<PepDeclaration>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pep_declarations_pkey");

            entity.ToTable("pep_declarations", "compliance");

            entity.HasIndex(e => e.PersonId, "pep_declarations_current_uk")
                .IsUnique()
                .HasFilter("(superseded_at IS NULL)");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.ExerciseCountryId).HasColumnName("exercise_country_id");
            entity.Property(e => e.HasPepPartners).HasColumnName("has_pep_partners");
            entity.Property(e => e.Institution)
                .UseCollation("ci_ai")
                .HasColumnName("institution");
            entity.Property(e => e.IsPep).HasColumnName("is_pep");
            entity.Property(e => e.PeriodEnd).HasColumnName("period_end");
            entity.Property(e => e.PeriodStart).HasColumnName("period_start");
            entity.Property(e => e.PersonId).HasColumnName("person_id");
            entity.Property(e => e.Position)
                .UseCollation("ci_ai")
                .HasColumnName("position");
            entity.Property(e => e.SourceFunds)
                .UseCollation("ci_ai")
                .HasColumnName("source_funds");
            entity.Property(e => e.SupersededAt).HasColumnName("superseded_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.ExerciseCountry).WithMany(p => p.PepDeclarations)
                .HasForeignKey(d => d.ExerciseCountryId)
                .HasConstraintName("pep_declarations_exercise_country_id_fkey");

            entity.HasOne(d => d.Person).WithOne(p => p.PepDeclaration)
                .HasForeignKey<PepDeclaration>(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("pep_declarations_person_id_fkey");
        });

        modelBuilder.Entity<PepPartner>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pep_partners_pkey");

            entity.ToTable("pep_partners", "compliance");

            entity.HasIndex(e => e.PepDeclarationId, "pep_partners_declaration_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.MaternalLastname).HasColumnName("maternal_lastname");
            entity.Property(e => e.Names).HasColumnName("names");
            entity.Property(e => e.PaternalLastname).HasColumnName("paternal_lastname");
            entity.Property(e => e.PepDeclarationId).HasColumnName("pep_declaration_id");
            entity.Property(e => e.Position)
                .UseCollation("ci_ai")
                .HasColumnName("position");
            entity.Property(e => e.RelationshipId).HasColumnName("relationship_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.PepDeclaration).WithMany(p => p.PepPartners)
                .HasForeignKey(d => d.PepDeclarationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("pep_partners_pep_declaration_id_fkey");

            entity.HasOne(d => d.Relationship).WithMany(p => p.PepPartners)
                .HasForeignKey(d => d.RelationshipId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("pep_partners_relationship_id_fkey");
        });

        modelBuilder.Entity<PepRelative>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("pep_relatives_pkey");

            entity.ToTable("pep_relatives", "compliance");

            entity.HasIndex(e => e.PepDeclarationId, "pep_relatives_declaration_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DocumentNumber).HasColumnName("document_number");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.MaternalLastname).HasColumnName("maternal_lastname");
            entity.Property(e => e.Names).HasColumnName("names");
            entity.Property(e => e.NationalityId).HasColumnName("nationality_id");
            entity.Property(e => e.PaternalLastname).HasColumnName("paternal_lastname");
            entity.Property(e => e.PepDeclarationId).HasColumnName("pep_declaration_id");
            entity.Property(e => e.RelationshipId).HasColumnName("relationship_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Nationality).WithMany(p => p.PepRelatives)
                .HasForeignKey(d => d.NationalityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("pep_relatives_nationality_id_fkey");

            entity.HasOne(d => d.PepDeclaration).WithMany(p => p.PepRelatives)
                .HasForeignKey(d => d.PepDeclarationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("pep_relatives_pep_declaration_id_fkey");

            entity.HasOne(d => d.Relationship).WithMany(p => p.PepRelatives)
                .HasForeignKey(d => d.RelationshipId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("pep_relatives_relationship_id_fkey");
        });

        modelBuilder.Entity<Person>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("people_pkey");

            entity.ToTable("people", "core");

            entity.HasIndex(e => e.DocumentHash, "people_document_hash_uk").IsUnique();

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.Address).HasColumnName("address");
            entity.Property(e => e.BirthPlace).HasColumnName("birth_place");
            entity.Property(e => e.Birthdate).HasColumnName("birthdate");
            entity.Property(e => e.Cellphone).HasColumnName("cellphone");
            entity.Property(e => e.CityId).HasColumnName("city_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DocumentComplement).HasColumnName("document_complement");
            entity.Property(e => e.DocumentExtension)
                .UseCollation("ci_ai")
                .HasColumnName("document_extension");
            entity.Property(e => e.DocumentHash).HasColumnName("document_hash");
            entity.Property(e => e.DocumentNumber).HasColumnName("document_number");
            entity.Property(e => e.DocumentType)
                .UseCollation("ci_ai")
                .HasColumnName("document_type");
            entity.Property(e => e.EconomicActivity)
                .UseCollation("ci_ai")
                .HasColumnName("economic_activity");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.Gender)
                .UseCollation("ci_ai")
                .HasColumnName("gender");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.MaritalStatus)
                .UseCollation("ci_ai")
                .HasColumnName("marital_status");
            entity.Property(e => e.MaternalLastname).HasColumnName("maternal_lastname");
            entity.Property(e => e.MonthlyIncomeRange)
                .UseCollation("ci_ai")
                .HasColumnName("monthly_income_range");
            entity.Property(e => e.Names).HasColumnName("names");
            entity.Property(e => e.NationalityId).HasColumnName("nationality_id");
            entity.Property(e => e.OccupationId).HasColumnName("occupation_id");
            entity.Property(e => e.PaternalLastname).HasColumnName("paternal_lastname");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.City).WithMany(p => p.People)
                .HasForeignKey(d => d.CityId)
                .HasConstraintName("people_city_id_fkey");

            entity.HasOne(d => d.Nationality).WithMany(p => p.People)
                .HasForeignKey(d => d.NationalityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("people_nationality_id_fkey");

            entity.HasOne(d => d.Occupation).WithMany(p => p.People)
                .HasForeignKey(d => d.OccupationId)
                .HasConstraintName("people_occupation_id_fkey");
        });

        modelBuilder.Entity<Plan>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("plans_pkey");

            entity.ToTable("plans", "offer");

            entity.HasIndex(e => e.Code, "plans_code_uk").IsUnique();

            entity.HasIndex(e => e.ProductId, "plans_product_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Description)
                .UseCollation("ci_ai")
                .HasColumnName("description");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Product).WithMany(p => p.Plans)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("plans_product_id_fkey");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("products_pkey");

            entity.ToTable("products", "offer");

            entity.HasIndex(e => e.Code, "products_code_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Description)
                .UseCollation("ci_ai")
                .HasColumnName("description");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<QrPayment>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("qr_payments_pkey");

            entity.ToTable("qr_payments", "sales");

            entity.HasIndex(e => e.BankTransactionId, "qr_payments_bank_tx_uk").IsUnique();

            entity.HasIndex(e => new { e.ContractId, e.CreatedAt }, "qr_payments_contract_idx").IsDescending(false, true);

            entity.HasIndex(e => e.ContractId, "qr_payments_one_pending_uk")
                .IsUnique()
                .HasFilter("(status = 'Pendiente'::text)");

            entity.Property(e => e.Id)
                .HasDefaultValueSql("uuidv7()")
                .HasColumnName("id");
            entity.Property(e => e.Amount)
                .HasPrecision(12, 2)
                .HasColumnName("amount");
            entity.Property(e => e.BankTransactionId).HasColumnName("bank_transaction_id");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Currency)
                .UseCollation("ci_ai")
                .HasColumnName("currency");
            entity.Property(e => e.ExpiresAt).HasColumnName("expires_at");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.PaidAt).HasColumnName("paid_at");
            entity.Property(e => e.Status)
                .HasDefaultValueSql("'Pendiente'::text")
                .UseCollation("ci_ai")
                .HasColumnName("status");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");

            entity.HasOne(d => d.Contract).WithOne(p => p.QrPayment)
                .HasForeignKey<QrPayment>(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("qr_payments_contract_id_fkey");
        });

        modelBuilder.Entity<Relationship>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("relationships_pkey");

            entity.ToTable("relationships", "core");

            entity.HasIndex(e => e.Code, "relationships_code_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsUnique).HasColumnName("is_unique");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<RuleDefinition>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("rule_definitions_pkey");

            entity.ToTable("rule_definitions", "offer");

            entity.HasIndex(e => e.Code, "rule_definitions_code_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DataType)
                .UseCollation("ci_ai")
                .HasColumnName("data_type");
            entity.Property(e => e.Description)
                .UseCollation("ci_ai")
                .HasColumnName("description");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsRequired).HasColumnName("is_required");
            entity.Property(e => e.Name)
                .UseCollation("ci_ai")
                .HasColumnName("name");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
        });

        modelBuilder.Entity<Screening>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("screenings_pkey");

            entity.ToTable("screenings", "compliance");

            entity.HasIndex(e => new { e.ContractId, e.PersonId, e.Provider }, "screenings_contract_idx").UseCollation(new[] { null, null, "ci_ai" });

            entity.HasIndex(e => e.ExceptionId, "screenings_exception_idx").HasFilter("(exception_id IS NOT NULL)");

            entity.HasIndex(e => new { e.PersonId, e.CreatedAt }, "screenings_person_idx").IsDescending(false, true);

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.ExceptionId).HasColumnName("exception_id");
            entity.Property(e => e.PersonId).HasColumnName("person_id");
            entity.Property(e => e.Provider)
                .UseCollation("ci_ai")
                .HasColumnName("provider");
            entity.Property(e => e.Result).HasColumnName("result");
            entity.Property(e => e.Status)
                .UseCollation("ci_ai")
                .HasColumnName("status");

            entity.HasOne(d => d.Contract).WithMany(p => p.Screenings)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("screenings_contract_id_fkey");

            entity.HasOne(d => d.Exception).WithMany(p => p.Screenings)
                .HasForeignKey(d => d.ExceptionId)
                .HasConstraintName("screenings_exception_id_fkey");

            entity.HasOne(d => d.Person).WithMany(p => p.Screenings)
                .HasForeignKey(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("screenings_person_id_fkey");
        });

        modelBuilder.Entity<ScreeningException>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("screening_exceptions_pkey");

            entity.ToTable("screening_exceptions", "core");

            entity.HasIndex(e => new { e.PersonId, e.Provider }, "screening_exceptions_lookup_idx")
                .HasFilter("is_active")
                .UseCollation(new[] { null, "ci_ai" });

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.ApprovedBy)
                .UseCollation("ci_ai")
                .HasColumnName("approved_by");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.PersonId).HasColumnName("person_id");
            entity.Property(e => e.Provider)
                .UseCollation("ci_ai")
                .HasColumnName("provider");
            entity.Property(e => e.Reason)
                .UseCollation("ci_ai")
                .HasColumnName("reason");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.ValidFrom).HasColumnName("valid_from");
            entity.Property(e => e.ValidUntil).HasColumnName("valid_until");

            entity.HasOne(d => d.Person).WithMany(p => p.ScreeningExceptions)
                .HasForeignKey(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("screening_exceptions_person_id_fkey");
        });

        modelBuilder.Entity<ScreeningItem>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("screening_items_pkey");

            entity.ToTable("screening_items", "compliance");

            entity.HasIndex(e => e.ScreeningId, "screening_items_screening_idx");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Code)
                .UseCollation("ci_ai")
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Entity)
                .UseCollation("ci_ai")
                .HasColumnName("entity");
            entity.Property(e => e.FoundIn)
                .UseCollation("ci_ai")
                .HasColumnName("found_in");
            entity.Property(e => e.Observation)
                .UseCollation("ci_ai")
                .HasColumnName("observation");
            entity.Property(e => e.Position)
                .UseCollation("ci_ai")
                .HasColumnName("position");
            entity.Property(e => e.ScreeningId).HasColumnName("screening_id");
            entity.Property(e => e.Year)
                .UseCollation("ci_ai")
                .HasColumnName("year");

            entity.HasOne(d => d.Screening).WithMany(p => p.ScreeningItems)
                .HasForeignKey(d => d.ScreeningId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("screening_items_screening_id_fkey");
        });

        modelBuilder.Entity<SubscriptionRule>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("subscription_rules_pkey");

            entity.ToTable("subscription_rules", "offer");

            entity.HasIndex(e => e.DefinitionId, "subscription_rules_definition_idx");

            entity.HasIndex(e => new { e.PlanId, e.DefinitionId, e.ValidFrom }, "subscription_rules_lookup_idx").HasFilter("is_active");

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.DefinitionId).HasColumnName("definition_id");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.PlanId).HasColumnName("plan_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("updated_by");
            entity.Property(e => e.ValidFrom).HasColumnName("valid_from");
            entity.Property(e => e.ValidTo).HasColumnName("valid_to");
            entity.Property(e => e.Value)
                .UseCollation("ci_ai")
                .HasColumnName("value");

            entity.HasOne(d => d.Definition).WithMany(p => p.SubscriptionRules)
                .HasForeignKey(d => d.DefinitionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("subscription_rules_definition_id_fkey");

            entity.HasOne(d => d.Plan).WithMany(p => p.SubscriptionRules)
                .HasForeignKey(d => d.PlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("subscription_rules_plan_id_fkey");
        });

        modelBuilder.Entity<SurveyResponse>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("survey_responses_pkey");

            entity.ToTable("survey_responses", "feedback");

            entity.HasIndex(e => new { e.ContractId, e.Type }, "survey_responses_type_uk").IsUnique();

            entity.Property(e => e.Id)
                .UseIdentityAlwaysColumn()
                .HasColumnName("id");
            entity.Property(e => e.Comment)
                .UseCollation("ci_ai")
                .HasColumnName("comment");
            entity.Property(e => e.ContractId).HasColumnName("contract_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("now()")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy)
                .UseCollation("ci_ai")
                .HasColumnName("created_by");
            entity.Property(e => e.Score).HasColumnName("score");
            entity.Property(e => e.Type)
                .UseCollation("ci_ai")
                .HasColumnName("type");

            entity.HasOne(d => d.Contract).WithMany(p => p.SurveyResponses)
                .HasForeignKey(d => d.ContractId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("survey_responses_contract_id_fkey");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
