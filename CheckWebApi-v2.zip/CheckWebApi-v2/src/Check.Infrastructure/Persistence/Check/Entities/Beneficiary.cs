﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Beneficiary
{
    public long Id { get; set; }

    public Guid ContractId { get; set; }

    public long RelationshipId { get; set; }

    public byte[]? DocumentNumber { get; set; }

    public byte[] Names { get; set; } = null!;

    public byte[]? PaternalLastname { get; set; }

    public byte[]? MaternalLastname { get; set; }

    public decimal Percentage { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Contract Contract { get; set; } = null!;

    public virtual Relationship Relationship { get; set; } = null!;
}
