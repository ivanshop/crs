﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class ContractEvent
{
    public Guid Id { get; set; }

    public Guid ContractId { get; set; }

    public string Type { get; set; } = null!;

    public string? Queue { get; set; }

    public string Payload { get; set; } = null!;

    public string Status { get; set; } = null!;

    public short Attempts { get; set; }

    public DateTime? NextAttemptAt { get; set; }

    public DateTime? PublishedAt { get; set; }

    public DateTime? CompletedAt { get; set; }

    public string? LastError { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Contract Contract { get; set; } = null!;
}
