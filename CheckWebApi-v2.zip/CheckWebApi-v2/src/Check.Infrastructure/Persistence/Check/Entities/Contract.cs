﻿using System;
using System.Collections.Generic;
using System.Net;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Contract
{
    public Guid Id { get; set; }

    public string? Number { get; set; }

    public long PlanId { get; set; }

    public string Status { get; set; } = null!;

    public string? RejectionReason { get; set; }

    public decimal PremiumAmount { get; set; }

    public string Currency { get; set; } = null!;

    public DateTime? CoverageFrom { get; set; }

    public DateTime? CoverageTo { get; set; }

    public string Channel { get; set; } = null!;

    public IPAddress? ClientIp { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<Beneficiary> Beneficiaries { get; set; } = new List<Beneficiary>();

    public virtual ICollection<Consent> Consents { get; set; } = new List<Consent>();

    public virtual ICollection<ContractDetail> ContractDetails { get; set; } = new List<ContractDetail>();

    public virtual ICollection<ContractEvent> ContractEvents { get; set; } = new List<ContractEvent>();

    public virtual ICollection<ContractParty> ContractParties { get; set; } = new List<ContractParty>();

    public virtual ICollection<IdentityReading> IdentityReadings { get; set; } = new List<IdentityReading>();

    public virtual ICollection<OtpChallenge> OtpChallenges { get; set; } = new List<OtpChallenge>();

    public virtual Plan Plan { get; set; } = null!;

    public virtual QrPayment? QrPayment { get; set; }

    public virtual ICollection<Screening> Screenings { get; set; } = new List<Screening>();

    public virtual ICollection<SurveyResponse> SurveyResponses { get; set; } = new List<SurveyResponse>();
}
