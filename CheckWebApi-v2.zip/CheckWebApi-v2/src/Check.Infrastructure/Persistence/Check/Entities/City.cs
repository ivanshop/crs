﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class City
{
    public short Id { get; set; }

    public string Name { get; set; } = null!;

    public string Province { get; set; } = null!;

    public string Department { get; set; } = null!;

    public int SortOrder { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<Person> People { get; set; } = new List<Person>();
}
