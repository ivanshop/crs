﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class SurveyResponse
{
    public long Id { get; set; }

    public Guid ContractId { get; set; }

    public string Type { get; set; } = null!;

    public short Score { get; set; }

    public string? Comment { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual Contract Contract { get; set; } = null!;
}
