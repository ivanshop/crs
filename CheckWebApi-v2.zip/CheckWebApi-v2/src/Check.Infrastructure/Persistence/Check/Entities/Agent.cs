﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Agent
{
    public Guid Id { get; set; }

    public Guid AgencyId { get; set; }

    public Guid PersonId { get; set; }

    public string Code { get; set; } = null!;

    public string? LicenseNumber { get; set; }

    public DateOnly ValidFrom { get; set; }

    public DateOnly? ValidTo { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Agency Agency { get; set; } = null!;

    public virtual ICollection<ContractParty> ContractParties { get; set; } = new List<ContractParty>();

    public virtual Person Person { get; set; } = null!;
}
