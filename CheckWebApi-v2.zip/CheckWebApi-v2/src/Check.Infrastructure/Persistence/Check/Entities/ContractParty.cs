﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class ContractParty
{
    public long Id { get; set; }

    public Guid ContractId { get; set; }

    public Guid PersonId { get; set; }

    public string Role { get; set; } = null!;

    public Guid? AgentId { get; set; }

    public long? PepDeclarationId { get; set; }

    public byte[] DocumentNumber { get; set; } = null!;

    public byte[]? DocumentComplement { get; set; }

    public string? DocumentExtension { get; set; }

    public byte[] Names { get; set; } = null!;

    public byte[]? PaternalLastname { get; set; }

    public byte[]? MaternalLastname { get; set; }

    public byte[]? Birthdate { get; set; }

    public byte[]? Address { get; set; }

    public byte[]? Cellphone { get; set; }

    public byte[]? Email { get; set; }

    public string? Gender { get; set; }

    public short? NationalityId { get; set; }

    public string? City { get; set; }

    public string? MaritalStatus { get; set; }

    public string? Occupation { get; set; }

    public string? EconomicActivity { get; set; }

    public string? MonthlyIncomeRange { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public byte[]? BirthPlace { get; set; }

    public long? RelationshipId { get; set; }

    public virtual Agent? Agent { get; set; }

    public virtual ICollection<Consent> Consents { get; set; } = new List<Consent>();

    public virtual Contract Contract { get; set; } = null!;

    public virtual Nationality? Nationality { get; set; }

    public virtual PepDeclaration? PepDeclaration { get; set; }

    public virtual Person Person { get; set; } = null!;

    public virtual Catalog? Relationship { get; set; }
}
