﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Coverage
{
    public long Id { get; set; }

    public long PlanId { get; set; }

    public string Name { get; set; } = null!;

    public string Type { get; set; } = null!;

    public decimal? InsuredAmount { get; set; }

    public string? Currency { get; set; }

    public string Description { get; set; } = null!;

    public int WaitingPeriod { get; set; }

    public int SortOrder { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Plan Plan { get; set; } = null!;
}
