﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class ScreeningException
{
    public long Id { get; set; }

    public Guid PersonId { get; set; }

    public string Provider { get; set; } = null!;

    public string Reason { get; set; } = null!;

    public string ApprovedBy { get; set; } = null!;

    public DateOnly ValidFrom { get; set; }

    public DateOnly ValidUntil { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Person Person { get; set; } = null!;

    public virtual ICollection<Screening> Screenings { get; set; } = new List<Screening>();
}
