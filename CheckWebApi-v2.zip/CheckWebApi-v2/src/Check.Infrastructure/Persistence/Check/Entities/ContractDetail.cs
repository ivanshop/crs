﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class ContractDetail
{
    public long Id { get; set; }

    public Guid ContractId { get; set; }

    public long FieldDefinitionId { get; set; }

    public string Value { get; set; } = null!;

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Contract Contract { get; set; } = null!;

    public virtual ContractFieldDefinition FieldDefinition { get; set; } = null!;
}
