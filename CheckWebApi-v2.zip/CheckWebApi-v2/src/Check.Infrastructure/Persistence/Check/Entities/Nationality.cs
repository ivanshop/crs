﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Nationality
{
    public short Id { get; set; }

    public string Iso { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Country { get; set; } = null!;

    public int SortOrder { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<ContractParty> ContractParties { get; set; } = new List<ContractParty>();

    public virtual ICollection<Person> People { get; set; } = new List<Person>();

    public virtual ICollection<PepDeclaration> PepDeclarations { get; set; } = new List<PepDeclaration>();

    public virtual ICollection<PepRelative> PepRelatives { get; set; } = new List<PepRelative>();
}
