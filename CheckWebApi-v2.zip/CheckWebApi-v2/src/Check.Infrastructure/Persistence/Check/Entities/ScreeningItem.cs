﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class ScreeningItem
{
    public long Id { get; set; }

    public long ScreeningId { get; set; }

    public string FoundIn { get; set; } = null!;

    public string? Code { get; set; }

    public string? Position { get; set; }

    public string? Entity { get; set; }

    public string? Year { get; set; }

    public string? Observation { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual Screening Screening { get; set; } = null!;
}
