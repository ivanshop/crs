﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Person
{
    public Guid Id { get; set; }

    public string DocumentType { get; set; } = null!;

    public byte[] DocumentNumber { get; set; } = null!;

    public byte[]? DocumentComplement { get; set; }

    public string? DocumentExtension { get; set; }

    public byte[] DocumentHash { get; set; } = null!;

    public byte[] Names { get; set; } = null!;

    public byte[]? PaternalLastname { get; set; }

    public byte[]? MaternalLastname { get; set; }

    public byte[] Birthdate { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public short NationalityId { get; set; }

    public byte[]? Address { get; set; }

    public byte[]? Cellphone { get; set; }

    public byte[]? Email { get; set; }

    public short? CityId { get; set; }

    public string? MaritalStatus { get; set; }

    public short? OccupationId { get; set; }

    public string? EconomicActivity { get; set; }

    public string? MonthlyIncomeRange { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public byte[]? BirthPlace { get; set; }

    public virtual ICollection<Agent> Agents { get; set; } = new List<Agent>();

    public virtual City? City { get; set; }

    public virtual ICollection<ContractParty> ContractParties { get; set; } = new List<ContractParty>();

    public virtual ICollection<IdentityReading> IdentityReadings { get; set; } = new List<IdentityReading>();

    public virtual Nationality Nationality { get; set; } = null!;

    public virtual Occupation? Occupation { get; set; }

    public virtual PepDeclaration? PepDeclaration { get; set; }

    public virtual ICollection<ScreeningException> ScreeningExceptions { get; set; } = new List<ScreeningException>();

    public virtual ICollection<Screening> Screenings { get; set; } = new List<Screening>();
}
