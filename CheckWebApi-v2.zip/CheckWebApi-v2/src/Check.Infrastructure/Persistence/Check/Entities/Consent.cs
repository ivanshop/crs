﻿using System;
using System.Collections.Generic;
using System.Net;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Consent
{
    public long Id { get; set; }

    public Guid ContractId { get; set; }

    public long ContractPartyId { get; set; }

    public long? OtpChallengeId { get; set; }

    public string DocumentType { get; set; } = null!;

    public string DocumentCode { get; set; } = null!;

    public string DocumentVersion { get; set; } = null!;

    public IPAddress IpAddress { get; set; } = null!;

    public string? UserAgent { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual Contract Contract { get; set; } = null!;

    public virtual ContractParty ContractParty { get; set; } = null!;

    public virtual OtpChallenge? OtpChallenge { get; set; }
}
