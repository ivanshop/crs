﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Catalog
{
    public long Id { get; set; }

    public string Topic { get; set; } = null!;

    public string Code { get; set; } = null!;

    public string Value { get; set; } = null!;

    public int SortOrder { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<ContractParty> ContractParties { get; set; } = new List<ContractParty>();

    public virtual ICollection<PepPartner> PepPartners { get; set; } = new List<PepPartner>();

    public virtual ICollection<PepRelative> PepRelatives { get; set; } = new List<PepRelative>();
}
