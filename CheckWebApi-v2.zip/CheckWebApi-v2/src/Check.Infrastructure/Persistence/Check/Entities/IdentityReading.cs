﻿using System;
using System.Collections.Generic;
using System.Net;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class IdentityReading
{
    public Guid Id { get; set; }

    public Guid? PersonId { get; set; }

    public Guid? ContractId { get; set; }

    public string Provider { get; set; } = null!;

    public string FrontImagePath { get; set; } = null!;

    public string BackImagePath { get; set; } = null!;

    public string Status { get; set; } = null!;

    public byte[]? ExtractedFields { get; set; }

    public string? FailureReason { get; set; }

    public IPAddress? ClientIp { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public string? ProviderDocumentId { get; set; }

    public virtual Contract? Contract { get; set; }

    public virtual Person? Person { get; set; }
}
