﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class PepDeclaration
{
    public long Id { get; set; }

    public Guid PersonId { get; set; }

    public short? ExerciseCountryId { get; set; }

    public bool IsPep { get; set; }

    public bool HasPepPartners { get; set; }

    public string? SourceFunds { get; set; }

    public string? Position { get; set; }

    public string? Institution { get; set; }

    public DateOnly? PeriodStart { get; set; }

    public DateOnly? PeriodEnd { get; set; }

    public DateTime? SupersededAt { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<ContractParty> ContractParties { get; set; } = new List<ContractParty>();

    public virtual Nationality? ExerciseCountry { get; set; }

    public virtual ICollection<PepPartner> PepPartners { get; set; } = new List<PepPartner>();

    public virtual ICollection<PepRelative> PepRelatives { get; set; } = new List<PepRelative>();

    public virtual Person Person { get; set; } = null!;
}
