﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class SubscriptionRule
{
    public long Id { get; set; }

    public long PlanId { get; set; }

    public long DefinitionId { get; set; }

    public string Value { get; set; } = null!;

    public DateOnly ValidFrom { get; set; }

    public DateOnly? ValidTo { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual RuleDefinition Definition { get; set; } = null!;

    public virtual Plan Plan { get; set; } = null!;
}
