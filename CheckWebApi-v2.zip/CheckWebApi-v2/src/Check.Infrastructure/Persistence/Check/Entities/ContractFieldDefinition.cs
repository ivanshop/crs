﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class ContractFieldDefinition
{
    public long Id { get; set; }

    public long ProductId { get; set; }

    public string Code { get; set; } = null!;

    public string DataType { get; set; } = null!;

    public bool IsRequired { get; set; }

    public int SortOrder { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<ContractDetail> ContractDetails { get; set; } = new List<ContractDetail>();

    public virtual Product Product { get; set; } = null!;
}
