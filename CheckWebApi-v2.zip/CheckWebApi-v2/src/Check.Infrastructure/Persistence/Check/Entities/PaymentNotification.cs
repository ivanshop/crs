﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class PaymentNotification
{
    public long Id { get; set; }

    public Guid? QrPaymentId { get; set; }

    public string BankTransactionId { get; set; } = null!;

    public string RawPayload { get; set; } = null!;

    public DateTime ReceivedAt { get; set; }

    public string Result { get; set; } = null!;

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual QrPayment? QrPayment { get; set; }
}
