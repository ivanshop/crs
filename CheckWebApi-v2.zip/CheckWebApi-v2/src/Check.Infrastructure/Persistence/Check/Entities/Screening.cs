﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class Screening
{
    public long Id { get; set; }

    public Guid PersonId { get; set; }

    public Guid ContractId { get; set; }

    public string Provider { get; set; } = null!;

    public string Status { get; set; } = null!;

    public byte[]? Result { get; set; }

    public long? ExceptionId { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual Contract Contract { get; set; } = null!;

    public virtual ScreeningException? Exception { get; set; }

    public virtual Person Person { get; set; } = null!;

    public virtual ICollection<ScreeningItem> ScreeningItems { get; set; } = new List<ScreeningItem>();
}
