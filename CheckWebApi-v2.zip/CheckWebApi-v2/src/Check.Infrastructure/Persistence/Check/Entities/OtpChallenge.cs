﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class OtpChallenge
{
    public long Id { get; set; }

    public Guid ContractId { get; set; }

    public string Channel { get; set; } = null!;

    public byte[] Destination { get; set; } = null!;

    public byte[]? CodeHash { get; set; }

    public DateTime ExpiresAt { get; set; }

    public short Attempts { get; set; }

    public short MaxAttempts { get; set; }

    public DateTime? VerifiedAt { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public string? ProviderHash { get; set; }

    public virtual ICollection<Consent> Consents { get; set; } = new List<Consent>();

    public virtual Contract Contract { get; set; } = null!;
}
