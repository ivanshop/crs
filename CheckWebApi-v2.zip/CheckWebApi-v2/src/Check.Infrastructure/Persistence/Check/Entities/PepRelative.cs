﻿using System;
using System.Collections.Generic;

namespace Check.Infrastructure.Persistence.Check.Entities;

public partial class PepRelative
{
    public long Id { get; set; }

    public long PepDeclarationId { get; set; }

    public long RelationshipId { get; set; }

    public byte[] Names { get; set; } = null!;

    public byte[]? PaternalLastname { get; set; }

    public byte[]? MaternalLastname { get; set; }

    public byte[]? DocumentNumber { get; set; }

    public short NationalityId { get; set; }

    public bool IsActive { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public string? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual Nationality Nationality { get; set; } = null!;

    public virtual PepDeclaration PepDeclaration { get; set; } = null!;

    public virtual Catalog Relationship { get; set; } = null!;
}
