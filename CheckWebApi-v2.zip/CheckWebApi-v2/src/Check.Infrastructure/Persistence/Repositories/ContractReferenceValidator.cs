using Check.Application.Contracts;
using Check.Domain.People;
using Check.Infrastructure.Persistence.Check;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>Valida que los ids y códigos del formulario existan y estén activos en los catálogos.</summary>
public sealed class ContractReferenceValidator(CheckDbContext db) : IContractReferenceValidator
{
    public const string ExtensionTopic = "Departamento";
    public const string MaritalStatusTopic = "Estado-Civil";

    public async Task<IReadOnlyList<string>> FindInvalidAsync(PersonalData person, string prefix, CancellationToken ct)
    {
        var invalid = new List<string>();

        if (!await db.Nationalities.AnyAsync(n => n.Id == person.NationalityId && n.IsActive, ct))
            invalid.Add($"{prefix}.nationalityId");
        if (!await db.Cities.AnyAsync(c => c.Id == person.CityId && c.IsActive, ct))
            invalid.Add($"{prefix}.cityId");
        if (!await db.Occupations.AnyAsync(o => o.Id == person.OccupationId && o.IsActive, ct))
            invalid.Add($"{prefix}.occupationId");
        if (!await db.Catalogs.AnyAsync(c => c.Topic == MaritalStatusTopic && c.Code == person.MaritalStatus && c.IsActive, ct))
            invalid.Add($"{prefix}.maritalStatus");
        if (person.Extension is not null &&
            !await db.Catalogs.AnyAsync(c => c.Topic == ExtensionTopic && c.Code == person.Extension && c.IsActive, ct))
            invalid.Add($"{prefix}.extension");

        return invalid;
    }
}
