using Check.Application.Plans;
using Check.Domain.Offer;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Mappers;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

public sealed class PlanRepository(CheckDbContext db) : IPlanRepository
{
    public async Task<PlanRulesResponse?> GetRulesAsync(long planId, CancellationToken ct)
    {
        var plan = await db.Plans
            .AsNoTracking()
            .Where(pl => pl.Id == planId && pl.IsActive)
            .Include(pl => pl.SubscriptionRules.Where(r => r.IsActive && r.Definition.IsActive))
                .ThenInclude(r => r.Definition)
            .FirstOrDefaultAsync(ct);

        return plan?.ToRulesResponse();
    }

    public Task<PlanSummary?> GetSummaryAsync(long planId, CancellationToken ct) =>
        db.Plans.AsNoTracking()
            .Where(pl => pl.Id == planId && pl.IsActive && pl.Product.IsActive)
            .Select(pl => new PlanSummary(pl.Id, pl.Code, pl.Product.Code))
            .FirstOrDefaultAsync(ct);

    public async Task<PlanTerms?> GetTermsAsync(long planId, DateOnly date, CancellationToken ct)
    {
        var plan = await db.Plans
            .AsNoTracking()
            .Where(pl => pl.Id == planId && pl.IsActive && pl.Product.IsActive)
            .Include(pl => pl.SubscriptionRules.Where(r => r.IsActive && r.Definition.IsActive
                && r.ValidFrom <= date && (r.ValidTo == null || r.ValidTo >= date)))
                .ThenInclude(r => r.Definition)
            .FirstOrDefaultAsync(ct);

        return plan?.ToTerms();
    }
}
