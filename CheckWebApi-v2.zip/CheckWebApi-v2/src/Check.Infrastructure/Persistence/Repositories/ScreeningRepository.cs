using Check.Application.Common;
using Check.Application.Screening;
using Check.Domain.Compliance;
using Check.Domain.Contracts;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

public sealed class ScreeningRepository(CheckDbContext db, FieldEncryptor crypto, ICurrentUser user, TimeProvider time)
    : IScreeningRepository
{
    private const string BoliviaIso = "BO";

    public async Task<ContractForScreening?> GetContractAsync(Guid contractId, CancellationToken ct)
    {
        var contract = await db.Contracts.AsNoTracking()
            .Where(c => c.Id == contractId && c.IsActive)
            .Select(c => new
            {
                c.Id,
                c.Status,
                // Un intento = una consulta al asegurado (siempre se valida primero).
                SegipAttempts = c.Screenings.Count(s => s.Provider == ScreeningProviders.Segip
                    && c.ContractParties.Any(p => p.Role == PartyRoles.Insured && p.PersonId == s.PersonId)),
                Parties = c.ContractParties
                    .Where(p => p.IsActive && (p.Role == PartyRoles.Insured || p.Role == PartyRoles.Contractor))
                    .Select(p => new { Party = p, p.Person.DocumentType, NationalityIso = p.Nationality!.Iso })
                    .ToList()
            })
            .FirstOrDefaultAsync(ct);

        if (contract is null) return null;

        // Si compra para sí mismo, Contratante y Asegurado son la misma persona: se valida una vez (como Asegurado).
        var subjects = contract.Parties
            .OrderBy(p => p.Party.Role == PartyRoles.Insured ? 0 : 1)
            .DistinctBy(p => p.Party.PersonId)
            .Select(p => new ScreeningSubject(p.Party.PersonId, p.Party.Role, new SegipQuery(
                crypto.Decrypt(p.Party.DocumentNumber),
                Decrypt(p.Party.DocumentComplement),
                crypto.Decrypt(p.Party.Names),
                Decrypt(p.Party.PaternalLastname),
                Decrypt(p.Party.MaternalLastname),
                DateOnly.Parse(crypto.Decrypt(p.Party.Birthdate!)),
                IsForeigner: p.NationalityIso != BoliviaIso)))
            .ToList();

        return new ContractForScreening(contract.Id, contract.Status, contract.SegipAttempts, subjects);
    }

    public async Task SaveAsync(Guid contractId, IReadOnlyList<ScreeningRecord> records, string? newStatus, string? rejectionReason, CancellationToken ct)
    {
        foreach (var r in records)
        {
            db.Screenings.Add(new Screening
            {
                ContractId = contractId,
                PersonId = r.PersonId,
                Provider = r.Provider,
                Status = r.Status,
                Result = r.ResultJson is null ? null : crypto.Encrypt(r.ResultJson),
                CreatedBy = user.Name
            });
        }

        if (newStatus is not null)
        {
            var contract = await db.Contracts.FirstAsync(c => c.Id == contractId, ct);
            contract.Status = newStatus;
            contract.RejectionReason = rejectionReason;
            contract.UpdatedBy = user.Name;
            contract.UpdatedAt = time.GetUtcNow().UtcDateTime;
        }

        await db.SaveChangesAsync(ct);
    }

    private string? Decrypt(byte[]? value) => value is null ? null : crypto.Decrypt(value);
}
