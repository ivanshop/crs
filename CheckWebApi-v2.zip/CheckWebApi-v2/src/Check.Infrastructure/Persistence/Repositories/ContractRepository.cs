using System.Net;
using Check.Application.Common;
using Check.Application.Contracts;
using Check.Domain.Contracts;
using Check.Domain.People;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Check.Infrastructure.Persistence.Mappers;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

public sealed class ContractRepository(CheckDbContext db, FieldEncryptor crypto, ICurrentUser user, TimeProvider time)
    : IContractRepository
{
    public async Task CreateAsync(NewContract contract, IdentityReadingLink? readingLink, string? clientIp, CancellationToken ct)
    {
        var insured = await UpsertPersonAsync(contract.Insured, ct);
        var contractor = contract.Contractor is null ? insured : await UpsertPersonAsync(contract.Contractor, ct);

        db.Contracts.Add(new Contract
        {
            Id = contract.Id,
            PlanId = contract.PlanId,
            Status = contract.Status,
            PremiumAmount = contract.Premium,
            Currency = contract.Currency,
            Channel = contract.Channel,
            ClientIp = IPAddress.TryParse(clientIp, out var ip) ? ip : null,
            IsActive = true,
            CreatedBy = user.Name
        });

        long? relationshipId = contract.ContractorRelationship is null
            ? null
            : await db.Catalogs
                .Where(c => c.Topic == ContractorRelationships.Topic && c.Code == contract.ContractorRelationship && c.IsActive)
                .Select(c => (long?)c.Id)
                .FirstOrDefaultAsync(ct)
              ?? throw new InvalidOperationException($"Falta el parentesco '{contract.ContractorRelationship}' en core.catalogs ({ContractorRelationships.Topic}).");

        var payer = contract.Contractor ?? contract.Insured;
        db.ContractParties.Add(payer.ToParty(contract.Id, contractor.Id, PartyRoles.Contractor,
            await NamesAsync(payer, ct), relationshipId, crypto, user.Name));
        db.ContractParties.Add(contract.Insured.ToParty(contract.Id, insured.Id, PartyRoles.Insured,
            await NamesAsync(contract.Insured, ct), null, crypto, user.Name));

        if (readingLink is not null && await db.IdentityReadings.FindAsync([readingLink.ReadingId], ct) is { } reading)
        {
            reading.ContractId = contract.Id;
            reading.PersonId = readingLink.IsContractor ? contractor.Id : insured.Id;
            reading.UpdatedBy = user.Name;
            reading.UpdatedAt = time.GetUtcNow().UtcDateTime;
        }

        // Una sola transacción: personas, contrato, partes y lectura.
        await db.SaveChangesAsync(ct);
    }

    /// <summary>Busca a la persona por el HMAC de su documento; si existe, actualiza sus datos actuales.</summary>
    private async Task<Person> UpsertPersonAsync(PersonalData data, CancellationToken ct)
    {
        var hash = crypto.Hash(data.DocumentKey);
        var person = await db.People.FirstOrDefaultAsync(p => p.DocumentHash == hash, ct);

        if (person is null)
        {
            person = new Person { Id = Guid.CreateVersion7(), CreatedBy = user.Name };
            db.People.Add(person);
        }
        else
        {
            person.UpdatedBy = user.Name;
            person.UpdatedAt = time.GetUtcNow().UtcDateTime;
        }

        data.ApplyTo(person, crypto);
        return person;
    }

    private async Task<PartyNames> NamesAsync(PersonalData data, CancellationToken ct)
    {
        var city = await db.Cities.Where(c => c.Id == data.CityId).Select(c => c.Name).FirstAsync(ct);
        var occupation = await db.Occupations.Where(o => o.Id == data.OccupationId).Select(o => o.Name).FirstAsync(ct);
        var marital = await db.Catalogs
            .Where(c => c.Topic == ContractReferenceValidator.MaritalStatusTopic && c.Code == data.MaritalStatus)
            .Select(c => c.Value).FirstAsync(ct);
        return new PartyNames(city, occupation, marital);
    }

}
