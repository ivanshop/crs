using Check.Application.Contracts;
using Check.Infrastructure.Persistence.Check;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>Consultas de solo lectura del contrato (sin datos personales).</summary>
public sealed class ContractQueries(CheckDbContext db) : IContractQueries
{
    public async Task<ContractSummaryResponse?> GetSummaryAsync(Guid contractId, CancellationToken ct)
    {
        var row = await db.Contracts.AsNoTracking()
            .Where(c => c.Id == contractId && c.IsActive)
            .Select(c => new
            {
                c.Id, c.Status, c.Number, ProductName = c.Plan.Product.Name, PlanName = c.Plan.Name,
                c.PremiumAmount, c.Currency, c.CoverageFrom, c.CoverageTo, c.RejectionReason,
                // Se consulta la tabla y no la navegación: el scaffold modeló Contract–QrPayment como 1:1.
                Qr = db.QrPayments
                    .Where(q => q.ContractId == c.Id)
                    .OrderByDescending(q => q.CreatedAt)
                    .Select(q => new { q.Id, q.Status, q.ExpiresAt, q.PaidAt })
                    .FirstOrDefault()
            })
            .FirstOrDefaultAsync(ct);

        if (row is null) return null;

        return new ContractSummaryResponse(
            row.Id, row.Status, row.Number, row.ProductName, row.PlanName, row.PremiumAmount, row.Currency,
            Utc(row.CoverageFrom), Utc(row.CoverageTo), row.RejectionReason,
            row.Qr is null ? null : new QrSummaryResponse(row.Qr.Id, row.Qr.Status, Utc(row.Qr.ExpiresAt)!.Value, Utc(row.Qr.PaidAt)));
    }

    private static DateTimeOffset? Utc(DateTime? value) =>
        value is null ? null : new DateTimeOffset(DateTime.SpecifyKind(value.Value, DateTimeKind.Utc));
}
