using Check.Application.Common;
using Check.Application.Declarations;
using Check.Domain.Contracts;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>sales.beneficiaries y compliance.pep_declarations / pep_relatives / pep_partners. Nombres y documentos cifrados.</summary>
public sealed class DeclarationRepository(CheckDbContext db, FieldEncryptor crypto, ICurrentUser user, TimeProvider time)
    : IDeclarationRepository
{
    public async Task<DeclarationContext?> GetContextAsync(Guid contractId, CancellationToken ct)
    {
        var row = await db.Contracts.AsNoTracking()
            .Where(c => c.Id == contractId && c.IsActive)
            .Select(c => new
            {
                c.Id,
                c.Status,
                c.PlanId,
                Insured = c.ContractParties.Where(p => p.Role == PartyRoles.Insured && p.IsActive)
                    .Select(p => new { p.Birthdate, p.DocumentNumber }).FirstOrDefault(),
                ContractorPersonId = c.ContractParties.Where(p => p.Role == PartyRoles.Contractor && p.IsActive)
                    .Select(p => (Guid?)p.PersonId).FirstOrDefault()
            })
            .FirstOrDefaultAsync(ct);

        if (row?.Insured?.Birthdate is null || row.ContractorPersonId is null) return null;

        return new DeclarationContext(row.Id, row.Status, row.PlanId,
            DateOnly.Parse(crypto.Decrypt(row.Insured.Birthdate)),
            crypto.Decrypt(row.Insured.DocumentNumber),
            row.ContractorPersonId.Value);
    }

    public async Task<DeclarationCatalogs> GetCatalogsAsync(CancellationToken ct)
    {
        var relationships = await db.Relationships.AsNoTracking()
            .Where(r => r.IsActive).ToDictionaryAsync(r => r.Code.ToUpperInvariant(), r => r.IsUnique, ct);
        var pep = await CatalogCodesAsync(PepCatalogs.RelativeTopic, ct);
        var partners = await CatalogCodesAsync(PepCatalogs.PartnerTopic, ct);
        var nationalities = await db.Nationalities.AsNoTracking().Where(n => n.IsActive).Select(n => n.Id).ToListAsync(ct);

        return new DeclarationCatalogs(relationships, pep, partners, nationalities.ToHashSet());
    }

    public async Task SaveAsync(DeclarationContext context, IReadOnlyList<BeneficiaryData> beneficiaries, PepDeclarationData pep, CancellationToken ct)
    {
        var now = time.GetUtcNow().UtcDateTime;
        var relationshipIds = await db.Relationships.Where(r => r.IsActive).ToDictionaryAsync(r => r.Code.ToUpperInvariant(), r => r.Id, ct);
        var pepIds = await CatalogIdsAsync(PepCatalogs.RelativeTopic, ct);
        var partnerIds = await CatalogIdsAsync(PepCatalogs.PartnerTopic, ct);

        await using var transaction = await db.Database.BeginTransactionAsync(ct);

        // 1) Beneficiarios: los anteriores quedan inactivos (historial) y se cargan los nuevos.
        await db.Beneficiaries
            .Where(b => b.ContractId == context.ContractId && b.IsActive)
            .ExecuteUpdateAsync(s => s
                .SetProperty(b => b.IsActive, false)
                .SetProperty(b => b.UpdatedBy, user.Name)
                .SetProperty(b => b.UpdatedAt, now), ct);

        foreach (var b in beneficiaries)
        {
            db.Beneficiaries.Add(new Beneficiary
            {
                ContractId = context.ContractId,
                RelationshipId = relationshipIds[b.RelationshipCode],
                DocumentNumber = Encrypt(b.DocumentNumber),
                Names = crypto.Encrypt(b.Names),
                PaternalLastname = Encrypt(b.PaternalLastname),
                MaternalLastname = Encrypt(b.MaternalLastname),
                Percentage = b.Percentage,
                IsActive = true,
                CreatedBy = user.Name
            });
        }

        // 2) PEP: la declaración vigente del contratante se marca como reemplazada ANTES de insertar la nueva
        //    (índice único: una sola vigente por persona). Se hace con UPDATE directo para que EF no rastree
        //    las dos a la vez (el scaffold modeló Person–PepDeclaration como 1:1).
        await db.PepDeclarations
            .Where(d => d.PersonId == context.ContractorPersonId && d.SupersededAt == null)
            .ExecuteUpdateAsync(s => s
                .SetProperty(d => d.SupersededAt, now)
                .SetProperty(d => d.UpdatedBy, user.Name)
                .SetProperty(d => d.UpdatedAt, now), ct);

        var declaration = new PepDeclaration
        {
            PersonId = context.ContractorPersonId,
            IsPep = pep.IsPep,
            HasPepPartners = pep.HasPepPartners,
            Position = pep.Position,
            Institution = pep.Institution,
            SourceFunds = pep.SourceFunds,
            ExerciseCountryId = pep.ExerciseCountryId,
            PeriodStart = pep.PeriodStart,
            PeriodEnd = pep.PeriodEnd,
            CreatedBy = user.Name
        };
        foreach (var r in pep.Relatives)
        {
            declaration.PepRelatives.Add(new PepRelative
            {
                RelationshipId = pepIds[r.RelationshipCode],
                Names = crypto.Encrypt(r.Names),
                PaternalLastname = Encrypt(r.PaternalLastname),
                MaternalLastname = Encrypt(r.MaternalLastname),
                DocumentNumber = Encrypt(r.DocumentNumber),
                NationalityId = r.NationalityId,
                IsActive = true,
                CreatedBy = user.Name
            });
        }
        foreach (var p in pep.Partners)
        {
            declaration.PepPartners.Add(new PepPartner
            {
                RelationshipId = partnerIds[p.RelationshipCode],
                Names = crypto.Encrypt(p.Names),
                PaternalLastname = Encrypt(p.PaternalLastname),
                MaternalLastname = Encrypt(p.MaternalLastname),
                Position = p.Position,
                IsActive = true,
                CreatedBy = user.Name
            });
        }
        db.PepDeclarations.Add(declaration);

        // 3) Las filas del contratante en este contrato apuntan a la nueva declaración
        //    (si compra para sí mismo, también la del Asegurado: es la misma persona).
        var parties = await db.ContractParties
            .Where(p => p.ContractId == context.ContractId && p.PersonId == context.ContractorPersonId && p.IsActive)
            .ToListAsync(ct);
        foreach (var party in parties)
        {
            party.PepDeclaration = declaration;
            party.UpdatedBy = user.Name;
            party.UpdatedAt = now;
        }

        // 4) Contrato Declarado.
        var contract = await db.Contracts.FirstAsync(c => c.Id == context.ContractId, ct);
        contract.Status = ContractStatus.Declared;
        contract.UpdatedBy = user.Name;
        contract.UpdatedAt = now;

        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
    }

    private async Task<IReadOnlySet<string>> CatalogCodesAsync(string topic, CancellationToken ct) =>
        (await db.Catalogs.AsNoTracking().Where(c => c.Topic == topic && c.IsActive).Select(c => c.Code).ToListAsync(ct))
            .Select(c => c.ToUpperInvariant()).ToHashSet();

    private Task<Dictionary<string, long>> CatalogIdsAsync(string topic, CancellationToken ct) =>
        db.Catalogs.Where(c => c.Topic == topic && c.IsActive).ToDictionaryAsync(c => c.Code.ToUpperInvariant(), c => c.Id, ct);

    private byte[]? Encrypt(string? value) => string.IsNullOrEmpty(value) ? null : crypto.Encrypt(value);
}
