using Check.Application.Products;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Mappers;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

public sealed class ProductRepository(CheckDbContext db) : IProductRepository
{
    public async Task<IReadOnlyList<ProductResponse>> GetActiveAsync(CancellationToken ct)
    {
        var products = await db.Products
            .AsNoTracking()
            .Where(p => p.IsActive && p.Plans.Any(pl => pl.IsActive))
            .Include(p => p.Plans.Where(pl => pl.IsActive))
                .ThenInclude(pl => pl.Coverages.Where(c => c.IsActive).OrderBy(c => c.SortOrder).ThenBy(c => c.Id))
            .Include(p => p.Plans.Where(pl => pl.IsActive))
                .ThenInclude(pl => pl.Assistances.Where(a => a.IsActive).OrderBy(a => a.SortOrder).ThenBy(a => a.Id))
            .Include(p => p.Plans.Where(pl => pl.IsActive))
                .ThenInclude(pl => pl.SubscriptionRules.Where(r => r.IsActive))
                .ThenInclude(r => r.Definition)
            .OrderBy(p => p.Name)
            .AsSplitQuery()
            .ToListAsync(ct);

        return products.Select(p => p.ToResponse()).ToList();
    }
}
