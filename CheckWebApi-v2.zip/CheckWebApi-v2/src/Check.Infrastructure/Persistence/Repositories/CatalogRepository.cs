using Check.Application.Catalogs;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Mappers;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

public sealed class CatalogRepository(CheckDbContext db) : ICatalogRepository
{
    public async Task<CatalogsResponse> GetAllAsync(CancellationToken ct)
    {
        // Consultas secuenciales: un DbContext no admite consultas en paralelo.
        var nationalities = await db.Nationalities.AsNoTracking()
            .Where(n => n.IsActive)
            .OrderBy(n => n.SortOrder).ThenBy(n => n.Name)
            .Select(CatalogMapper.ToNationality)
            .ToListAsync(ct);

        var occupations = await db.Occupations.AsNoTracking()
            .Where(o => o.IsActive)
            .OrderBy(o => o.Name)
            .Select(CatalogMapper.ToOccupation)
            .ToListAsync(ct);

        var cities = await db.Cities.AsNoTracking()
            .Where(c => c.IsActive)
            .OrderBy(c => c.Department).ThenBy(c => c.SortOrder).ThenBy(c => c.Name)
            .Select(CatalogMapper.ToCity)
            .ToListAsync(ct);

        var relationships = await db.Relationships.AsNoTracking()
            .Where(r => r.IsActive)
            .OrderBy(r => r.Name)
            .Select(CatalogMapper.ToRelationship)
            .ToListAsync(ct);

        var items = await db.Catalogs.AsNoTracking()
            .Where(c => c.IsActive)
            .OrderBy(c => c.Topic).ThenBy(c => c.SortOrder).ThenBy(c => c.Value)
            .Select(c => new { c.Topic, Item = new CatalogItemResponse(c.Code, c.Value) })
            .ToListAsync(ct);

        var lists = items
            .GroupBy(i => i.Topic, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(
                g => g.Key,
                g => (IReadOnlyList<CatalogItemResponse>)g.Select(i => i.Item).ToList(),
                StringComparer.OrdinalIgnoreCase);

        return new CatalogsResponse(nationalities, occupations, cities, relationships, lists);
    }
}
