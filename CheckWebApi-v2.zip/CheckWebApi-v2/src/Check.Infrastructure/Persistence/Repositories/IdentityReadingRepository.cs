using System.Net;
using System.Text.Json;
using Check.Application.Common;
using Check.Application.IdentityReadings;
using Check.Domain.Compliance;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>compliance.identity_readings. Los campos extraídos se guardan cifrados (JSON de IdentityFields).</summary>
public sealed class IdentityReadingRepository(CheckDbContext db, FieldEncryptor encryptor, ICurrentUser user, TimeProvider time)
    : IIdentityReadingRepository
{
    private const string Provider = "LlamitAI";

    public async Task AddAsync(NewIdentityReading reading, CancellationToken ct)
    {
        db.IdentityReadings.Add(new IdentityReading
        {
            Id = reading.Id,
            Provider = Provider,
            ProviderDocumentId = reading.ProviderDocumentId,
            FrontImagePath = reading.FrontImagePath,
            BackImagePath = reading.BackImagePath,
            Status = reading.Status,
            FailureReason = reading.FailureReason,
            ClientIp = IPAddress.TryParse(reading.ClientIp, out var ip) ? ip : null,
            IsActive = true,
            CreatedBy = user.Name
        });
        await db.SaveChangesAsync(ct);
    }

    public async Task<IdentityReadingRecord?> GetAsync(Guid id, CancellationToken ct)
    {
        var row = await db.IdentityReadings.AsNoTracking()
            .Where(r => r.Id == id && r.IsActive)
            .Select(r => new { r.Id, r.Status, r.ProviderDocumentId, r.ExtractedFields, r.FailureReason, r.CreatedAt })
            .FirstOrDefaultAsync(ct);

        if (row is null) return null;

        var fields = row.ExtractedFields is null
            ? null
            : JsonSerializer.Deserialize<IdentityFields>(encryptor.Decrypt(row.ExtractedFields));

        return new IdentityReadingRecord(row.Id, row.Status, row.ProviderDocumentId, fields, row.FailureReason,
            new DateTimeOffset(DateTime.SpecifyKind(row.CreatedAt, DateTimeKind.Utc)));
    }

    public Task CompleteAsync(Guid id, IdentityFields fields, CancellationToken ct)
    {
        var encrypted = encryptor.Encrypt(JsonSerializer.Serialize(fields));
        return db.IdentityReadings
            .Where(r => r.Id == id && r.Status == IdentityReadingStatus.Pending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(r => r.Status, IdentityReadingStatus.Completed)
                .SetProperty(r => r.ExtractedFields, encrypted)
                .SetProperty(r => r.UpdatedBy, user.Name)
                .SetProperty(r => r.UpdatedAt, time.GetUtcNow().UtcDateTime), ct);
    }

    public Task FailAsync(Guid id, string reason, CancellationToken ct) =>
        db.IdentityReadings
            .Where(r => r.Id == id && r.Status == IdentityReadingStatus.Pending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(r => r.Status, IdentityReadingStatus.Failed)
                .SetProperty(r => r.FailureReason, reason)
                .SetProperty(r => r.UpdatedBy, user.Name)
                .SetProperty(r => r.UpdatedAt, time.GetUtcNow().UtcDateTime), ct);
}
