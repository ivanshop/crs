using Check.Application.Common;
using Check.Application.Payments;
using Check.Domain.Contracts;
using Check.Domain.Payments;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>sales.payment_notifications, activación del contrato y sales.contract_events.</summary>
public sealed class PaymentNotificationRepository(CheckDbContext db, ICurrentUser user, TimeProvider time)
    : IPaymentNotificationRepository
{
    public Task<QrPaymentInfo?> FindQrAsync(string bankTransactionId, CancellationToken ct) =>
        db.QrPayments.AsNoTracking()
            .Where(q => q.BankTransactionId == bankTransactionId)
            .Select(q => new QrPaymentInfo(
                q.Id, q.ContractId, q.Amount, q.Currency, q.Status,
                new DateTimeOffset(DateTime.SpecifyKind(q.ExpiresAt, DateTimeKind.Utc)),
                q.Contract.PlanId, q.Contract.Plan.Product.Code, q.Contract.Number))
            .FirstOrDefaultAsync(ct);

    public async Task SaveNotificationAsync(Guid? qrPaymentId, string bankTransactionId, string rawPayload, string result, CancellationToken ct)
    {
        db.PaymentNotifications.Add(NewNotification(qrPaymentId, bankTransactionId, rawPayload, result));
        await db.SaveChangesAsync(ct);
    }

    public async Task<bool> ActivateAsync(PaymentActivation a, CancellationToken ct)
    {
        var now = time.GetUtcNow().UtcDateTime;
        await using var transaction = await db.Database.BeginTransactionAsync(ct);

        // Solo si sigue Pendiente: si otro aviso llegó a la vez, este no actualiza nada y se trata como duplicado.
        var updated = await db.QrPayments
            .Where(q => q.Id == a.QrPaymentId && q.Status == QrPaymentStatus.Pending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(q => q.Status, QrPaymentStatus.Paid)
                .SetProperty(q => q.PaidAt, a.PaidAt.UtcDateTime)
                .SetProperty(q => q.UpdatedBy, user.Name)
                .SetProperty(q => q.UpdatedAt, now), ct);
        if (updated == 0)
        {
            await transaction.RollbackAsync(ct);
            return false;
        }

        db.PaymentNotifications.Add(NewNotification(a.QrPaymentId, a.BankTransactionId, a.RawPayload, PaymentNotificationResult.Applied));

        var contract = await db.Contracts.FirstAsync(c => c.Id == a.ContractId, ct);
        contract.Status = ContractStatus.Active;
        contract.Number = a.ContractNumber;
        contract.CoverageFrom = a.CoverageFrom.UtcDateTime;
        contract.CoverageTo = a.CoverageTo.UtcDateTime;
        contract.UpdatedBy = user.Name;
        contract.UpdatedAt = now;

        // Bitácora (PagoConfirmado) y outbox hacia Service Bus (bienvenida y carpeta del cliente).
        db.ContractEvents.AddRange(
            NewEvent(a, ContractEventTypes.PaymentConfirmed, null, ContractEventStatus.Logged, null),
            NewEvent(a, ContractEventTypes.WelcomeEmail, ContractEventQueues.WelcomeEmail, ContractEventStatus.Pending, now),
            NewEvent(a, ContractEventTypes.ClientFolder, ContractEventQueues.ClientFolder, ContractEventStatus.Pending, now));

        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
        return true;
    }

    public Task<PendingQr?> GetPendingQrAsync(Guid contractId, CancellationToken ct) =>
        db.QrPayments.AsNoTracking()
            .Where(q => q.ContractId == contractId && q.Status == QrPaymentStatus.Pending && q.BankTransactionId != null)
            .Select(q => new PendingQr(q.BankTransactionId!, q.Amount, q.Currency, q.Contract.Plan.Product.Name, q.Contract.Plan.Name))
            .FirstOrDefaultAsync(ct);

    private PaymentNotification NewNotification(Guid? qrPaymentId, string bankTransactionId, string rawPayload, string result) => new()
    {
        QrPaymentId = qrPaymentId,
        BankTransactionId = bankTransactionId,
        RawPayload = rawPayload,
        Result = result,
        CreatedBy = user.Name
    };

    private ContractEvent NewEvent(PaymentActivation a, string type, string? queue, string status, DateTime? nextAttemptAt) => new()
    {
        Id = Guid.CreateVersion7(),
        ContractId = a.ContractId,
        Type = type,
        Queue = queue,
        Payload = a.EventPayload,
        Status = status,
        NextAttemptAt = nextAttemptAt,
        IsActive = true,
        CreatedBy = user.Name
    };
}
