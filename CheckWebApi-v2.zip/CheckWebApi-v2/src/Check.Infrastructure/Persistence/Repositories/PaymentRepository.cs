using Check.Application.Common;
using Check.Application.Payments;
using Check.Domain.Contracts;
using Check.Domain.Payments;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>sales.qr_payments.</summary>
public sealed class PaymentRepository(CheckDbContext db, ICurrentUser user, TimeProvider time) : IPaymentRepository
{
    public Task<QrContext?> GetQrContextAsync(Guid contractId, CancellationToken ct) =>
        db.Contracts.AsNoTracking()
            .Where(c => c.Id == contractId && c.IsActive)
            .Select(c => new QrContext(
                c.Id, c.Status, c.PremiumAmount, c.Currency, c.Plan.Product.Name, c.Plan.Name,
                db.QrPayments.Count(q => q.ContractId == c.Id)))
            .FirstOrDefaultAsync(ct);

    public async Task SaveQrAsync(NewQrPayment qr, CancellationToken ct)
    {
        var now = time.GetUtcNow().UtcDateTime;
        await using var transaction = await db.Database.BeginTransactionAsync(ct);

        // El pendiente anterior queda Reemplazado ANTES de insertar el nuevo (índice único: un solo Pendiente
        // por contrato). UPDATE directo: el scaffold modeló Contract–QrPayment como 1:1.
        await db.QrPayments
            .Where(q => q.ContractId == qr.ContractId && q.Status == QrPaymentStatus.Pending)
            .ExecuteUpdateAsync(s => s
                .SetProperty(q => q.Status, QrPaymentStatus.Replaced)
                .SetProperty(q => q.UpdatedBy, user.Name)
                .SetProperty(q => q.UpdatedAt, now), ct);

        db.QrPayments.Add(new QrPayment
        {
            Id = qr.Id,
            ContractId = qr.ContractId,
            Amount = qr.Amount,
            Currency = qr.Currency,
            BankTransactionId = qr.BankTransactionId,
            ExpiresAt = qr.ExpiresAt.UtcDateTime,
            Status = QrPaymentStatus.Pending,
            IsActive = true,
            CreatedBy = user.Name
        });

        var contract = await db.Contracts.FirstAsync(c => c.Id == qr.ContractId, ct);
        contract.Status = ContractStatus.PendingPayment;
        contract.UpdatedBy = user.Name;
        contract.UpdatedAt = now;

        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
    }
}
