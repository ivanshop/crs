using Check.Application.Common;
using Check.Application.Surveys;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Microsoft.EntityFrameworkCore;
using SurveyEntity = Check.Infrastructure.Persistence.Check.Entities.SurveyResponse;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>feedback.survey_responses (solo escritura).</summary>
public sealed class SurveyRepository(CheckDbContext db, ICurrentUser user) : ISurveyRepository
{
    public async Task<(string Status, bool Answered)?> GetAsync(Guid contractId, string type, CancellationToken ct)
    {
        var row = await db.Contracts.AsNoTracking()
            .Where(c => c.Id == contractId && c.IsActive)
            .Select(c => new { c.Status, Answered = c.SurveyResponses.Any(s => s.Type == type) })
            .FirstOrDefaultAsync(ct);
        return row is null ? null : (row.Status, row.Answered);
    }

    public async Task AddAsync(Guid contractId, string type, int score, string? comment, CancellationToken ct)
    {
        db.SurveyResponses.Add(new SurveyEntity
        {
            ContractId = contractId,
            Type = type,
            Score = (short)score,
            Comment = comment,
            CreatedBy = user.Name
        });
        await db.SaveChangesAsync(ct);
    }
}
