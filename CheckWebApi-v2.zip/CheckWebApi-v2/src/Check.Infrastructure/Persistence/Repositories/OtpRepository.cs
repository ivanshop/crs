using System.Text.Json;
using Check.Application.Common;
using Check.Application.Otp;
using Check.Domain.Contracts;
using Check.Infrastructure.Persistence.Check;
using Check.Infrastructure.Persistence.Check.Entities;
using Check.Infrastructure.Security;
using Microsoft.EntityFrameworkCore;

namespace Check.Infrastructure.Persistence.Repositories;

/// <summary>sales.otp_challenges. Destino cifrado; el código verificado se guarda como HMAC (no se puede revertir).</summary>
public sealed class OtpRepository(CheckDbContext db, FieldEncryptor crypto, ICurrentUser user, TimeProvider time) : IOtpRepository
{
    public async Task<OtpContract?> GetContractAsync(Guid contractId, CancellationToken ct)
    {
        var row = await db.Contracts.AsNoTracking()
            .Where(c => c.Id == contractId && c.IsActive)
            .Select(c => new
            {
                c.Id,
                c.Status,
                Payer = c.ContractParties
                    .Where(p => p.Role == PartyRoles.Contractor && p.IsActive)
                    .Select(p => new { p.DocumentNumber, p.Cellphone, p.Email })
                    .FirstOrDefault(),
                Sends = c.OtpChallenges.Count(),
                LastSentAt = c.OtpChallenges.Max(o => (DateTime?)o.CreatedAt)
            })
            .FirstOrDefaultAsync(ct);

        if (row?.Payer is null) return null;

        var payer = new OtpRecipient(
            crypto.Decrypt(row.Payer.DocumentNumber),
            row.Payer.Cellphone is null ? "" : crypto.Decrypt(row.Payer.Cellphone),
            row.Payer.Email is null ? "" : crypto.Decrypt(row.Payer.Email));

        return new OtpContract(row.Id, row.Status, payer, row.Sends, ToUtc(row.LastSentAt));
    }

    public async Task AddChallengeAsync(Guid contractId, OtpRecipient recipient, DateTimeOffset expiresAt, int maxAttempts, CancellationToken ct)
    {
        db.OtpChallenges.Add(new OtpChallenge
        {
            ContractId = contractId,
            Channel = OtpChannels.Multichannel,
            Destination = crypto.Encrypt(JsonSerializer.Serialize(new { recipient.Cellphone, recipient.Email })),
            ExpiresAt = expiresAt.UtcDateTime,
            MaxAttempts = (short)maxAttempts,
            IsActive = true,
            CreatedBy = user.Name
        });
        await db.SaveChangesAsync(ct);
    }

    public Task<OtpChallengeRecord?> GetLatestChallengeAsync(Guid contractId, CancellationToken ct) =>
        db.OtpChallenges.AsNoTracking()
            .Where(o => o.ContractId == contractId && o.IsActive)
            .OrderByDescending(o => o.CreatedAt).ThenByDescending(o => o.Id)
            .Select(o => new OtpChallengeRecord(
                o.Id,
                new DateTimeOffset(DateTime.SpecifyKind(o.ExpiresAt, DateTimeKind.Utc)),
                o.Attempts, o.MaxAttempts, o.VerifiedAt != null))
            .FirstOrDefaultAsync(ct);

    public Task RegisterFailedAttemptAsync(long challengeId, CancellationToken ct) =>
        db.OtpChallenges.Where(o => o.Id == challengeId)
            .ExecuteUpdateAsync(s => s
                .SetProperty(o => o.Attempts, o => (short)(o.Attempts + 1))
                .SetProperty(o => o.UpdatedBy, user.Name)
                .SetProperty(o => o.UpdatedAt, time.GetUtcNow().UtcDateTime), ct);

    public async Task VerifyAsync(long challengeId, Guid contractId, string code, string? providerHash, CancellationToken ct)
    {
        var now = time.GetUtcNow().UtcDateTime;
        var challenge = await db.OtpChallenges.FirstAsync(o => o.Id == challengeId, ct);
        challenge.VerifiedAt = now;
        challenge.Attempts++;
        // El contrato forma parte del hash: el mismo código en otro contrato da otro hash.
        challenge.CodeHash = crypto.Hash($"OTP|{contractId}|{code}");
        challenge.ProviderHash = providerHash;
        challenge.UpdatedBy = user.Name;
        challenge.UpdatedAt = now;

        var contract = await db.Contracts.FirstAsync(c => c.Id == contractId, ct);
        contract.Status = ContractStatus.Verified;
        contract.UpdatedBy = user.Name;
        contract.UpdatedAt = now;

        await db.SaveChangesAsync(ct);
    }

    private static DateTimeOffset? ToUtc(DateTime? value) =>
        value is null ? null : new DateTimeOffset(DateTime.SpecifyKind(value.Value, DateTimeKind.Utc));
}
