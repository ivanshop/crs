namespace Check.Infrastructure.ExternalServices.Segip;

/// <summary>Sección "Segip". Credenciales en user-secrets (desarrollo) o Key Vault (producción).</summary>
public sealed class SegipOptions
{
    public const string Section = "Segip";

    /// <summary>true = no llama a SEGIP. CI que termina en 000: nombres no coinciden; en 999: no encontrado.</summary>
    public bool UseFake { get; init; }
    public string Url { get; init; } = "https://wsconsulta.segip.gob.bo/ServicioExternoInstitucion.svc";
    public int TimeoutSeconds { get; init; } = 30;
    public int InstitutionCode { get; init; }
    public string User { get; init; } = "";
    public string Password { get; init; } = "";
    public string EndUserAccessKey { get; init; } = "";
}
