using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Check.Application.Common;
using Check.Application.Screening;
using Check.Domain.Compliance;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.ExternalServices.Segip;

/// <summary>
/// SEGIP: operación SOAP 1.1 ConsultaDatoPersonaContrastacion (BasicHttpBinding sobre HTTPS).
/// Se arma el envelope a mano: es una sola operación y así no se depende de WCF.
/// </summary>
internal sealed class SegipClient(HttpClient http, IOptions<SegipOptions> options, ILogger<SegipClient> logger) : ISegipClient
{
    private const string Service = "SEGIP";
    private const string SoapAction = "http://tempuri.org/IServicioExternoInstitucion/ConsultaDatoPersonaContrastacion";
    private static readonly XNamespace Soap = "http://schemas.xmlsoap.org/soap/envelope/";
    private static readonly XNamespace Tempuri = "http://tempuri.org/";

    private readonly SegipOptions _options = options.Value;

    public async Task<SegipResult> VerifyAsync(SegipQuery query, CancellationToken ct)
    {
        // pListaCampo: JSON con los nombres de campo de SEGIP. Lo no enviado va vacío.
        var fields = JsonSerializer.Serialize(new
        {
            NumeroDocumento = query.DocumentNumber,
            Complemento = query.Complement ?? "",
            Nombres = query.Names,
            PrimerApellido = query.PaternalLastname ?? "",
            SegundoApellido = query.MaternalLastname ?? "",
            FechaNacimiento = query.Birthdate.ToString("dd/MM/yyyy"),
            LugarNacimientoPais = "",
            LugarNacimientoDepartamento = "",
            LugarNacimientoProvincia = "",
            LugarNacimientoLocalidad = ""
        });

        var envelope = new XElement(Soap + "Envelope", new XAttribute(XNamespace.Xmlns + "s", Soap),
            new XElement(Soap + "Body",
                new XElement(Tempuri + "ConsultaDatoPersonaContrastacion",
                    new XElement(Tempuri + "pCodigoInstitucion", _options.InstitutionCode),
                    new XElement(Tempuri + "pUsuario", _options.User),
                    new XElement(Tempuri + "pContrasenia", _options.Password),
                    new XElement(Tempuri + "pClaveAccesoUsuarioFinal", _options.EndUserAccessKey),
                    new XElement(Tempuri + "pNumeroAutorizacion", ""),
                    new XElement(Tempuri + "pListaCampo", fields),
                    new XElement(Tempuri + "pTipoPersona", query.IsForeigner ? 2 : 1))));

        using var request = new HttpRequestMessage(HttpMethod.Post, "");
        request.Content = new StringContent(envelope.ToString(SaveOptions.DisableFormatting), Encoding.UTF8, "text/xml");
        request.Headers.Add("SOAPAction", $"\"{SoapAction}\"");

        XDocument xml;
        try
        {
            using var response = await http.SendAsync(request, ct);
            var body = await response.Content.ReadAsStringAsync(ct);
            xml = XDocument.Parse(body);

            if (!response.IsSuccessStatusCode)
            {
                var fault = xml.Descendants().FirstOrDefault(e => e.Name.LocalName == "faultstring")?.Value;
                logger.LogWarning("SEGIP respondió {Estado}: {Fault}", (int)response.StatusCode, fault);
                throw new ExternalServiceException(Service, $"Respondió {(int)response.StatusCode}.");
            }
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or System.Xml.XmlException && !ct.IsCancellationRequested)
        {
            throw new ExternalServiceException(Service, "No respondió, superó el tiempo de espera o devolvió una respuesta inválida.", ex);
        }

        var result = xml.Descendants().FirstOrDefault(e => e.Name.LocalName == "ConsultaDatoPersonaContrastacionResult")
                     ?? throw new ExternalServiceException(Service, "La respuesta no trae ConsultaDatoPersonaContrastacionResult.");

        string? Value(string name) => result.Elements().FirstOrDefault(e => e.Name.LocalName == name)?.Value;

        var contrast = Value("ContrastacionEnFormatoJson");
        var matches = string.IsNullOrWhiteSpace(contrast)
            ? new Dictionary<string, int>()
            : JsonSerializer.Deserialize<Dictionary<string, int>>(contrast) ?? [];

        return new SegipResult(
            int.TryParse(Value("CodigoRespuesta"), out var code) ? code : 0,
            bool.TryParse(Value("EsValido"), out var valid) && valid,
            Value("CodigoUnico"),
            Value("Mensaje") ?? Value("DescripcionRespuesta"),
            matches);
    }
}
