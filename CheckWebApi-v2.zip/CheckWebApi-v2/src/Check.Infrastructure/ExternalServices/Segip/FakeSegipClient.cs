using Check.Application.Screening;
using Check.Domain.Compliance;

namespace Check.Infrastructure.ExternalServices.Segip;

/// <summary>SEGIP de prueba (Segip:UseFake = true). CI que termina en 000: nombres no coinciden; en 999: no encontrado.</summary>
internal sealed class FakeSegipClient : ISegipClient
{
    public Task<SegipResult> VerifyAsync(SegipQuery query, CancellationToken ct)
    {
        if (query.DocumentNumber.EndsWith("999"))
            return Task.FromResult(new SegipResult(1, false, null, "No se encontró el registro", new Dictionary<string, int>()));

        var names = query.DocumentNumber.EndsWith("000") ? 0 : 1;
        var matches = new Dictionary<string, int>
        {
            ["NumeroDocumento"] = 1, ["Complemento"] = query.Complement is null ? 2 : 1, ["Nombres"] = names,
            ["PrimerApellido"] = 1, ["SegundoApellido"] = 1, ["FechaNacimiento"] = 1,
            ["LugarNacimientoPais"] = 2, ["LugarNacimientoDepartamento"] = 2, ["ApellidoEsposo"] = 2
        };
        return Task.FromResult(new SegipResult(2, true, $"FAKE-{Guid.NewGuid():N}"[..14], "La consulta se realizó satisfactoriamente", matches));
    }
}
