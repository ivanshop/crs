using System.Globalization;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.Json;
using Check.Application.Common;
using Check.Application.IdentityReadings;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.ExternalServices.Llamita;

/// <summary>
/// Cliente de Llamita (documenteai): POST de las fotos y GET del resultado.
/// Los campos se buscan sin distinguir mayúsculas ni guiones bajos (NumeroCedula = numero_cedula)
/// y la respuesta se acepta con o sin envoltura "data".
/// </summary>
internal sealed class LlamitaClient(HttpClient http, IOptions<LlamitaOptions> options, ILogger<LlamitaClient> logger)
    : IIdentityOcrClient
{
    private const string Service = "Llamita";
    private readonly LlamitaOptions _options = options.Value;

    public bool Supports(string productCode) => _options.Workspaces.ContainsKey(productCode);

    public async Task<string> UploadAsync(string productCode, string name, IdentityImage front, IdentityImage back, CancellationToken ct)
    {
        var workspace = _options.Workspaces[productCode];
        var body = new LlamitaUploadRequest(ToDataUri(front), ToDataUri(back), name, workspace.DocumentTypeId);

        // Cuerpo completo con Content-Length: Llamita no lee bien un cuerpo chunked (lo que envía PostAsJsonAsync).
        using var content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
        var root = await SendAsync(() => http.PostAsync($"v1/workspaces/{workspace.WorkspaceId}/documents/", content, ct), ct);
        return Find(root, "uuid")?.GetString()
               ?? throw new ExternalServiceException(Service, "La respuesta de la subida no trae uuid.");
    }

    public async Task<OcrResult> GetResultAsync(string providerDocumentId, CancellationToken ct)
    {
        var root = await SendAsync(() => http.GetAsync($"v1/workspace-documents/{providerDocumentId}/", ct), ct);
        var status = Find(root, "status")?.GetString()?.ToUpperInvariant();

        return status switch
        {
            "COMPLETED" => new OcrResult(OcrStatus.Completed, Find(root, "extraction") is { ValueKind: JsonValueKind.Object } e ? ToFields(e) : null,
                "Llamita no devolvió los datos extraídos."),
            "FAILED" => new OcrResult(OcrStatus.Failed, null,
                Find(root, "metadata") is { ValueKind: JsonValueKind.Object } m && Text(m, "message") is { } msg ? msg : "Llamita no pudo leer el carnet."),
            _ => new OcrResult(OcrStatus.Pending, null, null)
        };
    }

    private async Task<JsonElement> SendAsync(Func<Task<HttpResponseMessage>> send, CancellationToken ct)
    {
        HttpResponseMessage response;
        try
        {
            response = await send();
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ct.IsCancellationRequested)
        {
            throw new ExternalServiceException(Service, "No respondió o superó el tiempo de espera.", ex);
        }

        using (response)
        {
            if (!response.IsSuccessStatusCode)
            {
                // No se registra el cuerpo: puede traer datos personales.
                logger.LogWarning("Llamita respondió {Estado} en {Ruta}.", (int)response.StatusCode, response.RequestMessage?.RequestUri?.AbsolutePath);
                throw new ExternalServiceException(Service, $"Respondió {(int)response.StatusCode}.");
            }

            using var doc = await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);
            var root = doc.RootElement.Clone();
            return Find(root, "data") is { ValueKind: JsonValueKind.Object } data ? data : root;
        }
    }

    private static IdentityFields ToFields(JsonElement e)
    {
        var birthdate = Date(e, "FechaNacimiento");
        return new IdentityFields(
            DocumentType: Text(e, "TipoDocumento")?.ToUpperInvariant() switch
            {
                "CEDULA_DE_IDENTIDAD" => "CI",
                { } t when t.Contains("EXTRANJER") => "CE",
                _ => null
            },
            DocumentNumber: Text(e, "NumeroCedula"),
            Complement: Text(e, "Complemento"),
            Extension: Text(e, "Extension"),
            Names: Text(e, "Nombres"),
            PaternalLastname: Text(e, "ApellidoPaterno"),
            MaternalLastname: Text(e, "ApellidoMaterno"),
            Birthdate: birthdate,
            BirthPlace: Text(e, "LugarNacimiento"),
            Address: Text(e, "Domicilio"),
            Occupation: Text(e, "Ocupacion"),
            MaritalStatus: Text(e, "EstadoCivil"),
            IssuedAt: Date(e, "FechaEmision"),
            ExpiresAt: Date(e, "FechaExpiracion"),
            IsMinor: Find(e, "EsMenorDeEdad") switch
            {
                { ValueKind: JsonValueKind.True } => true,
                { ValueKind: JsonValueKind.False } => false,
                { ValueKind: JsonValueKind.String } s when bool.TryParse(s.GetString(), out var b) => b,
                _ => null
            });
    }

    private static string ToDataUri(IdentityImage image) =>
        $"data:{(image.Format == ImageFormat.Png ? "image/png" : "image/jpeg")};base64,{Convert.ToBase64String(image.Content)}";

    /// <summary>Busca una propiedad ignorando mayúsculas y guiones bajos.</summary>
    private static JsonElement? Find(JsonElement element, string name)
    {
        if (element.ValueKind != JsonValueKind.Object) return null;
        var key = Normalize(name);
        foreach (var p in element.EnumerateObject())
            if (Normalize(p.Name) == key) return p.Value;
        return null;
    }

    private static string Normalize(string name) => name.Replace("_", "").ToLowerInvariant();

    private static string? Text(JsonElement e, string name) =>
        Find(e, name) is { ValueKind: JsonValueKind.String } v && !string.IsNullOrWhiteSpace(v.GetString()) ? v.GetString()!.Trim() : null;

    /// <summary>Llamita devuelve las fechas como dd/MM/yyyy.</summary>
    private static DateOnly? Date(JsonElement e, string name) =>
        DateOnly.TryParseExact(Text(e, name), "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;
}

/// <summary>Body de la subida, con los nombres exactos que espera Llamita. Imágenes como data URI en base64.</summary>
internal sealed record LlamitaUploadRequest(
    [property: JsonPropertyName("front_image")] string FrontImage,
    [property: JsonPropertyName("back_image")] string BackImage,
    [property: JsonPropertyName("name")] string Name,
    [property: JsonPropertyName("documentTypeId")] string DocumentTypeId);
