namespace Check.Infrastructure.ExternalServices.Llamita;

/// <summary>Sección "Llamita" de appsettings. ApiKey va en user-secrets (desarrollo) o Key Vault (producción).</summary>
public sealed class LlamitaOptions
{
    public const string Section = "Llamita";

    /// <summary>true = no llama a Llamita: devuelve datos de prueba (Pendiente en la 1.ª consulta, luego Completado).</summary>
    public bool UseFake { get; init; }
    public string BaseUrl { get; init; } = "https://api-dev.documenteai.com/";
    public string ApiKey { get; init; } = "";
    public string Tenant { get; init; } = "";
    public int TimeoutSeconds { get; init; } = 30;

    /// <summary>Un workspace por producto, por código de producto (DEP-SEG...).</summary>
    public Dictionary<string, LlamitaWorkspace> Workspaces { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class LlamitaWorkspace
{
    public string WorkspaceId { get; init; } = "";
    public string DocumentTypeId { get; init; } = "";
}
