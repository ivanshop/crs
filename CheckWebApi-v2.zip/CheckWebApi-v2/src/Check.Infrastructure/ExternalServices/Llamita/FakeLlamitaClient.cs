using System.Collections.Concurrent;
using Check.Application.IdentityReadings;

namespace Check.Infrastructure.ExternalServices.Llamita;

/// <summary>Llamita de prueba (Llamita:UseFake = true): la 1.ª consulta responde Pendiente y la 2.ª, Completado.</summary>
internal sealed class FakeLlamitaClient : IIdentityOcrClient
{
    private readonly ConcurrentDictionary<string, int> _polls = new();

    public bool Supports(string productCode) => true;

    public Task<string> UploadAsync(string productCode, string name, IdentityImage front, IdentityImage back, CancellationToken ct) =>
        Task.FromResult(Guid.NewGuid().ToString());

    public Task<OcrResult> GetResultAsync(string providerDocumentId, CancellationToken ct)
    {
        if (_polls.AddOrUpdate(providerDocumentId, 1, (_, n) => n + 1) < 2)
            return Task.FromResult(new OcrResult(OcrStatus.Pending, null, null));

        var fields = new IdentityFields("CI", "1234567", null, "LP", "JUAN CARLOS", "PEREZ", "MAMANI",
            new DateOnly(1990, 5, 20), "LA PAZ - MURILLO - LA PAZ", "AV. SIEMPRE VIVA 123", "ESTUDIANTE", "SOLTERO",
            new DateOnly(2024, 1, 10), new DateOnly(2034, 1, 10), false);
        return Task.FromResult(new OcrResult(OcrStatus.Completed, fields, null));
    }
}
