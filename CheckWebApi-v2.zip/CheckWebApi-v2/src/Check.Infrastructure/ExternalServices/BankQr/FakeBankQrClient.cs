using System.Globalization;
using System.Text.Json;
using Check.Application.Payments;
using QRCoder;

namespace Check.Infrastructure.ExternalServices.BankQr;

/// <summary>
/// Banco de prueba: genera un QR real (escaneable) cuyo contenido es un JSON con id, monto, moneda, glosa y vencimiento.
/// Devuelve los mismos datos que recibió, como haría el banco.
/// </summary>
internal sealed class FakeBankQrClient : IBankQrClient
{
    public Task<QrResult> GenerateAsync(QrRequest request, CancellationToken ct)
    {
        var bankTransactionId = $"FAKE-{DateTime.UtcNow:yyyyMMddHHmmss}-{Random.Shared.Next(100000, 999999)}";
        var content = JsonSerializer.Serialize(new
        {
            banco = "BANCO DE PRUEBA",
            transaccion = bankTransactionId,
            referencia = request.QrPaymentId,
            monto = request.Amount.ToString("0.00", CultureInfo.InvariantCulture),
            moneda = request.Currency,
            glosa = request.Description,
            vence = request.ExpiresAt.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture),
            usoUnico = request.SingleUse
        });

        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(content, QRCodeGenerator.ECCLevel.M);
        var png = new PngByteQRCode(data).GetGraphic(8);

        return Task.FromResult(new QrResult(bankTransactionId, Convert.ToBase64String(png),
            request.Amount, request.Currency, request.Description, request.ExpiresAt));
    }
}
