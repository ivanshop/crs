namespace Check.Infrastructure.ExternalServices.BankQr;

/// <summary>
/// Sección "BankQr". El banco exige certificado de cliente: cuando tengamos su API, el cliente real se registra
/// con ConfigurePrimaryHttpMessageHandler y un HttpClientHandler con ClientCertificates (CertificatePath/Password
/// en desarrollo; en producción, el certificado desde Key Vault).
/// </summary>
public sealed class BankQrOptions
{
    public const string Section = "BankQr";

    /// <summary>Por ahora solo existe el banco falso.</summary>
    public bool UseFake { get; init; } = true;
    public string BaseUrl { get; init; } = "";
    public string CertificatePath { get; init; } = "";
    public string CertificatePassword { get; init; } = "";
    public int TimeoutSeconds { get; init; } = 20;
}
