using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Check.Application.Common;
using Check.Application.Otp;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Check.Infrastructure.ExternalServices.Otp;

/// <summary>Servicio OTP del banco: POST Generate y POST Validate. Respuesta OK: { state: "000", message, data }.</summary>
internal sealed class OtpClient(HttpClient http, IOptions<OtpOptions> options, ILogger<OtpClient> logger) : IOtpClient
{
    private const string Service = "OTP";
    private const string SuccessState = "000";
    private readonly OtpOptions _options = options.Value;

    public async Task<string> SendAsync(OtpRecipient recipient, CancellationToken ct)
    {
        var body = new GenerateRequest(_options.Channel, _options.Password, _options.Application,
            recipient.Email, recipient.Cellphone, recipient.DocumentNumber);

        var response = await PostAsync<GenerateData>("Generate", body, ct);
        return response.TextToDisplay ?? "Código enviado.";
    }

    public async Task<OtpValidation> ValidateAsync(string code, string documentNumber, CancellationToken ct)
    {
        var body = new ValidateRequest(_options.Channel, _options.Password, _options.Application, code, documentNumber);
        var data = await PostAsync<ValidateData>("Validate", body, ct);
        return new OtpValidation(data.IsValid, data.Hash, data.Description);
    }

    private async Task<TData> PostAsync<TData>(string endpoint, object body, CancellationToken ct)
    {
        // Cuerpo completo con Content-Length (sin chunked), igual que con Llamita.
        using var content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
        try
        {
            using var response = await http.PostAsync(endpoint, content, ct);
            if (!response.IsSuccessStatusCode)
            {
                // No se registra el cuerpo: puede traer el documento o el celular.
                logger.LogWarning("El servicio OTP respondió {Estado} en {Endpoint}.", (int)response.StatusCode, endpoint);
                throw new ExternalServiceException(Service, $"{endpoint} respondió {(int)response.StatusCode}.");
            }

            var result = await JsonSerializer.DeserializeAsync<OtpResponse<TData>>(
                await response.Content.ReadAsStreamAsync(ct), JsonSerializerOptions.Web, ct);

            if (result?.State != SuccessState || result.Data is null)
                throw new ExternalServiceException(Service, $"{endpoint} respondió state {result?.State}: {result?.Message}");

            return result.Data;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException && !ct.IsCancellationRequested)
        {
            throw new ExternalServiceException(Service, $"{endpoint} no respondió o devolvió una respuesta inválida.", ex);
        }
    }

    private sealed record GenerateRequest(
        [property: JsonPropertyName("canal")] string Canal,
        [property: JsonPropertyName("password")] string Password,
        [property: JsonPropertyName("aplicativo")] string Aplicativo,
        [property: JsonPropertyName("correoElectronico")] string CorreoElectronico,
        [property: JsonPropertyName("celular")] string Celular,
        [property: JsonPropertyName("nroDocumentoIdentidad")] string NroDocumentoIdentidad);

    private sealed record ValidateRequest(
        [property: JsonPropertyName("canal")] string Canal,
        [property: JsonPropertyName("password")] string Password,
        [property: JsonPropertyName("aplicativo")] string Aplicativo,
        [property: JsonPropertyName("codigo")] string Codigo,
        [property: JsonPropertyName("nroDocumentoIdentidad")] string NroDocumentoIdentidad);

    private sealed record OtpResponse<T>(string? State, string? Message, T? Data);
    private sealed record GenerateData(string? TextToDisplay);
    private sealed record ValidateData(bool IsValid, string? Status, string? Description, string? Hash);
}
