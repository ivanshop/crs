using Check.Application.Otp;

namespace Check.Infrastructure.ExternalServices.Otp;

/// <summary>OTP de prueba (Otp:UseFake = true): no envía nada y el código válido es 123456.</summary>
internal sealed class FakeOtpClient : IOtpClient
{
    public const string ValidCode = "123456";

    public Task<string> SendAsync(OtpRecipient recipient, CancellationToken ct)
    {
        var phone = recipient.Cellphone.Length > 2 ? new string('X', recipient.Cellphone.Length - 2) + recipient.Cellphone[^2..] : recipient.Cellphone;
        var at = recipient.Email.IndexOf('@');
        var mail = at > 0 ? new string('X', at) + recipient.Email[at..] : recipient.Email;
        return Task.FromResult($"Código OTP enviado a SMS: {phone} Correo: {mail} WhatsApp: {phone}");
    }

    public Task<OtpValidation> ValidateAsync(string code, string documentNumber, CancellationToken ct) =>
        Task.FromResult(code == ValidCode
            ? new OtpValidation(true, Random.Shared.NextInt64(1_000_000_000, 9_999_999_999).ToString(), "PROCESADO")
            : new OtpValidation(false, null, "CODIGO INCORRECTO"));
}
