namespace Check.Infrastructure.ExternalServices.Otp;

/// <summary>
/// Conexión al servicio OTP del banco (sección "Otp"; las reglas de negocio están en OtpSettings).
/// BaseUrl y credenciales en user-secrets (desarrollo) o Key Vault (producción).
/// </summary>
public sealed class OtpOptions
{
    public const string Section = "Otp";

    /// <summary>true = no llama al banco: el código válido es 123456.</summary>
    public bool UseFake { get; init; }
    /// <summary>Termina en /api/Otp/ (luego se agrega Generate o Validate).</summary>
    public string BaseUrl { get; init; } = "";
    public string Application { get; init; } = "";
    public string Channel { get; init; } = "";
    public string Password { get; init; } = "";
    public int TimeoutSeconds { get; init; } = 15;
}
