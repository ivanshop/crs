using System.ComponentModel.DataAnnotations;
using Check.Api.Infrastructure;
using Check.Application.IdentityReadings;
using Check.Domain.Compliance;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Check.Api.Controllers;

public sealed class IdentityReadingRequest
{
    [Required(ErrorMessage = "El planId es obligatorio.")]
    public long? PlanId { get; init; }

    [Required(ErrorMessage = "La foto del anverso es obligatoria.")]
    public IFormFile Front { get; init; } = null!;

    [Required(ErrorMessage = "La foto del reverso es obligatoria.")]
    public IFormFile Back { get; init; } = null!;
}

/// <summary>
/// Lectura del carnet con Llamita para precargar el formulario.
/// 1) POST con las fotos → 202 con el id. 2) GET cada 2-3 s hasta que el estado no sea Pendiente.
/// </summary>
[ApiController]
[Route("api/v1/identity-readings")]
[Authorize(Policy = Policies.WebClient)]
public sealed class IdentityReadingsController(
    StartIdentityReadingUseCase startReading,
    GetIdentityReadingUseCase getReading) : ControllerBase
{
    [HttpPost]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(12 * 1024 * 1024)]
    [EnableRateLimiting(RateLimits.IdentityReading)]
    [ProducesResponseType<ApiResponse<IdentityReadingResponse>>(StatusCodes.Status202Accepted)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> Start([FromForm] IdentityReadingRequest request, CancellationToken ct)
    {
        var result = await startReading.ExecuteAsync(
            request.PlanId!.Value, await ReadAsync(request.Front, ct), await ReadAsync(request.Back, ct),
            HttpContext.Connection.RemoteIpAddress?.ToString(), ct);

        return result.ToActionResult(this, "Estamos leyendo tu carnet.", StatusCodes.Status202Accepted);
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType<ApiResponse<IdentityReadingResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct)
    {
        var result = await getReading.ExecuteAsync(id, ct);
        var message = result.IsSuccess ? result.Value.Status switch
        {
            IdentityReadingStatus.Completed => "Carnet leído correctamente. Revisa tus datos.",
            IdentityReadingStatus.Failed => "No pudimos leer tu carnet. Completa tus datos manualmente.",
            _ => "Estamos leyendo tu carnet."
        } : "";

        return result.ToActionResult(this, message);
    }

    private static async Task<byte[]> ReadAsync(IFormFile file, CancellationToken ct)
    {
        using var memory = new MemoryStream((int)file.Length);
        await file.CopyToAsync(memory, ct);
        return memory.ToArray();
    }
}
