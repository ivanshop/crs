using Check.Api.Infrastructure;
using Check.Application.Contracts;
using Check.Application.Declarations;
using Check.Application.Otp;
using Check.Application.Payments;
using Check.Application.Screening;
using Check.Application.Surveys;
using Check.Domain.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/contracts")]
public sealed class ContractsController(
    StartContractUseCase startContract,
    GetContractUseCase getContract,
    ScreenContractUseCase screenContract,
    SendOtpUseCase sendOtp,
    VerifyOtpUseCase verifyOtp,
    DeclareUseCase declare,
    GenerateQrUseCase generateQr,
    SubmitSurveyUseCase submitSurvey) : ControllerBase
{
    /// <summary>
    /// Inicia la compra: registra al asegurado (y a su padre o madre si es menor) y crea el contrato en estado Iniciado.
    /// Devuelve el token del contrato para los pasos siguientes.
    /// </summary>
    [HttpPost]
    [Authorize(Policy = Policies.WebClient)]
    [ProducesResponseType<ApiResponse<StartContractResponse>>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> Start(StartContractRequest request, CancellationToken ct) =>
        (await startContract.ExecuteAsync(request, HttpContext.Connection.RemoteIpAddress?.ToString(), ct))
            .ToActionResult(this, "Contrato iniciado correctamente.", StatusCodes.Status201Created);

    /// <summary>
    /// Valida con SEGIP al asegurado y, si hay, al contratante. Usa el token del contrato.
    /// Todos aprobados → Validado. Datos que no coinciden o persona no encontrada → Rechazado.
    /// </summary>
    [HttpPost("{id:guid}/screening")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<ScreeningResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> Screen(Guid id, CancellationToken ct)
    {
        var result = await screenContract.ExecuteAsync(id, ct);
        var message = result.IsSuccess && result.Value.Status == ContractStatus.Validated
            ? "Tus datos fueron validados correctamente."
            : "Tus datos no coinciden con los registrados en SEGIP.";
        return result.ToActionResult(this, message);
    }

    /// <summary>Envía el código OTP al contratante (SMS, correo y WhatsApp). Requiere el contrato Validado.</summary>
    [HttpPost("{id:guid}/otp")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<SendOtpResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status422UnprocessableEntity)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> SendOtp(Guid id, CancellationToken ct) =>
        (await sendOtp.ExecuteAsync(id, ct)).ToActionResult(this, "Te enviamos el código de verificación.");

    /// <summary>Valida el código OTP. Correcto → contrato Verificado.</summary>
    [HttpPost("{id:guid}/otp/verification")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<VerifyOtpResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> VerifyOtp(Guid id, VerifyOtpRequest request, CancellationToken ct) =>
        (await verifyOtp.ExecuteAsync(id, request.Code, ct)).ToActionResult(this, "Código verificado correctamente.");

    /// <summary>
    /// Beneficiarios (vacío = herederos legales) y declaración PEP del contratante. Requiere el contrato Verificado;
    /// también se acepta Declarado para corregir antes de pagar. Deja el contrato Declarado.
    /// </summary>
    [HttpPut("{id:guid}/declarations")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<DeclarationsResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status422UnprocessableEntity)]
    public async Task<IActionResult> Declare(Guid id, DeclareRequest request, CancellationToken ct) =>
        (await declare.ExecuteAsync(id, request, ct)).ToActionResult(this, "Declaraciones registradas correctamente.");

    /// <summary>
    /// Genera el QR de pago por la prima del contrato (requiere Declarado). Si ya hay uno pendiente, lo reemplaza.
    /// Deja el contrato PendientePago hasta que llegue el aviso del banco.
    /// </summary>
    [HttpPost("{id:guid}/qr")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<QrResponse>>(StatusCodes.Status201Created)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status422UnprocessableEntity)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status503ServiceUnavailable)]
    public async Task<IActionResult> GenerateQr(Guid id, CancellationToken ct) =>
        (await generateQr.ExecuteAsync(id, ct)).ToActionResult(this, "QR generado. Escanéalo desde la app de tu banco.", StatusCodes.Status201Created);

    /// <summary>Encuesta opcional al terminar la compra: "¿Qué te pareció la experiencia de comprar tu seguro?" (1 a 10).</summary>
    [HttpPost("{id:guid}/survey")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<SurveyResponse>>(StatusCodes.Status201Created)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> SubmitSurvey(Guid id, SubmitSurveyRequest request, CancellationToken ct) =>
        (await submitSurvey.ExecuteAsync(id, request, ct)).ToActionResult(this, "¡Gracias por tu opinión!", StatusCodes.Status201Created);

    /// <summary>Estado del contrato. Mientras está PendientePago, el front lo consulta para saber cuándo llegó el pago.</summary>
    [HttpGet("{id:guid}")]
    [Authorize(Policy = Policies.ContractOwner)]
    [ProducesResponseType<ApiResponse<ContractSummaryResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(Guid id, CancellationToken ct) =>
        (await getContract.ExecuteAsync(id, ct)).ToActionResult(this, "Contrato obtenido correctamente.");
}
