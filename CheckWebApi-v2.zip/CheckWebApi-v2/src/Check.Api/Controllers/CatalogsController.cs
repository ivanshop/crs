using Check.Api.Infrastructure;
using Check.Application.Catalogs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/catalogs")]
[Authorize(Policy = Policies.WebClient)]
public sealed class CatalogsController(GetCatalogsUseCase getCatalogs) : ControllerBase
{
    /// <summary>Nacionalidades, ocupaciones, ciudades, parentescos y listas simples para los formularios.</summary>
    [HttpGet]
    [ProducesResponseType<ApiResponse<CatalogsResponse>>(StatusCodes.Status200OK)]
    public async Task<IActionResult> Get(CancellationToken ct) =>
        this.Success(await getCatalogs.ExecuteAsync(ct), "Catálogos obtenidos correctamente.");
}
