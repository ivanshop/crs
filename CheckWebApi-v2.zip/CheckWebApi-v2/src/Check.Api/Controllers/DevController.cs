using Check.Api.Infrastructure;
using Check.Application.Payments;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

public sealed class SimulatePaymentRequest
{
    /// <summary>Opcional: otro monto para probar "Monto Diferente".</summary>
    public decimal? Amount { get; init; }
}

/// <summary>Herramientas de prueba. Solo responden en el entorno Development (en otro entorno: 404).</summary>
[ApiController]
[Route("api/v1/dev")]
[ApiExplorerSettings(IgnoreApi = true)]
public sealed class DevController(SimulatePaymentUseCase simulatePayment, IWebHostEnvironment environment) : ControllerBase
{
    /// <summary>Simula el aviso del banco por el QR pendiente del contrato (mismo flujo que el aviso real).</summary>
    [HttpPost("contracts/{id:guid}/simulate-payment")]
    [Authorize(Policy = Policies.ContractOwner)]
    public async Task<IActionResult> SimulatePayment(Guid id, SimulatePaymentRequest? request, CancellationToken ct)
    {
        if (!environment.IsDevelopment()) return NotFound();
        return (await simulatePayment.ExecuteAsync(id, request?.Amount, ct)).ToActionResult(this, "Pago simulado.");
    }
}
