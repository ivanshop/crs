using Check.Api.Infrastructure;
using Check.Application.Products;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/products")]
[Authorize(Policy = Policies.WebClient)]
public sealed class ProductsController(GetProductsUseCase getProducts) : ControllerBase
{
    /// <summary>Productos activos con sus planes, coberturas y asistencias activos.</summary>
    [HttpGet]
    [ProducesResponseType<ApiResponse<IReadOnlyList<ProductResponse>>>(StatusCodes.Status200OK)]
    public async Task<IActionResult> Get(CancellationToken ct) =>
        this.Success(await getProducts.ExecuteAsync(ct), "Productos obtenidos correctamente.");
}
