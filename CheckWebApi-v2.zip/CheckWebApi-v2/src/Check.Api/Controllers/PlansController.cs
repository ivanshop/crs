using Check.Api.Infrastructure;
using Check.Application.Plans;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/plans")]
[Authorize(Policy = Policies.WebClient)]
public sealed class PlansController(GetPlanRulesUseCase getPlanRules) : ControllerBase
{
    /// <summary>Reglas de suscripción vigentes del plan (edades, prima, duración...), con su valor tipado.</summary>
    [HttpGet("{id:long}/rules")]
    [ProducesResponseType<ApiResponse<PlanRulesResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetRules(long id, CancellationToken ct) =>
        (await getPlanRules.ExecuteAsync(id, ct)).ToActionResult(this, "Reglas del plan obtenidas correctamente.");
}
