using Check.Api.Infrastructure;
using Check.Application.Payments;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Controllers;

[ApiController]
[Route("api/v1/payments")]
public sealed class PaymentsController(ProcessPaymentNotificationUseCase process) : ControllerBase
{
    /// <summary>
    /// Aviso de pago del banco (token del cliente bank-callback, rol "bank"). Siempre responde 200 con el resultado
    /// (Aplicado, Duplicado, Vencido, Monto Diferente o Desconocido) para que el banco no reintente.
    /// </summary>
    [HttpPost("notifications")]
    [Authorize(Policy = Policies.Bank)]
    [ProducesResponseType<ApiResponse<PaymentNotificationResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Notify(PaymentNotificationRequest request, CancellationToken ct) =>
        this.Success(await process.ExecuteAsync(request, ct), "Aviso de pago recibido.");
}
