using Check.Domain.Common;
using Check.Infrastructure.Security;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using System.ComponentModel.DataAnnotations;
using Check.Api.Infrastructure;

namespace Check.Api.Controllers;

public sealed class TokenRequest
{
    [Required(ErrorMessage = "El clientId es obligatorio.")]
    public string ClientId { get; init; } = null!;

    [Required(ErrorMessage = "El clientSecret es obligatorio.")]
    public string ClientSecret { get; init; } = null!;
}

public sealed record TokenResponse(string AccessToken, DateTimeOffset ExpiresAt);

/// <summary>
/// Emite tokens de cliente (client credentials). Si Check usa un proveedor de identidad,
/// este controller se elimina y la Api solo valida sus tokens.
/// </summary>
[ApiController]
[Route("api/v1/auth")]
public sealed class AuthController(JwtTokenFactory tokens, ILogger<AuthController> logger) : ControllerBase
{
    [HttpPost("token")]
    [EnableRateLimiting(RateLimits.Token)]
    public IActionResult Token(TokenRequest request)
    {
        var token = tokens.IssueForClient(request.ClientId, request.ClientSecret);
        if (token is null)
        {
            logger.LogWarning("Credenciales de cliente inválidas para {ClientId}.", request.ClientId);
            return Error.Unauthorized("INVALID_CLIENT", "Las credenciales del cliente no son válidas.").ToProblem(this);
        }

        logger.LogInformation("Token emitido para el cliente {ClientId}.", request.ClientId);
        return this.Success(new TokenResponse(token.Value, token.ExpiresAt), "Token emitido correctamente.");
    }
}
