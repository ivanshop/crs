using System.Diagnostics;

namespace Check.Api.Infrastructure;

/// <summary>Respuesta exitosa de toda la Api. Los errores se devuelven como ProblemDetails con el mismo traceId.</summary>
public sealed record ApiResponse<T>(string TraceId, string Message, T Data);

public static class TraceIds
{
    private const string ItemKey = "check.traceId";

    /// <summary>
    /// TraceId W3C de la solicitud: 32 caracteres hex (un GUID sin guiones). Es el mismo que va en los logs
    /// y en la cabecera traceparent. Si no hay Activity, se genera un GUID una sola vez por solicitud.
    /// </summary>
    public static string GetTraceId(this HttpContext context)
    {
        if (Activity.Current is { } activity) return activity.TraceId.ToHexString();
        if (context.Items[ItemKey] is string id) return id;
        id = Guid.NewGuid().ToString("N");
        context.Items[ItemKey] = id;
        return id;
    }
}
