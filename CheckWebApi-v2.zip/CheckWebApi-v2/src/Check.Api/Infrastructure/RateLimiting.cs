using System.Threading.RateLimiting;

namespace Check.Api.Infrastructure;

public static class RateLimits
{
    public const string Token = "token";
    /// <summary>Lectura del carnet con Llamita: cada llamada tiene costo.</summary>
    public const string IdentityReading = "identity-reading";

    public static IServiceCollection AddCheckRateLimiting(this IServiceCollection services, IConfiguration configuration)
    {
        var section = configuration.GetSection("RateLimiting");
        services.AddRateLimiter(o =>
        {
            o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
            o.OnRejected = (ctx, _) => new ValueTask(Problems.WriteAsync(ctx.HttpContext, 429,
                "Demasiadas solicitudes.", "Superaste el límite de intentos. Espera un momento antes de volver a intentar.", "RATE_LIMITED"));

            AddPerIp(o, Token, section.GetValue("TokenPerMinute", 20));
            AddPerIp(o, IdentityReading, section.GetValue("IdentityReadingPerMinute", 6));
        });
        return services;
    }

    private static void AddPerIp(Microsoft.AspNetCore.RateLimiting.RateLimiterOptions o, string name, int permitsPerMinute) =>
        o.AddPolicy(name, ctx => RateLimitPartition.GetFixedWindowLimiter(
            ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions { PermitLimit = permitsPerMinute, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 }));
}
