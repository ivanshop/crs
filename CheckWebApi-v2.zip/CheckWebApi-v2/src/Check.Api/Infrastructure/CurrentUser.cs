using Check.Application.Common;

namespace Check.Api.Infrastructure;

/// <summary>
/// Usuario para auditoría: el cliente (check-web, check-backoffice...). En el token de un contrato
/// viene en client_id (su "sub" es contract:{id}).
/// </summary>
public sealed class CurrentUser(IHttpContextAccessor accessor) : ICurrentUser
{
    public string Name =>
        accessor.HttpContext?.User.FindFirst("client_id")?.Value
        ?? accessor.HttpContext?.User.FindFirst("sub")?.Value
        ?? "system";
}
