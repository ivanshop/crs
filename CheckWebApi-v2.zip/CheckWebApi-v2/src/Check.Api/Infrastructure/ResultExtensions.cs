using System.Text.Json;
using Check.Domain.Common;
using Microsoft.AspNetCore.Mvc;

namespace Check.Api.Infrastructure;

/// <summary>Arma las respuestas HTTP: ApiResponse si fue bien, ProblemDetails si falló. Ambas con el mismo traceId.</summary>
public static class ResultExtensions
{
    public static IActionResult Success<T>(this ControllerBase controller, T data, string message, int status = StatusCodes.Status200OK) =>
        new ObjectResult(new ApiResponse<T>(controller.HttpContext.GetTraceId(), message, data)) { StatusCode = status };

    public static IActionResult ToActionResult<T>(this Result<T> result, ControllerBase controller, string message, int status = StatusCodes.Status200OK) =>
        result.IsSuccess
            ? controller.Success(result.Value, message, status)
            : result.Error!.ToProblem(controller);

    public static IActionResult ToProblem(this Error error, ControllerBase controller)
    {
        var (status, title) = error.Type switch
        {
            ErrorType.Validation => (StatusCodes.Status400BadRequest, "Los datos enviados no son válidos."),
            ErrorType.NotFound => (StatusCodes.Status404NotFound, "No se encontró el recurso."),
            ErrorType.Conflict => (StatusCodes.Status409Conflict, "La operación no es posible en el estado actual."),
            ErrorType.BusinessRule => (StatusCodes.Status422UnprocessableEntity, "La operación no cumple una regla del negocio."),
            ErrorType.Unauthorized => (StatusCodes.Status401Unauthorized, "No autenticado."),
            ErrorType.ExternalService => (StatusCodes.Status503ServiceUnavailable, "Un servicio externo no está disponible."),
            _ => (StatusCodes.Status500InternalServerError, "Ocurrió un error inesperado.")
        };

        var problem = Problems.Create(controller.HttpContext, status, title, error.Message, error.Code);
        return new ObjectResult(problem) { StatusCode = status, ContentTypes = { "application/problem+json" } };
    }
}

/// <summary>ProblemDetails con code y traceId, para usar también fuera de MVC (JWT, límites de uso).</summary>
public static class Problems
{
    public static ProblemDetails Create(HttpContext context, int status, string title, string detail, string code) => new()
    {
        Status = status,
        Title = title,
        Detail = detail,
        Extensions = { ["code"] = code, ["traceId"] = context.GetTraceId() }
    };

    public static Task WriteAsync(HttpContext context, int status, string title, string detail, string code)
    {
        context.Response.StatusCode = status;
        context.Response.ContentType = "application/problem+json";
        return context.Response.WriteAsync(JsonSerializer.Serialize(Create(context, status, title, detail, code), JsonSerializerOptions.Web));
    }
}
