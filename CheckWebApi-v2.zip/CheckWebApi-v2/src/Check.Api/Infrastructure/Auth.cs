using System.Text;
using Check.Infrastructure.Security;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;

namespace Check.Api.Infrastructure;

public static class Policies
{
    /// <summary>La web (u otro cliente) autenticado con client credentials.</summary>
    public const string WebClient = "WebClient";
    /// <summary>Operadores y sistemas internos (soporte, Cumplimiento, DocumentEngine).</summary>
    public const string Internal = "Internal";
    /// <summary>Token de un contrato: solo puede tocar el contrato de la ruta /contracts/{id}.</summary>
    public const string ContractOwner = "ContractOwner";
    /// <summary>El banco, para avisar los pagos (cliente bank-callback).</summary>
    public const string Bank = "Bank";
}

public sealed class ContractOwnerRequirement : IAuthorizationRequirement;

/// <summary>El claim contract_id del token debe coincidir con el {id} de la ruta.</summary>
public sealed class ContractOwnerHandler : AuthorizationHandler<ContractOwnerRequirement>
{
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ContractOwnerRequirement requirement)
    {
        if (context.Resource is HttpContext http &&
            http.GetRouteValue("id")?.ToString() is { } routeId &&
            context.User.FindFirst(CheckClaims.ContractId)?.Value is { } claimId &&
            string.Equals(routeId, claimId, StringComparison.OrdinalIgnoreCase))
        {
            context.Succeed(requirement);
        }
        return Task.CompletedTask;
    }
}

public static class AuthExtensions
{
    public static IServiceCollection AddCheckAuth(this IServiceCollection services, IConfiguration configuration)
    {
        var jwt = configuration.GetSection(JwtOptions.Section).Get<JwtOptions>()
                  ?? throw new InvalidOperationException("Falta la sección de configuración 'Jwt'.");
        if (string.IsNullOrEmpty(jwt.SigningKey) || jwt.SigningKey.Length < 32)
            throw new InvalidOperationException("Jwt:SigningKey debe tener al menos 32 caracteres.");

        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(o =>
            {
                o.MapInboundClaims = false;
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = jwt.Issuer,
                    ValidAudiences = [CheckClaims.ClientAudience, CheckClaims.ContractAudience],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.SigningKey)),
                    NameClaimType = "sub",
                    RoleClaimType = "role",
                    ClockSkew = TimeSpan.FromSeconds(30)
                };
                o.Events = new JwtBearerEvents
                {
                    OnChallenge = async ctx =>
                    {
                        ctx.HandleResponse();
                        await Problems.WriteAsync(ctx.HttpContext, StatusCodes.Status401Unauthorized,
                            "No autenticado.", "Debes enviar un token válido y vigente.", "UNAUTHENTICATED");
                    },
                    OnForbidden = ctx => Problems.WriteAsync(ctx.HttpContext, StatusCodes.Status403Forbidden,
                        "Acceso denegado.", "Tu token no tiene permiso para este recurso.", "FORBIDDEN")
                };
            });

        services.AddSingleton<IAuthorizationHandler, ContractOwnerHandler>();
        services.AddAuthorizationBuilder()
            .AddPolicy(Policies.WebClient, p => p.RequireAuthenticatedUser().RequireRole("web"))
            .AddPolicy(Policies.Internal, p => p.RequireAuthenticatedUser().RequireRole("internal"))
            .AddPolicy(Policies.Bank, p => p.RequireAuthenticatedUser().RequireRole("bank"))
            .AddPolicy(Policies.ContractOwner, p => p.RequireAuthenticatedUser()
                .RequireClaim(CheckClaims.ContractId)
                .AddRequirements(new ContractOwnerRequirement()));

        return services;
    }
}
