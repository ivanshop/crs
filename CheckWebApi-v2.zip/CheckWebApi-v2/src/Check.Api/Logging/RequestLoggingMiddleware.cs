using System.Diagnostics;
using Check.Api.Infrastructure;

namespace Check.Api.Logging;

/// <summary>
/// Una línea por solicitud (método, ruta, estado, duración) y un scope con traceId, ip, usuario y contrato,
/// que ZLogger agrega a todos los logs escritos durante la solicitud. No registra cuerpos: llevan datos personales.
/// </summary>
public sealed class RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var scope = new Dictionary<string, object?>
        {
            ["traceId"] = context.GetTraceId(),
            ["clientIp"] = context.Connection.RemoteIpAddress?.ToString()
        };

        using (logger.BeginScope(scope))
        {
            var started = Stopwatch.GetTimestamp();
            try
            {
                await next(context);
            }
            finally
            {
                var elapsedMs = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
                var status = context.Response.StatusCode;
                var level = status >= 500 ? LogLevel.Error : status >= 400 ? LogLevel.Warning : LogLevel.Information;
                logger.Log(level, "HTTP {Metodo} {Ruta} respondió {Estado} en {DuracionMs:0.0} ms (usuario {Usuario}, contrato {ContractId}).",
                    context.Request.Method, context.Request.Path.Value, status, elapsedMs,
                    context.User.FindFirst("sub")?.Value ?? "anónimo", context.GetRouteValue("id")?.ToString() ?? "-");
            }
        }
    }
}
