namespace Check.Domain.Offer;

/// <summary>Condiciones de venta de un plan a una fecha, armadas con sus reglas vigentes.</summary>
/// <summary>MaxBeneficiaries: 0 o sin configurar = solo herederos legales. DurationDays: días de cobertura desde el pago.</summary>
public sealed record PlanTerms(long PlanId, decimal? Premium, string? Currency, int? MinAge, int? MaxAge, int? MaxBeneficiaries, int? DurationDays)
{
    public bool IsSellable => Premium is > 0 && Currency is not null && MinAge is not null && MaxAge is not null;
}
