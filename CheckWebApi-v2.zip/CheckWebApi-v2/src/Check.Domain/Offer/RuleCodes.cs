namespace Check.Domain.Offer;

public static class RuleCodes
{
    public const string PremiumAmount = "MONTO_PRIMA";
    public const string PremiumCurrency = "MONEDA_PRIMA";
    public const string DurationDays = "DIAS_VIGENCIA";
    public const string MinAge = "EDAD_MINIMA_INGRESO";
    public const string MaxAge = "EDAD_MAXIMA_INGRESO";
    public const string MaxBeneficiaries = "MAXIMO_BENEFICIARIOS";
}
