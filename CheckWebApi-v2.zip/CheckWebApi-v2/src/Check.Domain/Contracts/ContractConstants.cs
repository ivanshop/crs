namespace Check.Domain.Contracts;

/// <summary>Valores de sales.contracts.status.</summary>
public static class ContractStatus
{
    public const string Started = "Iniciado";
    public const string Validated = "Validado";
    public const string Rejected = "Rechazado";
    /// <summary>El contratante confirmó la compra con el código OTP.</summary>
    public const string Verified = "Verificado";
    /// <summary>Beneficiarios y declaración PEP registrados.</summary>
    public const string Declared = "Declarado";
    /// <summary>QR generado; espera el aviso de pago del banco.</summary>
    public const string PendingPayment = "PendientePago";
    /// <summary>Pagado: póliza vigente, con número y cobertura.</summary>
    public const string Active = "Activo";
}

/// <summary>Valores de sales.contract_parties.role.</summary>
public static class PartyRoles
{
    public const string Contractor = "Contratante";
    public const string Insured = "Asegurado";
}

public static class SalesChannels
{
    public const string Web = "Web";
}

/// <summary>Códigos de core.catalogs con topic "Parentesco-Contratante": qué es el contratante del asegurado.</summary>
public static class ContractorRelationships
{
    public const string Topic = "Parentesco-Contratante";
    public const string Father = "P";
    public const string Mother = "M";
}

/// <summary>Valores de sales.otp_challenges.channel. El banco envía por SMS, correo y WhatsApp a la vez.</summary>
public static class OtpChannels
{
    public const string Multichannel = "Multicanal";
}
