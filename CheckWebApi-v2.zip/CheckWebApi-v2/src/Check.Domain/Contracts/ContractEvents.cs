namespace Check.Domain.Contracts;

/// <summary>Valores de sales.contract_events (bitácora y outbox hacia Service Bus).</summary>
public static class ContractEventTypes
{
    public const string PaymentConfirmed = "PagoConfirmado";
    public const string WelcomeEmail = "CorreoBienvenida";
    public const string ClientFolder = "CarpetaCliente";
}

public static class ContractEventQueues
{
    public const string WelcomeEmail = "policy-welcome-email";
    public const string ClientFolder = "client-folder";
}

public static class ContractEventStatus
{
    /// <summary>Solo bitácora: no se publica (queue null).</summary>
    public const string Logged = "Registrado";
    /// <summary>Espera que el publicador lo envíe a Service Bus.</summary>
    public const string Pending = "Pendiente";
}
