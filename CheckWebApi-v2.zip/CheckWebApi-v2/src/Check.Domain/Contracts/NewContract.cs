using Check.Domain.Common;
using Check.Domain.Offer;
using Check.Domain.People;

namespace Check.Domain.Contracts;

/// <summary>
/// Contrato que nace al iniciar la compra (estado Iniciado). Reglas:
/// - Asegurado dentro de las edades del plan.
/// - Asegurado menor de edad → contrata su padre o madre (mayor de edad, género acorde al parentesco).
/// - Asegurado mayor de edad → contrata para sí mismo (sin contratante).
/// </summary>
public sealed record NewContract(
    Guid Id,
    long PlanId,
    decimal Premium,
    string Currency,
    PersonalData Insured,
    PersonalData? Contractor,
    string? ContractorRelationship)
{
    public const int AdultAge = 18;

    public string Status => ContractStatus.Started;
    public string Channel => SalesChannels.Web;

    /// <summary>Quien paga y acepta: el contratante, o el propio asegurado si compra para sí mismo.</summary>
    public PersonalData Payer => Contractor ?? Insured;

    public static Result<NewContract> Start(
        PlanTerms terms, PersonalData insured, PersonalData? contractor, string? relationship, DateOnly today)
    {
        if (!terms.IsSellable) return ContractErrors.PlanNotSellable;

        if (Validate(insured, "asegurado", today) is { } insuredError) return insuredError;

        var age = insured.AgeOn(today);
        if (age < terms.MinAge || age > terms.MaxAge)
            return ContractErrors.InsuredAgeOutOfRange(age, terms.MinAge!.Value, terms.MaxAge!.Value);

        if (age >= AdultAge)
        {
            if (contractor is not null) return ContractErrors.ContractorNotAllowed;
            return new NewContract(Guid.CreateVersion7(), terms.PlanId, terms.Premium!.Value, terms.Currency!, insured, null, null);
        }

        if (contractor is null) return ContractErrors.ContractorRequired;
        if (Validate(contractor, "contratante", today) is { } contractorError) return contractorError;
        if (contractor.DocumentKey == insured.DocumentKey) return ContractErrors.ContractorSameAsInsured;
        if (contractor.AgeOn(today) < AdultAge) return ContractErrors.ContractorMustBeAdult;

        var expectedGender = relationship?.ToUpperInvariant() switch
        {
            ContractorRelationships.Father => Genders.Male,
            ContractorRelationships.Mother => Genders.Female,
            _ => null
        };
        if (expectedGender is null) return ContractErrors.ContractorRelationshipInvalid;
        if (contractor.Gender != expectedGender) return ContractErrors.ContractorGenderMismatch;

        return new NewContract(Guid.CreateVersion7(), terms.PlanId, terms.Premium!.Value, terms.Currency!,
            insured, contractor, relationship!.ToUpperInvariant());
    }

    private static Error? Validate(PersonalData person, string who, DateOnly today)
    {
        if (string.IsNullOrWhiteSpace(person.PaternalLastname) && string.IsNullOrWhiteSpace(person.MaternalLastname))
            return ContractErrors.LastnameRequired(who);
        if (person.Birthdate > today || person.Birthdate < today.AddYears(-120))
            return ContractErrors.BirthdateInFuture(who);
        return null;
    }
}
