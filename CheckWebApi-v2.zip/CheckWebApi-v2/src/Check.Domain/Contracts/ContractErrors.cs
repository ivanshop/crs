using Check.Domain.Common;

namespace Check.Domain.Contracts;

public static class ContractErrors
{
    public static readonly Error PlanNotSellable =
        Error.BusinessRule("PLAN_NOT_SELLABLE", "El plan no tiene prima o edades configuradas; no se puede contratar por ahora.");

    public static Error InsuredAgeOutOfRange(int age, int min, int max) =>
        Error.BusinessRule("INSURED_AGE_OUT_OF_RANGE", $"El asegurado tiene {age} años; este plan es para personas de {min} a {max} años.");

    public static readonly Error ContractorRequired =
        Error.BusinessRule("CONTRACTOR_REQUIRED", "El asegurado es menor de edad: su padre o madre debe contratar el seguro.");

    public static readonly Error ContractorNotAllowed =
        Error.BusinessRule("CONTRACTOR_NOT_ALLOWED", "El asegurado es mayor de edad: debe contratar el seguro para sí mismo.");

    public static readonly Error ContractorRelationshipInvalid =
        Error.Validation("CONTRACTOR_RELATIONSHIP_INVALID", "Indica si el contratante es el padre (P) o la madre (M) del asegurado.");

    public static readonly Error ContractorMustBeAdult =
        Error.BusinessRule("CONTRACTOR_MUST_BE_ADULT", "El contratante debe ser mayor de edad.");

    public static readonly Error ContractorGenderMismatch =
        Error.Validation("CONTRACTOR_GENDER_MISMATCH", "El parentesco no coincide con el género del contratante (padre = Masculino, madre = Femenino).");

    public static readonly Error ContractorSameAsInsured =
        Error.Validation("CONTRACTOR_SAME_AS_INSURED", "El contratante y el asegurado no pueden tener el mismo documento.");

    public static Error LastnameRequired(string who) =>
        Error.Validation("LASTNAME_REQUIRED", $"Indica al menos un apellido del {who}.");

    public static Error BirthdateInFuture(string who) =>
        Error.Validation("BIRTHDATE_INVALID", $"La fecha de nacimiento del {who} no es válida.");
}
