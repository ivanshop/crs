namespace Check.Domain.Contracts;

/// <summary>Valores de feedback.survey_responses.type.</summary>
public static class SurveyTypes
{
    /// <summary>"¿Qué te pareció la experiencia de comprar tu seguro?" (1 a 10).</summary>
    public const string PurchaseExperience = "FacilidadCompra";
    public const int MinScore = 1;
    public const int MaxScore = 10;
}
