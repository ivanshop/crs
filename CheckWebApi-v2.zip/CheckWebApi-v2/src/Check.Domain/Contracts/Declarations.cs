using Check.Domain.Common;

namespace Check.Domain.Contracts;

/// <summary>Beneficiario designado. RelationshipCode: código de core.relationships (PA, MA, HI, CO...).</summary>
public sealed record BeneficiaryData(
    string RelationshipCode, string? DocumentNumber, string Names, string? PaternalLastname, string? MaternalLastname, decimal Percentage);

/// <summary>Familiar del PEP. RelationshipCode: core.catalogs "Parentesco-PEP".</summary>
public sealed record PepRelativeData(
    string RelationshipCode, string Names, string? PaternalLastname, string? MaternalLastname, string? DocumentNumber, short NationalityId);

/// <summary>Socio del PEP. RelationshipCode: core.catalogs "Vinculo-Socio-PEP".</summary>
public sealed record PepPartnerData(
    string RelationshipCode, string Names, string? PaternalLastname, string? MaternalLastname, string Position);

/// <summary>Declaración PEP del contratante.</summary>
public sealed record PepDeclarationData(
    bool IsPep,
    bool HasPepPartners,
    string? Position,
    string? Institution,
    string? SourceFunds,
    short? ExerciseCountryId,
    DateOnly? PeriodStart,
    DateOnly? PeriodEnd,
    IReadOnlyList<PepRelativeData> Relatives,
    IReadOnlyList<PepPartnerData> Partners);

public static class PepCatalogs
{
    public const string RelativeTopic = "Parentesco-PEP";
    public const string PartnerTopic = "Vinculo-Socio-PEP";
}

/// <summary>Reglas de la declaración de beneficiarios y PEP (las que la BD no puede validar).</summary>
public static class DeclarationRules
{
    public const int MaxPepRelatives = 10;

    /// <param name="uniqueRelationships">Código de parentesco → is_unique (solo uno por contrato: padre, madre, cónyuge).</param>
    public static Error? ValidateBeneficiaries(
        IReadOnlyList<BeneficiaryData> beneficiaries, int? maxBeneficiaries, bool insuredIsMinor,
        string insuredDocumentNumber, IReadOnlyDictionary<string, bool> uniqueRelationships)
    {
        // Sin beneficiarios = herederos legales.
        if (beneficiaries.Count == 0) return null;

        if (insuredIsMinor)
            return Error.BusinessRule("BENEFICIARIES_NOT_ALLOWED", "El asegurado es menor de edad: sus beneficiarios son los herederos legales.");

        var max = maxBeneficiaries ?? 0;
        if (max == 0)
            return Error.BusinessRule("BENEFICIARIES_NOT_ALLOWED", "Este plan solo admite herederos legales como beneficiarios.");
        if (beneficiaries.Count > max)
            return Error.BusinessRule("BENEFICIARIES_EXCEEDED", $"Este plan admite hasta {max} beneficiarios.");

        if (beneficiaries.Any(b => string.IsNullOrWhiteSpace(b.PaternalLastname) && string.IsNullOrWhiteSpace(b.MaternalLastname)))
            return Error.Validation("BENEFICIARY_LASTNAME_REQUIRED", "Indica al menos un apellido de cada beneficiario.");

        if (beneficiaries.Any(b => b.Percentage <= 0 || b.Percentage > 100 || decimal.Round(b.Percentage, 2) != b.Percentage))
            return Error.Validation("BENEFICIARY_PERCENTAGE_INVALID", "Cada porcentaje debe estar entre 0,01 y 100, con hasta 2 decimales.");
        var total = beneficiaries.Sum(b => b.Percentage);
        if (total != 100)
            return Error.Validation("BENEFICIARIES_TOTAL_INVALID", $"Los porcentajes deben sumar 100 % (suman {total:0.##} %).");

        var repeated = beneficiaries
            .GroupBy(b => b.RelationshipCode)
            .FirstOrDefault(g => g.Count() > 1 && uniqueRelationships.GetValueOrDefault(g.Key));
        if (repeated is not null)
            return Error.Validation("BENEFICIARY_RELATIONSHIP_REPEATED", $"Solo puede haber un beneficiario con el parentesco {repeated.Key}.");

        if (beneficiaries.Any(b => b.DocumentNumber is not null && b.DocumentNumber == insuredDocumentNumber))
            return Error.Validation("BENEFICIARY_IS_INSURED", "El asegurado no puede ser su propio beneficiario.");

        return null;
    }

    public static Error? ValidatePep(PepDeclarationData pep, DateOnly today)
    {
        if (pep.IsPep)
        {
            if (string.IsNullOrWhiteSpace(pep.Position) || string.IsNullOrWhiteSpace(pep.Institution) || string.IsNullOrWhiteSpace(pep.SourceFunds))
                return Error.Validation("PEP_DATA_REQUIRED", "Si eres PEP, indica el cargo, la institución y el origen de tus fondos.");
            if (pep.ExerciseCountryId is null || pep.PeriodStart is null)
                return Error.Validation("PEP_DATA_REQUIRED", "Si eres PEP, indica el país donde ejerces el cargo y la fecha de inicio.");
            if (pep.PeriodStart > today)
                return Error.Validation("PEP_PERIOD_INVALID", "La fecha de inicio del cargo no puede ser futura.");
            if (pep.PeriodEnd is { } end && end < pep.PeriodStart)
                return Error.Validation("PEP_PERIOD_INVALID", "La fecha de fin del cargo no puede ser anterior a la de inicio.");
            if (pep.Relatives.Count is < 1 or > MaxPepRelatives)
                return Error.Validation("PEP_RELATIVES_INVALID", $"Si eres PEP, declara de 1 a {MaxPepRelatives} familiares.");
        }
        else if (pep.Relatives.Count > 0)
        {
            return Error.Validation("PEP_RELATIVES_NOT_ALLOWED", "Solo se declaran familiares si eres PEP.");
        }

        if (pep.HasPepPartners && pep.Partners.Count == 0)
            return Error.Validation("PEP_PARTNERS_REQUIRED", "Declara al menos un socio PEP.");
        if (!pep.HasPepPartners && pep.Partners.Count > 0)
            return Error.Validation("PEP_PARTNERS_NOT_ALLOWED", "Solo se declaran socios si indicas que tienes socios PEP.");

        if (pep.Relatives.Any(r => string.IsNullOrWhiteSpace(r.PaternalLastname) && string.IsNullOrWhiteSpace(r.MaternalLastname)) ||
            pep.Partners.Any(p => string.IsNullOrWhiteSpace(p.PaternalLastname) && string.IsNullOrWhiteSpace(p.MaternalLastname)))
            return Error.Validation("PEP_LASTNAME_REQUIRED", "Indica al menos un apellido de cada familiar y socio.");

        return null;
    }
}
