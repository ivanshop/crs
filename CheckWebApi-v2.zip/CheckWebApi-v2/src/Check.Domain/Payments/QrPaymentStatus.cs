namespace Check.Domain.Payments;

/// <summary>Valores de sales.qr_payments.status.</summary>
public static class QrPaymentStatus
{
    public const string Pending = "Pendiente";
    public const string Paid = "Pagado";
    public const string Expired = "Vencido";
    /// <summary>Se generó otro QR para el mismo contrato antes de que este se pagara.</summary>
    public const string Replaced = "Reemplazado";
}
