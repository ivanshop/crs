using System.Security.Cryptography;

namespace Check.Domain.Payments;

/// <summary>Valores de sales.payment_notifications.result.</summary>
public static class PaymentNotificationResult
{
    public const string Applied = "Aplicado";
    public const string Duplicate = "Duplicado";
    public const string Expired = "Vencido";
    public const string AmountMismatch = "Monto Diferente";
    public const string Unknown = "Desconocido";
}

/// <summary>Glosa del QR: la que se envía al banco y la que el banco devuelve en el aviso de pago.</summary>
public static class QrDescription
{
    public const int MaxLength = 60;

    public static string For(string productName, string planName)
    {
        var text = $"{productName} - Plan {planName}";
        return text.Length > MaxLength ? text[..MaxLength] : text;
    }
}

/// <summary>Número de póliza: {CÓDIGO PRODUCTO}-{AÑO}-{8 caracteres}. Ej.: DEP-SEG-2026-7K4QM92X.</summary>
public static class ContractNumber
{
    // Sin I, L, O ni U: no se confunden con 1, 0 ni V al dictarlos.
    private const string Alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

    public static string New(string productCode, DateOnly date) =>
        $"{productCode}-{date.Year}-{RandomNumberGenerator.GetString(Alphabet, 8)}";
}
