using System.Globalization;

namespace Check.Domain.Common;

/// <summary>
/// Conversión de los valores guardados como texto (subscription_rules.value, contract_details.value).
/// Formato invariante: decimales con punto, booleanos true/false, fechas yyyy-MM-dd.
/// </summary>
public static class DataTypeExtensions
{
    private const string DateFormat = "yyyy-MM-dd";

    /// <summary>"Integer" → DataType.Integer. Null si el texto no es un tipo conocido.</summary>
    public static DataType? ToDataType(this string? value) =>
        Enum.TryParse<DataType>(value, ignoreCase: true, out var type) && Enum.IsDefined(type) ? type : null;

    public static int? AsInteger(this string? value) =>
        int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var i) ? i : null;

    public static decimal? AsDecimal(this string? value) =>
        decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var d) ? d : null;

    public static bool? AsBoolean(this string? value) =>
        bool.TryParse(value, out var b) ? b : null;

    public static DateOnly? AsDate(this string? value) =>
        DateOnly.TryParseExact(value, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;

    /// <summary>
    /// Valor tipado según el data_type: int, decimal, bool, DateOnly o string.
    /// Null si el texto no corresponde al tipo (dato mal configurado o mal enviado).
    /// </summary>
    public static object? ParseValue(this DataType type, string? value) => type switch
    {
        DataType.Text => string.IsNullOrWhiteSpace(value) ? null : value,
        DataType.Integer => value.AsInteger(),
        DataType.Decimal => value.AsDecimal(),
        DataType.Boolean => value.AsBoolean(),
        DataType.Date => value.AsDate(),
        _ => null
    };

    /// <summary>¿El texto es un valor válido para este tipo? (validar lo que envía el cliente o lo configurado).</summary>
    public static bool IsValidValue(this DataType type, string? value) => type.ParseValue(value) is not null;
}
