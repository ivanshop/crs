namespace Check.Domain.Common;

public enum DataType
{
    Text,
    Integer,
    Decimal,
    Boolean,
    Date
}
