namespace Check.Domain.Compliance;

/// <summary>Valores de compliance.screenings.status.</summary>
public static class ScreeningStatus
{
    public const string Approved = "Aprobado";
    public const string Observed = "Observado";
    public const string Error = "Error";
}

/// <summary>Valores de compliance.screenings.provider.</summary>
public static class ScreeningProviders
{
    public const string Segip = "SEGIP";
}

/// <summary>Datos que se contrastan con SEGIP. IsForeigner: extranjero con carnet boliviano (pTipoPersona = 2).</summary>
public sealed record SegipQuery(
    string DocumentNumber,
    string? Complement,
    string Names,
    string? PaternalLastname,
    string? MaternalLastname,
    DateOnly Birthdate,
    bool IsForeigner);

/// <summary>
/// Respuesta de la contrastación. Matches: campo de SEGIP → 1 si coincide
/// (ContrastacionEnFormatoJson: {"NumeroDocumento":1,"Nombres":1,...}).
/// </summary>
public sealed record SegipResult(
    int ResponseCode,
    bool IsValid,
    string? UniqueCode,
    string? Message,
    IReadOnlyDictionary<string, int> Matches);

public sealed record SegipEvaluation(bool Approved, bool Found, IReadOnlyList<string> MismatchedFields);

/// <summary>
/// Regla de aprobación: SEGIP encontró un registro y coinciden número de documento, nombres y fecha de nacimiento,
/// más cada apellido y el complemento que se hayan enviado.
/// </summary>
public static class SegipRules
{
    /// <summary>CodigoRespuesta de SEGIP cuando encontró un registro.</summary>
    public const int FoundCode = 2;
    public const int Match = 1;

    public static SegipEvaluation Evaluate(SegipQuery query, SegipResult result)
    {
        if (result.ResponseCode != FoundCode || !result.IsValid)
            return new SegipEvaluation(false, false, []);

        // campo de SEGIP → nombre del campo en nuestra Api (para que el front lo marque)
        var required = new List<(string Segip, string Api)>
        {
            ("NumeroDocumento", "documentNumber"),
            ("Nombres", "names"),
            ("FechaNacimiento", "birthdate")
        };
        if (query.PaternalLastname is not null) required.Add(("PrimerApellido", "paternalLastname"));
        if (query.MaternalLastname is not null) required.Add(("SegundoApellido", "maternalLastname"));
        if (query.Complement is not null) required.Add(("Complemento", "complement"));

        var mismatched = required
            .Where(f => result.Matches.GetValueOrDefault(f.Segip) != Match)
            .Select(f => f.Api)
            .ToList();

        return new SegipEvaluation(mismatched.Count == 0, true, mismatched);
    }
}
