namespace Check.Domain.Compliance;

/// <summary>Valores de compliance.identity_readings.status.</summary>
public static class IdentityReadingStatus
{
    public const string Pending = "Pendiente";
    public const string Completed = "Completado";
    public const string Failed = "Fallido";
}
