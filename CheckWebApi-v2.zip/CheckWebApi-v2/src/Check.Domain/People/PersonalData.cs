namespace Check.Domain.People;

public static class DocumentTypes
{
    public const string Ci = "CI";
    public const string Ce = "CE";
}

public static class Genders
{
    public const string Male = "Masculino";
    public const string Female = "Femenino";
}

/// <summary>
/// Datos de una persona tal como llegan del formulario. Los códigos (Extension, MaritalStatus)
/// e ids (NationalityId, CityId, OccupationId) son los de /catalogs.
/// </summary>
public sealed record PersonalData(
    string DocumentType,
    string DocumentNumber,
    string? Complement,
    string? Extension,
    string Names,
    string? PaternalLastname,
    string? MaternalLastname,
    DateOnly Birthdate,
    string Gender,
    short NationalityId,
    string BirthPlace,
    string Address,
    string Cellphone,
    string Email,
    short CityId,
    string MaritalStatus,
    short OccupationId)
{
    /// <summary>Clave única del documento: TIPO|NÚMERO|COMPLEMENTO. Se guarda como HMAC en people.document_hash.</summary>
    public string DocumentKey => $"{DocumentType}|{DocumentNumber}|{Complement}".ToUpperInvariant();

    public int AgeOn(DateOnly date)
    {
        var age = date.Year - Birthdate.Year;
        return Birthdate > date.AddYears(-age) ? age - 1 : age;
    }
}
