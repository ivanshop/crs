using Microsoft.AspNetCore.Mvc;
using SportAffiliation.Domain.Errors;

namespace SportAffiliation.Api.Extensions;

public static class ProblemDetailsExtensions
{
    /// <summary>
    /// Maps a DomainError to the correct HTTP status + RFC 7807 ProblemDetails.
    /// </summary>
    public static IResult ToProblemResult(this DomainError error, HttpContext httpContext)
    {
        var (statusCode, title) = GetStatusInfo(error.Code);

        var problemDetails = new ProblemDetails
        {
            Type = $"https://tools.ietf.org/html/rfc9110#section-15.{GetRfcSection(statusCode)}",
            Title = title,
            Status = statusCode,
            Detail = error.Description,
            Instance = httpContext.Request.Path
        };

        problemDetails.Extensions["errorCode"] = error.Code;
        problemDetails.Extensions["traceId"] = httpContext.TraceIdentifier;

        return Results.Problem(problemDetails);
    }

    private static (int StatusCode, string Title) GetStatusInfo(string errorCode) => errorCode switch
    {
        var c when c.StartsWith("Identity.ServiceUnavailable") => (503, "Service Unavailable"),
        var c when c.StartsWith("Payment.ServiceUnavailable")  => (503, "Service Unavailable"),
        var c when c.StartsWith("Identity.ValidationFailed")   => (422, "Identity Validation Failed"),
        var c when c.StartsWith("Identity.NotFound")           => (422, "Identity Not Found"),
        var c when c.StartsWith("Affiliation.NotFound")        => (404, "Affiliation Not Found"),
        var c when c.StartsWith("Affiliation.AlreadyAffiliated") => (409, "Conflict"),
        var c when c.StartsWith("Affiliation.InvalidStatus")   => (409, "Conflict"),
        var c when c.StartsWith("Payment.AlreadyConfirmed")    => (409, "Conflict"),
        var c when c.StartsWith("Validation.")                 => (400, "Validation Error"),
        _                                                       => (500, "Internal Server Error")
    };

    private static string GetRfcSection(int statusCode) => statusCode switch
    {
        400 => "5.1",
        404 => "5.5",
        409 => "5.10",
        422 => "5.20",
        500 => "6.6",
        503 => "6.8",
        _   => "5.1"
    };
}
