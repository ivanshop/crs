using FluentValidation;
using Microsoft.AspNetCore.Mvc;

namespace SportAffiliation.Api.Filters;

/// <summary>
/// Endpoint filter that runs FluentValidation before the handler
/// and short-circuits with a 400 ProblemDetails if validation fails.
/// </summary>
public class ValidationFilter<T> : IEndpointFilter where T : class
{
    private readonly IValidator<T> _validator;

    public ValidationFilter(IValidator<T> validator)
    {
        _validator = validator;
    }

    public async ValueTask<object?> InvokeAsync(
        EndpointFilterInvocationContext context,
        EndpointFilterDelegate next)
    {
        var argument = context.Arguments.OfType<T>().FirstOrDefault();

        if (argument is null)
            return Results.Problem(new ProblemDetails
            {
                Title = "Bad Request",
                Detail = "Could not parse request body.",
                Status = 400
            });

        var result = await _validator.ValidateAsync(argument, context.HttpContext.RequestAborted);

        if (!result.IsValid)
        {
            var errors = result.Errors
                .GroupBy(e => e.PropertyName)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(e => e.ErrorMessage).ToArray());

            var problemDetails = new HttpValidationProblemDetails(errors)
            {
                Title = "One or more validation errors occurred.",
                Status = 400,
                Instance = context.HttpContext.Request.Path,
                Type = "https://tools.ietf.org/html/rfc9110#section-15.5.1"
            };

            problemDetails.Extensions["traceId"] = context.HttpContext.TraceIdentifier;

            return Results.ValidationProblem(
                errors,
                title: problemDetails.Title,
                instance: problemDetails.Instance,
                type: problemDetails.Type);
        }

        return await next(context);
    }
}
