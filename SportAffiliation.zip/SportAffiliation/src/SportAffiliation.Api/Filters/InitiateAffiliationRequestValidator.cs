using FluentValidation;
using SportAffiliation.Api.Controllers;
using SportAffiliation.Domain.Enums;

namespace SportAffiliation.Api.Filters;

/// <summary>
/// API-layer validator for the raw HTTP request.
/// Mirrors business rules from the Application layer validator
/// so the endpoint filter can short-circuit before hitting the service.
/// </summary>
public class InitiateAffiliationRequestValidator : AbstractValidator<InitiateAffiliationRequest>
{
    private static readonly int MinAge = 5;
    private static readonly int MaxAge = 70;

    public InitiateAffiliationRequestValidator()
    {
        RuleFor(x => x.NationalId)
            .NotEmpty().WithMessage("National ID is required.")
            .Length(6, 20).WithMessage("National ID must be between 6 and 20 characters.");

        RuleFor(x => x.FullName)
            .NotEmpty().WithMessage("Full name is required.")
            .MaximumLength(150).WithMessage("Full name must not exceed 150 characters.");

        RuleFor(x => x.BirthDate)
            .NotEmpty().WithMessage("Birth date is required.")
            .Must(BeValidAge)
            .WithMessage($"Applicant age must be between {MinAge} and {MaxAge} years old.");

        RuleFor(x => x.Sport)
            .IsInEnum().WithMessage("The selected sport is not supported.");
    }

    private static bool BeValidAge(DateOnly birthDate)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var age = today.Year - birthDate.Year;
        if (birthDate > today.AddYears(-age)) age--;
        return age >= MinAge && age <= MaxAge;
    }
}
