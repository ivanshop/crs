using SportAffiliation.Api.Extensions;
using SportAffiliation.Application.Common.Interfaces;

namespace SportAffiliation.Api.Controllers;

public static class PaymentWebhookEndpoints
{
    public static IEndpointRouteBuilder MapPaymentWebhookEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/webhooks/payments")
            .WithTags("Webhooks")
            .WithOpenApi();

        // POST /api/webhooks/payments/confirm
        // Called by the financial institution when the QR payment is detected.
        // The affiliationId is embedded in the QR and sent back by the bank.
        group.MapPost("/confirm", async (
            PaymentConfirmationWebhookRequest request,
            IAffiliationService affiliationService,
            HttpContext httpContext,
            CancellationToken cancellationToken) =>
        {
            var result = await affiliationService.ConfirmPaymentAsync(
                request.AffiliationId, cancellationToken);

            if (result.IsFailure)
                return result.Error.ToProblemResult(httpContext);

            // 204 No Content - webhook acknowledged, no body needed
            return Results.NoContent();
        })
        .WithName("ConfirmPayment")
        .WithSummary("Financial institution webhook - payment confirmation")
        .WithDescription(
            "Called by the bank/financial institution when a QR payment is detected. " +
            "Transitions the affiliation from PendingPayment to Affiliated.")
        .Produces(StatusCodes.Status204NoContent)
        .ProducesProblem(StatusCodes.Status404NotFound)
        .ProducesProblem(StatusCodes.Status409Conflict);

        return app;
    }
}
