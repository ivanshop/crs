using SportAffiliation.Api.Extensions;
using SportAffiliation.Api.Filters;
using SportAffiliation.Application.Affiliations.Commands;
using SportAffiliation.Application.Common.Interfaces;

// Alias to avoid conflict with Api.Controllers.AffiliationResponse
using AppAffiliationResponse = SportAffiliation.Application.Affiliations.Commands.AffiliationResponse;

namespace SportAffiliation.Api.Controllers;

public static class AffiliationEndpoints
{
    public static IEndpointRouteBuilder MapAffiliationEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/affiliations")
            .WithTags("Affiliations")
            .WithOpenApi();

        // POST /api/affiliations
        // Initiates: identity validation -> eligibility check -> QR payment generation
        group.MapPost("/", async (
            InitiateAffiliationRequest request,
            IAffiliationService affiliationService,
            HttpContext httpContext,
            CancellationToken cancellationToken) =>
        {
            var command = new InitiateAffiliationCommand(
                request.NationalId,
                request.FullName,
                request.BirthDate,
                request.Sport);

            var result = await affiliationService.InitiateAffiliationAsync(command, cancellationToken);

            return result.IsSuccess
                ? Results.Created($"/api/affiliations/{result.Value.AffiliationId}", result.Value)
                : result.Error.ToProblemResult(httpContext);
        })
        .AddEndpointFilter<ValidationFilter<InitiateAffiliationRequest>>()
        .WithName("InitiateAffiliation")
        .WithSummary("Initiate a sports insurance affiliation")
        .WithDescription(
            "Validates the applicant identity against the national registry, " +
            "checks eligibility (age + sport), and generates a QR code for payment.")
        .Produces<AppAffiliationResponse>(StatusCodes.Status201Created)
        .ProducesProblem(StatusCodes.Status400BadRequest)
        .ProducesProblem(StatusCodes.Status409Conflict)
        .ProducesProblem(StatusCodes.Status422UnprocessableEntity)
        .ProducesProblem(StatusCodes.Status503ServiceUnavailable);

        // GET /api/affiliations/{id}
        group.MapGet("/{id:guid}", async (
            Guid id,
            IAffiliationService affiliationService,
            HttpContext httpContext,
            CancellationToken cancellationToken) =>
        {
            var result = await affiliationService.GetAffiliationAsync(id, cancellationToken);

            return result.IsSuccess
                ? Results.Ok(result.Value)
                : result.Error.ToProblemResult(httpContext);
        })
        .WithName("GetAffiliation")
        .WithSummary("Get affiliation by ID")
        .WithDescription("Returns the current status of an affiliation, including the QR code URL if generated.")
        .Produces<AppAffiliationResponse>(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status404NotFound);

        return app;
    }
}
