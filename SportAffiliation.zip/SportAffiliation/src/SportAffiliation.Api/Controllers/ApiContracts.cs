using SportAffiliation.Domain.Enums;

namespace SportAffiliation.Api.Controllers;

// ---- Inbound request contracts (API layer only) ----

public record InitiateAffiliationRequest(
    string NationalId,
    string FullName,
    DateOnly BirthDate,
    Sport Sport);

public record PaymentConfirmationWebhookRequest(
    Guid AffiliationId,
    string PaymentReference,
    DateTime PaidAt);
