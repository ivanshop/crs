using SportAffiliation.Api.Controllers;
using SportAffiliation.Api.Extensions;
using SportAffiliation.Api.Middleware;
using SportAffiliation.Application;
using SportAffiliation.Infrastructure;
using Serilog;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Logging
builder.AddSerilog();

// Services
builder.Services
    .AddApiServices()
    .AddApplication()
    .AddInfrastructure(builder.Configuration);

// OpenAPI / Scalar
builder.Services.AddOpenApi();

var app = builder.Build();

// Global exception handler (must be first)
app.UseMiddleware<ExceptionHandlingMiddleware>();

// Scalar API docs (development only)
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference(options =>
    {
        options.Title = "Sports Affiliation API";
        options.Theme = ScalarTheme.BluePlanet;
    });
}

// Structured request logging
app.UseSerilogRequestLogging(options =>
{
    options.MessageTemplate =
        "HTTP {RequestMethod} {RequestPath} responded {StatusCode} in {Elapsed:0.0000}ms";
    options.EnrichDiagnosticContext = (diagnosticContext, httpContext) =>
    {
        diagnosticContext.Set("RequestHost", httpContext.Request.Host.Value);
        diagnosticContext.Set("UserAgent", httpContext.Request.Headers.UserAgent);
    };
});

// Endpoint registration
app.MapAffiliationEndpoints();
app.MapPaymentWebhookEndpoints();

app.Run();
