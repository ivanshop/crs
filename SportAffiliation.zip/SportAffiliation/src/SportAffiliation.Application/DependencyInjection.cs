using FluentValidation;
using Microsoft.Extensions.DependencyInjection;
using SportAffiliation.Application.Affiliations;
using SportAffiliation.Application.Common.Interfaces;

namespace SportAffiliation.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddValidatorsFromAssemblyContaining<IApplicationMarker>(ServiceLifetime.Scoped);
        services.AddScoped<IAffiliationService, AffiliationService>();
        return services;
    }
}

// Assembly marker
public interface IApplicationMarker { }
