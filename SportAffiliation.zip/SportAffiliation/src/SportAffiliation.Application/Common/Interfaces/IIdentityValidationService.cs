namespace SportAffiliation.Application.Common.Interfaces;

public interface IIdentityValidationService
{
    /// <summary>
    /// Validates a person's identity against the national identity registry.
    /// </summary>
    Task<IdentityValidationResult> ValidateAsync(
        string nationalId,
        string fullName,
        DateOnly birthDate,
        CancellationToken cancellationToken = default);
}

public record IdentityValidationResult(
    bool IsValid,
    bool ServiceAvailable,
    string? ValidatedFullName = null);
