namespace SportAffiliation.Application.Common.Interfaces;

public interface IQrPaymentService
{
    /// <summary>
    /// Generates a QR code for the person to pay the insurance premium.
    /// Returns the QR image URL and a payment reference tied to the affiliationId.
    /// </summary>
    Task<QrGenerationResult> GenerateQrAsync(
        Guid affiliationId,
        string beneficiaryName,
        decimal amount,
        CancellationToken cancellationToken = default);
}

public record QrGenerationResult(
    bool Success,
    bool ServiceAvailable,
    string? QrCodeUrl = null,
    string? PaymentReference = null);
