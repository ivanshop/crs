using SportAffiliation.Application.Affiliations.Commands;
using SportAffiliation.Application.Common.Models;

namespace SportAffiliation.Application.Common.Interfaces;

public interface IAffiliationService
{
    Task<Result<AffiliationResponse>> InitiateAffiliationAsync(
        InitiateAffiliationCommand command,
        CancellationToken cancellationToken = default);

    Task<Result<AffiliationResponse>> GetAffiliationAsync(
        Guid affiliationId,
        CancellationToken cancellationToken = default);

    Task<Result> ConfirmPaymentAsync(
        Guid affiliationId,
        CancellationToken cancellationToken = default);
}
