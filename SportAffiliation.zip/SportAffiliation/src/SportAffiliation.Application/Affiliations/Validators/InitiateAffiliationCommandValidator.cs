using FluentValidation;
using SportAffiliation.Application.Affiliations.Commands;
using SportAffiliation.Domain.Enums;

namespace SportAffiliation.Application.Affiliations.Validators;

public class InitiateAffiliationCommandValidator : AbstractValidator<InitiateAffiliationCommand>
{
    private static readonly int MinAge = 5;
    private static readonly int MaxAge = 70;

    public InitiateAffiliationCommandValidator()
    {
        RuleFor(x => x.NationalId)
            .NotEmpty().WithMessage("National ID is required.")
            .Length(6, 20).WithMessage("National ID must be between 6 and 20 characters.");

        RuleFor(x => x.FullName)
            .NotEmpty().WithMessage("Full name is required.")
            .MaximumLength(150).WithMessage("Full name must not exceed 150 characters.");

        RuleFor(x => x.BirthDate)
            .NotEmpty().WithMessage("Birth date is required.")
            .Must(BeValidAge).WithMessage($"Age must be between {MinAge} and {MaxAge} years old.");

        RuleFor(x => x.Sport)
            .IsInEnum().WithMessage("The selected sport is not valid.");
    }

    private static bool BeValidAge(DateOnly birthDate)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var age = today.Year - birthDate.Year;
        if (birthDate > today.AddYears(-age)) age--;
        return age >= MinAge && age <= MaxAge;
    }
}
