using FluentValidation;
using Microsoft.Extensions.Logging;
using SportAffiliation.Application.Affiliations.Commands;
using SportAffiliation.Application.Common.Interfaces;
using SportAffiliation.Application.Common.Models;
using SportAffiliation.Domain.Entities;
using SportAffiliation.Domain.Enums;
using SportAffiliation.Domain.Errors;
using SportAffiliation.Domain.Interfaces;

namespace SportAffiliation.Application.Affiliations;

public class AffiliationService : IAffiliationService
{
    private const decimal BasePremium = 150.00m;

    private static readonly Dictionary<Sport, decimal> SportMultipliers = new()
    {
        { Sport.Football,     1.5m },
        { Sport.Basketball,   1.3m },
        { Sport.Tennis,       1.1m },
        { Sport.Swimming,     1.0m },
        { Sport.Cycling,      1.4m },
        { Sport.Athletics,    1.2m },
        { Sport.Boxing,       2.0m },
        { Sport.MartialArts,  1.8m }
    };

    private readonly IAffiliationRepository _repository;
    private readonly IIdentityValidationService _identityService;
    private readonly IQrPaymentService _qrPaymentService;
    private readonly IValidator<InitiateAffiliationCommand> _validator;
    private readonly ILogger<AffiliationService> _logger;

    public AffiliationService(
        IAffiliationRepository repository,
        IIdentityValidationService identityService,
        IQrPaymentService qrPaymentService,
        IValidator<InitiateAffiliationCommand> validator,
        ILogger<AffiliationService> logger)
    {
        _repository = repository;
        _identityService = identityService;
        _qrPaymentService = qrPaymentService;
        _validator = validator;
        _logger = logger;
    }

    public async Task<Result<AffiliationResponse>> InitiateAffiliationAsync(
        InitiateAffiliationCommand command,
        CancellationToken cancellationToken = default)
    {
        // Step 1: FluentValidation (structural/business rule validation)
        var validationResult = await _validator.ValidateAsync(command, cancellationToken);
        if (!validationResult.IsValid)
        {
            var firstError = validationResult.Errors.First();
            return Result.Failure<AffiliationResponse>(
                new DomainError("Validation." + firstError.PropertyName, firstError.ErrorMessage));
        }

        _logger.LogInformation(
            "Initiating affiliation for NationalId: {NationalId}, Sport: {Sport}",
            command.NationalId, command.Sport);

        // Step 2: Idempotency guard - no duplicate active affiliations
        var existing = await _repository.GetByNationalIdAndSportAsync(
            command.NationalId, (int)command.Sport, cancellationToken);

        if (existing is not null && existing.Status != AffiliationStatus.Rejected)
        {
            _logger.LogWarning(
                "Duplicate affiliation for NationalId: {NationalId}, Sport: {Sport}",
                command.NationalId, command.Sport);
            return Result.Failure<AffiliationResponse>(DomainError.AlreadyAffiliated);
        }

        // Step 3: Validate identity against external registry
        var identityResult = await _identityService.ValidateAsync(
            command.NationalId, command.FullName, command.BirthDate, cancellationToken);

        if (!identityResult.ServiceAvailable)
        {
            _logger.LogError("Identity service unavailable for NationalId: {NationalId}", command.NationalId);
            return Result.Failure<AffiliationResponse>(DomainError.IdentityServiceUnavailable);
        }

        if (!identityResult.IsValid)
        {
            _logger.LogWarning("Identity validation failed for NationalId: {NationalId}", command.NationalId);
            return Result.Failure<AffiliationResponse>(DomainError.IdentityValidationFailed);
        }

        // Step 4: Calculate premium based on sport risk profile
        var premium = CalculatePremium(command.Sport);

        // Step 5: Persist affiliation record
        var affiliation = Affiliation.Create(
            command.NationalId,
            identityResult.ValidatedFullName ?? command.FullName,
            command.BirthDate,
            command.Sport,
            premium);

        affiliation.MarkIdentityValidated();
        await _repository.AddAsync(affiliation, cancellationToken);

        _logger.LogInformation(
            "Affiliation created: {AffiliationId}. Generating QR payment...", affiliation.Id);

        // Step 6: Generate QR payment code
        var qrResult = await _qrPaymentService.GenerateQrAsync(
            affiliation.Id,
            affiliation.FullName,
            affiliation.InsurancePremium,
            cancellationToken);

        if (!qrResult.ServiceAvailable)
        {
            _logger.LogError("QR payment service unavailable for Affiliation: {AffiliationId}", affiliation.Id);
            return Result.Failure<AffiliationResponse>(DomainError.PaymentServiceUnavailable);
        }

        if (!qrResult.Success || qrResult.QrCodeUrl is null)
        {
            _logger.LogError("QR generation failed for Affiliation: {AffiliationId}", affiliation.Id);
            return Result.Failure<AffiliationResponse>(DomainError.QrGenerationFailed);
        }

        affiliation.AssignQrPayment(qrResult.QrCodeUrl, qrResult.PaymentReference!);
        await _repository.UpdateAsync(affiliation, cancellationToken);

        _logger.LogInformation(
            "Affiliation {AffiliationId} ready for payment. QR generated.", affiliation.Id);

        return Result.Success(MapToResponse(affiliation));
    }

    public async Task<Result<AffiliationResponse>> GetAffiliationAsync(
        Guid affiliationId,
        CancellationToken cancellationToken = default)
    {
        var affiliation = await _repository.GetByIdAsync(affiliationId, cancellationToken);
        if (affiliation is null)
            return Result.Failure<AffiliationResponse>(DomainError.AffiliationNotFound);

        return Result.Success(MapToResponse(affiliation));
    }

    /// <summary>
    /// Called by the financial institution webhook when payment is confirmed.
    /// Transitions: PendingPayment -> PaymentConfirmed -> Affiliated
    /// </summary>
    public async Task<Result> ConfirmPaymentAsync(
        Guid affiliationId,
        CancellationToken cancellationToken = default)
    {
        var affiliation = await _repository.GetByIdAsync(affiliationId, cancellationToken);
        if (affiliation is null)
        {
            _logger.LogWarning("Webhook received for unknown AffiliationId: {AffiliationId}", affiliationId);
            return Result.Failure(DomainError.AffiliationNotFound);
        }

        if (affiliation.Status == AffiliationStatus.Affiliated ||
            affiliation.Status == AffiliationStatus.PaymentConfirmed)
        {
            _logger.LogWarning(
                "Duplicate webhook for AffiliationId: {AffiliationId}. Status: {Status}",
                affiliationId, affiliation.Status);
            return Result.Failure(DomainError.PaymentAlreadyConfirmed);
        }

        if (affiliation.Status != AffiliationStatus.PendingPayment)
        {
            _logger.LogWarning(
                "Invalid status transition for AffiliationId: {AffiliationId}. Status: {Status}",
                affiliationId, affiliation.Status);
            return Result.Failure(DomainError.InvalidStatusTransition);
        }

        affiliation.ConfirmPayment();
        affiliation.Complete();
        await _repository.UpdateAsync(affiliation, cancellationToken);

        _logger.LogInformation(
            "Affiliation {AffiliationId} completed for {FullName}.",
            affiliation.Id, affiliation.FullName);

        return Result.Success();
    }

    private static decimal CalculatePremium(Sport sport)
    {
        var multiplier = SportMultipliers.GetValueOrDefault(sport, 1.0m);
        return Math.Round(BasePremium * multiplier, 2);
    }

    private static AffiliationResponse MapToResponse(Affiliation affiliation) =>
        new(
            affiliation.Id,
            affiliation.NationalId,
            affiliation.FullName,
            affiliation.Age,
            affiliation.Sport.ToString(),
            affiliation.Status.ToString(),
            affiliation.QrCodeUrl,
            affiliation.PaymentReference,
            affiliation.InsurancePremium,
            affiliation.CreatedAt,
            affiliation.AffiliatedAt);
}
