using SportAffiliation.Domain.Enums;

namespace SportAffiliation.Application.Affiliations.Commands;

public record InitiateAffiliationCommand(
    string NationalId,
    string FullName,
    DateOnly BirthDate,
    Sport Sport);

public record AffiliationResponse(
    Guid AffiliationId,
    string NationalId,
    string FullName,
    int Age,
    string Sport,
    string Status,
    string? QrCodeUrl,
    string? PaymentReference,
    decimal InsurancePremium,
    DateTime CreatedAt,
    DateTime? AffiliatedAt);
