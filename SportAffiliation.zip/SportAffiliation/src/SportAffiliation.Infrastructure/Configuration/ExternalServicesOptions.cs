namespace SportAffiliation.Infrastructure.Configuration;

public class IdentityServiceOptions
{
    public const string SectionName = "ExternalServices:IdentityService";
    public string BaseUrl { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 10;
}

public class QrPaymentServiceOptions
{
    public const string SectionName = "ExternalServices:QrPaymentService";
    public string BaseUrl { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 15;
}
