using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using SportAffiliation.Application.Common.Interfaces;

namespace SportAffiliation.Infrastructure.ExternalServices.QrCode;

public class QrPaymentService : IQrPaymentService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<QrPaymentService> _logger;

    public QrPaymentService(
        HttpClient httpClient,
        ILogger<QrPaymentService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<QrGenerationResult> GenerateQrAsync(
        Guid affiliationId,
        string beneficiaryName,
        decimal amount,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var request = new
            {
                ExternalReference = affiliationId.ToString(),
                BeneficiaryName = beneficiaryName,
                Amount = amount,
                Currency = "USD",
                Description = $"Sports Insurance - {beneficiaryName}",
                ExpirationMinutes = 1440  // 24 hours
            };

            var response = await _httpClient.PostAsJsonAsync(
                "api/qr/generate", request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning(
                    "QR service returned {StatusCode} for AffiliationId: {AffiliationId}",
                    response.StatusCode, affiliationId);
                return new QrGenerationResult(Success: false, ServiceAvailable: true);
            }

            var result = await response.Content
                .ReadFromJsonAsync<QrGenerationApiResponse>(cancellationToken: cancellationToken);

            if (result is null || string.IsNullOrEmpty(result.QrUrl))
                return new QrGenerationResult(Success: false, ServiceAvailable: true);

            return new QrGenerationResult(
                Success: true,
                ServiceAvailable: true,
                QrCodeUrl: result.QrUrl,
                PaymentReference: result.PaymentReference);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "QR payment service is unavailable.");
            return new QrGenerationResult(Success: false, ServiceAvailable: false);
        }
        catch (TaskCanceledException ex) when (!cancellationToken.IsCancellationRequested)
        {
            _logger.LogError(ex, "QR payment service request timed out.");
            return new QrGenerationResult(Success: false, ServiceAvailable: false);
        }
    }

    private sealed record QrGenerationApiResponse(string QrUrl, string PaymentReference);
}
