using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SportAffiliation.Application.Common.Interfaces;
using SportAffiliation.Infrastructure.Configuration;

namespace SportAffiliation.Infrastructure.ExternalServices.Identity;

public class IdentityValidationService : IIdentityValidationService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<IdentityValidationService> _logger;

    public IdentityValidationService(
        HttpClient httpClient,
        ILogger<IdentityValidationService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    public async Task<IdentityValidationResult> ValidateAsync(
        string nationalId,
        string fullName,
        DateOnly birthDate,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var request = new
            {
                NationalId = nationalId,
                FullName = fullName,
                BirthDate = birthDate.ToString("yyyy-MM-dd")
            };

            var response = await _httpClient.PostAsJsonAsync(
                "api/identity/validate", request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning(
                    "Identity service returned {StatusCode} for NationalId: {NationalId}",
                    response.StatusCode, nationalId);
                return new IdentityValidationResult(IsValid: false, ServiceAvailable: true);
            }

            var result = await response.Content
                .ReadFromJsonAsync<IdentityValidationApiResponse>(cancellationToken: cancellationToken);

            return new IdentityValidationResult(
                IsValid: result?.IsValid ?? false,
                ServiceAvailable: true,
                ValidatedFullName: result?.RegisteredName);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Identity service is unavailable.");
            return new IdentityValidationResult(IsValid: false, ServiceAvailable: false);
        }
        catch (TaskCanceledException ex) when (!cancellationToken.IsCancellationRequested)
        {
            _logger.LogError(ex, "Identity service request timed out.");
            return new IdentityValidationResult(IsValid: false, ServiceAvailable: false);
        }
    }

    private sealed record IdentityValidationApiResponse(bool IsValid, string? RegisteredName);
}
