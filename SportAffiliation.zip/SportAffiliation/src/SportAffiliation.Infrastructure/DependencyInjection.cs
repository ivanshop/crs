using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using SportAffiliation.Application.Common.Interfaces;
using SportAffiliation.Domain.Interfaces;
using SportAffiliation.Infrastructure.Configuration;
using SportAffiliation.Infrastructure.ExternalServices.Identity;
using SportAffiliation.Infrastructure.ExternalServices.QrCode;
using SportAffiliation.Infrastructure.Persistence.Repositories;

namespace SportAffiliation.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Repository (singleton for in-memory; use Scoped for EF Core)
        services.AddSingleton<IAffiliationRepository, InMemoryAffiliationRepository>();

        // Bind options
        services.Configure<IdentityServiceOptions>(
            configuration.GetSection(IdentityServiceOptions.SectionName));
        services.Configure<QrPaymentServiceOptions>(
            configuration.GetSection(QrPaymentServiceOptions.SectionName));

        // Typed HttpClient - Identity Service with retry policy
        services.AddHttpClient<IIdentityValidationService, IdentityValidationService>((sp, client) =>
        {
            var opts = configuration
                .GetSection(IdentityServiceOptions.SectionName)
                .Get<IdentityServiceOptions>()!;
            client.BaseAddress = new Uri(opts.BaseUrl);
            client.Timeout = TimeSpan.FromSeconds(opts.TimeoutSeconds);
            client.DefaultRequestHeaders.Add("X-Api-Key", opts.ApiKey);
        })
        .AddTransientHttpErrorPolicy(policy =>
            policy.WaitAndRetryAsync(
                retryCount: 2,
                sleepDurationProvider: attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt))));

        // Typed HttpClient - QR Payment Service with retry policy
        services.AddHttpClient<IQrPaymentService, QrPaymentService>((sp, client) =>
        {
            var opts = configuration
                .GetSection(QrPaymentServiceOptions.SectionName)
                .Get<QrPaymentServiceOptions>()!;
            client.BaseAddress = new Uri(opts.BaseUrl);
            client.Timeout = TimeSpan.FromSeconds(opts.TimeoutSeconds);
            client.DefaultRequestHeaders.Add("X-Api-Key", opts.ApiKey);
        })
        .AddTransientHttpErrorPolicy(policy =>
            policy.WaitAndRetryAsync(
                retryCount: 2,
                sleepDurationProvider: attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt))));

        return services;
    }
}
