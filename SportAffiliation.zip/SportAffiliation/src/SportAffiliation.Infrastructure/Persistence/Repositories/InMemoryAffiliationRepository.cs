using System.Collections.Concurrent;
using SportAffiliation.Domain.Entities;
using SportAffiliation.Domain.Interfaces;

namespace SportAffiliation.Infrastructure.Persistence.Repositories;

/// <summary>
/// Thread-safe in-memory repository. Replace with EF Core / Dapper for production.
/// </summary>
public class InMemoryAffiliationRepository : IAffiliationRepository
{
    private readonly ConcurrentDictionary<Guid, Affiliation> _store = new();

    public Task<Affiliation?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        _store.TryGetValue(id, out var affiliation);
        return Task.FromResult(affiliation);
    }

    public Task<Affiliation?> GetByNationalIdAndSportAsync(
        string nationalId, int sport, CancellationToken cancellationToken = default)
    {
        var affiliation = _store.Values
            .FirstOrDefault(a => a.NationalId == nationalId && (int)a.Sport == sport);
        return Task.FromResult(affiliation);
    }

    public Task<IReadOnlyList<Affiliation>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyList<Affiliation> list = _store.Values.ToList().AsReadOnly();
        return Task.FromResult(list);
    }

    public Task AddAsync(Affiliation affiliation, CancellationToken cancellationToken = default)
    {
        _store[affiliation.Id] = affiliation;
        return Task.CompletedTask;
    }

    public Task UpdateAsync(Affiliation affiliation, CancellationToken cancellationToken = default)
    {
        _store[affiliation.Id] = affiliation;
        return Task.CompletedTask;
    }
}
