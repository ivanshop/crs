# Persistence Layer

## Current: In-Memory Repository

`InMemoryAffiliationRepository` uses `ConcurrentDictionary<Guid, Affiliation>` 
for thread-safe storage during the process lifetime. 
**Data is lost on restart** - suitable for development/demo only.

## Upgrading to EF Core (Production)

1. Add NuGet packages:
   ```
   Microsoft.EntityFrameworkCore.SqlServer (or Npgsql.EntityFrameworkCore.PostgreSQL)
   Microsoft.EntityFrameworkCore.Tools
   ```

2. Create `AppDbContext`:
   ```csharp
   public class AppDbContext : DbContext
   {
       public DbSet<Affiliation> Affiliations => Set<Affiliation>();

       protected override void OnModelCreating(ModelBuilder modelBuilder)
       {
           modelBuilder.Entity<Affiliation>(entity =>
           {
               entity.HasKey(e => e.Id);
               entity.Property(e => e.NationalId).HasMaxLength(20).IsRequired();
               entity.Property(e => e.InsurancePremium).HasColumnType("decimal(18,2)");
               entity.HasIndex(e => new { e.NationalId, e.Sport });
           });
       }
   }
   ```

3. Implement `EfCoreAffiliationRepository` implementing `IAffiliationRepository`.

4. Register in `DependencyInjection.cs`:
   ```csharp
   services.AddDbContext<AppDbContext>(opts =>
       opts.UseSqlServer(configuration.GetConnectionString("Default")));
   services.AddScoped<IAffiliationRepository, EfCoreAffiliationRepository>();
   ```
