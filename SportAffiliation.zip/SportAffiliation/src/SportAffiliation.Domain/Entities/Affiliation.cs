using SportAffiliation.Domain.Enums;

namespace SportAffiliation.Domain.Entities;

public class Affiliation
{
    public Guid Id { get; private set; }
    public string NationalId { get; private set; } = string.Empty;
    public string FullName { get; private set; } = string.Empty;
    public DateOnly BirthDate { get; private set; }
    public int Age => CalculateAge();
    public Sport Sport { get; private set; }
    public AffiliationStatus Status { get; private set; }
    public string? QrCodeUrl { get; private set; }
    public string? PaymentReference { get; private set; }
    public decimal InsurancePremium { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime UpdatedAt { get; private set; }
    public DateTime? AffiliatedAt { get; private set; }

    private Affiliation() { }

    public static Affiliation Create(
        string nationalId,
        string fullName,
        DateOnly birthDate,
        Sport sport,
        decimal insurancePremium)
    {
        return new Affiliation
        {
            Id = Guid.NewGuid(),
            NationalId = nationalId,
            FullName = fullName,
            BirthDate = birthDate,
            Sport = sport,
            InsurancePremium = insurancePremium,
            Status = AffiliationStatus.PendingIdentityValidation,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
    }

    public void MarkIdentityValidated()
    {
        Status = AffiliationStatus.PendingPayment;
        UpdatedAt = DateTime.UtcNow;
    }

    public void AssignQrPayment(string qrCodeUrl, string paymentReference)
    {
        QrCodeUrl = qrCodeUrl;
        PaymentReference = paymentReference;
        UpdatedAt = DateTime.UtcNow;
    }

    public void ConfirmPayment()
    {
        Status = AffiliationStatus.PaymentConfirmed;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Complete()
    {
        Status = AffiliationStatus.Affiliated;
        AffiliatedAt = DateTime.UtcNow;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Reject()
    {
        Status = AffiliationStatus.Rejected;
        UpdatedAt = DateTime.UtcNow;
    }

    private int CalculateAge()
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var age = today.Year - BirthDate.Year;
        if (BirthDate > today.AddYears(-age)) age--;
        return age;
    }
}
