using SportAffiliation.Domain.Entities;

namespace SportAffiliation.Domain.Interfaces;

public interface IAffiliationRepository
{
    Task<Affiliation?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task<Affiliation?> GetByNationalIdAndSportAsync(string nationalId, int sport, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<Affiliation>> GetAllAsync(CancellationToken cancellationToken = default);
    Task AddAsync(Affiliation affiliation, CancellationToken cancellationToken = default);
    Task UpdateAsync(Affiliation affiliation, CancellationToken cancellationToken = default);
}
