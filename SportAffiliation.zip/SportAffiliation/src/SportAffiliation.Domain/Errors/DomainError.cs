namespace SportAffiliation.Domain.Errors;

public sealed record DomainError(string Code, string Description)
{
    public static readonly DomainError None = new(string.Empty, string.Empty);

    // Identity errors
    public static readonly DomainError IdentityNotFound =
        new("Identity.NotFound", "The person's identity could not be found in the registry.");

    public static readonly DomainError IdentityValidationFailed =
        new("Identity.ValidationFailed", "Identity validation failed. The provided data does not match our records.");

    public static readonly DomainError IdentityServiceUnavailable =
        new("Identity.ServiceUnavailable", "The identity validation service is temporarily unavailable.");

    // Affiliation business rule errors
    public static readonly DomainError AgeNotEligible =
        new("Affiliation.AgeNotEligible", "The person's age is not eligible for the requested sports insurance. Must be between 5 and 70 years old.");

    public static readonly DomainError SportNotSupported =
        new("Affiliation.SportNotSupported", "The requested sport is not currently covered by our insurance.");

    public static readonly DomainError AlreadyAffiliated =
        new("Affiliation.AlreadyAffiliated", "This person already has an active affiliation for the requested sport.");

    public static readonly DomainError AffiliationNotFound =
        new("Affiliation.NotFound", "No affiliation record was found with the provided identifier.");

    public static readonly DomainError InvalidStatusTransition =
        new("Affiliation.InvalidStatusTransition", "The affiliation cannot be updated in its current status.");

    // Payment errors
    public static readonly DomainError QrGenerationFailed =
        new("Payment.QrGenerationFailed", "Could not generate the QR code for payment. Please try again.");

    public static readonly DomainError PaymentServiceUnavailable =
        new("Payment.ServiceUnavailable", "The payment service is temporarily unavailable.");

    public static readonly DomainError PaymentAlreadyConfirmed =
        new("Payment.AlreadyConfirmed", "The payment for this affiliation has already been confirmed.");
}
