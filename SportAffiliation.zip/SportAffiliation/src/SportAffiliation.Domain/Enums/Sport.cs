namespace SportAffiliation.Domain.Enums;

public enum Sport
{
    Football = 1,
    Basketball = 2,
    Tennis = 3,
    Swimming = 4,
    Cycling = 5,
    Athletics = 6,
    Boxing = 7,
    MartialArts = 8
}
