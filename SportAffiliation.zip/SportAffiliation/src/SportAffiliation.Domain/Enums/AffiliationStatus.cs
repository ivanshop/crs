namespace SportAffiliation.Domain.Enums;

public enum AffiliationStatus
{
    PendingIdentityValidation = 1,
    PendingPayment = 2,
    PaymentConfirmed = 3,
    Affiliated = 4,
    Rejected = 5
}
