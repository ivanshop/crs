# Sports Insurance Affiliation API

.NET 10 Minimal API following **Clean Architecture** principles.

## Solution Structure

```
SportAffiliation/
├── src/
│   ├── SportAffiliation.Domain/          # Enterprise business rules
│   │   ├── Entities/                     # Affiliation (rich domain entity)
│   │   ├── Enums/                        # AffiliationStatus, Sport
│   │   ├── Errors/                       # DomainError catalogue
│   │   └── Interfaces/                   # IAffiliationRepository
│   │
│   ├── SportAffiliation.Application/     # Use cases / orchestration
│   │   ├── Affiliations/
│   │   │   ├── AffiliationService.cs     # Core flow orchestrator
│   │   │   ├── Commands/                 # DTOs (Commands + Responses)
│   │   │   └── Validators/              # FluentValidation rules
│   │   └── Common/
│   │       ├── Interfaces/               # IIdentityValidationService, IQrPaymentService
│   │       └── Models/                  # Result<T> pattern
│   │
│   ├── SportAffiliation.Infrastructure/  # External concerns
│   │   ├── ExternalServices/
│   │   │   ├── Identity/                # Typed HttpClient → identity registry
│   │   │   └── QrCode/                  # Typed HttpClient → QR payment provider
│   │   └── Persistence/
│   │       └── Repositories/            # InMemoryAffiliationRepository
│   │
│   └── SportAffiliation.Api/             # HTTP layer
│       ├── Controllers/                  # Minimal API endpoint groups
│       ├── Filters/                      # ValidationFilter<T>
│       ├── Middleware/                   # Global exception handler
│       └── Extensions/                  # ProblemDetails mapping, Serilog
```

## Affiliation Flow

```
POST /api/affiliations
        │
        ▼
[ValidationFilter] ──FAIL──► 400 ProblemDetails (FluentValidation errors)
        │ OK
        ▼
[Duplicate check] ──EXISTS──► 409 ProblemDetails (AlreadyAffiliated)
        │ NEW
        ▼
[Identity Service] ──DOWN──► 503 ProblemDetails (ServiceUnavailable)
        │         └─INVALID─► 422 ProblemDetails (IdentityValidationFailed)
        │ VALID
        ▼
[Create Affiliation record] → status: PendingPayment
        │
        ▼
[QR Payment Service] ──DOWN──► 503 ProblemDetails
        │            └─FAIL──► 500 ProblemDetails (QrGenerationFailed)
        │ OK
        ▼
[Update Affiliation: QrCodeUrl + PaymentReference]
        │
        ▼
201 Created → { affiliationId, qrCodeUrl, ... }


POST /api/webhooks/payments/confirm   ← called by financial institution
        │
        ▼
[Find affiliation by ID] ──NOT FOUND──► 404 ProblemDetails
        │
        ▼
[Status guard] ──ALREADY DONE──► 409 ProblemDetails
        │       └─WRONG STATUS──► 409 ProblemDetails
        │ OK
        ▼
[Affiliation.ConfirmPayment() → Complete()]
        │
        ▼
204 No Content
```

## HTTP Response Codes

| Scenario                          | Status |
|-----------------------------------|--------|
| Affiliation created + QR ready    | 201    |
| Get affiliation                   | 200    |
| Payment confirmed                 | 204    |
| Validation error                  | 400    |
| Affiliation not found             | 404    |
| Already affiliated / duplicate    | 409    |
| Identity invalid / not found      | 422    |
| External service unavailable      | 503    |
| Unexpected error                  | 500    |

All error responses follow **RFC 7807 ProblemDetails** format:
```json
{
  "type": "https://tools.ietf.org/html/rfc9110#section-15.5.1",
  "title": "Identity Validation Failed",
  "status": 422,
  "detail": "The provided data does not match our records.",
  "instance": "/api/affiliations",
  "errorCode": "Identity.ValidationFailed",
  "traceId": "0HN..."
}
```

## Running Locally

```bash
cd src/SportAffiliation.Api
dotnet run
```

Swagger/Scalar UI: https://localhost:7xxx/scalar/v1

## Configuration

`appsettings.json`:
```json
{
  "ExternalServices": {
    "IdentityService": {
      "BaseUrl": "https://your-identity-service.com/",
      "ApiKey": "...",
      "TimeoutSeconds": 10
    },
    "QrPaymentService": {
      "BaseUrl": "https://your-qr-provider.com/",
      "ApiKey": "...",
      "TimeoutSeconds": 15
    }
  }
}
```

## Key Design Decisions

- **Result\<T\> pattern** — no exceptions for expected business failures; errors flow as values.
- **Typed HttpClients** with Polly retry (exponential backoff, 2 retries).
- **ValidationFilter\<T\>** — FluentValidation runs as an endpoint filter before the handler.
- **ProblemDetailsExtensions** — single place that maps `DomainError` → HTTP status + RFC type.
- **InMemoryRepository** — swap for EF Core/Dapper with zero Application layer changes.
- **Serilog** — structured logging with request enrichment; JSON sink for production.
